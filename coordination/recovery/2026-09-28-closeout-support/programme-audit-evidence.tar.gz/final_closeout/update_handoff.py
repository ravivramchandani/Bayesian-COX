from pathlib import Path
import json, shutil
root=Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
base=Path('/Users/macuser/bayes-cox-runs'); close=base/'final-closeout-20260927'
for name in ('github-published-release.json','github-published-audit-release.json'):
    assert not json.loads((close/name).read_text())['isDraft']
assert json.loads((close/'student-restore-verification.json').read_text())['status']=='fresh_clone_remote_restore_verified'
def edit(path,changes):
    p=root/path;s=p.read_text()
    for old,new in changes:
        assert s.count(old)==1,(path,old[:60]);s=s.replace(old,new)
    p.write_text(s)
def section(s,start,end,new):
    a=s.index(start);b=s.index(end,a);return s[:a]+new+s[b:]
edit('docs/ravi_handoff.md',[
("The final supplementary release is being prepared. Do not treat this guide's\nplanned release URL as available until the final handoff records successful\nremote download and restoration.","All completed evidence is available remotely. Both result releases were\ndownloaded and verified through a fresh clone and fresh restore directories\non this Apple Silicon Mac. Ravi must verify the locked environment on his\nown Mac; a second physical laptop was not tested."),
('There are two evidence releases:','There are three evidence releases:'),
('verified code snapshot, QA and hash inventories. Release preparation is\n  still pending at this draft.','verified code snapshot, QA and hash inventories. All ten assets were\n  downloaded and restored successfully.\n- [Supporting audit evidence](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-audit-20260928):\n  full native PDF review evidence, completed logs, earlier probes and external\n  helpers; all three assets and 899 archive members verified after download.'),
('The numerical programme must reach its final verified release before this\nhandoff is marked complete. Its completed fits do not need to be rerun on\nthe receiving laptop. A new result always goes in a separate directory.','The existing numerical programme is complete and remotely verified. Its fits\ndo not need to be rerun on the receiving laptop. All 428 final PDFs passed\nreview; all nine separate sampler contrasts are estimable, have Holm-adjusted\np-values of 1.0 and corrected intervals containing zero. Read the\n[numerical summary](../coordination/recovery/2026-09-28-numerical-evidence-summary.json)\nand [close-out review](../coordination/reviews/2026-09-28-programme-closeout.md).\nA new result always goes in a separate directory.')])
p=root/'docs/ravi_handoff.md';s=p.read_text();s=s.replace('## Continue from the existing evidence', '''## Optional audit archive

The supporting archive is separate from the ten-asset result bundle. Restore
it when inspecting the native visual review, historical probes or logs:

```bash
RAVI_AUDIT_ASSETS="$RAVI_REPO/../ravi-audit-assets-20260928"
RAVI_AUDIT="$RAVI_REPO/../ravi-audit-evidence-20260928"
gh release download results-programme-audit-20260928 \\
  --repo ravivramchandani/Bayesian-COX --dir "$RAVI_AUDIT_ASSETS"
(cd "$RAVI_AUDIT_ASSETS" && shasum -a 256 -c SHA256SUMS)
mkdir "$RAVI_AUDIT"
tar -xzf "$RAVI_AUDIT_ASSETS/programme-audit-evidence.tar.gz" -C "$RAVI_AUDIT"
```

`programme-audit-manifest.json` records every member hash and size. Historical
logs and PID files describe earlier states; use the current HANDOFF for what
to run next. The final QA status is passed; earlier pending or format-rejected
records are retained for provenance.

## Continue from the existing evidence''');p.write_text(s)
p=root/'README.md';s=p.read_text()
s=section(s,'available. Robustness production is running','## Models','''available. Explanation production completed but failed its convergence
gate, so it permits no explanation-stability claim.

The refactors and complete code/results programme are verified. All 450
reproduction cells match outside recorded timing/hash fields. Robustness
retains 770 diagnostic passes and 55 failures across all 825 cells. The
separate post-hoc sampler sensitivity has 75 diagnostic passes; all nine
contrasts have Holm-adjusted p-values of 1.0 and corrected intervals including
zero. Both final rendered lineages and all 428 PDFs passed verification and
review. Original failed cells and incomplete primary inference are unchanged.

All completed results, exact code, tables, figures and audit records are in
private GitHub Releases and have been downloaded and restored independently.
New extension experiments remain planned. Overleaf edits and paper submission
are outside this completed code/results handoff.

## Start here — Ravi's handoff

Follow [Ravi's restore and continuation guide](docs/ravi_handoff.md) for a
fresh Apple Silicon Mac: exact environment, private-repository access,
checksummed downloads, restoration and next tasks.

- [Original 450-cell evidence](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/confirmatory-v1-44b6085)
- [Verified code/results programme](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-20260927-11f86ce)
- [Full audit evidence and logs](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-audit-20260928)

A Git clone contains current code, data manifests, plans and guides. Large
results are release assets in the same private repository. Restoration
verifies hashes and preserves immutable evidence; it does not fit models.
No files from the original laptop are required.

''')
s=s.replace('Frozen robustness production remains\nin its original unchanged worktree; refactored-code reproduction writes to\nseparate output directories.','Frozen robustness production completed in its unchanged worktree;\nrefactored-code reproduction completed in a separate output directory.')
s=section(s,'`scripts/complete_results_programme.py` coordinates','The full regeneration is verification-only.','''`scripts/complete_results_programme.py` completed the sealed programme from
commit `11f86ced8735b32767debb58f3cbbefbb5a7b8e6`: 450 reproduction cells,
frozen 825-cell robustness verification, the separate 75-cell sampler
sensitivity and both rendered bundles. All numerical stages and the
coordinator exited successfully. No restart is needed. Restore the released
evidence through Ravi's guide instead of using historical host PIDs.

''')
s=s.replace('After the generated bundles pass final visual QA, a `release_ready` seal','The generated bundles passed final visual QA. A `release_ready` seal')
s=s.replace('- Robustness production is running under the frozen code; final aggregation\n  and verification remain outstanding. Confirmatory explanation production','- Robustness production, aggregation and review completed: 825 cells, 770\n  diagnostic passes and 55 failures. Direct effects have 121/129 estimates\n  and 95/129 fully paired rows; difference-in-differences has 45 estimates\n  and 33 fully paired rows. Partial and unavailable estimates stay explicit.\n  Confirmatory explanation production')
s=s.replace('failed, so no RQ3 claim is permitted. Primary claim review and thesis writing\n  remain unfinished; Overleaf edits are excluded from the current programme.','failed, so no RQ3 claim is permitted. Code/results claim review is complete;\n  thesis wording and supervisor sign-off are later tasks. Overleaf edits\n  remain excluded from the current programme.')
p.write_text(s)
p=root/'coordination/HANDOFF.md';s=p.read_text();old='## Current checkpoint — numerical cells complete; final close-out pending';assert s.count(old)==1
s=s.replace(old,'''## Current state — verified programme released; Ravi can restore it

The completed programme is remotely available and independently restored.
Follow [Ravi's handoff](../docs/ravi_handoff.md), rather than historical PID
or reboot instructions below. No numerical process needs restart.

- Exact reproduction: 450/450 matches from sealed commit
  `11f86ced8735b32767debb58f3cbbefbb5a7b8e6`; all 90 code hashes match.
- Frozen robustness: 825 verified cells, 770 diagnostic passes and 55
  failures. Direct effects have 121/129 estimates and 95/129 fully paired
  rows; difference-in-differences has 45/45 estimates, 33 fully paired.
- Separate post-hoc sampler sensitivity: 75/75 diagnostic passes, nine
  estimable contrasts, all Holm-adjusted p-values 1.0 and all corrected
  intervals including zero.
- Both rendered lineages and all 428 PDFs/pages passed. The passed V3 review
  supports 426 exact PDF hashes; two new PDFs were actually inspected.
- The unchanged original source is in release `confirmatory-v1-44b6085`.
  New results and sealed code: [results-programme-20260927-11f86ce](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-20260927-11f86ce),
  exactly ten downloaded/verified assets, restored through a fresh clone.
- Native QA evidence, probes, complete logs and external helpers:
  [results-programme-audit-20260928](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-audit-20260928),
  three downloaded assets and all 899 archive members verified.

Compact evidence is in `coordination/recovery/2026-09-28-programme-closeout.json`
and `2026-09-28-numerical-evidence-summary.json`; the factual review is
`coordination/reviews/2026-09-28-programme-closeout.md`. Restoration was tested
on this Apple Silicon Mac with the existing verified lock, not on a second
physical laptop. The receiving Mac must verify its environment.

Original 20 horseshoe failures, incomplete primary inference and the failed
explanation gate remain findings. T-180 and the new extensions have not
started. The separate documentation-only pass is tracked in step 12.
Overleaf edits and paper/DOI work remain excluded.

## Earlier numerical checkpoint — before final close-out''',1)
s=section(s,'- **Current state: core programme running; planning updates authorised.**','At 10:01 UTC', '''- **Current state: core code/results programme complete and remotely verified.**
  - The latest owner instruction requests everything Ravi needs on GitHub.
    Evidence, full QA/log audit, restore guide and current plans are released.
  - The coordinator and numerical stages exited successfully. Do not launch
    a duplicate coordinator, robustness finisher or sampler run.
  - New ADR-035 analyses and the ADR-038 catalytic arm remain planned.
    T-180's actual addendum/freeze must precede their own results.
  - The documentation-only pass is tracked in step 12; its worktree edits
    are separate from the sealed numerical code identity.

''')
s=s.replace('Computational production is complete; task acceptance and scientific\n     claims still require the coverage/interpretation review in T-140–T-144.','Production and coverage/interpretation review are complete; T-140–T-144\n     record actual partial coverage and negative claim gates.')
s=s.replace('A final bundle incorporating completed robustness remains required.','The final completed-robustness and post-hoc bundles passed all 428 PDFs;\n   see the 2026-09-28 close-out review.')
s=section(s,'8. [ ] Complete the labelled','11. [ ]', '''8. [x] Complete the labelled post-hoc horseshoe sensitivity under ADR-032.
   All 75 cells and attempts verify and pass diagnostics. All nine contrasts
   are estimable, all adjusted p-values are 1.0 and all corrected intervals
   include zero. Separate rendering passed lineage verification and PDF review.
9. [x] Finalise documentation and evidence packaging. Strict numerical summary,
   coverage/claim review, actual visual QA and the seven-root seal are complete.
   Local and fresh remote restorations verified every archive member hash;
   two new private releases preserve results and full audit support.
10. [x] Commit and push verified evidence and Ravi's handoff. The final
    close-out is recorded in the dated review and compact receipt.

''')
s=s.replace('The four new analyses are not part of the running coordinator.','The new analyses were not part of the completed coordinator.')
s=s.replace('T-181 is the same sensitivity as step 8, already queued after robustness\n      and independent of T-180; do not run it twice;','T-181 is the completed sensitivity in step 8, independent of T-180;\n      do not run it twice;')
s=section(s,'`scripts/complete_results_programme.py` is the automatic continuation entry','Administrative deadline:', '''`scripts/complete_results_programme.py` completed from immutable checkout
`~/bayes-cox-runs/refactored-programme-20260927/`, with output in
`~/bayes-cox-runs/continuation-20260927/`. All 90 code hashes and original
explanation bytes remain sealed. Coordinator PID 3374, supervisor 3372,
workers and caffeinate exited. Its verified-analysis record was followed by
actual visual QA, claim review and private release verification. Historical
logs and host paths are in the audit release. The student restore guide
requires neither these host paths nor another run of the completed fits.

''')
p.write_text(s)
p=root/'coordination/TODO.md';s=p.read_text()
s=section(s,'code hashes still match. All 75','Original explanation production', '''code hashes still match. ADR-032 completed 75 sensitivity cells and its
nine-contrast inference, with all diagnostics passing, all adjusted p-values
1.0 and all corrected intervals including zero. Both final rendered lineages,
all 428 PDFs, coverage/claim review, packaging and local/fresh remote restore
passed. Completed results and full QA/log audit are in two new private
releases. Ravi's commands are in `docs/ravi_handoff.md`; completed fits need
no rerun. Final receipt: `coordination/recovery/2026-09-28-programme-closeout.json`.
''')
s=section(s,'T-132 is complete and verified. The 2026-09-27 instruction','- [ ] T-140', '''T-132 is complete and verified. T-140–T-144 production and evidence review
are complete. The summary and rendered tables retain diagnostic exclusions,
incomplete pairing, unavailable estimates and the failed explanation gate.
Completing these tasks does not establish general robustness, H2 support
or explanation stability.

''')
for n in (140,141,142,143,144,181):s=s.replace(f'- [ ] T-{n}',f'- [x] T-{n}',1)
s=s.replace('verify; comparison coverage and claim review remain outstanding.','verify. Design effects: 39/45 estimates, 31/45 fully paired. Report\n  intervals and attrition; no favourable configuration selected.')
s=s.replace('The completed frozen run and aggregates verify; accepted/expected paired\n  coverage, intervals and H2 interpretation still require claim review.','The frozen run verifies. All 54 RQ2 direct rows have estimates, 42 fully\n  paired; all 45 difference-in-differences rows have estimates, 33 fully\n  paired. Intervals include both signs; no uniform H2 support or invented\n  robustness p-value is claimed.')
s=s.replace('exclusion/coverage and interpretation review remain outstanding.','feature effects have 28/30 estimates and 22/30 fully paired rows.\n  Imputation averages predictions rather than forming a single posterior\n  propagating covariate-imputation uncertainty; partial rows remain explicit.')
s=s.replace('The completed assessment and aggregate hashes verify; PH findings and\n  their permitted interpretation remain to be reviewed.','The assessment verifies. METABRIC age and NPI reject within-fit Holm\n  in all 25 outer fits; other findings are in the summary. Dependent-fit\n  frequencies are descriptive and limit PH interpretation; no replacement\n  model was fitted.')
s=s.replace('Inference/completion and rendering were pending at the numerical checkpoint.\n  Independent of T-180; do not launch a duplicate sensitivity or finisher.','Inference/completion and separate rendering now verify. All nine contrasts\n  are estimable; all adjusted p-values are 1.0 and corrected intervals include\n  zero. Final PDF QA passed. Independent of T-180; no duplicate run needed.')
s=s.replace('remain unchecked until their actual completed evidence satisfies the gates.','are complete where actual evidence satisfies their acceptance criteria.\n  Historical restart counts are superseded by final close-out above.')
p.write_text(s)
edit('docs/current_evidence_status.md', [('Coverage and scientific claim review remain pending. | Report the completed grid and attrition; inferential claims require actual comparison coverage and intervals.','Coverage and review are complete: 121/129 direct estimates (95 fully paired); 45/45 difference-in-differences estimates (33 fully paired). | Report intervals and attrition; grid completion alone does not establish general robustness.')])
p=root/'docs/current_evidence_status.md';s=p.read_text()
s=section(s,'All 75 ADR-032 cells','ADR-036/ADR-037', '''All 75 ADR-032 cells, completion and separate inference are verified. All
pass diagnostics; all nine contrasts are estimable, all Holm-adjusted
p-values are 1.0 and every corrected interval includes zero. This post-hoc
finding cannot replace primary evidence or establish equivalence.

The robustness review retains 95 fully paired, 26 partially paired and eight
unavailable direct effects. All 45 difference-in-differences rows have
estimates, 33 fully paired and 12 partial. No robustness p-values are stored
or inferred. The five-imputation sensitivity averages predictions, rather
than forming a single posterior propagating imputation uncertainty.
Within-fit Holm PH tests identify repeated METABRIC age/NPI violations;
outer-fit frequencies are descriptive and no time-varying replacement model
was introduced. Full intervals and accepted/planned counts are in the
[numerical summary](../coordination/recovery/2026-09-28-numerical-evidence-summary.json)
and released tables.

Both rendered lineages and all 428 PDFs passed verification and review.
The private result and supporting-audit releases were downloaded and verified;
a fresh clone restored original and supplementary evidence without copying
original-host result files. See [Ravi's handoff](ravi_handoff.md) and the
[close-out review](../coordination/reviews/2026-09-28-programme-closeout.md).
The earlier numerical checkpoint is preserved unchanged as historical state.

''');p.write_text(s)
p=root/'coordination/reviews/2026-09-27-cross-laptop-continuation.md';s=p.read_text();first,rest=s.split('\n',1)
p.write_text(first+'''\n
Superseded on 2026-09-28 by [Ravi's completed-results restore guide](../../docs/ravi_handoff.md).
All numerical stages completed and their verified evidence is in private
GitHub Releases. Partial-run transfer/restart instructions below are historical;
no partial transfer or restart is now needed.
'''+rest)
for source,name in [(close/'numerical_evidence_summary.json','2026-09-28-numerical-evidence-summary.json'),(close/'claim_review.json','2026-09-28-claim-review.json'),(close/'packaging-path-correction.json','2026-09-28-packaging-path-correction.json')]:
    target=root/'coordination/recovery'/name;assert not target.exists();shutil.copyfile(source,target)
print('Updated handoff, README, TODO and evidence status; copied compact records.')
