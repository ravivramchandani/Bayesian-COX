import datetime, hashlib, json, subprocess
from pathlib import Path
base=Path('/Users/macuser/bayes-cox-runs');close=base/'final-closeout-20260927'
repo=Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def load(path):return json.loads(path.read_text())
programme=load(close/'github-published-release.json');audit=load(close/'github-published-audit-release.json')
student=load(close/'student-restore-verification.json');audit_receipt=load(close/'audit-download-verification.json')
assert not programme['isDraft'] and not audit['isDraft']
assert student['status']=='fresh_clone_remote_restore_verified'
qa_path=base/'final-pdf-qa-20260927/programme_visual_qa.json';qa=load(qa_path);assert qa['status']=='passed'
summary=load(close/'numerical_evidence_summary.json')
record={'status':'completed_code_results_programme_remote_handoff_verified','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_commit':'11f86ced8735b32767debb58f3cbbefbb5a7b8e6','exact_runtime':{'python':'3.11.15','platform':'macOS arm64','locked_packages':259,'lock_sha256':'1921895d4a404fc99e848d69ccd4a3f6639a3d1610315c82ecd463ed4bcdfb57'},'numerical_summary_content_sha256':summary['summary_content_sha256'],'analysis_verification_sha256':sha(base/'continuation-20260927/programme_analysis_verified.json'),'release_ready_seal_sha256':sha(close/'programme_release_ready-v2.json'),'visual_qa':{'status':qa['status'],'sha256':sha(qa_path),'pdf_count':qa['pdf_count'],'page_count':qa['page_count'],'exact_hash_reused_pdf_count':qa['exact_hash_reused_pdf_count'],'new_or_changed_pdf_count':qa['new_or_changed_pdf_count'],'pending_actual_visual_review_pdf_count':qa['pending_actual_visual_review_pdf_count'],'failed_pdf_count':qa['failed_pdf_count'],'manual_review_file':qa['manual_review_file']},'original_release':{'tag':'confirmatory-v1-44b6085','url':'https://github.com/ravivramchandani/Bayesian-COX/releases/tag/confirmatory-v1-44b6085','unchanged_archive_sha256':'0dbb745b82e5998b5aabc4bb3f05b28f87e00ba2851101a8accb83d447ddf34b','completion_content_sha256':'03870efdae3134305794ea977fd9cbe7913c0d693f1b009337546319aa03bee1'},'supplementary_release':{'tag':programme['tagName'],'url':programme['url'],'published_at':programme['publishedAt'],'target_commit':programme['targetCommitish'],'assets':[{'name':a['name'],'bytes':a['size'],'api_url':a['apiUrl']} for a in programme['assets']],'remote_verification':student},'audit_release':{'tag':audit['tagName'],'url':audit['url'],'published_at':audit['publishedAt'],'target_commit':audit['targetCommitish'],'assets':[{'name':a['name'],'bytes':a['size'],'api_url':a['apiUrl']} for a in audit['assets']],'remote_verification':audit_receipt},'scientific_boundaries':{'original_failed_cells_preserved':20,'original_primary_contrasts_estimable':5,'original_primary_contrasts_planned':9,'original_explanation_global_claim_permitted':False,'sampler_sensitivity_post_hoc':True,'new_thesis_extensions':'planned; no results yet'},'verification_limits':'Fresh clone and fresh GitHub downloads/restores on current Apple Silicon Mac with existing verified exact environment; second physical laptop not tested','excluded_work':['Overleaf editing','paper submission','DOI minting'],'claim_review_sha256':sha(close/'claim_review.json'),'packaging_path_correction_sha256':sha(close/'packaging-path-correction.json')}
for release in [programme,audit]:
 resolved=subprocess.check_output(['git','rev-parse',release['tagName']+'^{commit}'],cwd=repo,text=True).strip();assert resolved==record['code_commit']
record['resolved_release_tags_verified']=True
content=json.dumps(record,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
record['closeout_content_sha256']=hashlib.sha256(content.encode()).hexdigest()
target=repo/'coordination/recovery/2026-09-28-programme-closeout.json'
with target.open('x') as f:f.write(json.dumps(record,indent=2,sort_keys=True,allow_nan=False)+'\n')
print(target)
