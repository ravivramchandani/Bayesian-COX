Verified private evidence supplement for sealed code `11f86ced8735b32767debb58f3cbbefbb5a7b8e6`.

- 450/450 independent reproduction cells match every non-timing field of the immutable confirmatory source.
- The frozen robustness grid is complete and strictly verified: 825 cells, 770 diagnostic passes and 55 diagnostic failures. Direct comparisons retain 95/129 fully paired rows, 26 partially paired estimates and eight unavailable rows; 33/45 difference-in-differences rows have full pairing, with 12 partial estimates.
- The separate post-hoc target-acceptance 0.999 horseshoe sensitivity has 75/75 diagnostic passes and nine estimable contrasts. All nine Holm-adjusted p-values are 1.0 and all corrected intervals include zero.
- Both rendered lineages passed verification. Final visual QA passed all 428 PDFs/pages: 426 exact hashes reused from the passed full V3 review, plus two newly inspected PDFs.
- Five deterministic archives preserve the complete committed code tree, reproduction, robustness, original explanation and rendered reports, and the separate sampler sensitivity. Metadata and SHA256SUMS accompany the archives.

Restore the immutable original source first from [confirmatory-v1-44b6085](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/confirmatory-v1-44b6085). Then download all ten assets of this release and use `scripts/restore_programme_release.py` with `--release-dir`, `--original-run` and a fresh `--output-dir`. No fitting occurs during restoration. See the latest `docs/ravi_handoff.md` on main for the complete Apple Silicon Mac procedure.

Scientific boundaries: the original 20 horseshoe diagnostic failures, incomplete five-of-nine primary family and failed original explanation-convergence gate remain unchanged. The post-hoc sensitivity cannot replace them. These results do not establish superiority or equivalence. Robustness intervals are descriptive and retain actual accepted/planned paired coverage; no new robustness p-values are asserted. Covariate-imputation sensitivity averages predictions, rather than propagating imputation uncertainty through a single Bayesian posterior.

This is a private reproducibility/evidence release. New thesis extension experiments remain planned; paper submission and DOI minting are deferred. The full native-image review evidence, completed runtime logs and probe chronology are preserved in the separate `results-programme-audit-20260928` release.
