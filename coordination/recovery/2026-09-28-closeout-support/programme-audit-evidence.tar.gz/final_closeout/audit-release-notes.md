Supporting audit evidence for the verified programme at code `11f86ced8735b32767debb58f3cbbefbb5a7b8e6`.

The deterministic archive contains the complete passed V3 PDF review, final visual QA and actual native-image/crop inspection records, earlier horseshoe probes, completed runtime logs, external harness/helper source, strict numerical summary and claim review. Every member is inventoried by SHA-256 and size. It preserves historical failed/revised review records, including a rejected review JSON format that was corrected before the final passed QA; these historical records are not the final QA status.

Download all three assets, verify `SHA256SUMS`, inspect `programme-audit-manifest.json`, then extract the archive into a fresh folder. The manifest names every archive member and records the original host paths for provenance. Some logs contain historical PIDs and unfinished counts; they are dated evidence and must not trigger a restart. The completed result bundle is in [results-programme-20260927-11f86ce](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-20260927-11f86ce). See `docs/ravi_handoff.md` on main.

This release is private code/evidence support, not a paper or DOI publication.
