import json, os, shutil, subprocess, sys
from pathlib import Path

code = Path(os.environ['PROGRAMME_CODE'])
out = Path(os.environ['PROGRAMME_OUTPUT'])
closeout = Path(os.environ['PROGRAMME_CLOSEOUT'])
sys.path.insert(0, str(code))
from scripts.package_programme_release import (
    directory_inventory, read_release_seal, sha256_file, verify_content_hash,
)

def load(path):
    return json.loads(path.read_text())

identity = load(out / 'programme_manifest.json')
commit = os.environ['PROGRAMME_COMMIT']
assert identity['code_commit'] == commit
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=code, text=True).strip() == commit
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=code, text=True).strip()
actual_code = {str(p.relative_to(code)): sha256_file(p)
               for folder in ('src', 'scripts') for p in sorted((code / folder).rglob('*.py'))}
assert actual_code == identity['code_sha256'] and len(actual_code) == 90

report_path = out / 'programme_analysis_verified.json'
report = load(report_path)
verify_content_hash(report, 'result_content_sha256')
assert report['status'] == 'analysis_and_rendering_verified_pending_final_visual_qa'
assert report['code_commit'] == commit and report['reproduction_cells_identical'] == 450
for filename, digest in report['source_file_sha256'].items():
    assert sha256_file(Path(filename)) == digest, filename

summary = load(closeout / 'numerical_evidence_summary.json')
verify_content_hash(summary, 'summary_content_sha256')
assert summary['status'] == 'completed_numerical_evidence_verified_descriptive_summary'
assert summary['code_commit'] == commit and summary['reproduction']['all_450_equal']
assert summary['robustness']['stored_cells'] == 825
assert summary['posthoc_sampler_sensitivity']['stored_cells'] == 75
for filename, digest in summary['source_file_sha256'].items():
    assert sha256_file(Path(filename)) == digest, filename

qa_path = Path(os.environ['PROGRAMME_QA']) / 'programme_visual_qa.json'
qa = load(qa_path)
assert qa['status'] == 'passed'
assert qa['pending_actual_visual_review_pdf_count'] == qa['failed_pdf_count'] == 0
assert qa['all_pages_actually_reviewed_or_exact_hash_reused']
for label, folder in [('confirmatory', 'rendered_confirmatory'), ('posthoc', 'rendered_posthoc_sampler')]:
    root = out / folder
    assert qa['bundles'][label]['root'] == str(root.resolve())
    assert qa['bundles'][label]['lineage_sha256'] == sha256_file(root / 'lineage.json')
for pdf in qa['pdfs']:
    assert sha256_file(Path(pdf['pdf_path'])) == pdf['sha256']
if qa['manual_review_file'] is not None:
    ref = qa['manual_review_file']
    assert sha256_file(Path(ref['path'])) == ref['sha256']

samplers = list((out / 'posthoc_sampler').glob('*/manifest.json'))
assert len(samplers) == 1
explanation = Path(os.environ['PROGRAMME_EXPLANATION'])
assert sha256_file(explanation) == identity['explanation_sha256'] == '120984c7edfac468f471b9f500470623689b2647e4bde56d271cc9623346ecd5'
explanation_root = closeout / 'explanation'
explanation_root.mkdir(exist_ok=False)
shutil.copyfile(explanation, explanation_root / explanation.name)
roots = {
    'original450': Path(identity['source_dir']),
    'reproduction': out / 'reproduction',
    'robustness': Path(identity['robustness_dir']),
    'explanation': explanation_root,
    'rendered_confirmatory': out / 'rendered_confirmatory',
    'sampler_run': samplers[0].parent,
    'rendered_posthoc': out / 'rendered_posthoc_sampler',
}
seal = {
    'status': 'release_ready', 'code_commit': commit, 'code_files': actual_code,
    'verified_report': {'path': str(report_path.resolve()), 'sha256': sha256_file(report_path)},
    'visual_qa': {'status': 'passed', 'path': str(qa_path.resolve()), 'sha256': sha256_file(qa_path)},
    'artifacts': {name: {'root': str(root.resolve()), 'files': directory_inventory(root)}
                  for name, root in roots.items()},
}
seal_path = closeout / 'programme_release_ready.json'
with seal_path.open('x') as handle:
    handle.write(json.dumps(seal, indent=2, sort_keys=True, allow_nan=False) + '\n')
read_release_seal(seal_path)
print(seal_path)
