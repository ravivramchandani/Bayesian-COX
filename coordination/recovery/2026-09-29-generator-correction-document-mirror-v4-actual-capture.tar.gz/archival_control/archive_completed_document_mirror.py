"""Archive completed six-document mirror and its genuine parent captures."""
import importlib.util
import json
from pathlib import Path
BASE=Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
REPO=Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
OLD=Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
HERE=Path(__file__).absolute().parent
spec=importlib.util.spec_from_file_location('_root_archive',BASE/'correction_reporting_release_root_closeout_20260929_v1/preserve_checked_records.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.RECOVERY=REPO/'coordination/recovery'
owner=BASE/'original_checkout_document_mirror_actual_20260929_v4'
parent=BASE/'original_checkout_document_mirror_parent_capture_20260929_v4'
receipt=m.load(owner/'receipt.json')
assert {str(p.relative_to(owner)):m.binding(p) for p in owner.rglob('*') if p.is_file()}=={**receipt['artifacts'],'receipt.json':m.binding(owner/'receipt.json')}
assert m.binding(owner/'mirror_six_published_documents.py')['sha256']=='efa0cfd50bbed798dddf9b9e815c14f91e4328ddfff81cbac09ef7ff4e7e2093'
completed=m.load(owner/'completed.json')
assert completed['remote_verified_main']=='bb92d4c7cf32a8b3ac510e9180bc7f72a0eab9f5' and completed['document_count']==6
assert completed['all_target_bytes_equal_published_main'] and completed['all135_scoped_non_target_files_unchanged']
assert completed['all141_prior_versions_remain_preserved'] and completed['all6_previous_published_document_versions_separately_preserved']
assert completed['selected_shared_git_admin_metadata_before_after_unchanged'] and completed['resident752_implementation_files_unchanged']
assert not completed['old_git_stash_fetch_merge_reset_or_staging_performed'] and not completed['source_data_results_or_numerical_owners_modified']
assert not completed['numerical_programme_or_release_completed']
assert {name:m.binding(REPO/name) for name in completed['targets']}==completed['targets']=={name:m.binding(OLD/name) for name in completed['targets']}
for label in ('dated_progress','mirror','schemas'):
    invocation=m.load(parent/(label+'.invocation.json'))
    assert type(invocation['exit_code']) is int and invocation['exit_code']==0
    assert invocation['tested_source_before_equals_after'] and invocation['tested_source_files']==752
    assert invocation['capture_helper_sha256']=='ebb228adf53ee04a417c20247876d191b2560d5fc79ae5337d85a4dac91b5bf7'
    before=m.load(parent/(label+'.tested_source_before.json'));after=m.load(parent/(label+'.tested_source_after.json'))
    assert before==after and len(after)==752
    for role in ('stdout','stderr'):
        assert invocation['logs'][role]=={'path':str(parent/(label+'.'+role+'.log')),**m.binding(parent/(label+'.'+role+'.log'))}
source=m.load(BASE/'correction_guarded_dispatch_integration_validation_v3/make_test.tested_source_after.json')
assert {name:m.binding(REPO/name) for name in source}==source
archives={'completed_code_push':m.load(HERE/'completed_code_push_archive.json')}
assert m.binding(m.RECOVERY/archives['completed_code_push']['archive'])=={k:archives['completed_code_push'][k] for k in ('sha256','bytes')}
archives['sealed_six_document_mirror']=m.sealed('original-checkout-document-mirror-actual-v4',owner,'receipt.json',m.binding(owner/'receipt.json')['sha256'])
members={str(p.relative_to(parent)):p for p in sorted(parent.rglob('*')) if p.is_file()}
members['archival_control/archive_completed_document_mirror.py']=Path(__file__).absolute()
archives['actual_parent_captures']=m.archive('document-mirror-v4-actual-capture',members)
compact={'schema_version':1,'status':'published_document_only_mirror_and_actual_code_push_proofs_preserved',
         'completed_mirror':completed,'code_checkpoint_push':m.load(BASE/'guarded_dispatch_v3_integration_actual_push_20260929_v1/verified_push.json'),
         'dated_progress':m.load(parent/'dated_progress.stdout.log'),
         'new_archives':{name:{k:v for k,v in item.items() if k!='members'} for name,item in archives.items()},
         'current752_implementation_files_match_actual1040_test_capture':True,
         'guard_source_engineering_integrated':True,'scientific_approval_or_completion_created':False}
m.write_new(REPO/'coordination/recovery/2026-09-29-generator-correction-document-mirror-v4.json',compact)
m.write_new(HERE/'mirror_archive_members.json',archives)
print(json.dumps({'archives':{name:item['regular_members'] for name,item in archives.items()},'six_ide_documents_equal_actual_published_commit':True,'source752_unchanged':True},sort_keys=True))
