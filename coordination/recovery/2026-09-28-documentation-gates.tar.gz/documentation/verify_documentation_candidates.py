"""Verify task-owned doc candidates against both untouched Git baselines."""
import ast
import datetime
import hashlib
import importlib.util
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
MANIFEST = json.loads((ROOT / 'candidate_manifest.json').read_text())
SPEC = importlib.util.spec_from_file_location('doc_ast_proof', '/Users/macuser/bayes-cox-runs/harness/ast_equivalence.py')
PROOF = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROOF)


def docs(source):
    result = {}
    def visit(node, name):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            result[name] = ast.get_docstring(node)
        for field, value in ast.iter_fields(node):
            if field != 'body' or not isinstance(value, list):
                continue
            for child in value:
                if isinstance(child, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                    visit(child, name + '.' + child.name)
                elif isinstance(child, (ast.If, ast.With, ast.Try, ast.For, ast.While)):
                    visit(child, name)
    visit(ast.parse(source), 'module')
    return result


def verify(packages, output_name):
    out = {'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'original_base': MANIFEST['original_base'], 'integration_base': MANIFEST['integration_base'], 'packages': {}}
    for package in packages:
        rows = []
        ledger = []
        for record in MANIFEST['packages'][package]:
            rel = record['path']
            candidate = ROOT / 'candidates' / package / rel
            raw = candidate.read_bytes()
            source = raw.decode('utf-8')
            assert not any(line.rstrip() != line for line in source.splitlines()), rel
            checks = {}
            old_sources = {}
            for field in ('original_base', 'integration_base'):
                old = subprocess.run(['git', 'show', f'{MANIFEST[field]}:{rel}'], cwd=REPO, check=True, capture_output=True).stdout.decode('utf-8')
                old_sources[field] = old
                checks[field] = PROOF.normalised_dump(old) == PROOF.normalised_dump(source)
                assert checks[field], rel
            assert hashlib.sha256((REPO / rel).read_bytes()).hexdigest() == record['main_sha256'], rel + ' main moved'
            before = docs(old_sources['original_base'])
            after = docs(source)
            missing = [name for name, doc in after.items() if not doc]
            assert not missing, (rel, missing)
            rows.append({'path': rel, 'sha256': hashlib.sha256(raw).hexdigest(), 'checks': checks, 'documented_nodes': len(after), 'changed_from_integration_base': raw != old_sources['integration_base'].encode('utf-8')})
            for name, doc in after.items():
                previous = before.get(name)
                if previous != doc:
                    ledger.append({'path': rel, 'node': name, 'before': previous, 'after': doc, 'change': 'added' if not previous else 'expanded_or_corrected'})
        out['packages'][package] = {'status': 'documentation_only_against_both_bases', 'files_checked': len(rows), 'ast_comparisons_passed': 2 * len(rows), 'nodes_documented': sum(r['documented_nodes'] for r in rows), 'files': rows}
        ledger_path = ROOT / 'candidates' / package / f'{package}_root_documentation_changes.json'
        assert not ledger_path.exists()
        ledger_path.write_text(json.dumps({'original_base': MANIFEST['original_base'], 'entries': ledger}, indent=2, sort_keys=True) + '\n')
    output = ROOT / output_name
    assert not output.exists()
    output.write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print(json.dumps({p: {'files': out['packages'][p]['files_checked'], 'ast_passed': out['packages'][p]['ast_comparisons_passed'], 'nodes': out['packages'][p]['nodes_documented']} for p in packages}))
    return out


if __name__ == '__main__':
    verify(('rendering', 'scripts_tests'), 'root_final_package_ast_verification.json')
