Reviewed all 20 baseline files in src/explainability and src/rendering; the AST receipt lists each path and final hash. Added missing helper descriptions and public input/output contracts, including subject/feature/draw axes and risk-score scales. Defined abbreviations at first use where they occur in prose.

Corrected existing descriptions of protocol inputs, tied ranking (Spearman average ranks versus Kendall tau-b), the numerical-zero recovery threshold, variability in exact SHAP attributions, sampling-budget equivalence, Cox-partner availability, atomic writes and rendering-helper coverage. Documentation now follows the stored evidence and actual function bodies. It does not imply that an unavailable forest explanation can be obtained without refitting. All changed docstrings, with their previous and final text, appear in rendering_root_documentation_changes.json.

Both baseline comparisons pass: 40/40 AST matches against f0cce64 and 0ba4c3d. All 20 modules and every class/function in scope have docstrings. Scoped Ruff passes with src/scripts/tests explicitly recognised as first-party packages. Executable statements and imports are unchanged. The integrated test and normal repository Ruff gates remain a separate root gate.

No new suspected executable defect was found in this package. Existing provenance, availability and write-once checks remain unchanged.
