# Data and utility documentation

Changed nine files: `src/data/{__init__,cohorts,fold_preprocessing,survival_folds}.py`
and `src/utils/{__init__,frozen_evidence,io,posthoc_evidence,reproducibility}.py`.
Only comments/docstrings changed. Added package descriptions and missing helper
docstrings; expanded all seven existing module descriptions with purpose and entry points.

Existing docstrings completed/corrected:

- `cohorts.load_analysis_dataset`: array alignment, cohort time units and finite-time
  checks. `select_feature_spec`: arguments and shallow-copy return semantics.
- `survival_folds.SurvivalFold`, `event_time_strata`, `repeated_survival_folds`:
  row positions, one-based numbering, array shapes, within-event quantiles, integer
  conversion, seed progression and pairing across models.
- `fold_preprocessing.FoldFeaturePreprocessor` and `fit`, `transform`,
  `fit_transform`, `from_metadata`, `metadata`: training-only medians/population
  scaling, ordinal -1 coding, reference/unseen-category behaviour, encoded shape,
  hash restoration, exceptions and shared metadata containers.
- `io.json_safe`, `read_mapping`: supported conversions, format selection and
  return/error contracts. `write_json_atomic`: protects the destination from
  partial writes; temporary files may remain, and overwrite checks/shared temporary
  names do not provide concurrent exclusive creation.
- `reproducibility.sha256_file`, `canonical_json_hash`, `dependency_versions`,
  `file_hashes`, `build_run_manifest`: block reading, finite JSON requirements,
  distribution lookup, explicit missing markers and arguments/returns. Manifest
  determinism also requires unchanged software/host metadata; this recorder does
  not reject missing inputs.
- `frozen_evidence.checkpoint_blob`, `verify_checkpoint_inputs`,
  `verify_frozen_evidence`: historical-versus-live verification scope and errors.
- `posthoc_evidence.verify_posthoc_cell`, `verify_posthoc_run`: acceptance-target,
  fold-lineage, inventory and paired-availability checks. They do not independently
  recalculate stored diagnostics, scores or inferential estimates.

Proof: nine files, eighteen stripped-AST comparisons passed against
`f0cce646875ce6e7077edd50722838fb615f41a9` and
`0ba4c3d3a73e7b5d46830787517764d33dfb6b16`; per-file hashes are in
`data_utils_ast_receipt.json`. Scoped Ruff passed with copied `pyproject.toml`
and explicit first-party packages `src`, `scripts`, `tests`; no imports changed.

Suspected boundary issues left unchanged: event indicators are cast to integers
before validation, so fractional inputs may be truncated; `json_safe` cannot
iterate a zero-dimensional NumPy array; same-path JSON writes can race.
No tests, model fits, commits, or main/sealed/original-worktree edits were made.
