# Baseline documentation review

Changed all 31 baseline files: `src/models/{__init__,base,cox,deepsurv,random_survival_forest}.py`,
`src/models/bayesian/{__init__,diagnostics,model,piecewise,predictive_checks}.py`,
`src/evaluation/{__init__,calibration,calibration_model,metrics,ranking}.py`,
`src/statistics/{__init__,bootstrap,confidence_intervals,hypothesis_tests,permutation,repeated_cv,resampling}.py`,
`src/data/{__init__,cohorts,fold_preprocessing,survival_folds}.py`, and
`src/utils/{__init__,frozen_evidence,io,posthoc_evidence,reproducibility}.py`.

Completed missing module/class/function documentation, including
`bootstrap._validate_paired_predictions`. Public contracts now state arguments,
returns, relevant exceptions, subject alignment, shapes, units, scales and allowed
values. Private helpers use proportionate descriptions. Every revised/added
docstring is indexed in `documentation_review.json`; delegated data/utility details
are in `data_utils_report.md`.

Existing descriptions corrected/completed:

- Cox: ridge penalty includes subject count and standardised coefficients;
  confidence bounds are hazard ratios; Schoenfeld tests use training data and
  provide evidence rather than proof of proportional hazards.
- Forest/DeepSurv: non-negative forest risk; distinct importance standard-deviation
  denominators; dependency loading, empty architecture default, actual input/time
  validation, completed training logs and prefit summary behaviour.
- Bayesian: conditional training-derived prior checks, ADVI/NUTS draw shapes,
  non-centred geometry, prior-specific auxiliary signals, scalar absolute-term
  identity, prediction/credible-interval contracts and aggregate diagnostic gates.
- Evaluation/calibration: consistency assumptions rather than finite-sample
  unbiasedness; reference tie tolerance and time support; caller-side truncation;
  fixed prediction bootstrap, known weights, numerical clipping, bounded optimiser
  and qualified slope interpretation.
- Statistics: signed paired differences, skipped replicates, percentile/Student-t
  assumptions, zero-variance behaviour, singleton correction semantics, Holm's
  power guarantee, Benjamini-Hochberg dependence assumptions and resampling support.
- Data/utilities: training-only preprocessing, restored/shared metadata, outcome
  coercion, units/fold positions, shallow copies, actual serialization support,
  atomic-write limits and recorder/verifier evidence boundaries.

Proof: 31 files; **62/62 stripped-AST comparisons passed** against
`f0cce646875ce6e7077edd50722838fb615f41a9` and
`0ba4c3d3a73e7b5d46830787517764d33dfb6b16`. All module/class/function docstrings
are present. Scoped Ruff passed using copied `pyproject.toml` with explicit
first-party packages; imports were preserved.

Unchanged suspected boundary issues: integer event coercion/binary validation;
non-finite DeepSurv prediction times; unvalidated Bayesian credible-interval times
and unguarded exponentiation; NaNs skipped by diagnostic reductions; unchecked
permutation-repeat counts; zero-dimensional NumPy serialization and concurrent
JSON writes. These are code limitations, not observed result failures.

No tests, fits, commits, or main/sealed/original-worktree edits were performed.
