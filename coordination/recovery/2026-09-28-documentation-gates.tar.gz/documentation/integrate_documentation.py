"""Integrate only the predeclared baseline documentation candidates."""
import ast
import datetime
import hashlib
import importlib.util
import json
import pathlib
import subprocess

ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
manifest=json.loads((ROOT/'candidate_manifest.json').read_text())
spec=importlib.util.spec_from_file_location('doc_ast_proof','/Users/macuser/bayes-cox-runs/harness/ast_equivalence.py')
proof=importlib.util.module_from_spec(spec);spec.loader.exec_module(proof)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==manifest['integration_base']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True)
rows=[]; candidates={}; missing=[]
for package,records in manifest['packages'].items():
    for record in records:
        rel=record['path']; assert rel not in candidates,rel
        raw=(ROOT/'candidates'/package/rel).read_bytes();source=raw.decode('utf-8')
        assert hashlib.sha256((REPO/rel).read_bytes()).hexdigest()==record['main_sha256'],rel
        assert not any(line.rstrip()!=line for line in source.splitlines()),rel
        checks={}
        for field in ['original_base','integration_base']:
            old=subprocess.check_output(['git','show',f'{manifest[field]}:{rel}'],cwd=REPO).decode('utf-8')
            checks[field]=proof.normalised_dump(old)==proof.normalised_dump(source)
            assert checks[field],rel
        nodes=[n for n in ast.walk(ast.parse(source)) if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))]
        missing.extend(f'{rel}:{getattr(n,"lineno",0)}:{getattr(n,"name","module")}' for n in nodes if not ast.get_docstring(n))
        candidates[rel]=raw
        rows.append({'package':package,'path':rel,'sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'documented_nodes':len(nodes)})
assert len(rows)==115,(len(rows),'unexpected scope')
assert not missing,missing
originals=json.loads((ROOT/'draft_snapshot.json').read_text())
unchanged={}
for package in originals:
    hashes={rel:hashlib.sha256((pathlib.Path(package['source_worktree'])/rel).read_bytes()).hexdigest() for rel in package['files']}
    assert hashes==package['files'],package['package']+' original draft changed'
    unchanged[package['package']]={'files':len(hashes),'unchanged':True}
receipt={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_base':manifest['original_base'],'integration_base':manifest['integration_base'],'status':'all_candidates_verified_before_copy','files_checked':len(rows),'ast_comparisons_passed':len(rows)*2,'all_module_class_function_docstrings_present':True,'nodes_documented':sum(r['documented_nodes'] for r in rows),'original_drafts_unchanged':unchanged,'files':rows}
out=ROOT/'integrated_ast_verification.json';assert not out.exists()
out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
for rel,raw in candidates.items():
    (REPO/rel).write_bytes(raw)
for rel,raw in candidates.items():
    assert (REPO/rel).read_bytes()==raw,rel
patch=subprocess.check_output(['git','diff','--binary',manifest['integration_base'],'--','*.py'],cwd=REPO)
p=ROOT/'integrated_documentation.patch';assert not p.exists();p.write_bytes(patch)
print(json.dumps({'files_integrated':len(rows),'ast_matches':len(rows)*2,'documented_nodes':receipt['nodes_documented'],'original_drafts_unchanged':unchanged,'patch_sha256':hashlib.sha256(patch).hexdigest()}))
