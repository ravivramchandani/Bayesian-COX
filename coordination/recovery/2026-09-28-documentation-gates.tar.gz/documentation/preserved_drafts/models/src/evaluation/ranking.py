"""Single-time cumulative/dynamic AUC, kept for older callers.

The confirmatory pipeline calls :func:`src.evaluation.metrics.time_dependent_auc`
directly; this wrapper evaluates it at one time point.
"""

import numpy as np

from src.evaluation.metrics import time_dependent_auc as _cumulative_dynamic_auc


def time_dependent_auc_at(
    y_time: np.ndarray,
    y_event: np.ndarray,
    risk_scores: np.ndarray,
    eval_time: float,
    train_time: np.ndarray | None = None,
    train_event: np.ndarray | None = None,
) -> float:
    """Return the cumulative/dynamic AUC at a single time point.

    Censoring weights come from the training sample when both training
    arrays are supplied, otherwise from the evaluated sample itself.

    Raises:
        UnsupportedCensoringError: The censoring distribution does not
            support ``eval_time``.
    """
    if train_time is None or train_event is None:
        train_time, train_event = y_time, y_event

    auc, _ = _cumulative_dynamic_auc(
        train_time,
        train_event,
        y_time,
        y_event,
        risk_scores,
        np.array([eval_time], dtype=float),
    )
    return float(auc[0])
