"""Percentile and Student-t confidence intervals for a sample of values.

These are general helpers; the confirmatory analysis computes its intervals
in ``repeated_cv`` and in the calibration bootstrap.
"""

import numpy as np
from scipy.stats import sem, t


class ConfidenceIntervalCalculator:
    """Calculates non-parametric and parametric confidence bounds."""

    @staticmethod
    def _samples(samples: np.ndarray, *, minimum: int = 1) -> np.ndarray:
        """Return a finite one-dimensional float array with at least ``minimum`` values."""
        values = np.asarray(samples, dtype=float)
        if values.ndim != 1 or len(values) < minimum:
            raise ValueError(f"At least {minimum} one-dimensional samples are required.")
        if not np.isfinite(values).all():
            raise ValueError("Samples must contain only finite values.")
        return values

    @staticmethod
    def percentile_ci(samples: np.ndarray, alpha: float = 0.05) -> tuple[float, float]:
        """Return the ``alpha / 2`` and ``1 - alpha / 2`` percentiles of the samples.

        Percentiles use NumPy's default linear interpolation.
        """
        values = ConfidenceIntervalCalculator._samples(samples)
        if not 0 < alpha < 1:
            raise ValueError("alpha must lie strictly between 0 and 1.")
        lower = float(np.percentile(values, 100 * (alpha / 2.0)))
        upper = float(np.percentile(values, 100 * (1.0 - alpha / 2.0)))
        return lower, upper

    @staticmethod
    def normal_ci(samples: np.ndarray, alpha: float = 0.05) -> tuple[float, float]:
        """Calculate a Student-t interval for the sample mean.

        The interval is ``mean +/- t_{n-1, 1-alpha/2} * s / sqrt(n)``, with
        ``s`` the sample standard deviation. Despite the method name, it
        uses the t distribution, not the normal.
        """
        values = ConfidenceIntervalCalculator._samples(samples, minimum=2)
        if not 0 < alpha < 1:
            raise ValueError("alpha must lie strictly between 0 and 1.")
        mean = np.mean(values)
        se = sem(values)
        h = se * t.ppf(1.0 - alpha / 2.0, len(values) - 1)
        return float(mean - h), float(mean + h)

    @staticmethod
    def get_summary_statistics(
        samples: np.ndarray, alpha: float = 0.05
    ) -> dict[str, float]:
        """Return the mean, standard deviation, standard error and a percentile interval.

        ``std`` uses denominator n - 1. ``ci_lower`` and ``ci_upper`` are the
        percentile bounds from :meth:`percentile_ci` at level ``1 - alpha``
        (95% by default).
        """
        values = ConfidenceIntervalCalculator._samples(samples, minimum=2)
        mean_val = float(np.mean(values))
        std_val = float(np.std(values, ddof=1))
        se_val = float(sem(values))
        ci_lower, ci_upper = ConfidenceIntervalCalculator.percentile_ci(values, alpha)
        return {
            "mean": mean_val,
            "std": std_val,
            "se": se_val,
            "ci_lower": ci_lower,
            "ci_upper": ci_upper,
        }
