"""Bayesian piecewise-exponential proportional-hazards model and its MCMC diagnostics.

``model`` defines and fits the model, ``piecewise`` builds its Poisson
likelihood rows, ``predictive_checks`` holds the prior and posterior
predictive checks, and ``diagnostics`` holds the Markov chain Monte Carlo
(MCMC) convergence gate.
"""

from .diagnostics import check_convergence, divergences, summarise
from .model import SUPPORTED_PRIORS, BayesianCoxModel

__all__ = [
    "SUPPORTED_PRIORS",
    "BayesianCoxModel",
    "check_convergence",
    "divergences",
    "summarise",
]
