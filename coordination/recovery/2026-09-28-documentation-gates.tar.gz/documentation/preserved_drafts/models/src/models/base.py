"""Common interface for the four survival model families in the study.

Cox proportional hazards (PH), random survival forest (RSF), DeepSurv and the
Bayesian piecewise-exponential model all implement
:class:`BaseSurvivalModel`, so the confirmatory pipeline can fit, score and
evaluate them the same way: ``fit`` on the preprocessed outer-training fold,
then ``predict_risk`` and ``predict_survival`` on the validation fold.
"""

from abc import ABC, abstractmethod

import numpy as np
import pandas as pd


class BaseSurvivalModel(ABC):
    """Abstract base class for survival models with risk and survival predictions."""

    @abstractmethod
    def fit(self, X: pd.DataFrame, y_time: np.ndarray, y_event: np.ndarray) -> "BaseSurvivalModel":
        """Fit the model on training covariates, follow-up times and event indicators.

        Args:
            X: Preprocessed training covariates, one row per subject.
            y_time: Follow-up times in the cohort's own unit (days or months).
            y_event: Event indicators, 1 for an observed event and 0 for censoring.

        Returns:
            The fitted model.
        """

    @abstractmethod
    def predict_risk(self, X: pd.DataFrame) -> np.ndarray:
        """Return one risk score per row; higher scores mean shorter expected survival.

        Only the ranking is comparable across models, because the scale
        differs:

        - Cox: the partial hazard ``exp((x - x_mean) beta)``, centred at the
          training-fold covariate means by lifelines.
        - Random survival forest: the ensemble cumulative hazard summed over
          the distinct training event times (an expected number of events).
        - DeepSurv: the network output ``g(x)``, a log partial hazard.
        - Bayesian model: the posterior-mean linear predictor ``x E[beta]``,
          a log hazard ratio.
        """

    @abstractmethod
    def predict_survival(self, X: pd.DataFrame, eval_times: np.ndarray) -> np.ndarray:
        """Return survival probabilities ``S(t | x)`` of shape (n_samples, n_times).

        Args:
            X: Preprocessed covariates, one row per subject.
            eval_times: Times in the cohort's own unit, one column per time.
        """

    def get_summary(self) -> pd.DataFrame:
        """Return a summary of fitted parameters, or an empty frame if none applies."""
        return pd.DataFrame()


# Older name kept so existing imports still work.
BaseModel = BaseSurvivalModel
