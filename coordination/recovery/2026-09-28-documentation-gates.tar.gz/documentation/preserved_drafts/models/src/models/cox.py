"""Cox proportional hazards (PH) comparator built on lifelines.

The confirmatory pipeline fits one :class:`CoxPHModel` per outer-training
fold, with no outcome-driven tuning. lifelines maximises the Cox partial
likelihood (Efron's method for tied event times) with a small ridge penalty,
``0.5 * l2_reg * ||beta||^2`` (``l2_reg`` = 1e-4 in the confirmatory
configuration), and estimates the baseline hazard by Breslow's method.
lifelines standardises the covariates internally while fitting, applies the
penalty on that scale, and reports coefficients on the original covariate
scale.
"""

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.statistics import proportional_hazard_test

from src.models.base import BaseSurvivalModel


class CoxPHModel(BaseSurvivalModel):
    """Cox PH comparator with hazard ratios and a Schoenfeld residual test.

    Args:
        l2_reg: lifelines ``penalizer`` (pure ridge penalty).
        random_state: Stored for interface consistency; the fit is
            deterministic and does not use it.
    """

    def __init__(self, l2_reg: float = 0.0001, random_state: int = 42) -> None:
        self.l2_reg = l2_reg
        self.random_state = random_state
        self.fitter: CoxPHFitter | None = None
        self.feature_names: list[str] = []
        self._train_time: np.ndarray | None = None
        self._train_event: np.ndarray | None = None

    def fit(self, X: pd.DataFrame, y_time: np.ndarray, y_event: np.ndarray) -> "CoxPHModel":
        """Fit penalised Cox partial likelihood on the supplied training fold.

        Args:
            X: Preprocessed training covariates.
            y_time: Follow-up times in the cohort's original units.
            y_event: Binary event indicators, 1 for an observed event.

        Returns:
            The fitted model.
        """
        self.feature_names = list(X.columns)
        self._train_time = np.asarray(y_time, dtype=float)
        self._train_event = np.asarray(y_event, dtype=int)

        df = X.copy()
        df["time"] = self._train_time
        df["event"] = self._train_event

        self.fitter = CoxPHFitter(penalizer=self.l2_reg)
        self.fitter.fit(df, duration_col="time", event_col="event")
        return self

    def predict_risk(self, X: pd.DataFrame) -> np.ndarray:
        """Return the partial hazard ``exp((x - x_mean) beta)``; higher means higher hazard.

        lifelines centres each covariate at its training-fold mean
        ``x_mean``, so the score is the hazard ratio relative to a subject
        with average covariates. It is exponentiated, unlike the log-scale
        scores of DeepSurv and the Bayesian model.
        """
        self._check_fitted()
        return self.fitter.predict_partial_hazard(X[self.feature_names]).to_numpy()

    def predict_survival(self, X: pd.DataFrame, eval_times: np.ndarray) -> np.ndarray:
        """Return Breslow-baseline survival probabilities of shape (n_samples, n_times).

        ``eval_times`` are in the cohort's own unit.
        """
        self._check_fitted()
        surv = self.fitter.predict_survival_function(
            X[self.feature_names], times=np.asarray(eval_times, dtype=float)
        )
        return surv.to_numpy().T

    def summary(self) -> pd.DataFrame:
        """Return coefficients, hazard ratios, 95% confidence intervals and Wald p-values."""
        self._check_fitted()
        s = self.fitter.summary
        return pd.DataFrame(
            {
                "feature": s.index,
                "coef": s["coef"].to_numpy(),
                "hazard_ratio": s["exp(coef)"].to_numpy(),
                "se": s["se(coef)"].to_numpy(),
                "ci_lower": s["exp(coef) lower 95%"].to_numpy(),
                "ci_upper": s["exp(coef) upper 95%"].to_numpy(),
                "z": s["z"].to_numpy(),
                "p": s["p"].to_numpy(),
            }
        ).reset_index(drop=True)

    def proportional_hazards_test(
        self, X: pd.DataFrame, y_time: np.ndarray, y_event: np.ndarray
    ) -> pd.DataFrame:
        """Test the proportional-hazards assumption for each covariate.

        Uses lifelines' scaled Schoenfeld residual test against
        rank-transformed time. A covariate whose coefficient drifts over time
        violates PH and gives a small p-value. ``ph_satisfied`` is only
        ``p > 0.05`` for that covariate, without multiplicity adjustment; the
        pipeline applies Holm's correction itself.

        Args:
            X: Preprocessed covariates of the subjects to test.
            y_time: Their follow-up times in the cohort's own unit.
            y_event: Their event indicators.

        Returns:
            Columns ``feature``, ``test_statistic``, ``p`` and ``ph_satisfied``.
        """
        self._check_fitted()
        df = X[self.feature_names].copy()
        df["time"] = np.asarray(y_time, dtype=float)
        df["event"] = np.asarray(y_event, dtype=int)

        result = proportional_hazard_test(self.fitter, df, time_transform="rank")
        table = result.summary.reset_index()
        table.columns = ["feature", *list(table.columns[1:])]
        table["ph_satisfied"] = table["p"] > 0.05
        return table[["feature", "test_statistic", "p", "ph_satisfied"]]

    def _check_fitted(self) -> None:
        """Raise ``RuntimeError`` if :meth:`fit` has not been called."""
        if self.fitter is None:
            raise RuntimeError("Model is not fitted. Call fit() first.")
