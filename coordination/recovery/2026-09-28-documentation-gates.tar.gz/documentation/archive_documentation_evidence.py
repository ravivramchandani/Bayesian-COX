"""Preserve original drafts and verified documentation evidence for transfer."""
import gzip
import hashlib
import io
import json
import pathlib
import tarfile

ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
VALID=pathlib.Path('/Users/macuser/bayes-cox-runs/extensions-20260928/transfer_validation_v4_documentation')
manifest=json.loads((ROOT/'candidate_manifest.json').read_text())
files={}
def add(name,path):
    assert name not in files,name
    assert path.is_file() and not path.is_symlink(),path
    files[name]=path.read_bytes()
for p in ROOT.iterdir():
    if p.is_file() and p.suffix in {'.json','.patch','.py','.md','.log'}:
        add('documentation/'+p.name,p)
for p in (ROOT/'preserved_drafts').rglob('*'):
    if p.is_file():
        add('documentation/'+str(p.relative_to(ROOT)),p)
for package,records in manifest['packages'].items():
    folder=ROOT/'candidates'/package
    for row in records:
        add('documentation/candidates/'+package+'/'+row['path'],folder/row['path'])
    for p in folder.iterdir():
        if p.is_file() and p.suffix in {'.json','.md','.log','.toml'}:
            add('documentation/candidates/'+package+'/'+p.name,p)
for p in VALID.iterdir():
    if p.is_file():
        add('validation/'+p.name,p)
add('harness/ast_equivalence.py',pathlib.Path('/Users/macuser/bayes-cox-runs/harness/ast_equivalence.py'))
source=json.loads((VALID/'tested_source.json').read_text())
assert all(hashlib.sha256((REPO/p).read_bytes()).hexdigest()==sha for p,sha in source.items())
record={'schema_version':1,'classification':'documentation_only_original_drafts_and_verified_integration','members':[{'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for p,raw in sorted(files.items())]}
files['documentation_evidence_manifest.json']=(json.dumps(record,indent=2,sort_keys=True)+'\n').encode()
out=ROOT/'documentation-gates.tar.gz';assert not out.exists()
with out.open('xb') as f:
    with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,raw in sorted(files.items()):
                item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0
                tar.addfile(item,io.BytesIO(raw))
with tarfile.open(out,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(files)
    assert {m.name:tar.extractfile(m).read() for m in members}==files
archive_sha=hashlib.sha256(out.read_bytes()).hexdigest()
target=REPO/'coordination/recovery/2026-09-28-documentation-gates.tar.gz';assert not target.exists();target.write_bytes(out.read_bytes())
receipt=json.loads((VALID/'validation.json').read_text())
receipt.update({'validation_record_sha256':hashlib.sha256((VALID/'validation.json').read_bytes()).hexdigest(),'evidence_archive':'coordination/recovery/2026-09-28-documentation-gates.tar.gz','evidence_archive_sha256':archive_sha,'evidence_archive_members':len(files),'evidence_archive_bytes':out.stat().st_size,'original_drafts_preserved':103,'production_commit_unchanged':'119476fef55b1eeb690527f234c1423440720d45','analysis_commit_unchanged':'8551d326b02bfe88915cfd9eb50c6ca8e5690e3a'})
r=REPO/'coordination/recovery/2026-09-28-documentation-pass-verification.json';assert not r.exists();r.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'members':len(files),'archive_bytes':out.stat().st_size,'archive_sha256':archive_sha,'validation_sha256':receipt['validation_record_sha256']}))
