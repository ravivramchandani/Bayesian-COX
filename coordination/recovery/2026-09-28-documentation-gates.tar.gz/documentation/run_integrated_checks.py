"""Record integrated documentation verification against fixed source bytes."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import time

REPO=pathlib.Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
ROOT=pathlib.Path('/Users/macuser/bayes-cox-runs/documentation-pass-20260928')
OUT=pathlib.Path('/Users/macuser/bayes-cox-runs/extensions-20260928/transfer_validation_v4_documentation')
PY='/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python'
OUT.mkdir(exist_ok=False)
files=json.loads((OUT.parent/'transfer_validation_v3/tested_source.json').read_text())
def snapshot():
    return {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in files}
source=snapshot();(OUT/'tested_source.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n')
commands={
    'full_tests':['make','test','PYTHON='+PY],
    'ast_equivalence':[PY,'/Users/macuser/bayes-cox-runs/harness/ast_equivalence.py','.', '0ba4c3d3a73e7b5d46830787517764d33dfb6b16'],
    'ruff':[PY,'-m','ruff','check','.'],
    'schemas':[PY,'tests/test_coordination_schemas.py'],
    'diff_check':['git','diff','--check'],
}
results={}
for name,cmd in commands.items():
    start=time.monotonic()
    with (OUT/f'{name}.log').open('w') as log:
        result=subprocess.run(cmd,cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=False)
    results[name]={'command':cmd,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3)}
    (OUT/'checks_status.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
    print(name,result.returncode,results[name]['seconds'],flush=True)
    assert result.returncode==0,name
assert snapshot()==source,'tested source changed during gates'
text=(OUT/'full_tests.log').read_text();match=re.search(r'(\d+) passed.*?in ([\d.]+)s',text)
assert match and int(match.group(1))==349,text[-2000:]
ast_receipt=ROOT/'integrated_ast_verification.json'
record={'schema_version':1,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':'0ba4c3d3a73e7b5d46830787517764d33dfb6b16','evidence_status':'documentation_verified_numerical_grid_pending','repository_tests_passed':int(match.group(1)),'repository_tests_seconds':float(match.group(2)),'files_documented':115,'nodes_documented':858,'ast_comparisons_passed':230,'all_module_class_function_docstrings_present':True,'source_unchanged':True,'tested_source_files':len(source),'checks':results,'documentation_receipt_sha256':hashlib.sha256(ast_receipt.read_bytes()).hexdigest(),'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.is_file()},'remaining_gates':['complete 1625-cell accounting','full deep verification and aggregates','92 official exact refit receipts','32-page actual visual QA','private release and fresh remote science restoration']}
(OUT/'validation.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('INTEGRATED_DOCUMENTATION_VERIFIED',json.dumps({'tests':record['repository_tests_passed'],'seconds':record['repository_tests_seconds'],'source_files':len(source)}),flush=True)
