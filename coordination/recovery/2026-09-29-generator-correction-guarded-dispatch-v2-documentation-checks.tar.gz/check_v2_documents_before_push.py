"""Check published checkpoint documents without scientific execution."""
import datetime
import hashlib
import importlib.util
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).absolute().parent
BASE = HERE.parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')

def binding(path):
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

old = json.loads((BASE / 'correction_release_v3_integration_validation_v1/make_test.tested_source_after.json').read_text())
assert len(old) == 634 and {key:binding(REPO/key) for key in old} == old
schema = json.loads((HERE/'v2_document_schemas.invocation.json').read_text())
assert type(schema['exit_code']) is int and schema['exit_code'] == 0 and schema['tested_source_before_equals_after']
assert json.loads((HERE/'v2_document_schemas.tested_source_after.json').read_text()) == old
argv = ['git','show','fe1c26de2c71e91fd026474e412e72343a0153e8:docs/ravi_handoff.md']
result = subprocess.run(argv,cwd=REPO,capture_output=True,text=True,check=False)
assert type(result.returncode) is int and result.returncode == 0
current = (REPO/'docs/ravi_handoff.md').read_text()
marker = '## What is on GitHub\n'
assert current.count(marker) == result.stdout.count(marker) == 1
assert current.split(marker,1)[1] == result.stdout.split(marker,1)[1]
links = re.findall(r'\]\(([^)]+)\)',current.split(marker,1)[0])
assert all((REPO/'docs'/target).resolve().is_file() for target in links)
paths = ['coordination/HANDOFF.md','coordination/JOURNAL.md','coordination/TODO.md','docs/catalytic_correction_execution.md','docs/code_guide.md','docs/ravi_handoff.md']
record = {'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'root_checked_v2_review_documents_before_push',
 'actual_schema_exit_code':0,'schema_invocation':binding(HERE/'v2_document_schemas.invocation.json'),
 'resident_634_files_equal_successful_998_test_capture':True,'completed_baseline_restore_body_unchanged':True,
 'actual_baseline_read':{'argv':argv,'cwd':str(REPO),'exit_code':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr.encode()).hexdigest()},
 'ravi_front_local_links_checked':len(links),'six_document_bindings':{key:binding(REPO/key) for key in paths},
 'guard_adopted':False,'actual_scientific_reviews_freeze_selection_fits_or_release_approval':False}
with (HERE/'v2_documents_before_push.json').open('x') as stream: json.dump(record,stream,sort_keys=True,indent=2);stream.write('\n')
helper = BASE/'correction_reporting_release_root_closeout_20260929_v1/preserve_checked_records.py'
spec = importlib.util.spec_from_file_location('_root_archive_v2_document_checks',helper)
m = importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.RECOVERY = REPO/'coordination/recovery'
names = ['capture_run_v5.py','check_v2_documents_before_push.py','v2_documents_before_push.json']
names.extend('v2_document_schemas.'+suffix for suffix in ('stdout.log','stderr.log','launch.json','invocation.json','tested_source_before.json','tested_source_after.json'))
archive = m.archive('guarded-dispatch-v2-documentation-checks',{name:HERE/name for name in names})
record['archive']={k:v for k,v in archive.items() if k != 'members'}
m.write_new(m.RECOVERY/'2026-09-29-generator-correction-guarded-dispatch-v2-documentation-checks.json',record)
print(json.dumps({'status':record['status'],'local_links':len(links),'archive':record['archive']},sort_keys=True))
