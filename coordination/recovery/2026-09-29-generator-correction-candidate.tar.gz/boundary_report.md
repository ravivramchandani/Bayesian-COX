# Tested candidate boundary

One external rank-conditioned wrapper and isolated original-source adapter are
implemented. All 14 synthetic tests, two source syntax checks and scoped Ruff
pass. Test and Ruff invocation receipts bind the exact final source bytes;
the earlier 13-test pass and failed first Ruff log remain retained.

The normal direct original-import fixture matches the thin adapter's first
design, synthetic times, hazard and untouched legacy metadata. The invented
singleton fixture rejects seed4 and accepts retry seed341562260. A valid
original engineered x-copy fixture remains structurally rank deficient and
exhausts cap2; actual rejected hashes and constructor restoration are retained.
Injected tests also exercise cap1/256, all255 retry seeds against the original
seed function, nonrank exception propagation, spoof refusal and serial locking.

The adapter is implemented, but rebuilds original training preprocessing in a
fresh child per proposal. It accepts no arbitrary previously fitted processor
state, writes no proposal files and provides no production model integration.
The first-draw control is fixture evidence only, not a full-input/state equality
proof for real jobs. Thirteen source/dependency/initializer bytes are pinned;
this is not a complete scientific code/environment/fitting provenance audit.

The cap1–256 policy remains a single candidate setting; the method, cap and
new freeze are not approved. Mathematical normalization, complete825-job
input preflight, WME inner/outer integration, input-state reuse proofs,
production fitting/verification, corrected results and performance remain
pending. No real-cohort data, new study proposals, optimizer/MCMC fits,
evaluation or completion certification occurred. The sealed proposal, repo,
running code/results and transfer helpers/bundles were not edited.
