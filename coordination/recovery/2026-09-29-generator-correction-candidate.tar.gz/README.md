# Bounded synthetic-input candidate

This is one tested-candidate preparation for review, not an approved correction
method or freeze. No cohort generation, 825-job preflight, optimizer/MCMC fit,
evaluation, production integration or completion certification is provided.
The earlier four-file proposal, repository, sealed checkout and active jobs
remain unchanged. The default cap 256 is a candidate bound only; this version
accepts integer caps 1–256 including the first draw.

`generate_rank_conditioned(draw, original_seed, cap=256)` leaves attempt index0
at the original seed. Indices1–255 use exactly
`deterministic_seed(original_seed, 'rank_conditioned_retry', index)`. Every
retry runs the complete original proposal in its original source-marginal,
rate, exponential-time, transform, constructor and metadata order. The wrapper
does not resample parts of a rejected proposal or change M/p, source levels,
rank tolerance, rate, preprocessing or guard priority.

Only the adapter's tag for the exact pinned `CatalyticData.__post_init__`
rank-raise at line32 is retryable. The real constructor executes first;
dimensions, finite design/positive times, hazard and rank checks retain their
original order. A same-message exception outside that rank branch, preprocessing
failure, invalid hazard, nonfinite data, or optimizer/MCMC error is not retried.
Exhaustion raises `RankConditionedExhausted`, with actual attempt hashes and a
separate exhausted-cap execution status. It is not a diagnostic outcome.

`DrawProposal.legacy_metadata` preserves exactly the metadata returned by a
successful original generator. For a rejected original call it is `None`;
the generator never returned metadata. Actual captured constructor values,
training-derived metadata and attempt/cap/history hashes have separate fields.
Nothing claims fit reuse, fitting-provenance compatibility, a full-block audit,
mathematical approval or a new scientific freeze.

## Adapter boundary

The real `IsolatedOriginalAdapter` requires an explicitly selected original
source checkout and trusted in-memory **training-only** frame/spec/times/events.
It has no evaluation/test input. Each proposal starts a new isolated process,
byte-checks 13 original files/initializers, and executes verified original leaf
bytes in a minimal private package namespace. This bypasses unrelated eager
Bayesian/fitting imports. Original seed options load under a registered private
name. No caller `src` module or constructor is replaced.

The child rebuilds original
`ExtensionPreprocessor(feature_spec, gene_budget).fit(training)` for each
proposal. Arbitrary already-fitted processor states are not supported. The
captured processor metadata permits a later state check, but no such all-grid
comparison was performed here. It intercepts only preprocessing's local
`CatalyticData` alias, delegates to the real original constructor, and restores
the alias/releases its serial lock in `finally`, including other exceptions.
Foreign-thread/reentrant interception is refused. There is no output-file IO
in the adapter; only private trusted pickle transport over child pipes.

Example API shape, **not a command to generate real study inputs**:

```python
adapter = IsolatedOriginalAdapter(
    original_checkout, training_frame, feature_spec, train_time, train_event,
    gene_budget=gene_budget, python=verified_python,
)
result = generate_rank_conditioned(adapter, original_seed, cap=256)
constructor_inputs = result.proposal.data
unchanged_legacy_metadata = result.proposal.legacy_metadata
separate_attempt_history = result.proposal_metadata
```

The carrier exposes captured design/time/hazard values; it is not a substitute
for integrating the original scientific model class. Future production-fit
integration, complete source/environment/fitting provenance, reuse witnesses,
825-job preflight, method review and all-grid performance remain pending.
Child startup and rebuilding cost are unmeasured for real cohorts.

## Synthetic checks

The focused suite uses invented numeric/category training fixtures and injected
callbacks only. It checks original first-data/metadata preservation, exact
retry seeds/order, deterministic singleton omission/recovery, caps1/256 and
exhaustion, an actual-original structural derived-column dependency that stays
rank-deficient at every draw, nonrank errors, same-message spoof refusal, and restoration/serial
collision handling. One separate child performs a normal direct original
generator import, including normal package initialization, and compares its
common-level fixture arrays/rate/returned metadata against the thin adapter.
This is fixture-only compatibility evidence, not proof across all inputs or
of fit/provenance compatibility. No optimizer is invoked.

All numeric thread limits are1. That normal-import child's incidental caches
are redirected to this candidate folder. Test logs include failed attempts if
any; successful preparation must bind the actual passed logs/source hashes.

```bash
cd /Users/macuser/bayes-cox-runs/extensions-20260928/generator_correction_candidate_v1
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
  /Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python \
  -B -m unittest -v test_rank_conditioned_candidate
/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python \
  -B -m ruff check rank_conditioned_candidate.py test_rank_conditioned_candidate.py
```

Preparation receipt records actual synthetic/syntax/Ruff results, with all
scientific approval, corrected execution and completion fields false.
