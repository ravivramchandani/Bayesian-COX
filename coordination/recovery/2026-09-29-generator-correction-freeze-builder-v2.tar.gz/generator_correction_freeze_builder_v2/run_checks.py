"""Retain exact bounded synthetic/lint invocations without launching science."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

SOURCES = ("build_freeze.py", "test_build_freeze.py", "run_checks.py")


def source_hashes(root: Path) -> dict[str, str]:
    """Hash only the three small owned Python preparation sources."""
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in SOURCES}


def main() -> int:
    """Run the requested bounded checks once with exclusively retained evidence."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", type=int, required=True)
    args = parser.parse_args()
    if args.attempt < 1:
        raise ValueError("positive attempt required")
    root = Path(__file__).absolute().parent
    prefix = f"checks_attempt{args.attempt}"
    environment = dict(os.environ)
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        environment[name] = "1"
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    begin = source_hashes(root)
    started, monotonic = datetime.now(UTC).isoformat(), time.monotonic()
    records = []
    commands = (["nice", "-n", "15", sys.executable, "-B", "-m", "unittest", "-v", "test_build_freeze"],
                ["nice", "-n", "15", sys.executable, "-B", "-m", "ruff", "check", *SOURCES, "--config", str(root / "pyproject.toml")])
    for index, command in enumerate(commands):
        stdout_path, stderr_path = root / f"{prefix}_{index}.stdout.log", root / f"{prefix}_{index}.stderr.log"
        at, start = datetime.now(UTC).isoformat(), time.monotonic()
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            result = subprocess.run(command, cwd=root, env=environment, stdout=stdout, stderr=stderr, check=False)
            for stream in (stdout, stderr):
                stream.flush()
                os.fsync(stream.fileno())
        records.append({"argv": command, "started_at_utc": at, "finished_at_utc": datetime.now(UTC).isoformat(),
                        "wall_seconds": time.monotonic() - start, "exit_code": result.returncode,
                        "stdout": stdout_path.name, "stderr": stderr_path.name})
    syntax = []
    for name in SOURCES:
        text = (root / name).read_text()
        ast.parse(text, filename=name)
        compile(text, name, "exec", dont_inherit=True)
        syntax.append(name)
    value = {"scope": "invented_injected_synthetic_only_no_science_execution", "started_at_utc": started,
             "finished_at_utc": datetime.now(UTC).isoformat(), "wall_seconds": time.monotonic() - monotonic,
             "source_hashes_start": begin, "source_hashes_finish": source_hashes(root), "invocations": records,
             "syntax_sources_passed": syntax, "numeric_threads": 1,
             "real_cohort_operations": False, "actual_freeze_created": False, "actual_fits_dispatched": 0}
    with (root / f"{prefix}.json").open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"source_hashes_unchanged": begin == value["source_hashes_finish"],
                      "exit_codes": [row["exit_code"] for row in records], "syntax_count": len(syntax)}))
    return 0 if begin == value["source_hashes_finish"] and all(row["exit_code"] == 0 for row in records) else 1


if __name__ == "__main__":
    raise SystemExit(main())
