# Prospective correction freeze builder v1

This external stdlib helper prepares an execution proposal and assembles an actual freeze only from existing root review receipts. It never creates approvals, runs the lock checker, imports a scientific package, loads numerical arrays, generates data, fits, predicts or scores. Preparation tests use fictional metadata/bytes; no actual proposal, scientific review, freeze or fit is created here. Root owns integration, approval and launch.

`build_freeze.py` imports `fit_common.py` only after checking its exact sealed byte hash in a fresh private namespace. The three integrated files in `project/scripts/catalytic_correction` must match the sealed runtime hashes. Contracts83cb, preflight6b03 and reusedb558 are also fixed. The CLI has no configurable production counts: exactly1,625 input witnesses, all825 original catalytic outer contexts and825 WME inner contexts, and all1,650 independent first-draw replays are mandatory. It checks actual completion/context/replay/proof bytes, finite content digests, canonical original/corrected role values, exact seed namespaces and complete generator context bindings. Existing arrays are byte-hashed as artifacts, never loaded or decomposed. The original full four-chain budget, remedies and complete correction policy remain mandatory.

The complete arithmetic account is validated by the unchanged sealed fit guard. This preserves original negative kappa predicates, accepted-only arithmetic requirements, independently replayed unchanged inputs and terminal rank/nonrank/input failures. Missing checks, mismatches or missing actual failure evidence cannot authorize a freeze. Historical original acquisition snapshots remain bound; original availability does not filter pilots. Launch still needs the actual owner-finished snapshot checks in the selective runner. The largest `n_train*p` per `(model,setting,gene_budget)`, then stable cell ID, determines the prospective pilot even when its original owner is pending.

Root supplies one finite content-sealed `input_bindings.json` with:

```json
{
  "schema_version": 1,
  "status": "prospective_corrective_freeze_input_bindings",
  "fit_code": "/absolute/reviewed/integrated/scripts/catalytic_correction",
  "paths": {
    "source": "/absolute/clean/original119/source",
    "original_run": "/absolute/original/extension/run",
    "matched": "/absolute/frozen/matched.parquet",
    "preflight": "/absolute/completed/preflight",
    "contracts": "/absolute/byte-pinned/correction_fit_contracts.py",
    "preflight_core": "/absolute/byte-pinned/preflight_core.py",
    "reuse_core": "/absolute/byte-pinned/reuse_core.py",
    "witness_root": "/absolute/completed/reuse/witnesses",
    "inventory": "/absolute/completed/reuse/witnesses/inventories/digest/inventory.json"
  },
  "definition_sha256": "actual definition.json byte SHA",
  "input_inventory_sha256": "actual inventory byte SHA",
  "preflight_manifest_sha256": "actual preflight manifest byte SHA",
  "preflight_completion_sha256": "actual preflight completion byte SHA",
  "replay_completion_sha256": "actual replay/completion.json byte SHA",
  "arithmetic_accounting": {"path": "/absolute/completed/accounting.json", "sha256": "actual byte SHA"},
  "content_sha256": "canonical digest of every other field"
}
```

These are schema examples, not asserted actual inputs. Root fills existing reviewed paths/hashes. The exact freeze path roles match `generator_correction_fit_runner_v1/interface_contract.json`. The integrated checkout commit/cleanliness is root review evidence; this assembler binds the three actual runtime bytes without certifying repository or scientific readiness.

First create only an unapproved proposal in an absent, disjoint directory:

```sh
"$LOCK_PYTHON" -B "$BUILDER/build_freeze.py" --operation proposal \
  --fit-code "$FIT_CODE" --input-bindings "$INPUT_BINDINGS" \
  --input-bindings-sha256 "$INPUT_BINDINGS_SHA256" \
  --preparation-receipt "$BUILDER/preparation_receipt.json" \
  --preparation-receipt-sha256 "$BUILDER_PREPARATION_SHA256" --output "$NEW_PROPOSAL_DIR"
```

`proposal.json` contains an unapproved freeze template, deterministic pilots and `execution_definition_sha256`. The digest covers immutable code/input/policy/arithmetic fields and excludes later review hashes and the freeze itself. Root reviews those exact bytes and independently writes the five existing review files (`method`, `arithmetic`, `input_witness`, `implementation`, `freeze`). Each must have status `reviewed_for_corrected_fit_execution`, its role, the exact `definition_content_sha256`, `input_inventory_sha256` and proposal `execution_definition_sha256`, plus its finite internal content digest.

Root's separately sealed review carrier has status `root_supplied_corrective_execution_review_bindings` and `review_bindings` mapping exactly those five roles to `{path: absolute existing file, sha256: actual file byte SHA}`. Then finalize into another absent, disjoint directory with the same unchanged input carrier:

```sh
"$LOCK_PYTHON" -B "$BUILDER/build_freeze.py" --operation finalize \
  --fit-code "$FIT_CODE" --input-bindings "$INPUT_BINDINGS" \
  --input-bindings-sha256 "$INPUT_BINDINGS_SHA256" \
  --preparation-receipt "$BUILDER/preparation_receipt.json" \
  --preparation-receipt-sha256 "$BUILDER_PREPARATION_SHA256" \
  --proposal "$NEW_PROPOSAL_DIR/proposal.json" --proposal-sha256 "$PROPOSAL_SHA256" \
  --review-bindings "$ROOT_REVIEW_BINDINGS" --review-bindings-sha256 "$ROOT_REVIEW_BINDINGS_SHA256" \
  --output "$NEW_APPROVED_FREEZE_DIR"
```

Changed input-carrier bytes require a new unapproved proposal. Changed scientific code, input, arithmetic or policy digests require actual reviews bound to the new execution digest. Finalization writes `freeze.json` and `manifest.json`, invokes only the existing structural `fit_common.load_gates` on their actual bytes, and publishes `assembly_receipt.json` only after current input rechecks. No numerical job starts. Both operations refuse collisions, symlinks and protected-root overlap. A race or partial output can leave retained evidence but never successful CLI stdout; root must review it and use a new destination. This helper neither resumes nor overwrites partial output. Numerical verification, pilot review, reporting, reproduction and release remain separate gates.
