# Ravi: restore the results and continue the work

The newly authorised post-hoc extensions are a separate active programme.
See [extension execution](extensions_execution.md) for its frozen settings,
complete fit grid and verification gates. The released baseline below stays
unchanged; extension results are not yet remotely complete.

The generator correction is proceeding separately under ADR-040/T-190.
The original extension run continues. Corrected fits have not started; their
scope and reusable results require training-input preflight and exact
compatibility checks first. Read the current HANDOFF/TODO before launching
anything on another Mac. A later correction keeps the original failed records
and has its own specification, results and verified transfer; the original
release receipts do not certify it.

The tested candidate and real training-preflight runner are now implemented
and pushed at `cc231a0`; see
[correction execution](catalytic_correction_execution.md). The actual
1,650-context audit has completed on the owner's Mac: 1,400 contexts accepted
their original draw and 250 accepted a rank-conditioned redraw, with no
terminal outcome. Root's saved-record audit passed at 2026-09-29 09:05 UTC,
verifying all 12,446 artifact bindings and seed histories. This establishes
training-input feasibility; optimizer, MCMC and exact reuse/refit verification
remain pending before any corrected numerical freeze. Do not
start a duplicate audit. The recovery archives preserve the original
candidate, recipe inventory, runner and selective-fit-contract preparation
receipts, plus the independently reviewed arithmetic preparation. They do
not contain completed corrected fits or a completed
extension release.

The next-stage replay, arithmetic-accounting and selective-fit scripts are
also integrated with focused injected tests and separate source reviews.
The full locked integration suite passed 553 tests and 57 subtests; exact
environment, schema and lint checks passed.
These scripts require actual complete input evidence and the reviewed
corrected freeze before fitting. A Git checkout alone does not supply the
pending numerical results. Ravi should use the final private release and
its verified restore instructions once those gates are complete.

One detached continuation on the owner's Mac verified the full preflight
and started independent original replay at 08:55 UTC. It runs the complete
replay/reuse inventory and changed-input
arithmetic serially. It stops before the actual reviews, corrected freeze
and full-budget pilot. Inspect its launch receipt and logs in the current
HANDOFF; do not start overlapping work on another laptop. ADR-041 fixes
selected correction reproduction before corrected scores to the original
92 identities plus input-selected pilots. It distinguishes fresh corrected
refits, inherited original numerical reproduction and terminal no-fit recipe
replay. Those actual evidence checks and the corrected release remain pending.

The first continuation exited during an external-storage I/O incident at
about 09:44 UTC. Root preserved the complete disk image, passed a read-only
APFS check and reverified every preflight artifact plus the 76 completed
replay contexts. A new captured continuation resumed those checkpoints at
09:55 UTC on `BayesCoxTransfer20260929`; the old attempt remains read-only.
The current owner and exact output paths are in HANDOFF. Keep SSD980 and its
two mounted images available while the owner's work continues.

The reviewed freeze builder, mixed deep verifier and selected reproduction
controller are integrated too. With the separate read-only receiving verifier,
the receiving integration suite passed 792 tests and 70 subtests with no skips;
exact environment, schema and lint checks
passed, and all 157 original source/build/lock files are unchanged. The
[dated integration record](../coordination/recovery/2026-09-29-generator-correction-verification-reproduction-integration.json)
contains the earlier checks and preserved validation history. The
[receiving integration record](../coordination/recovery/2026-09-29-generator-correction-receiving-integration.json)
records that check. These checks do not
supply corrected numerical outcomes or a completed handoff. Correction-aware
reporting, actual figure review and fresh receiving verification remain
required before the corrected private release is complete.

The reporting/visual-QA implementation is now integrated with 51 passing
portable checks and three subtests. It requires the completed mixed
certificate, selected reproduction and an actual named review of every
figure. The separately reviewed v2 transfer implementation now passes
68 portable checks and 35 subtests, and retains its full 100-file preparation.
It resolves the process-capture and archive-completeness findings while
preserving the original failed preparation. The resulting full locked suite
passed 911 tests and 108 subtests with no skips at 11:22 UTC on 29 September.
The [reporting/release integration record](../coordination/recovery/2026-09-29-generator-correction-reporting-release-integration.json)
retains the successful commands and both earlier cancelled attempts. The
original code, scientific settings and gates remain unchanged. These checks do not supply final reports,
scientific approval or a release. ADR-042 preserves distinct per-entry
outputs if missing inherited producer evidence actually requires new work;
the subset and execution remain pending actual complete-input checks.

The exact 44-file per-entry implementation is now integrated with 54 passing
portable checks and 32 subtests. The full locked suite passed 965 tests and
140 subtests without skips at 12:35 UTC on 29 September. All captured
implementation bytes and all 157 original source/build/lock files remain
unchanged. The [per-entry integration record](../coordination/recovery/2026-09-29-generator-correction-per-entry-io-integration.json)
preserves the actual checks. Any new original-law work still requires the
actual missing subset, a reviewed location plan and separately pinned
release wiring before execution.

The separately pinned release-v3 implementation is integrated with its full
233-file preparation and unchanged predecessor evidence. Its focused checks
passed 33 tests and 17 subtests; the expanded full locked suite passed 998
tests and 157 subtests without skips at 12:50 UTC on 29 September. The
[v3 integration record](../coordination/recovery/2026-09-29-generator-correction-release-v3-integration.json)
retains exact archives and validation. Actual source capture, release and
fresh receiving verification remain pending completed scientific evidence.
ADR-041's actual selection and scope review must be frozen and checked before
any corrected pilot score; the numerical freeze alone does not enforce that
additional gate. The current continuation stops before fitting.

At 12:51 UTC on 29 September, the current replay had 342 verified contexts;
the original grid had 1,103 stored outcomes: 908 complete, 169 failed and
26 failed diagnostics. The read-only exit observer
registered all nine original processes and records future exits. Registration
does not certify finished numerical work. The interrupted replay, partial
child and storage recovery remain preserved for the final private release.

The [completed-preflight record](../coordination/recovery/2026-09-29-generator-correction-complete-preflight-verification.json)
and metadata archive are pushed. Full proposal arrays remain on the owner's
APFS workspace for the pending private evidence release. A
[storage receipt](../coordination/recovery/2026-09-29-generator-correction-storage-verification.json)
records the reversible relocation of inactive duplicate compressed caches;
the original scientific inputs, results, traces and running owners are intact.
Ravi should not launch overlapping original or correction jobs while this
owner-side programme is active.

This guide describes the handoff for an Apple Silicon Mac. The authoritative
task state is in [HANDOFF](../coordination/HANDOFF.md) and
[TODO](../coordination/TODO.md). Read [the code guide](code_guide.md) for the
pipeline and [the evidence status](current_evidence_status.md) for permitted
scientific claims.

All completed baseline-programme evidence is available remotely. Both result releases were
downloaded and verified through a fresh clone and fresh restore directories
on this Apple Silicon Mac. Ravi must verify the locked environment on his
own Mac; a second physical laptop was not tested.

## What is on GitHub

The private repository is
[ravivramchandani/Bayesian-COX](https://github.com/ravivramchandani/Bayesian-COX).
Use an account with access to this repository. There are three evidence releases:

- [Original confirmatory evidence](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/confirmatory-v1-44b6085):
  all 450 original cells, predictions, metrics, inference and source manifests.
- [Supplementary code/results programme](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-20260927-11f86ce):
  the exact 450-cell reproduction, 825-cell robustness run, 75-cell post-hoc
  sampler sensitivity, original explanation, final reports and figures,
  verified code snapshot, QA and hash inventories. All ten assets were
  downloaded and restored successfully.
- [Supporting audit evidence](https://github.com/ravivramchandani/Bayesian-COX/releases/tag/results-programme-audit-20260928):
  full native PDF review evidence, completed logs, earlier probes and external
  helpers; all three assets and 899 archive members verified after download.

Large results are release assets in the same private repository. A Git clone
contains the current code, plans and guides; the commands below retrieve the
result files and verify them. None of these releases requires files from the
supervisor's laptop.

## Install and restore on a fresh Mac

Prerequisites: Apple Silicon, macOS 14 or newer, Git, authenticated GitHub CLI
(`gh`), and an arm64 conda installation. Use the exact environment described
in [environment_lock.md](environment_lock.md). Install the lock tool in its
own environment; do not regenerate the scientific lock.

The pending extension/correction receiving checks also require equality with
the complete frozen environment report. That report records arm64,
macOS 26.6 and Python 3.11.15, with all 259 locked packages. The baseline
installation minimum above does not certify extension replay on another OS
version. Verify the actual report before running the final extension checks;
keep any mismatch explicit and preserve the frozen environment requirements.

Run these commands in Terminal, using fresh destination directories:

```bash
gh auth status
gh repo clone ravivramchandani/Bayesian-COX bayesian-cox
cd bayesian-cox

conda create -n bayes-cox-conda-lock-4-0-2 \
  --override-channels -c conda-forge conda-lock=4.0.2
conda run -n bayes-cox-conda-lock-4-0-2 \
  conda-lock install -n bayes-cox-clean conda-lock.yml
conda run -n bayes-cox-clean python scripts/verify_environment.py

conda run -n bayes-cox-clean python scripts/restore_confirmatory_release.py

RAVI_REPO="$PWD"
RAVI_ORIGINAL="$RAVI_REPO/reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651"
RAVI_ASSETS="$RAVI_REPO/../ravi-programme-assets-20260927"
RAVI_RESULTS="$RAVI_REPO/../ravi-programme-results-20260927"

gh release download results-programme-20260927-11f86ce \
  --repo ravivramchandani/Bayesian-COX --dir "$RAVI_ASSETS"
conda run -n bayes-cox-clean python scripts/restore_programme_release.py \
  --release-dir "$RAVI_ASSETS" --original-run "$RAVI_ORIGINAL" \
  --output-dir "$RAVI_RESULTS"

conda run -n bayes-cox-clean make test PYTHON=python
conda run -n bayes-cox-clean python -m ruff check .
```

The original restoration reports `cells=450 complete=430 failed_diagnostics=20`
and completion content hash
`03870efdae3134305794ea977fd9cbe7913c0d693f1b009337546319aa03bee1`.
The supplementary helper verifies every asset, archive member and metadata
hash, checks the original evidence, and restores into a fresh directory.
If the result directory already exists, it verifies its exact contents rather
than replacing them. No model is fitted by either restoration command.

The exact locked environment has 259 packages, Python 3.11.15 and matching
HDF5 2.1.0 build/runtime libraries. A differently configured Python environment
does not satisfy the numerical reproduction claim.

## Where to find the restored files

Paths below are relative to `$RAVI_RESULTS`, except the original source:

| Location | Contents |
| --- | --- |
| `$RAVI_ORIGINAL` | Immutable original 450-cell study |
| `code/` | Complete committed code snapshot `11f86ced8735b32767debb58f3cbbefbb5a7b8e6` used for the verified programme |
| `reproduction/` | All 450 refits, checkpoint and exact-comparison report |
| `robustness/` | All 825 cells, completion record and robustness/PH aggregates |
| `sampler_run/` | All 75 separate higher-acceptance horseshoe cells and their inference |
| `explanation/` | Unchanged original explanation result |
| `rendered_confirmatory/` | Generated primary, robustness and explanation tables, figures and LaTeX |
| `rendered_posthoc/` | Separately labelled sampler-sensitivity tables and figure |
| `release_metadata/` | Analysis verification, visual QA, release seal, manifest and checksums |

Read current plans and teaching documentation from the latest Git clone.
`code/` preserves the exact earlier revision used for the numerical claim.
Some preserved provenance records contain the original host's absolute
paths. Keep those bytes unchanged; use the restored paths above. A new
experiment records its actual host paths in a new manifest and output folder.

## Optional audit archive

The supporting archive is separate from the ten-asset result bundle. Restore
it when inspecting the native visual review, historical probes or logs:

```bash
RAVI_AUDIT_ASSETS="$RAVI_REPO/../ravi-audit-assets-20260928"
RAVI_AUDIT="$RAVI_REPO/../ravi-audit-evidence-20260928"
gh release download results-programme-audit-20260928 \
  --repo ravivramchandani/Bayesian-COX --dir "$RAVI_AUDIT_ASSETS"
(cd "$RAVI_AUDIT_ASSETS" && shasum -a 256 -c SHA256SUMS)
mkdir "$RAVI_AUDIT"
tar -xzf "$RAVI_AUDIT_ASSETS/programme-audit-evidence.tar.gz" -C "$RAVI_AUDIT"
```

`programme-audit-manifest.json` records every member hash and size. Historical
logs and PID files describe earlier states; use the current HANDOFF for what
to run next. The final QA status is passed; earlier pending or format-rejected
records are retained for provenance.

## Continue from the existing evidence

The existing numerical programme is complete and remotely verified. Its fits
do not need to be rerun on the receiving laptop. All 428 final PDFs passed
review; all nine separate sampler contrasts are estimable, have Holm-adjusted
p-values of 1.0 and corrected intervals containing zero. Read the
[numerical summary](../coordination/recovery/2026-09-28-numerical-evidence-summary.json)
and [close-out review](../coordination/reviews/2026-09-28-programme-closeout.md).
A new result always goes in a separate directory.

T-180 is now frozen, and the separate 1,625-fit post-hoc extension grid is
running from sealed commit `119476f`. It covers penalised Cox (T-182), the
precisely specified Piironen–Vehtari variant (T-183), survival decision
curves (T-184), matched METABRIC clinical/expression comparisons (T-185), and
the catalytic-prior variants/reference-parity checks (T-189). Do not start
duplicate workers on a receiving laptop while the active host owns this run.
The extension transfer is pending its complete-grid, deep verification,
92-refit, final PDF-QA and fresh remote-restoration gates. Follow
[extension execution](extensions_execution.md) and the current HANDOFF;
T-186 is checked only after its separate evidence bundle passes.

The original 20 horseshoe failures, incomplete original primary contrast
family and failed explanation-convergence gate remain part of the evidence.
The 75 new sampler fits are post-hoc sensitivity results and cannot replace
them. Preserve the actual earlier Holm-bound and sampler-probe chronology.

Overleaf editing still requires the owner's instruction. Paper drafting,
submission and DOI minting are deferred until after thesis submission.

## Post-hoc extension evidence

The active 1,625-cell extension programme remains separate from the released
baseline above. Its final release is pending numerical, visual and remote-transfer
verification. The [extension restoration guide](extensions_restore.md) gives the
receiving-Mac procedure and baseline dependencies; replace its remaining tag and
digest placeholders only after the verified release receipt is committed.
