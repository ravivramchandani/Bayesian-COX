"""Capture the genuine corrective pre-fit continuation; no execution reviews."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
BASE = Path(__file__).resolve().parent
PYTHON = Path("/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python")
HELPER = Path("/Users/macuser/bayes-cox-runs/extensions-20260928/correction_continuation_v1.py")
REQUEST = BASE / "continuation_v2_request.json"
NUMERIC = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == "4bd349a85748a257cc48944b87eaa41aa336784e056183d7fe2652ad845419c2"
assert hashlib.sha256(REQUEST.read_bytes()).hexdigest() == "bc1836449e12d83ae5d8e3e2a5692df9f26ae430744ee15d3926b8807e2797c1"
assert all(os.environ.get(name) == "1" for name in NUMERIC)
argv = [str(PYTHON), "-B", str(HELPER), "--request", str(REQUEST), "--request-sha256", hashlib.sha256(REQUEST.read_bytes()).hexdigest()]
started, tick = dt.datetime.now(dt.timezone.utc).isoformat(), time.monotonic()
with (BASE / "owned_continuation_v2.stdout.log").open("xb") as stdout, (BASE / "owned_continuation_v2.stderr.log").open("xb") as stderr:
    child = subprocess.Popen(argv, cwd=BASE, env=os.environ.copy(), stdout=stdout, stderr=stderr)
    initial = {"argv": argv, "cwd": str(BASE), "wrapper_pid": os.getpid(), "continuation_pid": child.pid, "started_at_utc": started, "helper_sha256": hashlib.sha256(HELPER.read_bytes()).hexdigest(), "request_sha256": hashlib.sha256(REQUEST.read_bytes()).hexdigest(), "numeric_threads": {name: os.environ[name] for name in NUMERIC}, "corrected_fitting_approved": False}
    with (BASE / "owned_continuation_v2.started.json").open("x") as stream: json.dump(initial, stream, sort_keys=True, indent=2); stream.write("\n"); stream.flush(); os.fsync(stream.fileno())
    code = child.wait()
final = {**initial, "finished_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "elapsed_seconds": time.monotonic() - tick, "actual_continuation_returncode": code, "logs": {}}
for name in ("stdout", "stderr"):
    path = BASE / ("owned_continuation_v2." + name + ".log")
    raw = path.read_bytes(); final["logs"][name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "path": str(path)}
with (BASE / "owned_continuation_v2.finished.json").open("x") as stream: json.dump(final, stream, sort_keys=True, indent=2); stream.write("\n"); stream.flush(); os.fsync(stream.fileno())
raise SystemExit(code)
