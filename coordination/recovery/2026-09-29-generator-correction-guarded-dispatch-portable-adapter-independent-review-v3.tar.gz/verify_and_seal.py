"""Verify this sealed adapter delta by stdlib reads and seal an external review."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import re
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).absolute().parent
SUBJECT = OUT.parent / "generator_correction_guarded_dispatch_repository_test_adapter_v2"
SUBJECT_SHA = "cbe9759f9ff529c57555d57a26f2c5a2fabb050d5f6c58a8f292190c86dc6257"
OLD = OUT.parent / "generator_correction_guarded_dispatch_repository_test_adapter_v1"
OLD_SHA = "a1ae7162f038e30e1073bbe38492183715be51ee1b36c4f421720a809c0061ab"
GUARD = OUT.parent / "generator_correction_guarded_dispatch_v3"
GUARD_SHA = "65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a"
CLARIFICATION = OUT.parent / "generator_correction_guarded_dispatch_adapter_ast_convention_clarification_v1"
CLARIFICATION_SHA = "2f157282a8cb7746936604c2ece2d66b54cc6be1ad5bd458e8a11653130370ab"


def binding(path):
    assert path.is_absolute() and ".." not in path.parts
    assert not any(item.is_symlink() for item in (path, *path.parents))
    assert path.is_file()
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def read(path, expected=None):
    if expected is not None:
        assert binding(path)["sha256"] == expected
    value = json.loads(path.read_text())
    if "content_sha256" in value:
        assert value["content_sha256"] == digest({key: item for key, item in value.items() if key != "content_sha256"})
    return value


def full(path, expected_sha, receipt_name="preparation_receipt.json"):
    receipt = read(path / receipt_name, expected_sha)
    files = {str(path / name): evidence for name, evidence in receipt["artifacts"].items()}
    files[str(path / receipt_name)] = binding(path / receipt_name)
    assert {str(member) for member in path.rglob("*") if member.is_file()} == set(files)
    directories = sorted(str(member.relative_to(path)) for member in path.rglob("*") if member.is_dir())
    assert directories == receipt["artifact_directories"]
    for member in path.rglob("*"):
        assert not member.is_symlink() and (member.is_file() or member.is_dir())
    for name, evidence in files.items():
        assert binding(Path(name)) == evidence
    return receipt, files, directories


def definitions(path):
    result = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.FunctionDef):
            result[node.name] = hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
        elif isinstance(node, ast.ClassDef):
            for method in node.body:
                if isinstance(method, ast.FunctionDef):
                    result[node.name + "." + method.name] = hashlib.sha256(ast.dump(method, include_attributes=False).encode()).hexdigest()
    return result


def constants(path):
    result = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == "frozenset":
                result[node.targets[0].id] = frozenset(ast.literal_eval(node.value.args[0]))
            else:
                result[node.targets[0].id] = ast.literal_eval(node.value)
    return result


def methods(path, class_name):
    classes = [node for node in ast.parse(path.read_text()).body if isinstance(node, ast.ClassDef) and node.name == class_name]
    assert len(classes) == 1
    return {node.name: hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
            for node in classes[0].body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}


def write(name, value):
    assert "content_sha256" not in value
    raw = (json.dumps({**value, "content_sha256": digest(value)}, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    with (OUT / name).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def evidence(path, first, last):
    lines = path.read_text().splitlines()
    return {"path": str(path), **binding(path), "line_start": first, "line_end": last,
            "lines": [{"line": n, "text": lines[n - 1]} for n in range(first, last + 1)]}


subject, subject_files, subject_dirs = full(SUBJECT, SUBJECT_SHA)
old, old_files, old_dirs = full(OLD, OLD_SHA)
guard, guard_files, guard_dirs = full(GUARD, GUARD_SHA)
clarification, clarification_files, clarification_dirs = full(CLARIFICATION, CLARIFICATION_SHA, "receipt.json")
assert len(subject_files) == 251 and len(subject_dirs) == 9
assert len(old_files) == 111 and len(old_dirs) == 3
assert len(guard_files) == 116 and len(guard_dirs) == 4
assert len(clarification_files) == 12 and clarification_dirs == []
for original, copied, files, directories in ((OLD, SUBJECT / "preserved_v2_adapter", old_files, old_dirs),
                                             (GUARD, SUBJECT / "sealed_guard_v3", guard_files, guard_dirs)):
    assert sorted(str(path.relative_to(copied)) for path in copied.rglob("*") if path.is_dir()) == directories
    assert {str(path.relative_to(copied)) for path in copied.rglob("*") if path.is_file()} == {str(Path(name).relative_to(original)) for name in files}
    for name, expected in files.items():
        assert binding(copied / Path(name).relative_to(original)) == expected
source_before = {**subject_files, **old_files, **guard_files, **clarification_files}
unit_capture = read(SUBJECT / "actual_v3_unittest_1.invocation.json")
for name, expected in unit_capture["source_before"].items():
    assert binding(Path(name)) == expected
    source_before[name] = expected
source_before[str(Path(__file__).absolute())] = binding(Path(__file__).absolute())
assert len(source_before) == 497
helper = SUBJECT / "guarded_dispatch_repository_adapter.py"
test = SUBJECT / "test_catalytic_correction_guarded_dispatch.py"
assert binding(helper) == {"bytes": 30099, "sha256": "e3c7eeaaddf92c019eb9acef01319be9ac75beff16b315e4b35b8aae078fde4f"}
assert binding(test) == {"bytes": 10302, "sha256": "6c7505b99de34c6604494c22e4d68a44fa2349d851c13ca8148c55ed56dba20f"}
assert binding(SUBJECT / "capture_adapter_checks.py") == binding(OLD / "capture_adapter_checks.py")
old_defs, new_defs = definitions(OLD / helper.name), definitions(helper)
changed = sorted(name for name in old_defs if old_defs[name] != new_defs[name])
added = sorted(set(new_defs) - set(old_defs))
assert changed == ["ImportedGuards.__init__", "ImportedGuards.report", "method_surface", "validate_surface"]
assert added == ["consistency_surface"] and not set(old_defs) - set(new_defs)
delta = read(SUBJECT / "adapter_delta.json")
assert delta["changed_existing_definitions"] == changed and delta["added_definitions"] == added
for name, expected in delta["unchanged_scope_boundary_ASTs"].items():
    assert old_defs[name] == new_defs[name]
comparison = read(CLARIFICATION / "comparison.json")
assert comparison["creation_time_executable_and_version_retained"] is False
assert comparison["historical_exact_interpreter_certified"] is False
assert comparison["declared_boundary_ASTs"] == delta["unchanged_scope_boundary_ASTs"]
assert comparison["locked311_boundary_ASTs"] == {name: new_defs[name] for name in delta["unchanged_scope_boundary_ASTs"]}
assert comparison["current_python314_all_declarations_reproduced"] is True
assert comparison["locked311_all_declarations_reproduced"] is False
assert comparison["both_interpreters_old_new_boundary_ASTs_exactly_equal"] is True
clarification_captures = {}
for label, version, declared_match in (("locked311", [3, 11, 15], False), ("python314", [3, 14, 7], True)):
    capture = read(CLARIFICATION / f"{label}.invocation.json")
    observation = json.loads((CLARIFICATION / f"{label}.stdout.json").read_text())
    assert type(capture["actual_returncode"]) is int and capture["actual_returncode"] == 0
    assert capture["target_import_or_execution"] is observation["target_import_or_execution"] is False
    assert capture["probe_source"] == binding(CLARIFICATION / "probe_ast_conventions.py")
    assert capture["stdout"] == binding(CLARIFICATION / f"{label}.stdout.json")
    assert capture["stderr"] == binding(CLARIFICATION / f"{label}.stderr.log")
    assert capture["argv"][1:4] == ["-I", "-B", str(CLARIFICATION / "probe_ast_conventions.py")]
    assert observation["python_version_info"][:3] == version
    assert observation["source_before"] == observation["source_after"]
    assert observation["source_unchanged"] is observation["all_old_and_new_AST_strings_equal"] is True
    assert observation["all_declared_hashes_match_this_interpreter"] is declared_match
    assert len(observation["boundaries"]) == 9
    for name, value in observation["boundaries"].items():
        assert value["old_ast_dump"] == value["new_ast_dump"]
        actual_digest = hashlib.sha256(value["new_ast_dump"].encode()).hexdigest()
        assert actual_digest == value["old_ast_dump_sha256"] == value["new_ast_dump_sha256"]
        assert value["declared_sha256"] == delta["unchanged_scope_boundary_ASTs"][name]
        assert value["declaration_matches_this_interpreter"] is declared_match
        assert (actual_digest == value["declared_sha256"]) is declared_match
        if label == "locked311":
            assert actual_digest == new_defs[name] == old_defs[name]
    for name, expected in observation["source_before"].items():
        assert binding(Path(name)) == expected
    clarification_captures[label] = {"invocation": binding(CLARIFICATION / f"{label}.invocation.json"),
                                     "actual_returncode": capture["actual_returncode"], "argv": capture["argv"],
                                     "observed_version": observation["python_version_info"], "old_new_AST_strings_equal": True,
                                     "all_declaration_hashes_match_observed_version": declared_match,
                                     "raw_stdout": capture["stdout"], "raw_stderr": capture["stderr"]}
old_const, new_const = constants(OLD / helper.name), constants(helper)
assert new_const["PREPARATION_SHA"] == GUARD_SHA
assert new_const["SOURCE_SHA"] == guard["runtime_source_sha256"]
assert new_const["CARRIER_MEMBERS"] == 116 and new_const["BOUND_ARTIFACTS"] == 115
assert list(new_const["CARRIER_DIRECTORIES"]) == guard_dirs
assert new_const["TEST_ORDER"] == ("test_guarded_dispatch.py", "test_guarded_dispatch_regressions.py", "test_guarded_dispatch_reuse_consistency.py")
assert new_const["ALIASES"] == old_const["ALIASES"] | {"test_guarded_dispatch_reuse_consistency"}
for name in ("ORIGINAL_METHOD_AST", "REGRESSION_METHOD_AST", "FIT_PINS", "REPRODUCTION_PINS", "SCIENCE_PREFIXES", "THREADS", "OWNED_FIXTURE_PREFIXES"):
    assert new_const[name] == old_const[name]
surfaces = {}
expected_roster = []
for filename, cls, const in (("test_guarded_dispatch.py", "GuardTests", "ORIGINAL_METHOD_AST"),
                             ("test_guarded_dispatch_regressions.py", "GuardV2Regressions", "REGRESSION_METHOD_AST"),
                             ("test_guarded_dispatch_reuse_consistency.py", "GuardV3ReuseConsistency", "CONSISTENCY_METHOD_AST")):
    surface = methods(GUARD / filename, cls)
    assert surface == new_const[const]
    assert binding(GUARD / filename)["sha256"] == new_const["TEST_SHA"][filename]
    surfaces[cls] = surface
    expected_roster.extend([[cls, name] for name in surface])
assert len(expected_roster) == 41 and len({tuple(row) for row in expected_roster}) == 41
test_old_defs, test_new_defs = definitions(OLD / test.name), definitions(test)
assert set(test_old_defs) == set(test_new_defs)
assert [name for name in test_old_defs if test_old_defs[name] != test_new_defs[name]] == ["TestGuardCarrierPortability.test_complete_carrier_preserved_methods_caller_isolation_and_failed_setup_cleanup"]
test_tree = ast.parse(test.read_text())
test_cases = [cls for cls in test_tree.body if isinstance(cls, ast.ClassDef)]
assert len(test_cases) == 1 and test_cases[0].name == "TestGuardCarrierPortability"
assert len(methods(test, "TestGuardCarrierPortability")) == 1
unit_report = json.loads((SUBJECT / "actual_v3_unittest_1.stdout.log").read_text())
assert unit_report["preparation_sha256"] == GUARD_SHA and unit_report["complete_carrier_members"] == 116
assert unit_report["complete_carrier_directories"] == guard_dirs
assert unit_report["retained_methods"] == sorted(expected_roster)
assert unit_report["tests_run"] == unit_report["expected_tests"] == 42
assert unit_report["errors"] == unit_report["failures"] == 0
assert unit_report["preexisting_src_and_alias_objects_restored"] is True
assert unit_report["actual_subprocess_controller_checker_generator_model_score_or_approval_invoked"] is False
unit_lines = re.findall(r"^(test_[A-Za-z0-9_]+) \(([^)]+)\)(?: \.\.\. ok)?$", (SUBJECT / "actual_v3_unittest_1.stderr.log").read_text(), re.MULTILINE)
assert len(unit_lines) == 42 and len(set(unit_lines)) == 42
expected_names = sorted([row[1] for row in expected_roster] + [next(iter(methods(test, "TestGuardCarrierPortability")))])
assert sorted(name for name, _owner in unit_lines) == expected_names
assert "Ran 42 tests" in (SUBJECT / "actual_v3_unittest_1.stderr.log").read_text()
assert (SUBJECT / "actual_v3_unittest_1.stderr.log").read_text().endswith("\nOK\n")
assert "42 passed, 136 subtests passed" in (SUBJECT / "actual_v3_pytest_1.stdout.log").read_text()
assert (SUBJECT / "actual_v3_ruff_1.stdout.log").read_text() == "All checks passed!\n"
assert (SUBJECT / "actual_v3_ast_1.stdout.log").read_text() == "AST3 source-only parse passed\n"
captures = {}
for prefix in ("actual_v3_unittest_1", "actual_v3_pytest_1", "actual_v3_ruff_1", "actual_v3_ast_1"):
    capture = read(SUBJECT / f"{prefix}.invocation.json")
    assert type(capture["returncode"]) is int and capture["returncode"] == 0 and capture["error"] is None
    assert capture["source_before"] == capture["source_after"] == unit_capture["source_before"]
    assert capture["source_unchanged"] is capture["carrier_unchanged"] is capture["owned_fixture_cleanup_complete"] is True
    assert capture["scratch_before"] == capture["scratch_after"] == {"directories": [], "files": {}}
    assert capture["actual_controller_scientific_or_original_owner_invoked"] is capture["actual_approval_created"] is False
    assert capture["samefile_current_interpreter"] is True and capture["argv"][:3] == [capture["python"], "-I", "-B"]
    assert capture["numeric_environment"] == {key: "1" for key in new_const["THREADS"]}
    for stream in ("stdout", "stderr"):
        assert binding(SUBJECT / f"{prefix}.{stream}.log") == capture["raw_logs"][stream]
    for name, expected in capture["source_before"].items():
        assert binding(Path(name)) == expected
    captures[prefix] = {"invocation_path": str(SUBJECT / f"{prefix}.invocation.json"),
                        "invocation": binding(SUBJECT / f"{prefix}.invocation.json"),
                        "actual_returncode": capture["returncode"], "argv": capture["argv"],
                        "raw_logs": capture["raw_logs"], "nine_source_pins_current_exact": True,
                        "complete_carrier_and_owned_cleanup_compared_by_fixed_driver": True}
source_after = {name: binding(Path(name)) for name in source_before}
assert source_after == source_before
full(SUBJECT, SUBJECT_SHA)
full(OLD, OLD_SHA)
full(GUARD, GUARD_SHA)
full(CLARIFICATION, CLARIFICATION_SHA, "receipt.json")
write("findings.json", {"schema_version": 1, "status": "bounded_portable_v3_adapter_delta_no_material_issue_identified",
      "material_finding_count": 0, "findings": [], "subject_preparation_receipt_sha256": SUBJECT_SHA,
      "exact_v3_guard_receipt_sha256": GUARD_SHA, "retained41_methods_exported_once_plus_one_portability_guard": True,
      "new_consistency_alias_and_nested_predecessor_path_correct": True,
      "native_subprocess_run_preserved": True, "all_existing_import_scope_cleanup_facades_and_export_ASTs_unchanged": True,
      "actual42_producer_unit_and_pytest_captures_verified": True, "duplicate_tests_or_target_imports_by_review": False,
      "version_sensitive_boundary_metadata_clarified": True, "boundary_metadata_creation_time_interpreter_unknown": True,
      "initial_stricter_validator_rc1_retained_not_relabelled": True,
      "scientific_or_root_adoption_approval": False})
write("source_evidence.json", {"schema_version": 1, "status": "exact_portable_v3_adapter_source_line_evidence",
      "evidence": [evidence(helper, 27, 97), evidence(helper, 147, 230), evidence(helper, 292, 347),
                   evidence(helper, 349, 459), evidence(test, 47, 124),
                   evidence(SUBJECT / "capture_adapter_checks.py", 63, 127)],
      "changed_definitions": changed, "added_definitions": added,
      "declared_version_sensitive_boundary_ASTs": delta["unchanged_scope_boundary_ASTs"],
      "independently_equal_locked311_boundary_ASTs": {name: new_defs[name] for name in delta["unchanged_scope_boundary_ASTs"]},
      "exact41_method_ASTs_by_class": surfaces})
write("validation.json", {"schema_version": 1, "status": "independent_source_only_roster_AST_and_actual_capture_verification_complete",
      "checked_at_utc": datetime.now(UTC).isoformat(), "subject_file_count": 251, "subject_directory_roster": subject_dirs,
      "original_v2_adapter_file_count": 111, "original_v2_adapter_directory_roster": old_dirs,
      "original_v3_guard_file_count": 116, "original_v3_guard_directory_roster": guard_dirs,
      "complete_original_and_preserved_rosters_byte_exact": True, "source_before": source_before, "source_after": source_after,
      "core485_plus_clarification12_total497_input_files_unchanged": True, "actual_producer_final_captures_verified": captures,
      "unit_observed_exact41_retained_methods": unit_report["retained_methods"], "unit_observed_total_cases": 42,
      "pytest_observed_cases": 42, "pytest_observed_subtests": 136, "all_source_method_ASTs_exact": surfaces,
      "changed_helper_definition_surface": changed, "added_helper_definition_surface": added,
      "declared_version_sensitive_boundary_ASTs": delta["unchanged_scope_boundary_ASTs"],
      "independently_equal_locked311_boundary_ASTs": {name: new_defs[name] for name in delta["unchanged_scope_boundary_ASTs"]},
      "AST_convention_clarification_receipt": {"path": str(CLARIFICATION / "receipt.json"), **binding(CLARIFICATION / "receipt.json")},
      "AST_convention_actual_source_only_captures_checked": clarification_captures,
      "boundary_metadata_creation_time_executable_and_version_unknown": True,
      "initial_validator_attempt1_actual_rc1_retained": {"note": binding(OUT / "attempt1_note.json"),
                                                       "source": binding(OUT / "verify_and_seal_attempt1.py")},
      "validator_attempt2_docstring_regex_actual_rc1_retained": {"note": binding(OUT / "attempt2_note.json"),
                                                               "source": binding(OUT / "verify_and_seal_attempt2.py")},
      "prep_capture_driver_byte_identical": True,
      "independent_work": "stdlib source_AST_hash_roster_and_raw_log_reads_only_no_target_import_or_duplicate_test",
      "new_writes_only_external_review_directory": True, "actual_scientific_controller_checker_or_owner_query": False,
      "resident_original_source_or_real_output_mutation": False, "scientific_or_root_adoption_approval": False})
assert {name: binding(Path(name)) for name in source_before} == source_before
artifacts = {str(path.relative_to(OUT)): binding(path) for path in sorted(OUT.rglob("*")) if path.is_file()}
assert len(artifacts) == 9 and not any(path.is_dir() for path in OUT.rglob("*"))
write("receipt.json", {"schema_version": 1, "status": "portable_v3_adapter_independent_delta_review_sealed_no_material_issue_identified",
      "sealed_at_utc": datetime.now(UTC).isoformat(), "owner": str(OUT), "subject": str(SUBJECT),
      "subject_preparation_receipt": binding(SUBJECT / "preparation_receipt.json"), "artifacts": artifacts,
      "artifact_directories": [], "material_finding_count": 0, "scientific_or_root_adoption_approval": False})
assert {str(path.relative_to(OUT)) for path in OUT.rglob("*")} == set(artifacts) | {"receipt.json"}
for name, expected in artifacts.items():
    assert binding(OUT / name) == expected
read(OUT / "receipt.json")
print(json.dumps({"receipt": str(OUT / "receipt.json"), **binding(OUT / "receipt.json"), "bound_files": len(artifacts),
                  "all_files": len(artifacts) + 1, "checked_input_files_unchanged": len(source_before), "material_findings": 0}, sort_keys=True))
