# Narrow original-IDE document mirror

The proposed **six-document-only mirror is supported within the sealed path audit**. Root can mirror the published versions of `coordination/HANDOFF.md`, `coordination/JOURNAL.md`, `coordination/TODO.md`, `docs/catalytic_correction_execution.md`, `docs/code_guide.md` and `docs/ravi_handoff.md` to those same original-main working paths after the verified push, retaining the backed-up original versions.

These exact six paths have no intersection with the retained SOURCE119118 input map, and no reviewed launch/dispatch source targets them. The numerical, support, observer and continuation routes use frozen external sources. Copying only these ordinary document files requires no Git operation. Thus the general synchronization risk from four worktrees sharing ORIGINAL/.git does not, by itself, block this narrowly separated document operation.

This conclusion is limited to those six disjoint targets and the already captured path evidence. Root must select the remote-verified replacement bytes and keep the operation document-only: no directory-wide copy, aliases, Git administration/maintenance, source, data, results or owner mutation. The reviewer has not inspected the proposed new document contents, performed the mirror/push, verified present liveness or approved scientific status. General old-checkout Git synchronization stays deferred; resident main remains the publishing checkout.

The predecessor audit remains unchanged: receipt `c88064c27aac0ecd7949f2ea0115577005a4dbfb82083918f3ecda908620fc00`, report `c8e867e0d7f082f60bcedd7f30290f62a5acdf4912aef6e216fe9e03528d9079`. This addendum uses only those existing facts. No further source, process, Git, data, archive or remote query occurred.
