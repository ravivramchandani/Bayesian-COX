"""Capture small immutable support-file inputs for the new external assembler.

This preparation inventories historical evidence only. It does not inspect
production cells or NetCDF traces, assemble a release, or authorize a review.
"""

from __future__ import annotations

import json
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

from assemble_validation_bundle import (
    BASE, BOUNDARY_DRIVER, COMPANION_SHA, EXPECTED_HERE, FREEZE_CONTENT,
    MANIFEST_SHA, MATCHED_SHA, PRODUCTION, RANK_HELPER, TOOL_COMMIT,
    TRUSTED_HELPER, canonical, encoded, file_bytes, file_row, require, sha,
    unlinked, write_once,
)

PROJECT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
TOOLS = Path('/Users/macuser/bayes-cox-runs/extensions-transfer-code-20260928-2b701a8')


def main() -> None:
    """Retain exact historical source bindings once, with future gates pending."""
    require(not (EXPECTED_HERE / 'input_manifest.json').exists(), 'prepared input manifest already exists')
    files, trees, archive_members = [], [], []

    def add(path: Path, target: str) -> None:
        files.append(file_row(path, target))

    def tree(name: str, target: str, excluded: tuple[str, ...] = ()) -> None:
        source = BASE / name
        unlinked(source, directory=True)
        names = []
        for path in sorted(source.rglob('*')):
            require(not path.is_symlink(), f'linked historical input: {path}')
            relative = path.relative_to(source)
            if '__pycache__' in path.parts or path.suffix == '.pyc' or any(p in excluded for p in relative.parts):
                continue
            if path.is_file():
                names.append(relative.as_posix())
                add(path, target + '/' + relative.as_posix())
            else:
                require(path.is_dir(), f'nonordinary historical input: {path}')
        trees.append({'source': str(source), 'target': target,
                      'relative_files': names, 'excluded_parts': list(excluded)})

    tree('integration_validation_bundle_v1', 'historical/integration_validation_bundle_v1')
    tree('integration_validation_bundle_v2', 'historical/integration_validation_bundle_v2')
    for name in ['transfer_validation_v1', 'transfer_validation_v2', 'transfer_validation_v3',
                 'transfer_validation_v4_documentation', 'transfer_validation_v5_extension_documentation']:
        tree(name, name)
    for name in ['extension_documentation_review_c317', 'extension_documentation_corrections_verified_v1',
                 'extension_test_documentation_review_v1', 'coordination_consistency_review_v1']:
        tree(name, 'extension_documentation/' + name)
    for name in ['final_transfer_runbook_v1', 'final_transfer_runbook_review_v1',
                 'final_transfer_runbook_v2', 'final_transfer_runbook_review_v2']:
        tree(name, 'transfer_preparation/' + name)
    for name in ['receiving_guide_validation_v1', 'receiving_guide_validation_v2_apfs', 'storage_refresh_v1']:
        tree(name, 'receiving_and_storage/' + name)
    tree('postfit_support_review_v1', 'companion/current/postfit_support_review_v1')
    tree('failure_provenance_v1', 'historical/failure_provenance_v1')
    tree('diagnostic_boundary_fullgrid_v1', 'diagnostic_boundary_fullgrid_v1',
         ('full_grid_result', 'numba_cache'))
    tree('final_claim_review_preparation_v1', 'final_claim_review_preparation_v1')

    for name in ['complete_postfit_support_v1.py', 'postfit_support_process_v1.json']:
        add(BASE / name, 'companion/current/' + name)
    for name in ['coordinate_after_fits.py', 'coordinate_after_fits_v2.py',
                 'worker_logs/coordinator_v1_source.py']:
        add(BASE / name, 'coordinator_history/' + name)
    old_log = file_bytes(BASE / 'worker_logs/coordinator.log')
    old_log_capture = EXPECTED_HERE / 'historical_coordinator/coordinator_v1_log_snapshot.log'
    write_once(old_log_capture, old_log)
    add(old_log_capture, 'coordinator_history/coordinator_v1_log_snapshot.log')
    for name in ['external_volume_preflight.json', 'exfat_preflight_failure.json']:
        add(BASE / name, 'receiving_and_storage/' + name)
    for name in ['transfer_tool_worktree_verification.json', 'failure_provenance_v2_initial_verification.json']:
        add(BASE / name, 'partial_rank_and_tool_proof/' + name)
    for name in ['preserve_extension_documentation_v5.py', 'verify_extension_documentation_v5.py',
                 'preserve_postfit_preparation_v1.py']:
        add(BASE / name, 'preservation_helpers/' + name)
    for name in ['scripts/extension_release/audit_rank_failures.py', 'scripts/extension_release/verify.py']:
        add(TOOLS / name, 'current_transfer_tools/' + name)

    recovery_names = ['2026-09-28-extension-documentation-gates.tar.gz',
                      '2026-09-28-extension-documentation-verification.json',
                      '2026-09-28-extension-postfit-preparation.tar.gz',
                      '2026-09-28-extension-postfit-preparation-verification.json',
                      '2026-09-28-extension-external-storage-verification.json',
                      '2026-09-28-extension-receiving-guide-verification.json',
                      '2026-09-28-extension-receiving-guide-apfs-verification.json',
                      '2026-09-28-extension-native-path-verification.json',
                      '2026-09-28-extension-failure-qa-verification.json',
                      '2026-09-28-extension-transfer-verification.json']
    for name in recovery_names:
        add(PROJECT / 'coordination/recovery' / name, 'repository_recovery/' + name)
    for name in ['2026-09-28-documentation-pass.md', '2026-09-28-extension-documentation-pass.md',
                 '2026-09-28-extension-postfit-preparation.md']:
        add(PROJECT / 'coordination/reviews' / name, 'repository_reviews/' + name)

    partial = json.loads(file_bytes(BASE / 'failure_provenance_v2_initial_verification.json'))
    partial_path = BASE / 'failure_provenance_v2/snapshots' / (
        'failure_provenance_' + partial['snapshot_content_sha256'] + '.json')
    require(sha(file_bytes(partial_path)) == partial['snapshot_sha256'], 'historical partial v2 snapshot differs')
    add(partial_path, 'partial_rank_and_tool_proof/' + partial_path.name)

    def member(archive_name: str, member_name: str, target: str, expected: str | None = None) -> None:
        archive = PROJECT / 'coordination/recovery' / archive_name
        archive_sha = sha(file_bytes(archive))
        with tarfile.open(archive, 'r:gz') as tar:
            matches = [m for m in tar.getmembers() if m.name == member_name]
            require(len(matches) == 1 and matches[0].isfile(), 'missing historical member')
            stream = tar.extractfile(matches[0])
            require(stream is not None, 'unreadable historical member')
            with stream:
                data = stream.read()
        require(expected is None or sha(data) == expected, 'historical helper source hash differs')
        archive_members.append({'archive': str(archive), 'archive_sha256': archive_sha,
                                'member': member_name, 'target': target,
                                'bytes': len(data), 'sha256': sha(data)})

    member('2026-09-28-extension-documentation-gates.tar.gz',
           'historical/failure_provenance_v1_audit_rank_failures.py',
           'historical/failure_provenance_v1_audit_rank_failures.py',
           '6b6655dd5d24a0f4b36efb55c945dcec2c32d6307eb1e94e906b44e9120883bc')
    member('2026-09-28-extension-documentation-gates.tar.gz',
           'historical/external_preflight_archive_common.py',
           'historical/external_preflight_archive_common.py')
    for name in ['complete_postfit_support_v1.py', 'postfit_support_process_v1.json',
                 'postfit_support_review_v1/review_receipt.json', 'postfit_support_review_v1/report.md']:
        member('2026-09-28-extension-postfit-preparation.tar.gz', 'preparation/' + name,
               'companion/original_archived/' + name)

    guides = [('b4300fcff3fb756a4684b99a28958107792704a1', 'receiving_guide_v1.md',
               '5b3509a8cac9f8b6b1fef4524f80f48ae3b110daf5e6915460cbbf1802ee2e51'),
              (TOOL_COMMIT, 'receiving_guide_v2_apfs.md',
               '95bc4b4ec70cb9e556b32c5bc60a5dbd2fd5095f51fef2a0d3f7fb48ec1c290e')]
    for commit, name, expected in guides:
        data = subprocess.check_output(['git', 'show', commit + ':docs/extensions_restore.md'], cwd=PROJECT)
        require(sha(data) == expected, 'receiving guide does not match its verification receipt')
        path = EXPECTED_HERE / 'historical_guides' / name
        write_once(path, data)
        add(path, 'receiving_and_storage/' + name)

    # Check the exact earlier bundle inventory; this is small evidence hashing,
    # not a trace scan or a fresh diagnostic audit.
    old = json.loads(file_bytes(BASE / 'integration_validation_bundle_v2/bundle_manifest.json'))
    for row in old['files']:
        data = file_bytes(BASE / 'integration_validation_bundle_v2' / row['path'])
        require(sha(data) == row['sha256'] and len(data) == row['bytes'], 'old v2 payload differs')
    claim = json.loads(file_bytes(BASE / 'final_claim_review_preparation_v1/preparation_receipt.json'))
    require(sha(file_bytes(BASE / 'final_claim_review_preparation_v1/preparation_receipt.json'))
            == '6c71cfa31b97ed0e50f285150bf07caf3c149bfb48be7dfed26d27f47ce46ed0',
            'final claim preparation receipt differs')
    for name, row in claim['files'].items():
        require(sha(file_bytes(BASE / 'final_claim_review_preparation_v1' / name)) == row['sha256'],
                'final claim prepared source differs')
    boundary_prep = json.loads(file_bytes(BASE / 'diagnostic_boundary_fullgrid_v1/preparation_receipt.json'))
    require(sha(file_bytes(BASE / 'complete_postfit_support_v1.py')) == COMPANION_SHA,
            'current companion differs from reviewed original')
    require(sha(file_bytes(TOOLS / 'scripts/extension_release/audit_rank_failures.py')) == RANK_HELPER,
            'current transfer helper differs')
    record = {'schema_version': 1, 'prepared_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'prepared_historical_inputs_dynamic_completion_pending',
              'repository_checkpoint_for_postfit_capture': '2a7fc2ffef740e3ccc061276c8fa329e827aacff',
              'historical_coordinator_log_capture': {'source_at_preparation': str(BASE / 'worker_logs/coordinator.log'),
                  'retained_snapshot': str(old_log_capture), 'sha256': sha(old_log),
                  'classification': 'dated original v1 log capture, not current coordinator completion'},
              'fixed_trees': trees, 'files': sorted(files, key=lambda r: r['target']),
              'archive_members': sorted(archive_members, key=lambda r: r['target']),
              'receiving_guide_history': [{'commit': c, 'file': n, 'sha256': h} for c, n, h in guides],
              'frozen_support_pins': {'source_manifest_sha256': MANIFEST_SHA, 'production_commit': PRODUCTION,
                  'matched_sha256': MATCHED_SHA, 'freeze_content_sha256': FREEZE_CONTENT,
                  'transfer_tool_commit': TOOL_COMMIT, 'rank_helper_sha256': RANK_HELPER,
                  'boundary_driver_sha256': BOUNDARY_DRIVER, 'trusted_helper_sha256': TRUSTED_HELPER,
                  'trusted_cache_artefact_sha256': boundary_prep['trusted_cache_artefact_sha256']},
              'pending_required_inputs': [str(BASE / 'postfit_support_prepared_v1.json'),
                  str(BASE / 'completed_support_review_v1.json'),
                  str(BASE / 'diagnostic_boundary_fullgrid_v1/full_grid_result'),
                  'full 1625-cell rank snapshot named by the future support marker',
                  *[str(BASE / 'worker_logs' / n) for n in ['postfit_support_rank_v1.log',
                    'postfit_support_rank_v1.stderr.log', 'postfit_support_boundary_v1.log',
                    'postfit_support_boundary_v1.stderr.log']],
                  'completed stable postfit_support_companion_v1.log bytes'],
              'historical_missing_files': [], 'science_gates_added': False,
              'full_failure_v2_tree': 'retained separately and passed to stager --failure-audit',
              'small_support_file_bytes_hashed_only': True, 'netcdf_files_read': 0,
              'numerical_or_transfer_completion_claimed': False}
    record['manifest_content_sha256'] = canonical(record)
    write_once(EXPECTED_HERE / 'input_manifest.json', encoded(record))
    print(json.dumps({'fixed_file_inputs': len(files), 'historical_members': len(archive_members),
                      'fixed_payload_bytes': sum(r['bytes'] for r in files),
                      'input_manifest_content_sha256': record['manifest_content_sha256'],
                      'historical_missing_files': [], 'assembled': False}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
