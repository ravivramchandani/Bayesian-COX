"""Preserve reviewed supporting evidence in a fresh bundle; never run science.

The fixed prepared manifest binds historical bytes. Completed supporting audits
and an explicit later root review are required before any output is created.
QA, official refits, scientific acceptance and transfer remain stager-owned.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import tarfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = Path(__file__).absolute().parent
EXPECTED_HERE = BASE / 'final_validation_bundle_preparation_v1'
DEFAULT_OUTPUT = BASE / 'integration_validation_bundle_v3'
ROOT_REVIEW = BASE / 'completed_support_review_v1.json'
BOUNDARY = BASE / 'diagnostic_boundary_fullgrid_v1/full_grid_result'
RANK_ROOT = BASE / 'failure_provenance_v2'
MANIFEST = BASE / 'run/manifest.json'
SUPPORT = BASE / 'postfit_support_prepared_v1.json'
MANIFEST_SHA = '83b9049fb6aaaadab576b34de0741e4f510344dcefba9f96198d15b5ab4f49b9'
MANIFEST_CONTENT = '4577c615486ee871d508837aa812f59539b59338c63834716453a8b03ea394a3'
PRODUCTION = '119476fef55b1eeb690527f234c1423440720d45'
TOOL_COMMIT = '2b701a87a2c8b97b5d4034276a437755e74f1fbd'
RANK_HELPER = '98cc7563c466e01d5bc72b8ba72a5beda771dceee16aeb3224a9639e1c1030fe'
BOUNDARY_DRIVER = '20a7e53880c223fafedac7a4ea400399262a28fafba8d908fdced0d1d2841a7b'
TRUSTED_HELPER = 'df7c47668d541a819e0e2c9267fec4bdd8c62d15eca22a92a4867dee6ca92d9b'
COMPANION_SHA = '7d4f7dc22caa93391cfa918d27266d3a16c6a0d48348fd533ba4b1f291a05ada'
FREEZE_CONTENT = '50b5f30f697b633718078e18c0da54be297361f8b06aeaf95af32e12aa1c646f'
MATCHED_SHA = '36ddcdc14d0bd76ee7c88d2c78fab2fab2039ed3819e5c70fd27b21c7b335971'
REQUIRED_LOGS = tuple(BASE / 'worker_logs' / name for name in (
    'postfit_support_rank_v1.log', 'postfit_support_rank_v1.stderr.log',
    'postfit_support_boundary_v1.log', 'postfit_support_boundary_v1.stderr.log',
    'postfit_support_companion_v1.log',
))


class Refusal(RuntimeError):
    """A missing, unsafe, incomplete or changed supporting input."""


def require(condition: bool, message: str) -> None:
    """Reject a failed evidence condition before publication."""
    if not condition:
        raise Refusal(message)


def sha(data: bytes) -> str:
    """Hash exact bytes."""
    return hashlib.sha256(data).hexdigest()


def canonical(value: Any) -> str:
    """Match the frozen finite-only canonical JSON encoding."""
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'),
                          ensure_ascii=False, allow_nan=False).encode('utf-8'))


def encoded(value: Any) -> bytes:
    """Encode a readable receipt without nonfinite JSON numbers."""
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False,
                       allow_nan=False) + '\n').encode('utf-8')


def self_hash(record: dict[str, Any], field: str) -> None:
    """Check a canonical content hash independently of byte hashes."""
    require(record.get(field) == canonical({k: v for k, v in record.items() if k != field}),
            f'{field} differs')


def safe_name(name: str) -> bool:
    """Accept only ordinary portable relative output names."""
    parts = PurePosixPath(name).parts
    return bool(parts) and not name.startswith('/') and '\\' not in name and all(
        p not in ('', '.', '..') for p in name.split('/'))


def output_policy(output: Path, exists: bool, safe_parents: bool) -> None:
    """Apply a pure fresh-output policy, including no alternate source roots."""
    require(output.is_absolute() and '..' not in output.parts, 'output must be an absolute normalized path')
    require(output.parent == BASE and output.name.startswith('integration_validation_bundle_v3'),
            'output must be a new v3 bundle directly under the external execution root')
    require(not exists, 'output already exists; no existing bytes may be replaced')
    require(safe_parents, 'output ancestor is linked or unavailable')


def unlinked(path: Path, *, directory: bool = False) -> None:
    """Reject linked ancestors and nonordinary source files/directories."""
    require(path.is_absolute() and '..' not in path.parts, f'unsafe absolute input: {path}')
    require(not any(p.is_symlink() for p in (path, *path.parents)), f'linked input/ancestor: {path}')
    mode = path.stat().st_mode
    require(stat.S_ISDIR(mode) if directory else stat.S_ISREG(mode), f'nonordinary input: {path}')


def signature(path: Path) -> tuple[int, int, int, int, int]:
    """Capture mutation-sensitive file metadata."""
    s = path.stat()
    return s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns


def file_bytes(path: Path) -> bytes:
    """Read a small evidence file without accepting concurrent mutation."""
    unlinked(path)
    before = signature(path)
    data = path.read_bytes()
    require(signature(path) == before and len(data) == before[2], f'input changed during read: {path}')
    return data


def file_row(path: Path, target: str) -> dict[str, Any]:
    """Bind one source file to the eventual portable bundle location."""
    require(safe_name(target), f'unsafe target: {target}')
    data = file_bytes(path)
    return {'source': str(path), 'target': target, 'bytes': len(data), 'sha256': sha(data)}


def read_record(path: Path) -> tuple[dict[str, Any], bytes]:
    """Read strict object JSON while retaining its exact byte binding."""
    data = file_bytes(path)
    value = json.loads(data, parse_constant=lambda text: (_ for _ in ()).throw(Refusal(f'nonfinite JSON: {text}')))
    require(isinstance(value, dict), f'JSON input is not an object: {path}')
    return value, data


def validate_completed_support(manifest: dict[str, Any], rank: dict[str, Any],
                               snapshot: dict[str, Any], summary: dict[str, Any],
                               receipt: dict[str, Any], support: dict[str, Any],
                               wrappers: list[dict[str, Any]], raw_lines: list[bytes],
                               trusted_cache_hashes: dict[str, str]) -> None:
    """Verify completed receipt consistency without recomputing diagnostics."""
    self_hash(manifest, 'manifest_content_sha256')
    require(manifest.get('manifest_content_sha256') == MANIFEST_CONTENT,
            'manifest content binding differs')
    planned = manifest['plan']
    ids = {row['cell_id'] for row in planned}
    require(type(manifest.get('planned_fits')) is int and manifest['planned_fits'] == 1625
            and len(planned) == len(ids) == 1625, 'frozen plan is not exactly 1625 unique cells')
    self_hash(rank, 'content_sha256')
    require(rank.get('available_source_cells_scanned') == 1625
            and rank.get('planned_source_cells') == 1625
            and rank.get('source_grid_counts') == {'planned': 1625, 'stored': 1625},
            'rank snapshot does not cover all 1625 source cells')
    require(rank.get('evidence_status') == 'post_hoc_failure_provenance'
            and rank.get('scientific_model_fits_performed') is False,
            'rank evidence classification differs')
    bindings = rank['bindings']
    for key, expected in {'source_manifest_sha256': MANIFEST_SHA,
                          'source_manifest_content_sha256': MANIFEST_CONTENT,
                          'source_git_commit': PRODUCTION,
                          'source_freeze_content_sha256': FREEZE_CONTENT,
                          'matched_sha256': MATCHED_SHA,
                          'audit_helper_sha256': RANK_HELPER}.items():
        require(bindings.get(key) == expected, f'rank binding differs: {key}')
    rows = snapshot['source_cells']
    cell_ids = [Path(row['path']).stem for row in rows]
    require(snapshot.get('manifest_sha256') == MANIFEST_SHA
            and snapshot.get('planned_cells') == 1625 and len(rows) == len(set(cell_ids)) == 1625
            and set(cell_ids) == ids, 'boundary snapshot does not bind the exact full grid')
    cells = {Path(row['path']).stem: row for row in rows}
    require(len(rank['cases']) == rank.get('rank_failed_cells_audited')
            and len({row['cell_id'] for row in rank['cases']}) == len(rank['cases']),
            'rank case inventory count/uniqueness differs')
    for case in rank['cases']:
        require(case['cell_id'] in cells and cells[case['cell_id']]['status'] == 'failed'
                and case['source_cell_sha256'] == cells[case['cell_id']]['sha256'],
                'rank and boundary source-cell byte bindings differ')
    self_hash(summary, 'result_content_sha256')
    self_hash(receipt, 'receipt_content_sha256')
    for value in (summary, receipt):
        require(value.get('audit_complete') is True and value.get('scope_complete') is True,
                'boundary completion or scope remains incomplete')
    require(summary.get('source_cells') == 1625
            and summary.get('referenced_diagnostic_scope_complete') is True,
            'boundary result does not cover the full referenced diagnostic scope')
    require(type(summary.get('diagnostic_boundary_clean')) is bool, 'boundary clean flag is absent')
    expected_status = 'complete_clean' if summary['diagnostic_boundary_clean'] else 'complete_with_findings'
    require(summary.get('status') == receipt.get('status') == expected_status,
            'boundary finding status differs; findings may be reviewed without being clean')
    for key, expected in {'source_manifest_sha256': MANIFEST_SHA,
                          'driver_sha256': BOUNDARY_DRIVER,
                          'trusted_helper_sha256': TRUSTED_HELPER}.items():
        require(receipt.get(key) == expected, f'boundary completion binding differs: {key}')
    require(snapshot.get('driver_sha256') == BOUNDARY_DRIVER
            and snapshot.get('trusted_helper_sha256') == TRUSTED_HELPER,
            'boundary source snapshot helper binding differs')
    require(snapshot.get('cache_artefact_sha256') == receipt.get('cache_artefact_sha256')
            == trusted_cache_hashes, 'boundary trusted historical cache byte bindings differ')
    jobs = snapshot['jobs']
    require(len(jobs) == len(wrappers) == len(raw_lines) == summary.get('referenced_traces')
            == len(receipt['record_bindings']), 'boundary referenced-record count differs')
    identities = [(j['cell_id'], j['attempt'], j['trace_label']) for j in jobs]
    require(len(set(identities)) == len(identities), 'duplicate boundary trace job')
    for job, wrap, raw, record_binding in zip(jobs, wrappers, raw_lines, receipt['record_bindings'], strict=True):
        require(wrap['job'] == job and wrap['job_content_sha256'] == canonical(job)
                == canonical(wrap['job'])
                and wrap['record_content_sha256'] == canonical(wrap['record'])
                and wrap.get('trusted_helper_sha256') == TRUSTED_HELPER,
                'boundary record/job content binding differs')
        expected = {'cell_id': job['cell_id'], 'attempt': job['attempt'],
                    'trace_label': job['trace_label'], 'origin': wrap['origin'],
                    'job_content_sha256': wrap['job_content_sha256'],
                    'record_content_sha256': wrap['record_content_sha256'],
                    'written_line_sha256': sha(raw),
                    'cached_record_line_sha256': wrap['cached_record_line_sha256']}
        require(record_binding == expected, 'boundary completion line binding differs')
    require(support.get('status') == 'postfit_support_complete_review_pending'
            and support.get('source_cells') == 1625 and support.get('rank_audit_exit_code') == 0
            and support.get('boundary_exit_code') == (0 if summary['diagnostic_boundary_clean'] else 1)
            and support.get('boundary_diagnostic_findings') is (not summary['diagnostic_boundary_clean'])
            and support.get('driver_sha256') == COMPANION_SHA
            and support.get('transfer_tool_commit') == TOOL_COMMIT
            and support.get('models_fitted') is False and support.get('frozen_gate_changed') is False,
            'companion marker is not the completed reviewed-source supporting run')


def validate_root_review(review: dict[str, Any], required: dict[str, str]) -> None:
    """Require an actual root review binding the completed support bytes."""
    require(review.get('schema_version') == 1 and review.get('status') == 'completed_support_reviewed'
            and review.get('reviewer') == 'root' and review.get('source_cells') == 1625
            and review.get('findings_reviewed') is True
            and review.get('approved_for_validation_bundle') is True,
            'actual completed root support review is absent or does not approve preservation')
    timestamp = review.get('reviewed_utc')
    require(isinstance(timestamp, str), 'root review UTC timestamp is absent')
    parsed = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
    require(parsed.utcoffset() == timezone.utc.utcoffset(parsed), 'root review timestamp is not explicit UTC')
    require(isinstance(review.get('bindings'), dict), 'root review byte bindings are absent')
    for name, expected in required.items():
        require(review['bindings'].get(name) == expected, f'root review does not bind completed input: {name}')


def archive_member(row: dict[str, Any]) -> bytes:
    """Read only a byte-pinned ordinary tar member; never extract old evidence."""
    archive = Path(row['archive'])
    require(sha(file_bytes(archive)) == row['archive_sha256'], 'historical source archive differs')
    with tarfile.open(archive, 'r:gz') as tar:
        members = [m for m in tar.getmembers() if m.name == row['member']]
        require(len(members) == 1 and members[0].isfile(), 'missing/unsafe/duplicate historical archive member')
        stream = tar.extractfile(members[0])
        require(stream is not None, 'historical archive member is unreadable')
        with stream:
            data = stream.read()
    require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'historical archive member bytes differ')
    return data


def validate_prepared_inputs(record: dict[str, Any]) -> None:
    """Confirm all fixed historical inventories before creating output."""
    self_hash(record, 'manifest_content_sha256')
    require(record.get('status') == 'prepared_historical_inputs_dynamic_completion_pending',
            'prepared input manifest classification differs')
    for tree in record['fixed_trees']:
        root = Path(tree['source'])
        unlinked(root, directory=True)
        actual = []
        for path in sorted(root.rglob('*')):
            relative_parts = path.relative_to(root).parts
            require(not path.is_symlink(), f'linked historical tree member: {path}')
            if '__pycache__' in path.parts or path.suffix == '.pyc' or any(
                    part in tree.get('excluded_parts', []) for part in relative_parts):
                continue
            if path.is_file():
                actual.append(path.relative_to(root).as_posix())
            else:
                require(path.is_dir(), f'nonordinary historical tree member: {path}')
        require(actual == tree['relative_files'], f'historical tree inventory changed: {root}')
    for row in record['files']:
        actual = file_row(Path(row['source']), row['target'])
        require(actual == row, f'prepared historical bytes differ: {row["source"]}')
    for row in record['archive_members']:
        require(safe_name(row['target']), 'unsafe archived member output name')
        archive_member(row)


def completed_inputs(review: dict[str, Any], trusted_cache_hashes: dict[str, str]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Read small full-support receipts, records and logs, never NetCDF arrays."""
    support, support_bytes = read_record(SUPPORT)
    rank_path = Path(support['rank_result']['snapshot'])
    require(rank_path.parent == RANK_ROOT / 'snapshots', 'rank snapshot is outside frozen audit output')
    rank, rank_bytes = read_record(rank_path)
    require(rank_path.name == f'failure_provenance_{rank["content_sha256"]}.json',
            'rank snapshot filename content address differs')
    require(sha(rank_bytes) == support['rank_result']['snapshot_sha256']
            and rank['content_sha256'] == support['rank_result']['snapshot_content_sha256']
            and rank.get('rank_failed_cells_audited') == support['rank_result']['rank_failed_cells_audited'],
            'companion rank result byte/content/count binding differs')
    manifest, manifest_bytes = read_record(MANIFEST)
    require(sha(manifest_bytes) == MANIFEST_SHA, 'current frozen manifest bytes differ')
    snapshot, snapshot_bytes = read_record(BOUNDARY / 'source_snapshot.json')
    summary, summary_bytes = read_record(BOUNDARY / 'audit_summary.json')
    receipt, receipt_bytes = read_record(BOUNDARY / 'completion_receipt.json')
    records_bytes = file_bytes(BOUNDARY / 'trace_records.jsonl')
    lines = records_bytes.splitlines(keepends=True)
    require(all(line.endswith(b'\n') for line in lines), 'completed boundary JSONL has an unfinished line')
    wrappers = [json.loads(line) for line in lines]
    validate_completed_support(manifest, rank, snapshot, summary, receipt, support, wrappers, lines,
                               trusted_cache_hashes)
    output_bytes = {'source_snapshot.json': snapshot_bytes, 'audit_summary.json': summary_bytes,
                    'trace_records.jsonl': records_bytes}
    require(receipt['output_sha256'] == {name: sha(data) for name, data in output_bytes.items()},
            'boundary completion output byte hashes differ')
    require(sha(receipt_bytes) == support['boundary_completion_receipt_sha256']
            and sha(summary_bytes) == support['boundary_summary_sha256'],
            'companion boundary output byte bindings differ')
    require(set(support['logs_sha256']) == {str(p) for p in REQUIRED_LOGS[:4]},
            'companion recorded audit log inventory differs')
    rows = [file_row(SUPPORT, 'support_completion/postfit_support_prepared_v1.json'),
            file_row(rank_path, 'support_completion/failure_provenance_v2/' + rank_path.name),
            file_row(MANIFEST, 'support_completion/frozen_source_manifest.json')]
    rows += [file_row(BOUNDARY / name, 'diagnostic_boundary_fullgrid_v1/full_grid_result/' + name)
             for name in (*output_bytes, 'completion_receipt.json')]
    rows += [file_row(path, 'support_completion/logs/' + path.name) for path in REQUIRED_LOGS]
    required = {row['source']: row['sha256'] for row in rows}
    for name, expected in support['logs_sha256'].items():
        require(required[name] == expected, f'completed audit log changed: {name}')
    for name in ['complete_postfit_support_v1.py', 'postfit_support_process_v1.json',
                 'postfit_support_review_v1/review_receipt.json', 'postfit_support_review_v1/report.md']:
        row = file_row(BASE / name, 'companion/current/' + name)
        required[row['source']] = row['sha256']
    validate_root_review(review, required)
    detail = {'source_cells': 1625, 'rank_snapshot_sha256': sha(rank_bytes),
              'rank_snapshot_content_sha256': rank['content_sha256'],
              'rank_failed_cells_audited': rank['rank_failed_cells_audited'],
              'boundary_status': summary['status'],
              'boundary_diagnostic_clean': summary['diagnostic_boundary_clean'],
              'boundary_result_content_sha256': summary['result_content_sha256'],
              'boundary_completion_content_sha256': receipt['receipt_content_sha256'],
              'root_review_required_bindings': required,
              'science_qa_official92_publication_restore_completion': 'not_assessed',
              'full_current_failure_v2_tree': 'separate stager --failure-audit input; only its bound full snapshot retained here'}
    return rows, detail


def copy_checked(row: dict[str, Any], output: Path) -> None:
    """Copy one source with exclusive creation and verify its round trip."""
    path, destination = Path(row['source']), output / row['target']
    unlinked(path)
    before = signature(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as source, destination.open('xb') as target:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            target.write(chunk)
            count += len(chunk)
            digest.update(chunk)
        target.flush()
        os.fsync(target.fileno())
    require(signature(path) == before and digest.hexdigest() == row['sha256']
            and count == row['bytes'], f'source changed during copy: {path}')
    copied = file_bytes(destination)
    require(len(copied) == row['bytes'] and sha(copied) == row['sha256'],
            f'copy roundtrip failed: {row["target"]}')


def write_once(path: Path, data: bytes) -> None:
    """Publish new exact bytes without overwriting any path."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    require(file_bytes(path) == data, f'write roundtrip failed: {path}')


def prepare_plan(output: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """Validate all prerequisites before any bundle directory is created."""
    require(HERE == EXPECTED_HERE, 'assembler must run from its prepared external source directory')
    output_policy(output, output.exists() or output.is_symlink(),
                  BASE.is_dir() and not any(p.is_symlink() for p in (BASE, *BASE.parents)))
    review, _ = read_record(ROOT_REVIEW)  # genuinely pending; never fabricated here
    manifest, _ = read_record(HERE / 'input_manifest.json')
    validation, detail = completed_inputs(review, manifest['frozen_support_pins']['trusted_cache_artefact_sha256'])
    validate_prepared_inputs(manifest)
    prep, _ = read_record(HERE / 'preparation_receipt.json')
    for name, expected in prep['files'].items():
        require(safe_name(name) and sha(file_bytes(HERE / name)) == expected['sha256'],
                f'assembler preparation changed: {name}')
    rows = [*manifest['files'], *validation,
            file_row(ROOT_REVIEW, 'support_completion/completed_support_review_v1.json')]
    for path in sorted(HERE.rglob('*')):
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        require(not path.is_symlink(), 'linked assembler preparation member')
        if path.is_file():
            rows.append(file_row(path, 'bundle_preparation/' + path.relative_to(HERE).as_posix()))
    members = manifest['archive_members']
    targets = [r['target'] for r in (*rows, *members)]
    require(len(set(targets)) == len(targets) and all(safe_name(n) for n in targets),
            'duplicate/unsafe final payload target')
    require(not any(Path(r['source']).is_relative_to(output) for r in rows),
            'output overlaps a required immutable source')
    detail['input_manifest_sha256'] = sha(file_bytes(HERE / 'input_manifest.json'))
    detail['completed_support_review_sha256'] = sha(file_bytes(ROOT_REVIEW))
    detail['assembler_sha256'] = sha(file_bytes(Path(__file__).absolute()))
    return rows, members, detail


def main() -> None:
    """Preserve supporting bytes only after a later actual root review."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument('--check-only', action='store_true', help='check small receipts/support bytes only; do not write a bundle or inspect scientific traces')
    args = parser.parse_args()
    rows, members, detail = prepare_plan(args.output)
    inventory = [{'path': row['target'], 'bytes': row['bytes'], 'sha256': row['sha256']}
                 for row in (*rows, *members)]
    inventory.sort(key=lambda row: row['path'])
    content_sha = canonical(inventory)
    if args.check_only:
        print(json.dumps({'status': 'ready_to_preserve_support_only', 'payload_files': len(inventory),
                          'payload_content_sha256': content_sha, 'gates': detail}, indent=2, sort_keys=True))
        return
    # All required source inventories, bytes, complete receipts and root review
    # have been verified. A concurrent creator still cannot be overwritten.
    args.output.mkdir(exist_ok=False)
    for row in rows:
        copy_checked(row, args.output)
    for row in members:
        write_once(args.output / row['target'], archive_member(row))
    # Reject source changes during copying before publishing the final receipt.
    final_rows, final_members, final_detail = prepare_plan_for_existing_output(args.output)
    require(final_rows == rows and final_members == members and final_detail == detail,
            'support source/gates changed during preservation')
    for row in inventory:
        data = file_bytes(args.output / row['path'])
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'final payload verification differs')
    inventory_record = {'schema_version': 1, 'scope': 'payload only; manifests/receipt are separately bound',
                        'files': inventory, 'payload_content_sha256': content_sha}
    inventory_path = f'inventories/payload_{content_sha}.json'
    inventory_bytes = encoded(inventory_record)
    write_once(args.output / inventory_path, inventory_bytes)
    manifest = {'schema_version': 1, 'classification': 'implementation_and_supporting_audit_preservation',
                'created_utc': datetime.now(timezone.utc).isoformat(),
                'content_sha256': content_sha, 'files': inventory,
                'content_addressed_inventory': inventory_path,
                'inventory_sha256': sha(inventory_bytes), 'completed_support': detail,
                'historical_752_snapshot': 'preserved unchanged; not a full-grid claim',
                'numerical_programme_completion': 'not_assessed',
                'qa_official92_artifact_gates': 'separately enforced by stage_extensions.py',
                'publication_and_fresh_restore': 'not_assessed'}
    manifest_bytes = encoded(manifest)
    write_once(args.output / 'bundle_manifest.json', manifest_bytes)
    receipt = {'schema_version': 1, 'verified_utc': datetime.now(timezone.utc).isoformat(),
               'status': 'support_bundle_preserved_byte_roundtrip_verified',
               'output': str(args.output), 'payload_files_verified': len(inventory),
               'payload_bytes_verified': sum(row['bytes'] for row in inventory),
               'payload_content_sha256': content_sha, 'inventory_path': inventory_path,
               'inventory_sha256': sha(inventory_bytes), 'bundle_manifest_sha256': sha(manifest_bytes),
               'assembler_sha256': detail['assembler_sha256'],
               'input_manifest_sha256': detail['input_manifest_sha256'],
               'completed_support_review_sha256': detail['completed_support_review_sha256'],
               'science_qa_official92_publication_restore_completion': 'not_assessed',
               'fits_or_scientific_audits_executed': False}
    receipt['receipt_content_sha256'] = canonical(receipt)
    write_once(args.output / 'bundle_receipt.json', encoded(receipt))
    print(json.dumps(receipt, indent=2, sort_keys=True))


def prepare_plan_for_existing_output(output: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """Revalidate sources without weakening the public new-output-only entry."""
    # Avoid bypassing output_policy: plan under a guaranteed nonexistent sibling
    # is identical because output paths are deliberately not part of evidence.
    candidate = output.with_name(output.name + '_internal_recheck_' + str(os.getpid()))
    require(not candidate.exists() and not candidate.is_symlink(), 'internal recheck name unexpectedly exists')
    return prepare_plan(candidate)


if __name__ == '__main__':
    try:
        main()
    except (Refusal, OSError, ValueError, KeyError, TypeError) as exc:
        raise SystemExit(f'SUPPORT BUNDLE REFUSED: {exc}') from exc
