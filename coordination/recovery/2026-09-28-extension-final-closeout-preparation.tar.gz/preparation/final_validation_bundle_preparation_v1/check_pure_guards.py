"""Exercise only synthetic in-memory evidence guards; never assemble/audit."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import assemble_validation_bundle as assembly


def fixture() -> list:
    """Construct complete synthetic receipts to test metadata logic only."""
    manifest = {'planned_fits': 1625, 'plan': [{'cell_id': f'cell_{i:04d}'} for i in range(1625)]}
    manifest['manifest_content_sha256'] = assembly.canonical(manifest)
    # A synthetic fixture cannot collide with the real frozen hash. The override
    # exists only in this separate pure-check process; no prepared source changes.
    assembly.MANIFEST_CONTENT = manifest['manifest_content_sha256']
    cache = {'artifact_receipt.json': 'a' * 64, 'audit_saved_diagnostics.py': assembly.TRUSTED_HELPER}
    rank = {'schema_version': 1, 'available_source_cells_scanned': 1625, 'planned_source_cells': 1625,
            'source_grid_counts': {'planned': 1625, 'stored': 1625},
            'evidence_status': 'post_hoc_failure_provenance', 'scientific_model_fits_performed': False,
            'bindings': {'source_manifest_sha256': assembly.MANIFEST_SHA,
                         'source_manifest_content_sha256': assembly.MANIFEST_CONTENT,
                         'source_git_commit': assembly.PRODUCTION,
                         'source_freeze_content_sha256': assembly.FREEZE_CONTENT,
                         'matched_sha256': assembly.MATCHED_SHA, 'audit_helper_sha256': assembly.RANK_HELPER},
            'rank_failed_cells_audited': 1,
            'cases': [{'cell_id': 'cell_0000', 'source_cell_sha256': 'b' * 64}]}
    rank['content_sha256'] = assembly.canonical(rank)
    job = {'cell_id': 'cell_0001', 'attempt': 1, 'trace_label': 'posterior', 'value': 1}
    snapshot = {'manifest_sha256': assembly.MANIFEST_SHA, 'planned_cells': 1625,
                'source_cells': [{'path': f'/synthetic/cells/cell_{i:04d}.json', 'sha256': 'b' * 64,
                                 'status': 'failed' if i == 0 else 'complete'} for i in range(1625)],
                'jobs': [job], 'driver_sha256': assembly.BOUNDARY_DRIVER,
                'trusted_helper_sha256': assembly.TRUSTED_HELPER, 'cache_artefact_sha256': cache}
    wrap = {'job': job, 'job_content_sha256': assembly.canonical(job), 'record': {'checked': True},
            'record_content_sha256': assembly.canonical({'checked': True}),
            'trusted_helper_sha256': assembly.TRUSTED_HELPER, 'origin': 'new_pinned_helper_inspection',
            'cached_record_line_sha256': None}
    raw = (json.dumps(wrap, sort_keys=True) + '\n').encode()
    summary = {'audit_complete': True, 'scope_complete': True, 'source_cells': 1625,
               'referenced_diagnostic_scope_complete': True, 'diagnostic_boundary_clean': True,
               'status': 'complete_clean', 'referenced_traces': 1}
    summary['result_content_sha256'] = assembly.canonical(summary)
    receipt = {'audit_complete': True, 'scope_complete': True, 'status': 'complete_clean',
               'source_manifest_sha256': assembly.MANIFEST_SHA, 'driver_sha256': assembly.BOUNDARY_DRIVER,
               'trusted_helper_sha256': assembly.TRUSTED_HELPER, 'cache_artefact_sha256': cache,
               'record_bindings': [{'cell_id': job['cell_id'], 'attempt': 1, 'trace_label': 'posterior',
                   'origin': wrap['origin'], 'job_content_sha256': wrap['job_content_sha256'],
                   'record_content_sha256': wrap['record_content_sha256'], 'written_line_sha256': assembly.sha(raw),
                   'cached_record_line_sha256': None}]}
    receipt['receipt_content_sha256'] = assembly.canonical(receipt)
    support = {'status': 'postfit_support_complete_review_pending', 'source_cells': 1625,
               'rank_audit_exit_code': 0, 'boundary_exit_code': 0, 'boundary_diagnostic_findings': False,
               'driver_sha256': assembly.COMPANION_SHA, 'transfer_tool_commit': assembly.TOOL_COMMIT,
               'models_fitted': False, 'frozen_gate_changed': False}
    return [manifest, rank, snapshot, summary, receipt, support, [wrap], [raw], cache]


def resign(record: dict, field: str) -> None:
    """Refresh a mutated synthetic canonical hash to test semantic guards."""
    record[field] = assembly.canonical({k: v for k, v in record.items() if k != field})


def main() -> None:
    """Report synthetic checks without filesystem mutations or actual results."""
    passed = []
    valid = fixture()

    def accept(name: str, operation) -> None:
        operation()
        passed.append({'name': name, 'outcome': 'accepted_expected_valid_synthetic_input'})

    def reject(name: str, operation) -> None:
        try:
            operation()
        except (assembly.Refusal, ValueError, TypeError, KeyError):
            passed.append({'name': name, 'outcome': 'refused_expected_invalid_synthetic_input'})
        else:
            raise AssertionError(f'guard unexpectedly accepted: {name}')

    def change(name: str, operation) -> None:
        case = copy.deepcopy(valid)
        operation(case)
        reject(name, lambda: assembly.validate_completed_support(*case))

    accept('complete_clean_support', lambda: assembly.validate_completed_support(*valid))
    findings = copy.deepcopy(valid)
    findings[3].update(diagnostic_boundary_clean=False, status='complete_with_findings')
    resign(findings[3], 'result_content_sha256')
    findings[4]['status'] = 'complete_with_findings'
    resign(findings[4], 'receipt_content_sha256')
    findings[5].update(boundary_exit_code=1, boundary_diagnostic_findings=True)
    accept('complete_findings_remain_reviewable_no_new_clean_gate',
           lambda: assembly.validate_completed_support(*findings))
    change('rank_partial_1624', lambda c: (c[1].update(available_source_cells_scanned=1624), resign(c[1], 'content_sha256')))
    change('rank_bad_content_hash', lambda c: c[1].update(content_sha256='0' * 64))
    change('rank_helper_changed', lambda c: (c[1]['bindings'].update(audit_helper_sha256='0' * 64), resign(c[1], 'content_sha256')))
    change('rank_wrong_production', lambda c: (c[1]['bindings'].update(source_git_commit='0' * 40), resign(c[1], 'content_sha256')))
    change('rank_cell_bytes_changed', lambda c: (c[1]['cases'][0].update(source_cell_sha256='c' * 64), resign(c[1], 'content_sha256')))
    change('rank_claimed_fitting', lambda c: (c[1].update(scientific_model_fits_performed=True), resign(c[1], 'content_sha256')))
    change('boundary_missing_cell', lambda c: c[2]['source_cells'].pop())
    change('boundary_duplicate_cell', lambda c: c[2]['source_cells'].__setitem__(1, c[2]['source_cells'][0]))
    change('boundary_incomplete_scope', lambda c: (c[4].update(scope_complete=False), resign(c[4], 'receipt_content_sha256')))
    change('boundary_bad_summary_content', lambda c: c[3].update(result_content_sha256='0' * 64))
    change('boundary_driver_changed', lambda c: (c[4].update(driver_sha256='0' * 64), resign(c[4], 'receipt_content_sha256')))
    change('boundary_cache_changed', lambda c: c[2].update(cache_artefact_sha256={'artifact_receipt.json': '0' * 64}))
    change('boundary_missing_record', lambda c: c[6].clear())
    change('boundary_record_hash_changed', lambda c: c[6][0].update(record_content_sha256='0' * 64))
    change('boundary_line_bytes_changed', lambda c: c[7].__setitem__(0, c[7][0] + b' '))
    change('boundary_integer_float_job_change', lambda c: c[6][0]['job'].update(value=1.0))
    change('companion_not_completed', lambda c: c[5].update(status='pending'))
    change('companion_source_changed', lambda c: c[5].update(driver_sha256='0' * 64))
    change('companion_findings_status_conflict', lambda c: c[5].update(boundary_exit_code=1))
    change('companion_gate_changed', lambda c: c[5].update(frozen_gate_changed=True))

    required = {'/synthetic/full_rank.json': 'a' * 64, '/synthetic/boundary_receipt.json': 'b' * 64}
    review = {'schema_version': 1, 'status': 'completed_support_reviewed', 'reviewer': 'root',
              'reviewed_utc': '2026-09-28T00:00:00+00:00', 'source_cells': 1625,
              'findings_reviewed': True, 'approved_for_validation_bundle': True, 'bindings': required}
    accept('actual_style_root_review_bindings', lambda: assembly.validate_root_review(review, required))
    for name, field, value in [('missing_root_approval', 'approved_for_validation_bundle', False),
                               ('findings_unreviewed', 'findings_reviewed', False),
                               ('wrong_reviewer', 'reviewer', 'assembler'),
                               ('pending_review_status', 'status', 'pending'),
                               ('review_timestamp_without_zone', 'reviewed_utc', '2026-09-28T00:00:00')]:
        case = copy.deepcopy(review)
        case[field] = value
        reject(name, lambda c=case: assembly.validate_root_review(c, required))
    case = copy.deepcopy(review)
    case['bindings']['/synthetic/full_rank.json'] = 'c' * 64
    reject('review_does_not_bind_actual_rank_bytes', lambda: assembly.validate_root_review(case, required))
    case = copy.deepcopy(review)
    case['bindings'].pop('/synthetic/boundary_receipt.json')
    reject('review_missing_completed_byte_binding', lambda: assembly.validate_root_review(case, required))

    accept('fresh_bundle_path', lambda: assembly.output_policy(assembly.DEFAULT_OUTPUT, False, True))
    reject('existing_bundle_before_output', lambda: assembly.output_policy(assembly.DEFAULT_OUTPUT, True, True))
    reject('linked_output_parent', lambda: assembly.output_policy(assembly.DEFAULT_OUTPUT, False, False))
    reject('output_inside_historical_bundle', lambda: assembly.output_policy(assembly.BASE / 'integration_validation_bundle_v2/new', False, True))
    reject('output_inside_repo', lambda: assembly.output_policy(Path('/synthetic/project/integration_validation_bundle_v3'), False, True))
    for value in ['../escape', '/absolute', 'x/../y', 'x//y', 'x\\y', './x', '']:
        reject('unsafe_payload_name_' + repr(value), lambda n=value: assembly.require(assembly.safe_name(n), 'unsafe name'))
    accept('portable_payload_name', lambda: assembly.require(assembly.safe_name('historical/file.json'), 'safe name refused'))
    print(json.dumps({'status': 'syntax_and_synthetic_in_memory_guards_passed',
                      'checks_passed': len(passed), 'checks': passed,
                      'actual_grid_or_traces_read': False, 'assembler_executed': False,
                      'review_record_created': False, 'filesystem_output_created_by_checks': False,
                      'scientific_or_transfer_completion_asserted': False}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
