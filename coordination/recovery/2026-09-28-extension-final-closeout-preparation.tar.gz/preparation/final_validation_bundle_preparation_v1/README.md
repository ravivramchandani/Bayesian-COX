# Prepared supporting-evidence bundle assembler

`assemble_validation_bundle.py` uses only the Python standard library. It has
not assembled v3, run scientific audits, inspected NetCDF traces, or approved
root's findings review. The existing v1/v2 bundles remain untouched.

The prepared input manifest pins 359 small historical files (12,075,561 bytes)
and six verified archive members. It includes all five transfer-validation
versions, both previous bundles with baseline269/cached752/coordinator history,
doc57 and pushed postfit50 archives/receipts/reviews, original and current
companion source/review/ownership, complete failure-v1 plus its exact `6b6655…`
helper, partial failure-v2 proof and tool-worktree receipt, boundary preparation,
both receiving guides and APFS receipts, ExFAT failure/preflight/space evidence,
both runbooks/reviews, and the finalized claim-review preparation. No required
historical input is missing. The original coordinator log is a dated immutable
capture; its original pathname is not assumed stable. The initial manifest is
retained as `input_manifest_pre_review.json` and is historical only.

The entire current `failure_provenance_v2` tree is a separate stager
`--failure-audit` input. This bundle additionally binds its final full snapshot.
The cached 752-cell audit remains explicitly historical. A full supporting
boundary result may have findings; root reviews them without adding a new
fitting acceptance gate. Orphan trace bytes are inventoried by that audit but
are not described as diagnostically inspected.

## Later execution, after actual audits and root review

Run these only after the existing companion has finished and root has reviewed
the actual results. Both commands require the completed support marker, full
rank snapshot, all four boundary result files, completed stable companion/audit
logs, and root's genuine review record. The first command creates no output.

```sh
PYTHON='/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python'
PREPARATION='/Users/macuser/bayes-cox-runs/extensions-20260928/final_validation_bundle_preparation_v1'
"$PYTHON" -B "$PREPARATION/assemble_validation_bundle.py" --check-only
"$PYTHON" -B "$PREPARATION/assemble_validation_bundle.py" \
  --output '/Users/macuser/bayes-cox-runs/extensions-20260928/integration_validation_bundle_v3'
```

Any existing destination is refused. Missing/incomplete/changed required inputs
are refused before output directories are created. After checks, copies use
exclusive file creation, source mutation checks, target byte roundtrip checks,
and a second complete prerequisite check. `inventories/payload_<hash>.json`
addresses the payload inventory by its canonical hash. `bundle_manifest.json`
binds it; `bundle_receipt.json` is written last and binds the complete copied
payload. If a copy fails, a partial directory may remain without that final
receipt; preserve it and choose a new `integration_validation_bundle_v3…`
destination after resolving the failure. Nothing is overwritten or deleted.

## Pending root review contract

The helper **never creates**
`/Users/macuser/bayes-cox-runs/extensions-20260928/completed_support_review_v1.json`.
It must be written by root only after actual review, with these fields:

| Field | Required actual value |
|---|---|
| `schema_version` | `1` |
| `status` | `completed_support_reviewed` |
| `reviewer` | `root` |
| `reviewed_utc` | Actual review time with explicit UTC timezone |
| `source_cells` | `1625` |
| `findings_reviewed` | `true`, after reviewing actual findings |
| `approved_for_validation_bundle` | `true`, only approving support preservation |
| `bindings` | Absolute input paths mapped to actual SHA-256 byte hashes |

Required byte bindings under the execution root are:

- `postfit_support_prepared_v1.json`, `run/manifest.json`;
- the exact full rank snapshot path named by the completed support marker;
- `diagnostic_boundary_fullgrid_v1/full_grid_result/{source_snapshot.json,trace_records.jsonl,audit_summary.json,completion_receipt.json}`;
- `worker_logs/postfit_support_{rank_v1.log,rank_v1.stderr.log,boundary_v1.log,boundary_v1.stderr.log,companion_v1.log}`;
- `complete_postfit_support_v1.py`, `postfit_support_process_v1.json`;
- `postfit_support_review_v1/{review_receipt.json,report.md}`.

The gate requires actual completed 1,625-cell rank/source metadata, canonical
content hashes, boundary record/line/output byte hashes, frozen helper/cache
bindings, and matching root-review hashes. It does not rerun numerical
diagnostics, claim full primary latent/energy coverage, or certify science.
Final numerical acceptance, official92 comparisons, visual QA and artifact
gates remain with the stager. Publication and fresh restore remain separate.

`preparation_receipt.json` records syntax and synthetic in-memory checks only.
The synthetic clean and findings fixtures are implementation checks, never
actual programme results or a fabricated root review.
