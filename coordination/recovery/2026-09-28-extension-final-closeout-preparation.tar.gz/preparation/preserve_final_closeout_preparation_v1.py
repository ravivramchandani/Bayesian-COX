"""Preserve verified final closeout preparation without touching numerical jobs."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
OUTPUT = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
PINS = {
    'final_validation_bundle_preparation_v1':
        'b3a9ad2eaf7663a95ffc8d1987918567586bffbfd899445316ee49fae0da7dab',
    'final_claim_review_preparation_v1':
        '6c71cfa31b97ed0e50f285150bf07caf3c149bfb48be7dfed26d27f47ce46ed0',
}


def sha(raw: bytes) -> str:
    """Return the digest of exact retained bytes."""
    return hashlib.sha256(raw).hexdigest()


def encoded(value: object) -> bytes:
    """Serialize a readable retained record with a final newline."""
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def check(raw: bytes, row: dict) -> None:
    """Reject a retained input whose size or digest has changed."""
    if len(raw) != row['bytes'] or sha(raw) != row['sha256']:
        raise RuntimeError('Retained preparation bytes differ')


def main() -> None:
    """Byte-check prepared tools and their historical inputs, then archive once."""
    tested_path = OUTPUT / 'transfer_validation_v5_extension_documentation/tested_source.json'
    tested = json.loads(tested_path.read_text())
    for name, expected in tested.items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise RuntimeError('Previously tested source differs')
    members = {}
    prepared = {}
    for folder, expected in PINS.items():
        directory = OUTPUT / folder
        receipt_raw = (directory / 'preparation_receipt.json').read_bytes()
        if sha(receipt_raw) != expected:
            raise RuntimeError('Reviewed preparation receipt differs')
        receipt = json.loads(receipt_raw)
        canonical = {k: v for k, v in receipt.items() if k != 'receipt_content_sha256'}
        digest = sha(json.dumps(canonical, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())
        if digest != receipt['receipt_content_sha256']:
            raise RuntimeError('Preparation canonical receipt differs')
        for rel, spec in receipt['files'].items():
            path = directory / rel
            if path.is_symlink():
                raise RuntimeError('Unexpected linked input')
            raw = path.read_bytes()
            check(raw, spec)
            members[f'preparation/{folder}/{rel}'] = raw
        members[f'preparation/{folder}/preparation_receipt.json'] = receipt_raw
        prepared[folder] = {'receipt_sha256': expected, 'bound_files_verified': len(receipt['files'])}
    manifest_raw = (OUTPUT / 'final_validation_bundle_preparation_v1/input_manifest.json').read_bytes()
    manifest = json.loads(manifest_raw)
    for row in manifest['files']:
        check(Path(row['source']).read_bytes(), row)
    for row in manifest['archive_members']:
        archive = Path(row['archive'])
        if sha(archive.read_bytes()) != row['archive_sha256']:
            raise RuntimeError('Historical archive differs')
        with tarfile.open(archive, 'r:gz') as tar:
            item = tar.getmember(row['member'])
            if not item.isfile():
                raise RuntimeError('Historical member is not an ordinary file')
            stream = tar.extractfile(item)
            if stream is None:
                raise RuntimeError('Historical member is unavailable')
            check(stream.read(), row)
    frozen_raw = (OUTPUT / 'run/manifest.json').read_bytes()
    if sha(frozen_raw) != '83b9049fb6aaaadab576b34de0741e4f510344dcefba9f96198d15b5ab4f49b9':
        raise RuntimeError('Frozen numerical manifest differs')
    planned = {row['cell_id'] for row in json.loads(frozen_raw)['plan']}
    statuses: Counter[str] = Counter()
    settings: Counter[str] = Counter()
    rows = []
    for path in sorted((OUTPUT / 'run/cells').glob('*.json')):
        raw = path.read_bytes()
        cell = json.loads(raw)
        if cell['cell_id'] != path.stem or cell['cell_id'] not in planned:
            raise RuntimeError('Unexpected stored numerical cell')
        statuses[cell['status']] += 1
        settings[f"{cell['dataset']}/{cell['setting']}"] += 1
        rows.append({'path': str(path.relative_to(OUTPUT)), 'sha256': sha(raw)})
    snapshot = {
        'observed_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Dated stored-cell accounting only; numerical and transfer completion unassessed',
        'planned_cells': len(planned), 'stored_cells': len(rows),
        'statuses': dict(statuses), 'settings': dict(settings), 'cell_bytes': rows,
        'candidate_refits': len(list((OUTPUT / 'reproduction/cells').glob('*.json'))),
        'official_refit_receipts': len(list((OUTPUT / 'reproduction/receipts').glob('*.json'))),
        'markers': {name: (OUTPUT / name).exists() for name in [
            'analysis_prepared.json', 'coordinator_failure.json',
            'postfit_support_prepared_v1.json', 'postfit_support_failure_v1.json']},
    }
    review = {
        'schema_version': 1, 'verified_utc': datetime.now(timezone.utc).isoformat(),
        'reviewer': 'root', 'status': 'preparation_reviewed_actual_completion_gates_pending',
        'preparations': prepared, 'historical_input_files_verified': len(manifest['files']),
        'historical_archive_members_verified': len(manifest['archive_members']),
        'historical_manifest_sha256': sha(manifest_raw),
        'tested_source_files_unchanged': len(tested), 'tested_source_sha256': sha(tested_path.read_bytes()),
        'claim_helper_pure_checks': 21, 'bundle_helper_pure_checks': 43,
        'models_fitted': False, 'actual_result_claim_helper_invoked': False,
        'actual_validation_bundle_assembled': False, 'visual_qa_certified': False,
        'release_download_restore_executed': False,
    }
    members['root_preparation_review.json'] = encoded(review)
    members['dated_source_snapshot.json'] = encoded(snapshot)
    members['preparation/preserve_final_closeout_preparation_v1.py'] = Path(__file__).read_bytes()
    inventory = {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())}
    members['archive_inventory.json'] = encoded(inventory)
    archive = ROOT / 'coordination/recovery/2026-09-28-extension-final-closeout-preparation.tar.gz'
    with archive.open('xb') as output, gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                tar.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive, 'r:gz') as tar:
        if {item.name for item in tar.getmembers()} != set(members):
            raise RuntimeError('Recovery member inventory differs')
        for item in tar.getmembers():
            stream = tar.extractfile(item)
            if not item.isfile() or stream is None or stream.read() != members[item.name]:
                raise RuntimeError('Recovery archive byte roundtrip differs')
    for name, expected in tested.items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise RuntimeError('Previously tested source changed during preservation')
    review.update({
        'archive': str(archive.relative_to(ROOT)), 'archive_sha256': sha(archive.read_bytes()),
        'archive_bytes': archive.stat().st_size, 'archive_members_verified': len(members),
        'archive_inventory_sha256': sha(members['archive_inventory.json']),
        'dated_partial_checkpoint': {k: v for k, v in snapshot.items() if k != 'cell_bytes'},
    })
    receipt = ROOT / 'coordination/recovery/2026-09-28-extension-final-closeout-preparation-verification.json'
    with receipt.open('xb') as output:
        output.write(encoded(review))
    print(encoded(review).decode(), end='')


if __name__ == '__main__':
    main()
