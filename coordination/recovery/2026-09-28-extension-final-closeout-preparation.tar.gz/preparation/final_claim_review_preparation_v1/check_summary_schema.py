"""Pure in-memory checks of the prepared read-only summary helper.

No actual run or result is opened, and no scientific completion is asserted.
"""

import copy
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
helper = Path(__file__).with_name("summarize_verified_claim_inputs.py")
compile(helper.read_text(), str(helper), "exec")
spec = importlib.util.spec_from_file_location("prepared_claim_summary", helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks = []


def passed(name, function):
    """Evaluate one positive pure schema check."""
    function()
    checks.append({"name": name, "outcome": "passed"})


def refused(name, function):
    """Require an inconsistent synthetic record to be rejected."""
    try:
        function()
    except (ValueError, KeyError, TypeError):
        checks.append({"name": name, "outcome": "refused_as_expected"})
    else:
        raise AssertionError(name)


def assert_true(value):
    """Require a pure check's assertion."""
    assert value


families = {}
for name, size in module.FAMILY_SIZES.items():
    families[name] = {
        "expected_contrasts": size,
        "family_complete": True,
        "contrasts": [
            {
                "dataset": "synthetic",
                "left": "a",
                "right": "b",
                "n_pairs": 25,
                "expected_pairs": 25,
                "status": "estimable",
                "effect": {},
                "holm_adjusted_p": 1.0,
                "holm_reject": False,
                "superiority_language_permitted": False,
            }
            for _ in range(size)
        ],
    }
passed("complete four-family schema", lambda: module.summarize_families(families))
partial = copy.deepcopy(families)
partial["catalytic_vs_original_priors"]["family_complete"] = False
for row in partial["catalytic_vs_original_priors"]["contrasts"]:
    for field in ("holm_adjusted_p", "holm_reject", "superiority_language_permitted"):
        row.pop(field)
row = partial["catalytic_vs_original_priors"]["contrasts"][0]
row.update(n_pairs=7, status="incomplete_no_inference")
row.pop("effect")
passed(
    "partial family retains 18 missing pairs and no Holm conclusion",
    lambda: assert_true(
        module.summarize_families(partial)["catalytic_vs_original_priors"]["missing_fold_pairs"] == 18
        and module.summarize_families(partial)["catalytic_vs_original_priors"]["stored_holm_reject_count"] is None
    ),
)
bad = copy.deepcopy(partial)
bad["catalytic_vs_original_priors"]["family_complete"] = True
refused("partial family falsely marked complete", lambda: module.summarize_families(bad))
bad = copy.deepcopy(partial)
bad["catalytic_vs_original_priors"]["contrasts"][0]["effect"] = {}
refused("effect attached to incomplete pairs", lambda: module.summarize_families(bad))
bad = copy.deepcopy(partial)
bad["catalytic_vs_original_priors"]["contrasts"][1]["holm_adjusted_p"] = 0.001
refused("adjustment attached to incomplete family", lambda: module.summarize_families(bad))
bad = copy.deepcopy(families)
bad["expression_increment"]["contrasts"].pop()
refused("missing comparison row", lambda: module.summarize_families(bad))

rq2 = [
    {
        "dataset": d,
        "model": m,
        "prior": p,
        "condition": c,
        "kind": k,
        "expected_pairs": 10,
        "n_pairs": 10,
        "role": "descriptive_no_significance_claim",
        "mean_difference": 0.0,
        "corrected_descriptive_interval": {},
    }
    for d in ("gbsg2", "whas500", "metabric")
    for m in module.NEW_MODELS[-3:]
    for p in module.ORIGINAL_MODELS[-3:]
    for c in module.RQ2_CONDITIONS
    for k in ("direct", "difference_in_differences")
]
passed("270 descriptive RQ2 row schema", lambda: assert_true(module.summarize_rq2(rq2)["full_coverage_rows"] == 270))
partial_rq2 = copy.deepcopy(rq2)
partial_rq2[0].update(n_pairs=0, mean_difference=None)
partial_rq2[0].pop("corrected_descriptive_interval")
partial_rq2[1].update(n_pairs=4)
partial_rq2[1].pop("corrected_descriptive_interval")
passed(
    "RQ2 zero and partial pairs remain counted",
    lambda: assert_true(
        module.summarize_rq2(partial_rq2)["zero_pair_rows"] == 1
        and module.summarize_rq2(partial_rq2)["missing_pair_slots"] == 16
    ),
)
bad = copy.deepcopy(partial_rq2)
bad[1]["corrected_descriptive_interval"] = {}
refused("interval attached to partial RQ2 coverage", lambda: module.summarize_rq2(bad))
bad = copy.deepcopy(rq2)
bad[0]["corrected_descriptive_interval"]["p_value"] = 0.001
refused("new RQ2 significance claim", lambda: module.summarize_rq2(bad))
refused("missing RQ2 row", lambda: module.summarize_rq2(rq2[:-1]))

groups = {}
for dataset, setting in module.SETTINGS:
    models = set(module.ORIGINAL_MODELS + module.NEW_MODELS)
    if dataset != "metabric_matched":
        models.add("bayesian_horseshoe_original")
    for h in (1, 2, 3):
        groups[f"{dataset}__{setting}__h{h}"] = {
            "thresholds": [i / 100 for i in range(1, 51)],
            "horizon_rule": (0.25, 0.5, 0.75)[h - 1],
            "unavailable": dict.fromkeys(models, "synthetic unavailable"),
            "support": {},
        }
passed(
    "15-group all-unavailable DCA counts 204 exclusions",
    lambda: assert_true(module.summarize_dca(groups)["unavailable_model_horizon_slots"] == 204),
)
available = copy.deepcopy(groups)
key = next(iter(available))
available[key]["unavailable"].pop("ridge")
available[key]["support"]["ridge"] = [{}] * 25
available[key]["curves"] = {"models": {"ridge": {}, "all": {}, "none": {}}, "uncertainty": "synthetic"}
passed(
    "DCA defaults excluded from model counts",
    lambda: assert_true(module.summarize_dca(available)["available_model_horizon_slots"] == 1),
)
bad = copy.deepcopy(available)
bad[key]["curves"]["models"].pop("none")
refused("missing DCA default", lambda: module.summarize_dca(bad))
bad = copy.deepcopy(groups)
bad[key]["unavailable"].pop("lasso")
refused("missing model/horizon exclusion", lambda: module.summarize_dca(bad))
bad = copy.deepcopy(groups)
bad.pop(key)
refused("missing DCA group", lambda: module.summarize_dca(bad))

cells = [
    {
        "dataset": "synthetic",
        "setting": "clinical",
        "model_key": "catalytic_fixed",
        "condition": "full",
        "status": s,
        "error_type": "ValueError",
        "message": "synthetic rank failure",
    }
    for s in ("complete", "failed", "failed_diagnostics")
]
passed(
    "execution and diagnostics counted separately",
    lambda: assert_true(
        module.summarize_cells(cells)["groups"][0]["execution_failures"] == 1
        and module.summarize_cells(cells)["groups"][0]["diagnostic_failures"] == 1
    ),
)
passed(
    "32 distinct figures in sealed renderer order",
    lambda: assert_true(len(module.figure_names()) == len(set(module.figure_names())) == 32),
)

real_read = module.read
manifest = {
    "plan": [{"cell_id": str(i)} for i in range(1625)],
    "planned_fits": 1625,
    "evidence_status": "post_hoc_extension",
    "code": {"git_commit": module.PRODUCTION_COMMIT, "git_dirty": False},
}
manifest["manifest_content_sha256"] = module.canonical(manifest)
completion = {"evidence_status": "post_hoc_extension", "planned": 1625, "stored": 1624, "verification": "deep"}
completion["completion_content_sha256"] = module.canonical(completion)
documents = {"manifest.json": manifest, "completion.json": completion, "verification.json": {}}
module.read = lambda path: documents[path.name]
refused(
    "partial 1624-cell numerical programme refused before filesystem traversal",
    lambda: module.load_numerical(Path("synthetic-memory-only")),
)
module.read = real_read


class TextOnly:
    """Provide only synthetic text to the strict JSON reader."""

    def read_text(self, **kwargs):
        return '{"number": NaN}'


refused("non-standard JSON NaN refused", lambda: module.read(TextOnly()))
passed(
    "canonical encoding distinguishes integer 1 and float 1.0",
    lambda: assert_true(module.canonical({"x": 1}) != module.canonical({"x": 1.0})),
)
print(
    json.dumps(
        {
            "status": "preparation_schema_checks_passed",
            "checks": checks,
            "check_count": len(checks),
            "actual_result_inputs_read": False,
            "scientific_completion_asserted": False,
        },
        indent=2,
        sort_keys=True,
    )
)
