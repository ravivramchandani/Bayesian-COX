# Prepared final claim-input review

This directory contains preparation, not the completed extension results. The
summary helper has not been executed against actual extension results. No task
T-182–T-189 is closed by this preparation. Fits, refits, finalization, rendering,
visual approval, publication and restore remain owned by the existing root
workflow. No repository files were changed here.

The schema was inspected in sealed analysis commit
`8551d326b02bfe88915cfd9eb50c6ca8e5690e3a`, with production pinned to
`119476fef55b1eeb690527f234c1423440720d45`. Exact inspected source hashes,
baseline pins and preparation checks are recorded separately in
`source_bindings.json` and `preparation_receipt.json`.

## Completion and verification records

`scripts/finalize_extensions.py:63` writes `run/completion.json` only after the
full grid has been deeply verified and its three aggregates have been written.
Its fields are:

| Field | Meaning for factual review |
|---|---|
| `evidence_status` | `post_hoc_extension`; the primary record remains separate. |
| `planned`, `stored` | Both must be 1,625; full accounting includes accepted fits and recorded failures. |
| `status_counts` | Counts of `complete`, `failed`, and `failed_diagnostics`. An execution failure is not a diagnostic rejection. |
| `independently_rescored` | Accepted cells independently rescored; should match the `complete` count. |
| `independently_checked_traces` | Recorded posterior/prior traces whose saved diagnostics were independently checked. This is a trace count, not a fit or patient count. |
| `verification` | `deep`, not merely `hash_membership_gate_only`. |
| `production_code_commit` | Exact production commit above. |
| `analysis_only_sha256` | The analysis-only verifier, finalizer and renderer bytes. |
| `cell_sha256` | Exact 1,625 cell JSON byte hashes, keyed by `cells/<cell_id>.json`. |
| `aggregate_sha256` | Exactly `paired_families.json`, `rq2_effects.json`, and `decision_curves.json`. |
| `manifest_sha256` | Run-manifest byte binding. |
| `completion_content_sha256` | Internal canonical JSON hash, excluding this field. |
| `selected_reproduction_status`, `render_status` | Both are initially and permanently `pending` in this sealed write-once completion. Later stages use separate receipts and lineage; preserve these completion bytes. |

`run/verification.json` contains the verification subset above. It does not
contain a visual-review or reproduction verdict. Exact planned membership is
in `run/manifest.json` (`planned_fits`, `plan`, `matched_sha256`,
`freeze_sha256`, `input_sha256`, clean production `code`, `run_config`, and
`manifest_content_sha256`). Manifest/cell content encoding distinguishes
integer `1` from float `1.0`; equal Python values do not establish equal hashes.

The sealed deep verifier rebuilds memberships and seeds, rechecks recorded
trace diagnostics and rescores accepted forecasts. The prepared helper checks
the stored numerical records and hashes only. It does not replace that
verifier, recompute metrics/arrays, inspect plots, or certify the fresh restore.

## Cell accounting and scientific failures

Every cell contains `dataset`, `setting`, `model_key`, `repeat`, `fold`,
`condition`, `cell_id`, `train_subject_ids`, `validation_subject_ids`,
`n_train`, `n_validation`, `events_train`, `seed`, and content hash. When the
relevant stage has succeeded, `p`, `events_per_coefficient`, `preprocessing`,
`selected_parameters`, `inner_tuning`, `synthetic_prior_data`, `fit_attempts`,
`model_checks`, `metrics`, and `predictions` provide its detailed evidence.
Some execution failures occur before these optional fields exist; do not fill
them with invented values.

| `status` | Reported interpretation |
|---|---|
| `complete` | Accepted predictions/metrics, including the unchanged posterior and joint-prior gates for Bayesian catalytic cells. |
| `failed_diagnostics` | Recorded attempted fitting exhausted the prescribed diagnostic remedies. Keep failed attempts/traces. |
| `failed` | Execution error, with `error_type`, `message`, and, where available, recorded attempts. A synthetic rank rejection remains an execution failure. |

Use `(dataset, setting, model_key, condition)` for accounting. The plan is:

| Grid component | Planned cells |
|---|---:|
| Three original clinical cohorts, seven new arms, 25 full folds each | 525 |
| Three original clinical cohorts, three catalytic arms, five non-full RQ2 conditions, ten repeat/fold pairs each | 450 |
| Matched METABRIC clinical-only and expression settings, 13 arms, 25 folds each | 650 |
| Total | 1,625 |

Each original cohort therefore has 325 extension cells. Each matched setting
has 325. Full-setting comparisons use 1,175 full cells; 450 are the non-full
RQ2 conditions. The numerical plan has 825 Bayesian and 800 point-estimate
cells. These are planned counts, not an assertion that all predictions pass.

For T-189, distinguish the two Bayesian catalytic arms from weighted-mixture
point estimates. Report execution errors by actual stored type/message and
whether attempts exist. Rank provenance comes from the separately owned final
`failure_provenance_v2` reconstruction. A missing `fit_attempts` list alone
does not identify which preprocessing/tuning stage failed. Do not add a redraw,
new sampler remedy or post-hoc acceptance gate to obtain more accepted cells.

## Four paired comparison families

`src/pipelines/extensions/analysis.py:46` writes these four distinct families:

| `paired_families.json` key | Contrasts | Pairing |
|---|---:|---|
| `penalized_vs_original_priors` | 27 | Three penalised Cox arms × three priors × three clinical cohorts. |
| `calibrated_vs_adr032_horseshoe` | 3 | Piironen–Vehtari variant against the ADR-032 sampler sensitivity, one per clinical cohort. |
| `catalytic_vs_original_priors` | 27 | Three catalytic arms × three priors × three clinical cohorts. |
| `expression_increment` | 13 | Expression minus clinical IBS for each arm in matched METABRIC. |

Each family contains `family_complete`, `expected_contrasts`, and `contrasts`.
Each contrast has identifying `dataset` and model/left/right fields,
`n_pairs`, `expected_pairs: 25`, `direction: left IBS minus right IBS`, and
`status`. At 25 accepted aligned pairs, `status` is `estimable` and `effect`
contains the stored corrected repeated-CV result. Otherwise the status is
`incomplete_no_inference`, with no effect. The aggregate stores pair counts,
not the identities of each missing repeat/fold; use the underlying cell
records if identities are needed.

Holm fields (`holm_adjusted_p`, `holm_reject`,
`superiority_language_permitted`) are present only when every specified
contrast in that particular family is estimable. Partial families must retain
all unavailable contrasts and must not be adjusted as an available subset.
The helper reports family coverage and stored flag counts without computing
tests or interpreting significance. IBS is lower-is-better: effect direction
must be preserved in any later wording. A null or incomplete comparison does
not establish equivalence.

The finalizer substitutes the 75 ADR-032 horseshoe refits for clinical paired
family references and DCA, retaining all other original cells. It separately
renames the original primary horseshoe arm to
`bayesian_horseshoe_original` for DCA. This does not replace the original
confirmatory result. Matched settings contain fresh separate original-model
arms under the extension sampler; these must not be described as original
full-cohort primary results.

## Catalytic RQ2

`src/pipelines/extensions/rq2.py:17` produces a JSON list of 270 rows:
three cohorts × three catalytic models × three priors × five non-full
conditions × two kinds (`direct`, `difference_in_differences`). Conditions
are `fraction_0.25`, `fraction_0.50`, `fraction_0.75`, `admin_q0.75`, and
`admin_q0.50`. Each row contains `dataset`, `model`, `prior`, `condition`,
`kind`, `n_pairs`, `expected_pairs: 10`,
`role: descriptive_no_significance_claim`, and `mean_difference`.

Direct rows require both condition fits to be accepted and exactly aligned.
Interaction rows additionally require both full anchors, with matched
validation identities. A zero-pair row has no mean. A nonzero partial row has
only its available descriptive mean. `corrected_descriptive_interval` exists
only for all ten pairs; the inferential helper's `p_value` is removed.
Unavailable and partial rows remain in the output and rendered table.

These prior references come from the unchanged frozen **robustness** run,
including its failed cells. They are not replaced by ADR-032. The 75/75
ADR-032 acceptance fact therefore cannot be applied to RQ2 pairing. Report
direct and interaction coverage separately. No multiplicity-controlled or
significance claim is specified for these RQ2 rows.

## Decision curves and exclusions

`src/pipelines/extensions/analysis.py:90` produces 15 groups named
`<dataset>__<setting>__h1`, `h2`, `h3`: the three original clinical cohorts
and the two matched METABRIC settings. The horizons are the training-event
quantiles 0.25/0.5/0.75, not a single fixed population time. Each group has
`thresholds` (50 values from 0.01 to 0.50), `horizon_rule`, `unavailable`
(model-to-reason mapping), and `support`. A supported group also contains
`curves`.

There are 14 specified model arms per original clinical group (seven new,
six reference arms including ADR-032 horseshoe, and the retained original
horseshoe), and 13 per matched group. Across the three horizons this is
204 model/horizon slots. `all` and `none` are separate reference strategies,
not extra fitted model arms. Every available model must have all 25 accepted
folds, five validation repeats per patient and common identities, horizons
and weights; otherwise its actual exclusion reason is retained.

`support[model]` has the 25 repeat/fold records, each containing `horizon`,
`G_horizon`, `training_at_risk`, `known_events`, `known_event_free`,
`early_censored`, `maximum_weight`, and `weight_ess`. Checks require the
training censoring survival to be at least 0.1 and training at-risk count at
least ten; other recorded support/identity errors are also exclusions.
Patients censored at or before the horizon contribute zero utility but stay
in the patient denominator. Sums across fold records include repeated
patients and must not be presented as unique patient counts.

`curves.models` contains `net_benefit`, `pointwise_lower`, `pointwise_upper`
for each model and both defaults. Each fitted model additionally contains
`differences.all` and `differences.none` with `estimate` and pointwise bounds.
The group records `n_patients`, `n_biological_clusters`, `n_repeats`,
`n_bootstraps`, `seed`, `resampling_unit`, and `uncertainty`. Known accession
pairs share biological cluster IDs. These are conditional descriptive
pointwise intervals from saved predictions, with no model refitting. They
support no clinical deployment/impact claim.

## Separate reproduction, rendering and visual-QA records

The numerical completion is not rewritten after these stages:

* `reproduction/receipts/<cell_id>.json`: exactly the frozen 92 selections
  with `repeat == fold == 1`, status `scientific_match`, source/refit content
  hashes and `trace_sample_arrays: exact; timing/NetCDF metadata excluded`.
  The official production harness compares actual posterior/sample-statistic
  arrays. Selected checks do not mean that all 1,625 fits were freshly refit.
* `rendered_v1/lineage.json`: 32 PDF/PNG figure pairs and six CSV tables,
  source manifest/completion hashes, exact renderer hash and source lists.
  Its `actual_visual_review` and figure `visual_review` fields deliberately
  remain pending because rendering alone does not constitute inspection.
* `pdf_qa_v1/qa_inventory.json`: exact 32 rendered page images, four contact
  sheets, six tables, source/helper hashes and automated checks. Preparation
  leaves visual review pending.
* `pdf_qa_v1/visual_qa_receipt.json`: actual separately completed named
  review, `visual_qa_status: passed`, 32 explicit pass verdicts, six table
  hashes, `test_only: false`, inventory/review hashes and source
  lineage/completion bindings. Preserve the original analysis855 QA helper
  bytes that produced this receipt.

The prepared summary requires all these records before emitting factual
counts, including the exact review file used to issue the QA receipt. It
checks receipt/content bindings; it neither performs visual inspection nor
repeats sampled-array comparisons.

## Original evidence to retain in every final account

These existing facts were read from pinned baseline artefacts, not inferred
from extension success:

* The original primary run stores 450 cells: 430 accepted and 20 diagnostic
  failures, all horseshoe (18 GBSG2, two METABRIC). GBSG2 horseshoe contrasts
  have 7/25 pairs and METABRIC horseshoe contrasts 23/25. Five of nine primary
  contrasts have complete pairing; the primary inference status is
  `incomplete` and `holm_family_complete` is false.
* ADR-032 stores 75/75 accepted refits in a separate post-hoc sensitivity.
  Its nine contrasts have complete pairing, adjusted p-values all 1.0 and
  corrected intervals including zero. `confirmatory_outcome_replaced` is
  false. This is not an equivalence finding or a correction to the original
  primary outcome.
* Frozen robustness stores 825 cells: 770 accepted and 55 diagnostic
  failures. Its own partial pairing/available estimates remain separate.
* The original explanation file hash is
  `120984c7edfac468f471b9f500470623689b2647e4bde56d271cc9623346ecd5`.
  It contains 1,845 comparisons. Its convergence summary is failed, with
  1,640 evaluable, 1,538 passed and 102 failed; `claim_permitted` is false.
  No extension figure or comparator restores an RQ3 claim.

The ADR-033 post-hoc Holm-family bound remains a separate earlier result.
No primary family completion, superiority, equivalence, causal feature truth,
external validation or deployment claim is created by this preparation.

## Task closeout mapping

| Task | Evidence to read once actual stages finish |
|---|---|
| T-182 | Clinical full ridge/lasso/elastic-net cell accounting; actual inner tuning/preprocessing; 27-contrast penalised family and its pairing/multiplicity availability; relevant selected receipts. |
| T-183 | All 75 clinical full PV cells/attempts, original fixed prior/calibration specification, unchanged gates, three paired contrasts against ADR-032 with coverage and stored results. |
| T-184 | All 15 DCA groups, every available curve/default difference, every exclusion and support record, repeated-patient uncertainty and fold-specific horizons. |
| T-185 | Pinned matched input/alignment manifest and source hashes; 650 cells/13 arms/two settings with common membership and training-only gene preprocessing; predictor/event counts; 13 expression-increment contrasts with unavailable pairs retained. |
| T-189 | Catalytic reference parity from already frozen tests/fixtures; all 825 catalytic cells across clinical, RQ2 and matched settings; execution/diagnostic counts; final reconstructed rank provenance; paired family and 270 descriptive RQ2 rows; selected receipts. |
| T-186 | Full numerical completion; 32 pairs/six tables and exact lineage; actual passed visual QA; retained original negatives. For the user's remote handoff, also require the root's release inventory, filtered fresh remote download, restored-code/source checks and full scientific restore receipt. |
| T-187–T-188 | Paper and DOI tasks remain deferred until after thesis submission. This code/results scope closes neither paper task nor Overleaf writing. |

Operational completion may include honestly recorded scientific failures and
unavailable comparisons. It does not require every model to pass diagnostics.
Do not turn incomplete scientific families into silent omissions or a reason
to refit beyond the frozen remedies. Final task checkboxes remain a root
decision after the complete authorised transfer and actual evidence review.

## Prepared helper usage

Use the locked Python after actual numerical/reproduction/render/QA stages
finish, with `--qa-review` pointing to the exact reviewed form used for the
receipt. The helper prints JSON only and returns 2 on a missing/inconsistent
input; it never writes a result. Root should retain stdout only after a zero
exit and valid JSON, in a fresh external file.

```bash
/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python \
  /Users/macuser/bayes-cox-runs/extensions-20260928/final_claim_review_preparation_v1/summarize_verified_claim_inputs.py \
  --run /Users/macuser/bayes-cox-runs/extensions-20260928/run \
  --reproduction /Users/macuser/bayes-cox-runs/extensions-20260928/reproduction \
  --rendered /Users/macuser/bayes-cox-runs/extensions-20260928/rendered_v1 \
  --qa-dir /Users/macuser/bayes-cox-runs/extensions-20260928/pdf_qa_v1 \
  --qa-review /Users/macuser/bayes-cox-runs/extensions-20260928/pdf_qa_v1/review.json \
  --primary /Users/macuser/bayes-cox-runs/student-restore-check-20260928/reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651 \
  --sampler /Users/macuser/bayes-cox-runs/student-programme-results-20260928/sampler_run \
  --robustness /Users/macuser/bayes-cox-runs/student-programme-results-20260928/robustness \
  --explanation /Users/macuser/bayes-cox-runs/frozen/reports/explainability/confirmatory_v1_confirmatory_cdcdcee84651_explainability_v1.json
```

The output labels `overall_programme_completion` as unassessed: publication,
transfer, fresh scientific restore and final task closure are outside this
summary helper. Preparing the helper is not evidence that its actual inputs
have yet passed. Its current checks use in-memory synthetic schemas only.
