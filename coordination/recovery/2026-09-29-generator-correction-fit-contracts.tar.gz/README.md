# Corrected catalytic fit/reuse preparation

This directory prepares ADR-040/T-190 integration contracts. It implements
small-record validation and synthetic tests only. It loads no cohorts or
scientific packages, calls no generator/SVD/optimizer/MCMC, calculates no real
score, and creates no method freeze, actual reuse decision or launch approval.
The root owns scientific review, integration and execution. The reviewed
generator candidate and 1,650-context inventory remain unchanged.

## Concrete interfaces

`correction_fit_contracts.py` is stdlib-only. Its public inputs are typed
`Comparison`, `SourceEvidence`, `FitWitness` and `TuningUse` records.

| API | Supplied input | Contract output |
| --- | --- | --- |
| `seed_ledger(original_cell_id)` | Original ID and frozen base seed | Original cell, outer prior, 3 attempt, inner-CV, 3 inner-prior, 9 inner-fit and evaluation seeds |
| `required_roles(model)` | Model key | 19 common roles; 2 more catalytic roles; 21 more WME inner roles |
| `classify(witness)` | Two exact role digests, proof receipt per role, all context receipts and available old evidence | Reuse, changed fit, changed fit with retained tuning, retune then fit, unresolved, await original outcome, or retained input failure |
| `reuse_envelope(decision, manifest_sha)` | Unaltered complete reuse decision | Corrected-run reference to original immutable accepted/failed payload; no new-fit claim |
| `resolve_wme_tuning(id, designs, uses)` | 3 shared designs and up to 9 actual slot records | Accounting/eligibility/selection semantic check; original NumPy selection remains required in integration |
| `pilot_dispatch_contract(...)` | Actual freeze/review hashes, frozen pilot IDs and original full budget | Validated pending dispatch record, zero launched fits |
| `summarize_pilot(plan, outcomes)` | Every actual success/failure receipt, timings and independent verification | Complete accounting for root review; no remaining-grid approval/time estimate |

Digests supplied to this module are **not** independently verified by it. The
future witness builder must hash actual current bytes/reconstructed arrays and
verify referenced receipts. An identical opaque hash supplied by a caller is
not scientific proof. Missing/partial proof cannot become reuse. Exceptions
and orphan traces are retained without invented diagnostic records.

## Freeze and witness integration

1. Finish the training-only preflight for all 825 catalytic outer positions
   plus all 825 WME inner positions, including originally unreached positions.
   Its future namespace is `contexts/<original_id>/<outer|inner_01..03>/`:
   `input.json`, `inputs.npz`, context `receipt.json`, and actual
   `attempt_000/receipt.json` plus `proposal.npz` for every proposal. The sibling
   preflight implementation owns its final schema. Its `completion.json`
   establishes context accounting, **not** model approval, fits or reuse.
2. Bind original accepted/rejected first proposals exactly. Include dtype,
   shape, C-order values, synthetic time and hazard; actual p/M; ordered raw
   IDs/values/dtypes/column order; censored outcomes; complete preprocessing
   and gene-selection state; feature spec/budget; original seed. Label
   constructor instrumentation/reconstruction separately. A rejected original
   generator did not return legacy metadata: bind its absence, not an invented
   returned dictionary. Complete candidate retry/cap/history is separate.
3. Build role receipts against the actual source cell snapshot. The common
   comparison surface includes all real training/validation inputs, processing
   states/designs, candidate/model configuration, model/fit/evaluation sources,
   environment, original seeds and unchanged execution dependencies. The
   reviewed generator seam is separately bound; it must not hide changes to
   other loaded sources/package initialization. Byte-pinned original source
   and input recipes can prove an unchanged unreachable stage, but require an
   explicit exact-reconstruction receipt. Subject IDs, rank or first-draw
   success alone prove no model/evaluation compatibility.
4. WME additionally needs all 3 inner memberships/outcomes/processors/designs,
   all 3 shared prior proposals, and all 9 candidate-specific numerical,
   fitting and evaluation inputs. One synthetic design per fold is shared
   across tau multipliers `[0.25,1,4]`. Model/fit seeds remain distinct. Hash
   original saved tuning/selection separately and validate its eligibility and
   tie-order against original code. If only outer inputs change and every inner
   dependency matches, a genuinely recorded verified selection can be retained.
   An inner/dependency change requires retuning; an absent selection does too.
   Whole-cell reuse preserves the original tuning record through cell bytes.
5. Decide scope from this inventory, not failure status. The 375 METABRIC and
   825 global positions are assessment counts, not new-fit counts. Reuse both
   complete and failed/diagnostic-failed old outcomes when all inputs match.
   A changed cell can be scheduled while the original worker continues, with
   old-outcome comparison explicitly pending. An identical-input cell awaits
   its original outcome rather than duplicating the running fit. Terminal
   input/rank-cap/nonrank failures produce new correction failure records and
   no optimizer/MCMC dispatch. Missing proof remains unresolved.
6. Review method implications and prior/WME arithmetic on changed accepted
   inputs. Freeze a new versioned addendum, actual reviewed code/dependencies,
   actual accepted-input/failure artifacts, complete plan/reuse inventory and
   specified full-budget pilot. Keep the binding graph acyclic: immutable
   scientific-definition digest → input/witness inventory → freeze → run
   manifest/outcome envelopes. `FitWitness.correction_specification_sha256`
   binds the first definition; it cannot include the later freeze that hashes
   that witness inventory. The pilot checks both definition and final freeze.
   Hash them in a **new** freeze/run manifest
   before any corrected outer-validation score. Conditioning is post-hoc after
   original failures were known and has a changed sampling law; no inherited
   iid/asymptotic or preregistration claim. Candidate cap/seeds/tolerance are
   not finalized by this preparation. Preserve T-180/119476f and old results.

## Runner and result schema seams

New integration needs these explicit APIs; they are **not implemented here**:

```python
build_actual_fit_witness(original_job, preflight, original_snapshot,
                         corrected_freeze) -> FitWitness
consume_frozen_context(context_dir, expected_receipt_sha, original_seed,
                       processor_state_sha) -> AcceptedProposal | InputFailure
run_corrected_cell(original_job, frozen_contexts, decision, corrected_manifest,
                   new_output_dir) -> CorrectedOutcomeEnvelope
resolve_corrected_view(manifest, outcome_ledger, new_cells,
                       original_payload_root) -> list[ResolvedOutcome]
verify_corrected_run(..., deep=True) -> VerificationReceipt
```

`consume_frozen_context` must check every frozen proposal artifact and the real
constructor guards; replay generation must reproduce the frozen accepted input
and history. It must never redraw because an optimizer or sampler failed.
The current candidate rebuilds preprocessing in a fresh child per proposal;
production consumption/caching requires actual state/hash equivalence and a
separate integration review. No all-grid performance claim is inherited.

Use a new run root and manifest, with `original_manifest_sha256`, original
1625-job plan/IDs, `correction_freeze_sha256`, original seed namespace, complete
preflight and witness digests, per-job action, new/reused/input-failed provenance
and exact source/environment bindings. 825 catalytic plus 800 other logical
slots remain accounted for; 90 RQ2 full anchors are links, not extra fits.
Do not place a new manifest in the original run or pretend all logical slots
were newly fitted. No real counts/actions exist yet.

The outcome envelope contains `original_cell_id`, corrected manifest/freeze,
original seed-ledger and decision hashes, `result_origin`, status and payload
reference/hash. Reuse points to unchanged original cell/recorded trace bytes;
new fits point to new cells and actual invocation/attempt/trace records;
terminal input failures point to actual context failure receipts. Original
outcomes still arriving are separately pending, never fabricated. Subsequent
snapshot ledgers are versioned, not overwritten. The resolved analysis view
must contain exactly one outcome per original logical ID while retaining these
envelopes and original/corrected comparison outside raw immutable old cells.

Adapt original `runner.py:64–129` at the generation/tuning seams while preserving
its training censoring, event guard, processor, all model/fitting/evaluation
arguments and original cell seed. Adapt `fitting.py:85–132` to record the three
inner designs/nine candidate uses, all warning/errors/scores, actual selection
and explicit not-executed slots after a terminal interruption. Retain original
`np.mean`, candidate order and the all-three-fold eligibility rule. A failed
candidate cannot select a new design. Instrument `fit_with_attempts` around
model construction as well as fitting/trace writing; retain every completed or
partial attempt and available trace on exceptions. Do not invent missing
diagnostics, change error classification or add retries after execution errors.

## Full-budget pilot contract

Specify exact original job IDs and training-input strata before scoring: changed
outer versus inner generation, fixed/adaptive/WME, clinical versus expression,
small fraction/censoring, proposal-attempt counts and encoded p/M. The root's
method/implementation review decides membership; this preparation picks no
patient/model/job and uses no performance-based selection.

The budget remains 4 chains × 2000 posterior draws, 2000 initial tune, 4000 tune
on either permitted diagnostic refit, target acceptance 0.999, maximum two
diagnostic refits, final noncentered baseline, and the same catalytic joint
prior/posterior all-parameter gates. Cores remain 1 per model. WME retains its
3-fold × 3-tau original optimizer/evaluation procedure and score tolerance.
Freeze full model/evaluation/optimizer configuration too; sampling equality
alone is insufficient. No execution failure gains a new fit remedy.

Keep every pilot cell and invocation, including rank/input, optimizer/tuning,
MCMC, trace-write and diagnostic failures. Record actual UTC start/finish,
monotonic wall/CPU time, measured memory, trace bytes, proposal/preprocessing,
tuning, prior/posterior fit and evaluation times where available, requested
budget and actual partial/completed steps. A failed sampler need not have
completed its requested draws; no shorter *requested* budget is permitted.
The first scoring timestamp must follow freeze; absence of scoring on failure
is explicit. The prototype verifies structure/chronology, not real diagnostics.

Before the remaining grid, root reviews pilot failures separately, all exact
input/fitting/score/trace verifications, resource measurements and unchanged
gates. Any pilot failure triggers retained-outcome review; no silent repair or
discard. A reviewed passing pilot cell may become its actual new-grid outcome
only with the same entire freeze/input identity. Estimate remaining compute
from measured full-budget strata and actual changed/retune counts, including
failures and prior fits; the old short profile is no completion estimate.

## Verification, reporting and private-transfer adapters

The original 8551d32 verifier (`verification.py:97–190`) enforces one original
manifest/source/config/1625-cell layout; the original 2b stager enforces its
original 92 selected refits, original QA/source bindings and transfer schema.
Neither certifies this new mixed provenance. Preserve their old certifications.

The minimal new verifier resolves each envelope, verifies actual original/new
bytes and witness/preflight/code/freeze membership, reconstructs the original
job/seed identities, rescales/rescores accepted saved forecasts with unchanged
evaluation, and recomputes all recorded prior/posterior diagnostics from traces.
It accepts failure accounting without accepting unavailable forecasts and
inventing diagnostics; preserve orphan bytes without adding arbitrary gates.
It must verify the new WME context/selection and partial-failure ledger.

Retain all 92 original selected logical positions. Unchanged reused positions
need explicit witness-bound old reproduction receipts and immutable evidence;
changed selected positions need actual corrected selected refits and scientific
trace-array/forecast/metric comparisons under the new freeze. Missing old
receipts remain pending. 24 METABRIC/60 global catalytic selected positions are
subset counts, not established new-refit counts or all-grid reproduction.

Feed only a verified resolved view into the unchanged family/RQ2/DCA arithmetic,
then bind new aggregates to every contributing envelope/payload. Rebuild
affected 27/3/27/13 families, 90 full-anchor links, paired effects/RQ2, DCA,
ratios and the 123 descriptive rows/formal links, original-versus-corrected
failure explanations, figures/tables and actual visual QA. Keep complete-pair
and complete-family exclusions unchanged; DCA still needs all 25 accepted folds
and common patient/horizon/weight identities. Do not drop failed folds silently.

Add explicit corrected stage/restore/science/reporting-replay adapters binding
the new manifest/envelopes/reproduction/QA and all required original payloads,
generator/preflight/witness/failure/code/arithmetic/pilot history. Copy or include
portable original evidence referenced by reuse; host-absolute references alone
are not a transferable package. Existing reporting sidecar/claim helpers need
an explicitly reviewed corrected-view input contract. Fresh private remote
restore must verify original and corrected scopes and replay corrected reporting
with actual rc0 evidence outside immutable restored payload before publication.
New tool test/review/release receipts and handoff boundaries remain pending;
the existing original-grid wrappers cannot be relabelled as correction proof.

Run only the included synthetic checks from this directory using locked Python:
`python -B -m unittest -v test_correction_fit_contracts.py`. No executable actual
fit, preflight, verification or transfer CLI is supplied here.
