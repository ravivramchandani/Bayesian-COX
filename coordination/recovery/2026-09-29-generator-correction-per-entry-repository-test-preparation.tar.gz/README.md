This is a portable repository test adapter for the separately reviewed per-entry I/O preparation with receipt SHA `6670b27e78fb05f7c266cc52b72241a4b477f5d9a27213e8882bdcbd1038f366`. It preserves all 53 original fictional/injected test methods and adds one guard for the exact eleven runtime/test sources, complete preparation, predecessor dependencies, private imports and a fresh stdlib-only Python process. It changes no reviewed runtime or original test source.

The intended runtime destination is `scripts/catalytic_correction/per_entry_io/`. Root owns adoption. The runtime directory is currently absent from main; the recorded bounded checks use the immutable external reviewed preparation and read-only main selected/receiving predecessors. The new adapter and its source-copy fixtures remain external preparation. Passing these tests does not select, review, freeze, run or certify any actual reproduction, numerical producer, scientific comparison or release.

Proposed repository files are:

```text
tests/test_catalytic_correction_per_entry_io.py
tests/repository_adapter.py
tests/fixtures/catalytic_correction/original_producer_completion_v1/producer_capture.py
tests/fixtures/catalytic_correction/original_producer_completion_v1/capture_original_producer.py
tests/fixtures/catalytic_correction/original_producer_completion_v1/verification_io.py
tests/fixtures/catalytic_correction/original_producer_completion_v1/preparation_receipt.json
```

`repository_adapter.py` defaults to the repository containing the adopted test file and resolves selected/receiving predecessors at `scripts/catalytic_correction/{reproduction,receiving}`. The capture predecessor is not yet integrated in main, so the four exact source/receipt bytes are provided as independently SHA-checked source-only test fixtures. They can be tracked at the proposed fixture paths or materialized from those exact tracked Git blobs after adoption. They are not a complete executable original-producer preparation and must not substitute for its full preparation during real packaging or scientific work.

Before adoption, only these explicit source-only overrides are supported:

```text
BAYES_COX_PER_ENTRY_TEST_REPOSITORY_ROOT=<repository containing exact integrated selected/receiving predecessors>
BAYES_COX_PER_ENTRY_TEST_SOURCE_ROOT=<immutable complete reviewed per-entry preparation>
BAYES_COX_PER_ENTRY_TEST_CAPTURE_FIXTURE=<directory containing the exact four predecessor source/receipt fixtures>
```

The original hardcoded Mac paths in `fictional_support.py` are never a fallback. Each test receives the exact portable role map through a scoped patch of `fictional_support.ROOTS`; the original fixture source bytes and methods remain unchanged. Missing or changed dependency members refuse test collection rather than skip or fabricate matching files. `portable_member_contract.json` enumerates every required dependency byte pin and adoption member.

All eleven sources are loaded under private module names. Temporary public aliases exist only while original source imports/tests resolve their unchanged sibling imports. Aliases are restored after each test, bytecode writing is disabled during those scopes, and only classes defined in the original two test modules are exported once. A mixin wraps `TestCase.run`; individual original test methods are inherited directly, so their assertions, mock targets and science gate guards remain unchanged. The retained string-based `os.link` mock continues to target the standard library. No original imported fixture class is exported a second time for test discovery.

The additional guard checks the exact eleven source SHA map, the byte/content-sealed preparation and all 43 bound artifacts/44 archival files, the actual predecessor source/preparation maps, no public alias leak, no new scientific module imports, and exactly 53 original method identities. It also refuses a changed ordinary temporary source-copy fixture and imports the same source graph in a genuine fresh `-I -B` Python process. That child imports guards only; it never dispatches a capture/controller/checker/model/generator/optimizer or reads actual scientific arrays/traces.

The runtime `location_core.preparation()` needs the exact receipt plus its eight local runtime modules. The later release whole-preparation loader additionally needs every artifact in that unchanged receipt. The complete 44-file original preparation includes four historical `.ruff_cache` files from its recorded style check. Those bytes are part of the immutable carrier, so they must be explicitly retained even if repository ignore rules would omit them. They are preparation metadata, not scientific evidence. Do not add `__init__.py`, fresh cache/bytecode files or the new repository test adapter inside that sealed directory. Retain the original full member set or create a separately reviewed new preparation; never silently prune a sealed artifact list.

The recorded checks are the original 53 plus the added guard: 54 stdlib tests and a separate bounded pytest collection/run, with scoped Ruff and AST checks. Pytest plugins and its cache provider are disabled for this preparation check. The original reviewed 44-member source tree is byte-checked before and after. Actual receiving/reproduction default scientific dispatch and root-controlled final gates remain pending.
