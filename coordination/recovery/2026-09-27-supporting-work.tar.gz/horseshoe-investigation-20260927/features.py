import sys, numpy as np, pandas as pd, yaml
from pathlib import Path
root=Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project'); sys.path.insert(0,str(root))
from src.pipelines.confirmatory import load_analysis_dataset,_feature_spec
from src.data.survival_folds import repeated_survival_folds
from src.data.fold_preprocessing import FoldFeaturePreprocessor
cfg=yaml.safe_load(open(root/'config/confirmatory.yaml')); dcfg=yaml.safe_load(open(root/'config/datasets.yaml'))
pd.set_option('display.width',250)
for ds in ['gbsg2','whas500','metabric']:
    raw,t,e,ids=load_analysis_dataset(root,ds,dcfg[ds]); spec=_feature_spec(dcfg[ds],'primary')
    folds=repeated_survival_folds(t,e,n_splits=5,n_repeats=5,base_seed=cfg['validation']['base_seed'],max_time_bins=cfg['validation']['followup_time_bins'])
    ps=[];
    for f in folds:
        x=FoldFeaturePreprocessor(spec).fit_transform(raw.iloc[f.train_indices]); ps.append(x.shape[1])
    f=folds[0]; x=FoldFeaturePreprocessor(spec).fit_transform(raw.iloc[f.train_indices])
    ev=e[f.train_indices].sum()
    print(f'== {ds}: N={len(t)} events={e.sum()} train n={len(f.train_indices)} train events={ev} p per fold={sorted(set(ps))} EPV={ev/np.mean(ps):.1f}')
    s=pd.DataFrame({'min':x.min(),'max':x.max(),'skew':x.skew(),'mean':x.mean(),'n_nonzero':(x!=0).sum() if True else None})
    print(s.round(2).to_string())
    print('max |x| overall', float(np.abs(x.values).max()), 'cond number', float(np.linalg.cond(x.values)))
