import json, glob, os
import pandas as pd
base='/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project/reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651/cells'
rows=[]
cells=[]
for f in sorted(glob.glob(f'{base}/*/*/bayesian_horseshoe.json')):
    d=json.load(open(f))
    ds=d['dataset']; rf=os.path.basename(os.path.dirname(f))
    atts=d.get('fit_attempts',[])
    cells.append(dict(dataset=ds,cell=rf,status=d['status'],n_att=len(atts),n_train=d.get('n_train'),events_train=d.get('events_train'),total_s=d.get('total_seconds')))
    for a in atts:
        dg=a.get('diagnostics',{})
        rows.append(dict(dataset=ds,cell=rf,status=d['status'],attempt=a.get('attempt'),
            ta=a.get('target_accept'),tune=a.get('tune'),draws=dg.get('n_draws'),chains=dg.get('n_chains'),
            nc=a.get('noncentered_baseline'),init=a.get('init'),
            rhat=dg.get('r_hat_max'),essb=dg.get('ess_bulk_min'),esst=dg.get('ess_tail_min'),
            div=dg.get('n_divergent'),bfmi=dg.get('bfmi_min'),mtd=dg.get('max_tree_depth'),ntd=dg.get('n_max_tree_depth'),
            conv=dg.get('converged'),fails='; '.join(dg.get('failures',[])),secs=a.get('fit_seconds'),npar=dg.get('n_parameters_checked'),
            keys=','.join(sorted(k for k in a.keys() if k not in('diagnostics','model_checks','posterior_trace_snapshot')))))
df=pd.DataFrame(rows); cdf=pd.DataFrame(cells)
df.to_csv(os.path.dirname(__file__)+'/attempts.csv',index=False)
cdf.to_csv(os.path.dirname(__file__)+'/cells.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_colwidth',80)
print(df['keys'].unique())
print(cdf.groupby(['dataset','status']).size())
print(cdf.groupby('dataset')[['n_train','events_train','total_s']].describe().T)
print(df.drop(columns=['keys']).to_string())
