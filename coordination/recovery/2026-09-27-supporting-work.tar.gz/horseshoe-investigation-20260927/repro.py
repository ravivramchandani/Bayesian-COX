"""Reproduce a frozen GBSG2 horseshoe cell and test candidate remedies.

Usage: python repro.py <repeat> <fold> <variant> [attempt]
variants:
  frozen      repo BayesianCoxModel exactly as the confirmatory attempt
  mirror      scratch copy of the frozen model (checks the copy is exact)
  ta999       frozen model, target_accept 0.999
  decomp      local and global half-t scales via normal / inverse-gamma
              decomposition (rstanarm hs() style), target_accept 0.99
  decomp999   decomp + target_accept 0.999
  log1p       frozen model, log1p(pnodes, progrec, estrec) before scaling
  pvtau0      frozen model, tau0 = p0/(D-p0)/sqrt(events), p0 = 3
"""
import json, sys, time
from pathlib import Path
import numpy as np, pandas as pd, pymc as pm, yaml

ROOT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
sys.path.insert(0, str(ROOT))
from src.pipelines.confirmatory import (load_analysis_dataset, _feature_spec,
    deterministic_seed, _model_from_parameters)
from src.data.survival_folds import repeated_survival_folds
from src.data.fold_preprocessing import FoldFeaturePreprocessor
from src.models.bayesian.model import BayesianCoxModel
from src.models.bayesian.diagnostics import check_convergence

OUT = Path(__file__).parent / 'results'
OUT.mkdir(exist_ok=True)
rep, fold, variant = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
attempt = int(sys.argv[4]) if len(sys.argv) > 4 else 0
ds = 'gbsg2'
cfg = yaml.safe_load(open(ROOT / 'config/confirmatory.yaml'))
dcfg = yaml.safe_load(open(ROOT / 'config/datasets.yaml'))
raw, t, e, ids = load_analysis_dataset(ROOT, ds, dcfg[ds])
spec = _feature_spec(dcfg[ds], 'primary')
folds = repeated_survival_folds(t, e, n_splits=5, n_repeats=5,
    base_seed=cfg['validation']['base_seed'], max_time_bins=cfg['validation']['followup_time_bins'])
f = [x for x in folds if x.repeat == rep and x.fold == fold][0]
cell = json.load(open(ROOT / f'reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651/cells/{ds}/repeat_{rep:02d}_fold_{fold:02d}/bayesian_horseshoe.json'))
assert list(ids[f.train_indices]) == cell['train_subject_ids'], 'train ids differ'
cell_seed = deterministic_seed(cfg['validation']['base_seed'], ds, rep, fold, 'bayesian_horseshoe')
assert cell_seed == cell['cell_seed']
seed = deterministic_seed(cell_seed, 'fit_attempt', attempt)

raw_train = raw.iloc[f.train_indices].copy()
if variant == 'log1p':
    for c in ['pnodes', 'progrec', 'estrec']:
        raw_train[c] = np.log1p(raw_train[c])
x = FoldFeaturePreprocessor(spec).fit_transform(raw_train)
yt, ye = t[f.train_indices], e[f.train_indices]
tune = 2000 if attempt == 0 else 4000

started = time.perf_counter()
if variant in ('frozen', 'ta999', 'log1p', 'pvtau0'):
    model = _model_from_parameters('bayesian_horseshoe', {}, seed=seed, confirmatory_config=cfg,
        bayes_draws=2000, bayes_tune=tune, bayes_chains=4,
        target_accept_override=(0.999 if variant == 'ta999' else None),
        noncentered_baseline=(attempt >= 2))
    if variant == 'pvtau0':
        p0, D, d = 3, x.shape[1], int(ye.sum())
        model.prior_params['tau0'] = p0 / (D - p0) / np.sqrt(d)
    model.fit(x, yt, ye)
    idata = model.idata
    diag = model.diagnostics
    extra = {'tau0': model.prior_params.get('tau0'), 'target_accept': model.target_accept}
else:
    # Scratch copy of model.py lines 118-251 with an optional decomposition.
    decomp = variant.startswith('decomp')
    ta = 0.999 if variant.endswith('999') else 0.99
    helper = BayesianCoxModel(n_intervals=6)
    X_mat = x.values.astype(float)
    ts = float(np.median(yt[ye == 1]))
    cut, expo, evm = helper._prepare_piecewise_data(X_mat, yt / ts, ye)
    M = len(cut) - 1
    valid = expo > 0
    obs_events, obs_exp = evm[valid], expo[valid]
    si, ii = np.where(valid)
    obs_X, log_exp = X_mat[si], np.log(obs_exp)
    n_features = X_mat.shape[1]
    tau0, slab_df, slab_scale, nu = 0.1, 4.0, 2.0, 2.0
    with pm.Model() as m:
        if decomp:
            # half-t(nu, s) = s * |N(0,1)| * sqrt(InvGamma(nu/2, nu/2))
            tau_a = pm.HalfNormal('tau_a', 1.0)
            tau_b = pm.InverseGamma('tau_b', alpha=nu / 2, beta=nu / 2)
            tau = pm.Deterministic('tau', tau0 * tau_a * pm.math.sqrt(tau_b))
            lam_a = pm.HalfNormal('lam_a', 1.0, shape=n_features)
            lam_b = pm.InverseGamma('lam_b', alpha=nu / 2, beta=nu / 2, shape=n_features)
            lam = pm.Deterministic('lam', lam_a * pm.math.sqrt(lam_b))
        else:
            tau = pm.HalfStudentT('tau', nu=2, sigma=tau0)
            lam = pm.HalfStudentT('lam', nu=2, sigma=1.0, shape=n_features)
        c2 = pm.InverseGamma('c2', alpha=slab_df / 2.0, beta=slab_df * slab_scale**2 / 2.0)
        lam_sq = lam**2
        lam_tilde = pm.math.sqrt(c2 * lam_sq / (c2 + tau**2 * lam_sq))
        z = pm.Normal('z', 0.0, 1.0, shape=n_features)
        beta = pm.Deterministic('beta', z * tau * lam_tilde)
        log_lambda = pm.Normal('log_lambda', mu=-2.0, sigma=2.0, shape=M)
        eta = pm.math.dot(obs_X, beta)
        mu = pm.math.exp(log_exp + log_lambda[ii] + eta)
        pm.Poisson('obs', mu=mu, observed=obs_events)
        pm.sample_prior_predictive(draws=200, var_names=['beta', 'log_lambda'], random_seed=seed)
        idata = pm.sample(draws=2000, tune=tune, chains=4, cores=1, target_accept=ta,
                          random_seed=seed, progressbar=False, return_inferencedata=True)
    diag = check_convergence(idata)
    extra = {'tau0': tau0, 'target_accept': ta}
secs = time.perf_counter() - started

# Where do divergences sit? Compare divergent draws with the rest.
post = idata.posterior
dv = idata.sample_stats['diverging'].values.astype(bool)
loc = {}
if dv.any():
    for name in ['tau', 'c2']:
        v = post[name].values
        loc[name] = {'div_values': v[dv].round(4).tolist(), 'q05_q50_q95': np.quantile(v, [.05, .5, .95]).round(4).tolist()}
    lamv = post['lam'].values
    loc['lam_div_percentile_by_feature'] = {
        str(fn): [float((lamv[..., j] < val).mean().round(3)) for val in lamv[..., j][dv]]
        for j, fn in enumerate(x.columns)}
    loc['log_tau_div_percentile'] = [float((post['tau'].values < v).mean().round(3)) for v in post['tau'].values[dv]]
bsum = {str(fn): {'mean': float(post['beta'].values[..., j].mean().round(4)),
                  'sd': float(post['beta'].values[..., j].std().round(4))}
        for j, fn in enumerate(x.columns)}
res = {'cell': f'r{rep:02d}f{fold:02d}', 'variant': variant, 'attempt': attempt + 1, 'seed': seed,
       'frozen_divergences_this_attempt': cell['fit_attempts'][attempt]['diagnostics']['n_divergent'] if attempt < len(cell['fit_attempts']) else None,
       'seconds': secs, **extra,
       'diag': {k: diag[k] for k in ['r_hat_max', 'ess_bulk_min', 'ess_tail_min', 'n_divergent', 'bfmi_min', 'max_tree_depth', 'n_max_tree_depth', 'converged', 'failures']},
       'mean_tree_depth': float(idata.sample_stats['tree_depth'].values.mean()),
       'step_size': idata.sample_stats['step_size'].values.mean(axis=1).round(4).tolist(),
       'div_per_chain': dv.sum(axis=1).tolist(),
       'beta': bsum, 'divergence_location': loc}
(OUT / f"{res['cell']}_{variant}_a{attempt + 1}.json").write_text(json.dumps(res, indent=1, default=float))
print(json.dumps({k: res[k] for k in ['cell', 'variant', 'attempt', 'seconds', 'diag', 'div_per_chain', 'mean_tree_depth']}, default=float))
