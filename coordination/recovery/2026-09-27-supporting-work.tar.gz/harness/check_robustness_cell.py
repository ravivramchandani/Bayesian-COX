"""Refit one stored robustness cell in a fresh process and compare it.

Follows the same steps as ``execute_robustness_run`` for a single cell, using
the options recorded in the run manifest. Only timing fields may differ.

Usage: python check_robustness_cell.py <project_root> <run_dir> <cell_json>
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

project_root = Path(sys.argv[1]).resolve()
run_dir = Path(sys.argv[2]).resolve()
cell_path = Path(sys.argv[3]).resolve()
sys.path.insert(0, str(project_root))

import yaml  # noqa: E402

import src.pipelines.robustness as rb  # noqa: E402
from src.data.survival_folds import repeated_survival_folds  # noqa: E402
from src.utils.reproducibility import sha256_file  # noqa: E402

config = yaml.safe_load((project_root / "config/confirmatory.yaml").read_text())
datasets = yaml.safe_load((project_root / "config/datasets.yaml").read_text())
manifest = json.loads((run_dir / "manifest.json").read_text())
rc = manifest["run_config"]
stored = json.loads(cell_path.read_text())
dataset_key, model_key = stored["dataset"], stored["model_key"]
options = rb.RobustnessOptions(
    mode=rc["mode"],
    datasets=tuple(rc["datasets"]),
    components=tuple(rc["components"]),
    outer_splits=rc["outer_splits"],
    outer_repeats=rc["outer_repeats"],
    fold_limit_per_dataset=rc["fold_limit_per_dataset"],
    bayes_draws=rc["bayes_draws"],
    bayes_tune=rc["bayes_tune"],
    bayes_chains=rc["bayes_chains"],
    sensitivity_bootstraps=rc["sensitivity_bootstraps"],
    resume=True,
    output_root=run_dir.parent,
    confirmatory_run_dir=project_root / "reports/confirmatory" / rc["confirmatory_run"],
)
fitted = tuple(c for c in options.components if c != "ph")
plan = rb.build_condition_plan(config, datasets[dataset_key], fitted)
cohort = datasets[dataset_key]
raw, times, events, subject_ids = rb.load_analysis_dataset(project_root, dataset_key, cohort)
folds = repeated_survival_folds(
    times,
    events,
    n_splits=options.outer_splits,
    n_repeats=options.outer_repeats,
    base_seed=int(config["validation"]["base_seed"]),
    max_time_bins=int(config["validation"]["followup_time_bins"]),
)
fold = next(f for f in folds if f.repeat == stored["repeat"] and f.fold == stored["fold"])
condition = next(c for c in plan if rb._cell_path(run_dir, dataset_key, fold, c, model_key) == cell_path)
subset_seed = rb.deterministic_seed(
    int(config["validation"]["base_seed"]), "robustness_subset", dataset_key, fold.repeat, fold.fold
)
train_indices, cutoff = rb._fold_condition_indices(
    condition,
    fold,
    times[fold.train_indices],
    events[fold.train_indices],
    [float(v) for v in config["robustness"]["training_fractions"]],
    seed=subset_seed,
    max_time_bins=int(config["validation"]["followup_time_bins"]),
)
cell = rb.run_robustness_cell(
    dataset_key,
    model_key,
    fold,
    condition,
    raw,
    times,
    events,
    subject_ids,
    rb._feature_spec(cohort, condition.feature_set),
    train_indices,
    cutoff,
    config=config,
    options=options,
    data_sha256=sha256_file(project_root / cohort["raw_file"]),
)
new = json.loads(json.dumps(rb._json_safe(cell), sort_keys=True))
volatile = {"total_seconds", "fit_seconds", "cell_content_sha256"}


def diff(a, b, path=""):
    if isinstance(a, dict) and isinstance(b, dict):
        out = []
        for k in sorted(set(a) | set(b)):
            if k in volatile:
                continue
            if k not in a or k not in b:
                out.append(f"{path}.{k} missing")
            else:
                out += diff(a[k], b[k], f"{path}.{k}")
        return out
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [f"{path} length"]
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in diff(x, y, f"{path}[{i}]")]
    return [] if a == b else [f"{path}: {str(a)[:60]} != {str(b)[:60]}"]


found = diff(new, stored)
print(f"{cell_path.relative_to(run_dir)} identical={not found} differences={len(found)}")
print("\n".join(found[:10]))
