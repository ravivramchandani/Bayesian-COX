#!/bin/zsh
# Final unsharded pass: verifies the freeze, fits any cell no worker
# completed, then writes aggregates and the completion record.
set -eu
ROOT=$HOME/bayes-cox-runs/frozen
PY=/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python
cd "$ROOT"
"$PY" scripts/run_robustness.py --mode robustness --resume \
  > "$HOME/bayes-cox-runs/logs/robustness_finish.log" 2>&1
tail -3 "$HOME/bayes-cox-runs/logs/robustness_finish.log"
