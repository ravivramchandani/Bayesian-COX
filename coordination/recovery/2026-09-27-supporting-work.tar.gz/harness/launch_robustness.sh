#!/bin/zsh
# Launch the sharded frozen robustness production run.
# Worker 0 creates the run directory and manifest; the others start after the
# manifest exists. When every worker has exited, run finish_robustness.sh.
set -eu
ROOT=$HOME/bayes-cox-runs/frozen
CLAIMS=$HOME/bayes-cox-runs/robustness-claims
LOGS=$HOME/bayes-cox-runs/logs
PY=/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python
WORKERS=${1:-6}
mkdir -p "$CLAIMS" "$LOGS"

nohup "$PY" "$HOME/bayes-cox-runs/harness/shard_worker.py" "$ROOT" "$CLAIMS" 0 \
  > "$LOGS/robustness_worker_0.log" 2>&1 &
echo $! > "$LOGS/robustness_worker_0.pid"

for _ in $(seq 1 180); do
  if ls "$ROOT"/reports/robustness/*/manifest.json >/dev/null 2>&1; then break; fi
  sleep 2
done
ls "$ROOT"/reports/robustness/*/manifest.json >/dev/null

for worker in $(seq 1 $((WORKERS - 1))); do
  nohup "$PY" "$HOME/bayes-cox-runs/harness/shard_worker.py" "$ROOT" "$CLAIMS" "$worker" \
    > "$LOGS/robustness_worker_${worker}.log" 2>&1 &
  echo $! > "$LOGS/robustness_worker_${worker}.pid"
  sleep 5
done
echo "launched $WORKERS workers"
