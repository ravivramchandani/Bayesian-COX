"""Run one worker of a sharded frozen robustness production run.

The worker executes the unmodified ``scripts/run_robustness.py`` from the
frozen worktree. Two module attributes are wrapped:

- ``_cell_path``: before a missing cell is fitted, the worker claims it by
  atomically creating a lock file outside the run directory. A cell that
  another worker has claimed is skipped, as if its file already existed.
- ``load_robustness_cells``: the worker exits after its cell loop, so only
  the final unsharded ``--resume`` invocation writes aggregates and the
  completion record.

Cell computation (``run_robustness_cell``) is not modified. Every cell is
fitted exactly once, with its own deterministic seeds.

Usage: python shard_worker.py <frozen_project_root> <claims_dir> <worker_id>
"""

from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path

project_root = Path(sys.argv[1]).resolve()
claims_dir = Path(sys.argv[2]).resolve()
worker_id = sys.argv[3]

sys.path.insert(0, str(project_root))
os.chdir(project_root)

import src.pipelines.robustness as robustness  # noqa: E402

original_cell_path = robustness._cell_path


def claiming_cell_path(run_dir, dataset_key, fold, condition, model_key):
    """Return the real path for cells this worker owns, else an existing file."""
    path = original_cell_path(run_dir, dataset_key, fold, condition, model_key)
    if path.exists():
        return path
    claim = claims_dir / (str(path.relative_to(run_dir)) + ".claim")
    claim.parent.mkdir(parents=True, exist_ok=True)
    try:
        handle = os.open(claim, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        return run_dir / "manifest.json"
    os.write(handle, f"worker={worker_id} pid={os.getpid()}\n".encode())
    os.close(handle)
    return path


def stop_before_aggregation(*_args, **_kwargs):
    """End the worker once its share of cells is written."""
    print(f"worker {worker_id} finished its cell loop", flush=True)
    raise SystemExit(0)


robustness._cell_path = claiming_cell_path
robustness.load_robustness_cells = stop_before_aggregation

sys.argv = ["scripts/run_robustness.py", "--mode", "robustness", "--resume"]
runpy.run_path(str(project_root / "scripts" / "run_robustness.py"), run_name="__main__")
