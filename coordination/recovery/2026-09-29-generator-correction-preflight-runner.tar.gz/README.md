# Training-only catalytic correction preflight runner

This implementation accounts for all 825 original catalytic outer positions
and all 825 WME inner generator positions. It constructs training inputs,
calls the separately reviewed rank-only proposal adapter and preserves every
constructor outcome. It never calls `select_parameters`, an optimizer, MCMC,
evaluation or validation-score selection. The real 1,650-context preflight
has not been launched by the preparer. Root owns integration and launch.

The runner is self-contained: `run_preflight.py` and `preflight_core.py` must
remain siblings. Invoke the script directly with `python -B`, without
importing a main-repository `src` package first. The candidate is loaded from
an explicit file under a private module name. The actual backend refuses
already loaded `src` modules, normally imports the clean sealed119476f
checkout, verifies every loaded source origin/digest and independently
rebuilds all 1,625 original jobs against the complete frozen manifest.

## Explicit invocation

Supply absolute paths for the exact source/run/matched data, the unchanged
recipe inventory, the active reviewed candidate, the prospective correction
config/addendum and a separate output directory. There are no local-user
defaults. The same exact lock interpreter runs the controller and every
proposal child; a normal conda `python` symlink is resolved and checked.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
nice -n 15 "$PREFLIGHT_PYTHON" -B "$PREFLIGHT_RUNNER/run_preflight.py" \
  --source "$PREFLIGHT_ORIGINAL_SOURCE" \
  --run "$PREFLIGHT_ORIGINAL_RUN" \
  --matched "$PREFLIGHT_MATCHED_PARQUET" \
  --inventory "$PREFLIGHT_RECIPE_INVENTORY" \
  --candidate-module "$PREFLIGHT_CANDIDATE_MODULE" \
  --candidate-sha256 "$PREFLIGHT_REVIEWED_CANDIDATE_SHA256" \
  --correction-config "$PREFLIGHT_CORRECTION_CONFIG" \
  --correction-addendum "$PREFLIGHT_CORRECTION_ADDENDUM" \
  --output "$PREFLIGHT_OUTPUT" --python "$PREFLIGHT_PYTHON" --cap 256
```

Add `--restore-processor-state` only for the root-reviewed active candidate
that supports exact learned-state restoration. The controller first fits
the original preprocessor on the complete current training frame. It then
passes only selected generator source columns and complete processor
metadata to the child. The child restores original state and must return
the identical metadata. This changes transport/reconstruction cost; the
rank gate, draw ordering, arrays, original seeds and legacy returned metadata
remain the candidate's responsibility. The runner records the selected mode
and candidate byte digest. Tests here inject that API rather than execute
real restoration; root's candidate tests/review remain separate evidence.

The exact259-package macOS arm64 environment is verified before cohort
loading. All Python, Matplotlib, NumExpr/BLAS and PyTensor cache/thread
settings are explicit; writable caches live under the output directory.
Output must be outside source, original run and preparation/candidate input
directories. Atomic no-replace publication uses hard links and file/directory
sync, so use a supporting filesystem such as APFS. The existing ExFAT
backing volume should be addressed through its mounted APFS image.

`--limit N` makes an explicitly partial first-N-position pass, useful for
resource measurement. Omit it for full coverage. Repeating the same command
verifies and resumes the same request; different source, candidate, config,
addendum, environment, mode or cap requires separate outputs.

## Training construction and original compatibility

The frozen original loader and job builder preserve ordered outer membership,
fractional subsets and administrative cutoffs. Membership/cutoff/seed checks
must match the original manifest and the1,650-position recipe inventory.
The original outer event guard remains. Administrative censoring occurs
before the three WME inner splits. Every inner processor and gene selection
is fitted on its current inner training rows. Neither outer nor inner
held-out rows enter preprocessing or generator source inputs. Only held-out
membership hashes are saved; no validation arrays or scores are saved.

All WME inner contexts are constructed even when the original execution did
not reach them. One inner design is shared by three frozen tau candidates;
it is not generated three times. Original cell, generator, inner-fit,
outer-fit-attempt and evaluation seeds remain recorded as compatibility
references. New corrected score/model execution is outside this runner.

The first proposal is the untouched original generator call captured by the
reviewed adapter. A rejected first proposal has no legacy returned metadata;
its actual constructor arrays and separately labelled instrumentation are
retained. Only the exact tagged frozen rank guard permits the next proposal.
Other errors stop that context and retain all preceding rank rejections.
Every capped exhaustion remains explicit. Parent singular-value/category
measurements are supplementary and never control redraw or acceptance.
Measurement failure is recorded without changing the constructor result.

Where an original cell exists, its byte/content hashes are verified and its
outer preprocessing and legacy synthetic metadata are compared. An exact
match certifies those saved fields only. Original cells do not save complete
inner designs or complete design-byte witnesses, so absent witnesses remain
unresolved. Original success, diagnostics and other failures retain their
status. No independent normal-import whole-grid replay or model/fit/evaluation
reuse is certified here.

## Output contract

`manifest.json` binds source/input/recipe/candidate/config/addendum/runner
bytes, exact environment, cap, processor mode and scope. Its
`content_sha256` is the run binding referenced by every context.

For each position, `contexts/<original_cell_id>/<outer|inner_01..03>/` holds:

- `input.json`: sealed `request` and `input_witness`; ordered training IDs,
  membership hashes, feature names, complete processor metadata, source-value
  hashes and exact real-design/time/event dtype/shape/element-byte witnesses.
- `inputs.npz`: compressed numeric `real_design`, `real_time`, `real_event`.
- `attempt_000/receipt.json` and later attempts: exact seed/index/constructor
  status, returned legacy metadata or null, separate actual instrumentation,
  singular/rank/category measurements, array witnesses and artifact hashes.
- `attempt_000/proposal.npz` and later captured constructors: compressed
  `synthetic_design`, `synthetic_time`, scalar `hazard`, scalar `time_scale`.
  Rejected constructors are saved too. Nonrank errors before a constructor
  have no fabricated proposal arrays.
- `receipt.json`: all attempts, accepted index or null, context outcome,
  request/input binding and every input/attempt artifact byte hash.
- `comparisons/<original_cell_byte_sha256>.json`: immutable scope-limited
  source comparison; `not_recorded.json` preserves an earlier absence. Later
  original cells add comparisons without altering the preflight outcome.

Per-array witnesses are `dtype` (`numpy.dtype.str`), `shape` and
`values_sha256` of exact C-order element bytes. Artifact maps are relative to
their owning receipt directory and contain `sha256` and `bytes`. Every sealed
JSON mapping has `content_sha256`, computed from all other keys using strict
original canonical JSON encoding. Object archives/pickle files are forbidden.

Context outcomes are `accepted_original_first_draw`,
`accepted_rank_conditioned_redraw`, `exhausted_rank_cap`, `nonrank_failure` or
`input_failure`. `completion.json` is written only after every scheduled
position is accounted for and original boundaries are rechecked. Its
`outcomes` list binds each context receipt's relative path, byte digest,
content digest and status. Its `all_contexts_feasible` distinguishes complete
accounting from successful construction. It does not certify methodology,
fits, reuse, new scores or transfer; those flags are explicitly false.

## Resume and interrupted work

Launcher, controller and context claims prevent duplicate owners. Completed
contexts are verified against freshly reconstructed training witnesses.
Complete proposal checkpoints inside an interrupted context may be reused
only after matching their exact request, seed/index, constructor status,
arrays and receipts. Each new proposal still uses one isolated child; there
is no cross-context proposal cache or altered draw implementation.

An invalid checkpoint is never silently skipped or overwritten. A partial
archive without its receipt stops resume for explicit root review. A killed
process can leave a claim. `--recover-stale-claims` archives only a claim
whose binding/host match and whose local PID is proven absent; a live or
other-host claim is rejected. No fitting jobs are inspected, stopped or
restarted. A complete input failure that later constructs is incompatible
with the same output and must stay separately recorded.

## Preparation validation

Focused tests use invented frames, injected proposals/diagnostics and pure
recipe JSON. They cover censor-before-split, held-out isolation, seeds,
unchanged first proposals, retained redraws/exhaustion/nonrank errors,
checkpoint corruption, interruption/resume, claims, direct-file namespace
guards, explicit restoration transport and restricted original comparisons.
No actual programme cohort loading, generator, SVD, optimizer, MCMC,
validation score or real preflight ran during preparation. Candidate parity,
whole-grid performance, changed-input arithmetic, method review, scope/reuse
proof, corrective freeze, full-budget pilot and fits remain separate gates.
