"""Record a stated transfer-space budget on the image and physical backing disk."""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

mode, stage, home, physical = sys.argv[1:5]
stage, home, physical = Path(stage), Path(home), Path(physical)
subprocess.run([sys.executable, '-B', str(Path(__file__).with_name('check_prepared_pins.py'))], check=True)
if mode not in {'before-package', 'before-download', 'before-remote-download', 'before-restore'}:
    raise SystemExit('Unknown transfer space phase')
paths = list(stage.rglob('*'))
if any(path.is_symlink() for path in paths):
    raise SystemExit('Linked staged evidence refused')
source_bytes = sum(path.stat().st_size for path in paths if path.is_file())
overhead = max(1024**3, (source_bytes + 19) // 20)
reserve = 5 * 1024**3
code_bytes = 0
for name in ('production.tar.gz', 'analysis.tar.gz'):
    with tarfile.open(stage / 'code' / name, 'r:gz') as archive:
        code_bytes += sum(member.size for member in archive if member.isfile())
inventory = None
if mode == 'before-package':
    # Conservative workflow allowance; final compressed bytes are measured below.
    required = source_bytes + 8192 * len(paths) + 500 * 1024**2 + overhead + reserve
    package_bytes = largest_shard = None
else:
    tools = Path('/Users/macuser/bayes-cox-runs/extensions-transfer-code-20260928-2b701a8/scripts/extension_release')
    sys.path.insert(0, str(tools))
    from verify import load_inventory
    package = home / ('download' if mode == 'before-restore' else 'package')
    inventory = load_inventory(package)
    if mode == 'before-restore' and inventory['canonical_sha256'] != sys.argv[5]:
        raise SystemExit('Separately recorded canonical inventory digest differs')
    source_bytes = sum(member['size'] for member in inventory['members'] if member['type'] == 'file')
    overhead = max(1024**3, (source_bytes + 19) // 20)
    package_bytes = sum(shard['bytes'] for shard in inventory['shards']) + (package / 'inventory.json').stat().st_size
    largest_shard = max((shard['bytes'] for shard in inventory['shards']), default=0)
    required = source_bytes + largest_shard + code_bytes + overhead + reserve
    if mode in {'before-download', 'before-remote-download'}:
        required += package_bytes
free_image = shutil.disk_usage(home).free
free_backing = shutil.disk_usage(physical).free
passed = min(free_image, free_backing) >= required
result = {
    'status': 'passed' if passed else 'insufficient_space', 'phase': mode,
    'budget_scope': 'workflow allowance, not exact physical allocation',
    'image_parent': str(home), 'physical_volume': str(physical),
    'logical_source_file_bytes': source_bytes, 'staged_entries': len(paths),
    'code_extraction_file_bytes': code_bytes, 'package_asset_bytes': package_bytes,
    'largest_shard_bytes': largest_shard, 'filesystem_overhead_allowance_bytes': overhead,
    'operating_reserve_bytes': reserve, 'required_remaining_free_bytes': required,
    'measured_free_image_bytes': free_image, 'measured_free_backing_bytes': free_backing,
    'canonical_inventory_sha256': inventory['canonical_sha256'] if inventory else None,
}
if inventory:
    result['inventory_file_sha256'] = hashlib.sha256((package / 'inventory.json').read_bytes()).hexdigest()
    result['shards'] = inventory['shards']
subprocess.run([sys.executable, '-B', str(Path(__file__).with_name('check_prepared_pins.py'))], check=True)
with (home / (mode + '.space.json')).open('x') as stream:
    stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
if not passed:
    raise SystemExit('Insufficient measured free space for the stated remaining transfer budget')
