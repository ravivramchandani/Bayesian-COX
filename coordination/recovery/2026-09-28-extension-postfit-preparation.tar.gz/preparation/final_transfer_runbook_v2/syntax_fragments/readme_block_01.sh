# Prepared documentation fragment; syntax validation only.
source /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v2/paths.sh
"$PYTHON" -B "$ANALYSIS/scripts/extension_release/extension_pdf_qa.py" receipt \
  --qa-dir "$QA" --review "$QA/review.json"
