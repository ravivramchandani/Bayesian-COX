# Prepared documentation fragment; syntax validation only.
source /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v2/paths.sh
PUBLISH_TAG='<pending-new-private-extension-tag>'
(
  set -euo pipefail
  case "$PUBLISH_TAG" in *pending*|*'<'*|*'>'*) exit 2 ;; esac
  test "$(gh repo view "$GITHUB_REPO" --json isPrivate --jq '.isPrivate')" = true
  gh release create "$PUBLISH_TAG" "$PACKAGE/inventory.json" "$PACKAGE"/part-*.tar.gz \
    --repo "$GITHUB_REPO" --target "$TOOLS_COMMIT" --draft --latest=false \
    --title 'Post-hoc extension evidence — 2026-09-28' \
    --notes-file "$TRANSFER_HOME/release-notes.md"
  test "$(gh repo view "$GITHUB_REPO" --json isPrivate --jq '.isPrivate')" = true
  test "$(gh release view "$PUBLISH_TAG" --repo "$GITHUB_REPO" --json isDraft --jq '.isDraft')" = true
  test "$(gh release view "$PUBLISH_TAG" --repo "$GITHUB_REPO" --json tagName --jq '.tagName')" = "$PUBLISH_TAG"
  PUBLISHED_TAG="$PUBLISH_TAG" \
  TRUSTED_CANONICAL_SHA256='<pending-canonical-digest-from-committed-receipt>' \
    bash /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v2/remote_restore.sh
)
