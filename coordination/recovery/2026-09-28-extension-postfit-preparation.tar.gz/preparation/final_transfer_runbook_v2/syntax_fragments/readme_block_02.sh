# Prepared documentation fragment; syntax validation only.
bash /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v2/stage_package.sh
