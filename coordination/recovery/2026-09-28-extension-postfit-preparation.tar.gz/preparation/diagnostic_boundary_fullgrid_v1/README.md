# Incremental full-grid diagnostic boundary audit

Prepared supporting audit; **the full-grid audit has not been executed**. Root should run it once after the frozen extension source grid finishes. It requires exactly 1,625 planned/current cells, including completed cells and recorded execution/diagnostic failures.

Run from any directory with the same frozen Python environment:

```sh
nice -n 15 env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMBA_CACHE_DIR=/Users/macuser/bayes-cox-runs/extensions-20260928/diagnostic_boundary_fullgrid_v1/numba_cache \
  /Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python -B \
  /Users/macuser/bayes-cox-runs/extensions-20260928/diagnostic_boundary_fullgrid_v1/run_full_grid_audit.py
```

The default source is `/Users/macuser/bayes-cox-runs/extensions-20260928/run`. The driver pins its manifest hash, verifies cell content/membership/hash bindings, hashes every current recorded trace, and requires the original 752 cached cell bytes to remain unchanged. It verifies the immutable original cache, helper, dependency versions and 698 records before reuse. Reuse requires the whole job context to match, including cell/trace hashes and stored diagnostics. Every new recorded trace is inspected by the pinned original `inspect_trace`; the numerical scope is its recorded posterior variables and `sample_stats.energy`. Legitimate execution-failed attempt trace subsets follow the frozen verifier's recorded-trace scope.

Output is a new write-once `full_grid_result` child directory:

- `source_snapshot.json`: exact source scope, cell/trace hashes, recorded jobs, cache bindings and separately inventoried unreferenced NetCDF hashes.
- `trace_records.jsonl`: full job/result bindings, pinned helper hash and reused cache line hashes.
- `audit_summary.json`: coverage and findings separately; explicit accepted-fit counts.
- `completion_receipt.json`: written only after every referenced trace has a record and all source/cache/driver hashes and inventories are rechecked; binds each record and output file.

Existing output is never overwritten. After an interrupted or refused run that created output, preserve it and use a fresh child directory, for example `--output /Users/macuser/bayes-cox-runs/extensions-20260928/diagnostic_boundary_fullgrid_v1/full_grid_result_retry1`. A partial directory without a valid completion receipt is incomplete evidence.

Exit codes:

- **0**: exact full referenced scope completed and no diagnostic-boundary findings.
- **1**: exact full referenced scope completed with explicit findings for review. This supporting audit does not change fitting statuses or the frozen programme gates.
- **2**: scope/integrity/output refusal, including an incomplete grid. Other uncaught I/O/inspection errors also produce no valid completion receipt.

Unreferenced NetCDF bytes are retained and hashed separately, with actual cell ownership/status where available. They are not numerically inspected by this driver; stored-diagnostic/gate comparisons are unavailable without a recorded trace entry, and worker logs are not inspected. Their presence is not an additional fitting gate. A complete referenced-scope audit does not claim orphan diagnostic coverage or unavailable full historical primary trace/energy coverage.

`--preflight-only` checks exact grid/cache/source hashes without new diagnostic inspection or output writes. At preparation, it correctly refused 771 current cells / 854 missing / 0 unexpected. That dated count is not a current completion claim. Final scoped Ruff and 23 cache/in-memory guards passed; details and exact byte bindings are in `preparation_receipt.json`. The earlier `guard_validation.json` binds a superseded preparation version and is retained as historical evidence.

