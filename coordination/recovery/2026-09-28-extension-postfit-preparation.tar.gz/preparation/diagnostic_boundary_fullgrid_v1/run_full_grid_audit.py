"""Extend the immutable diagnostic-boundary cache to the exact completed grid.

This driver only reads production cells and recorded posterior/prior traces.
It reuses a prior result only when the whole recorded job and present bytes
match, and delegates every new numerical inspection to the pinned original
``inspect_trace``. Its output is supporting evidence, not a replacement for
the frozen convergence gate or independent programme verification.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

DRIVER_DIR = Path(__file__).resolve().parent
DEFAULT_RUN = Path('/Users/macuser/bayes-cox-runs/extensions-20260928/run')
DEFAULT_CACHE = Path('/Users/macuser/bayes-cox-runs/documentation-pass-20260928/diagnostic_boundary_audit')
EXPECTED_CELLS = 1625
MANIFEST_SHA256 = '83b9049fb6aaaadab576b34de0741e4f510344dcefba9f96198d15b5ab4f49b9'
CACHE_RECEIPT_SHA256 = '60b7bcdea95fd35c577d118174a342ee6200bceabd183a1d0ca121bd2f154f9a'
HELPER_SHA256 = 'df7c47668d541a819e0e2c9267fec4bdd8c62d15eca22a92a4867dee6ca92d9b'
CACHE_SNAPSHOT_SHA256 = 'c49cec23cfdceb606222083efdbef8a61a8f5a4dd69748159deec897657fe3b6'
CACHE_RECORDS_SHA256 = 'cbc0375c367eaf2128e4b9cf1683c09929ed4d14804eb4e19ce7ace730893054'
BAYESIAN_MODELS = {
    'bayesian_normal', 'bayesian_horseshoe', 'bayesian_spike_slab',
    'pv_horseshoe', 'catalytic_fixed', 'catalytic_adaptive',
}


class AuditError(ValueError):
    """A source, cache or output boundary cannot support a complete receipt."""


def file_hash(path: Path) -> str:
    """Hash an ordinary file, rejecting symlinked source artefacts."""
    if not path.is_file() or path.is_symlink():
        raise AuditError(f'missing or symlinked file: {path}')
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def canonical_hash(value: Any) -> str:
    """Use the production canonical JSON encoding, including finite-only JSON."""
    data = json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')
    return hashlib.sha256(data).hexdigest()


def write_once(path: Path, value: Any) -> None:
    """Create one receipt without replacing any existing bytes."""
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def key(job: dict[str, Any]) -> tuple[str, int, str]:
    """Identify a diagnostic job independently of the JSONL line order."""
    return job['cell_id'], job['attempt'], job['trace_label']


def require_record(job: dict[str, Any], record: dict[str, Any]) -> None:
    """Bind a successful helper result to every context field and inventory."""
    if 'error' in record:
        raise AuditError(f'cannot reuse or complete an errored trace: {key(job)}')
    for name, expected in job.items():
        if name != 'stored_diagnostics' and record.get(name) != expected:
            raise AuditError(f'audit context differs: {key(job)}/{name}')
    expected = job['stored_diagnostics']
    if record.get('observed_trace_sha256') != job['expected_trace_sha256']:
        raise AuditError(f'audit trace hash differs: {key(job)}')
    if record.get('variables_checked') != expected['variables_checked']:
        raise AuditError(f'audit variable inventory differs: {key(job)}')
    if record.get('summary_parameter_count') != expected['n_parameters_checked']:
        raise AuditError(f'audit parameter count differs: {key(job)}')
    if record.get('recorded_trace_converged') != bool(expected['converged']):
        raise AuditError(f'audit stored convergence flag differs: {key(job)}')
    if record.get('groups_checked') != ['posterior', 'sample_stats.energy']:
        raise AuditError(f'audit inspected an unexpected group: {key(job)}')
    required = {
        'raw_posterior_findings', 'raw_energy_nonfinite_values',
        'nonfinite_diagnostic_rows', 'masked_nonfinite_fields', 'per_chain_bfmi',
        'nonfinite_bfmi_chains', 'constant_energy_chains',
        'zero_energy_variance_chains', 'reduced_gate_statistics_match_stored', 'warnings',
    }
    if not required <= record.keys():
        raise AuditError(f'incomplete audit record: {key(job)}')
    if set(record['reduced_gate_statistics_match_stored']) != {
        'r_hat_max', 'ess_bulk_min', 'bfmi_min',
    }:
        raise AuditError(f'incomplete reduced-statistic comparison: {key(job)}')


def load_cache(cache: Path) -> dict[str, Any]:
    """Verify the immutable cache before trusting any reused trace result."""
    receipt_path = cache / 'artifact_receipt.json'
    if file_hash(receipt_path) != CACHE_RECEIPT_SHA256:
        raise AuditError('the original cache receipt changed')
    receipt = json.loads(receipt_path.read_text())
    expected_files = receipt['files_sha256']
    if expected_files.get('audit_saved_diagnostics.py') != HELPER_SHA256:
        raise AuditError('cache receipt does not bind the trusted helper')
    if expected_files.get('snapshot_inventory.json') != CACHE_SNAPSHOT_SHA256:
        raise AuditError('cache receipt does not bind the trusted snapshot')
    if expected_files.get('extension_trace_audit.jsonl') != CACHE_RECORDS_SHA256:
        raise AuditError('cache receipt does not bind the trusted trace records')
    for name, expected in expected_files.items():
        if Path(name).name != name or file_hash(cache / name) != expected:
            raise AuditError(f'original cached artefact differs: {name}')
    snapshot = json.loads((cache / 'snapshot_inventory.json').read_text())
    summary = json.loads((cache / 'audit_summary.json').read_text())
    if (summary['script_sha256'] != HELPER_SHA256
            or summary['snapshot_inventory_sha256'] != CACHE_SNAPSHOT_SHA256
            or summary['extension_trace_audit_sha256'] != CACHE_RECORDS_SHA256
            or snapshot['extension_manifest_sha256'] != MANIFEST_SHA256):
        raise AuditError('cache summaries do not bind the pinned source and helper')
    execution = json.loads((cache / 'execution_receipt.json').read_text())
    versions = {name: importlib.metadata.version(name) for name in execution['versions']}
    if versions != execution['versions']:
        raise AuditError('diagnostic dependencies differ from the cached inspection')
    if sys.version.split()[0] != execution['python'].split()[0]:
        raise AuditError('Python version differs from the cached inspection')
    jobs = {}
    paths = set()
    for job in snapshot['trace_jobs']:
        if key(job) in jobs or job['trace_path'] in paths:
            raise AuditError('duplicate diagnostic job in the original cache')
        jobs[key(job)] = job
        paths.add(job['trace_path'])
    records = {}
    raw_line_hashes = {}
    with (cache / 'extension_trace_audit.jsonl').open('rb') as stream:
        for line in stream:
            record = json.loads(line)
            identity = key(record)
            if identity in records or identity not in jobs:
                raise AuditError('duplicate or unbound trace record in the original cache')
            require_record(jobs[identity], record)
            records[identity] = record
            raw_line_hashes[identity] = hashlib.sha256(line).hexdigest()
    if len(records) != 698 or set(records) != set(jobs):
        raise AuditError('the trusted 698-record cache is not complete')
    return {'snapshot': snapshot, 'jobs': jobs, 'records': records,
            'raw_line_hashes': raw_line_hashes, 'versions': versions,
            'artefact_hashes': {'artifact_receipt.json': CACHE_RECEIPT_SHA256, **expected_files}}


def current_snapshot(run: Path, old: dict[str, Any]) -> dict[str, Any]:
    """Require the exact planned grid and hash every current cell and trace."""
    manifest_path = run / 'manifest.json'
    if file_hash(manifest_path) != MANIFEST_SHA256:
        raise AuditError('production manifest bytes differ from the trusted source')
    manifest = json.loads(manifest_path.read_text())
    declared = manifest['manifest_content_sha256']
    if canonical_hash({k: v for k, v in manifest.items() if k != 'manifest_content_sha256'}) != declared:
        raise AuditError('production manifest content hash differs')
    planned = manifest['plan']
    planned_ids = {row['cell_id'] for row in planned}
    if (type(manifest['planned_fits']) is not int or manifest['planned_fits'] != EXPECTED_CELLS
            or len(planned) != EXPECTED_CELLS or len(planned_ids) != EXPECTED_CELLS):
        raise AuditError('manifest does not declare exactly 1,625 unique planned cells')
    paths = sorted((run / 'cells').glob('*.json'))
    if {str(path) for path in (run / 'cells').rglob('*.json')} != {str(path) for path in paths}:
        raise AuditError('unexpected nested cell JSON lies outside the recorded flat grid')
    actual_ids = {path.stem for path in paths}
    if len(paths) != EXPECTED_CELLS or actual_ids != planned_ids:
        raise AuditError(f'full-scope audit requires the exact 1,625-cell grid; '
                         f'{len(paths)} present, {len(planned_ids - actual_ids)} missing, '
                         f'{len(actual_ids - planned_ids)} unexpected')
    if any(Path(name).name != name for name in planned_ids):
        raise AuditError('planned identity is not a safe filename')
    planned_by_id = {row['cell_id']: row for row in planned}
    original_cells = {Path(row['path']).name: row['sha256']
                      for row in old['snapshot']['extension_cells']}
    if len(original_cells) != 752:
        raise AuditError('the original 752-cell snapshot is not unique')
    if not set(original_cells) <= {path.name for path in paths}:
        raise AuditError('a cell from the original immutable snapshot is missing')
    cells, jobs, trace_hashes = [], [], {}
    recorded_trace_write_errors = {}
    job_keys = set()
    for path in paths:
        cell_hash = file_hash(path)
        if path.name in original_cells and cell_hash != original_cells[path.name]:
            raise AuditError(f'previously inspected cell bytes changed: {path.name}')
        cell = json.loads(path.read_text())
        if cell['cell_id'] != path.stem or cell['status'] not in {
            'complete', 'failed', 'failed_diagnostics',
        }:
            raise AuditError(f'cell identity or status differs: {path.name}')
        if canonical_hash({k: v for k, v in cell.items() if k != 'cell_content_sha256'}) != cell['cell_content_sha256']:
            raise AuditError(f'cell content hash differs: {path.name}')
        plan = planned_by_id[cell['cell_id']]
        if (canonical_hash(cell['train_subject_ids']) != plan['train_sha256']
                or cell['training_membership_sha256'] != plan['train_sha256']
                or canonical_hash(cell['validation_subject_ids']) != plan['validation_sha256']
                or cell['censoring_cutoff'] != plan['censoring_cutoff']):
            raise AuditError(f'cell memberships or cutoff differ from plan: {path.name}')
        cells.append({'path': str(path), 'sha256': cell_hash, 'status': cell['status'],
                      'model_key': cell['model_key']})
        attempts = cell.get('fit_attempts', [])
        if cell['model_key'] in BAYESIAN_MODELS and cell['status'] in {'complete', 'failed_diagnostics'} and not attempts:
            raise AuditError(f'Bayesian cell lacks attempted fits: {path.name}')
        for index, attempt in enumerate(attempts):
            posterior = attempt.get('diagnostics', {})
            prior = attempt.get('prior_diagnostics', {})
            traces = attempt.get('traces', {})
            required = {'posterior', 'prior'} if cell['model_key'].startswith('catalytic_') else {'posterior'}
            if cell['model_key'] in BAYESIAN_MODELS:
                if cell['status'] in {'complete', 'failed_diagnostics'} and set(traces) != required:
                    raise AuditError(f'Bayesian attempt lacks its recorded trace groups: {path.name}')
                if cell['status'] == 'failed' and not set(traces) <= required:
                    raise AuditError(f'failed Bayesian attempt has an unexpected trace label: {path.name}')
            if traces and cell['model_key'] not in BAYESIAN_MODELS:
                raise AuditError(f'non-Bayesian attempt declares diagnostic traces: {path.name}')
            if type(attempt['attempt']) is not int or attempt['attempt'] != index + 1:
                raise AuditError(f'fit attempt numbering differs: {path.name}')
            if cell['status'] == 'failed' and cell['model_key'] in BAYESIAN_MODELS:
                for error in attempt.get('trace_write_errors', []):
                    label = error.get('label')
                    if label not in required:
                        continue
                    failed_path = run / 'traces' / cell['cell_id'] / f'attempt_{attempt["attempt"]}_{label}.nc'
                    recorded_trace_write_errors[str(failed_path)] = {
                        'cell_id': cell['cell_id'], 'cell_sha256': cell_hash,
                        'attempt': attempt['attempt'], 'trace_label': label,
                        'trace_write_error': error,
                        'reason_not_diagnosed': 'recorded trace-write error; no checkpoint trace hash',
                    }
            accepted = (cell['status'] == 'complete' and index == len(attempts) - 1
                        and bool(posterior.get('converged'))
                        and (not prior or bool(prior.get('converged'))))
            if cell['model_key'] in BAYESIAN_MODELS and cell['status'] == 'complete' and index == len(attempts) - 1 and not accepted:
                raise AuditError(f'accepted Bayesian cell lacks passing recorded gates: {path.name}')
            for label, trace in traces.items():
                filename = trace['filename']
                if Path(filename).name != filename or not filename.endswith('.nc'):
                    raise AuditError(f'unsafe recorded trace filename: {path.name}')
                trace_path = run / 'traces' / cell['cell_id'] / filename
                if trace_path.is_symlink() or any(p.is_symlink() for p in (trace_path.parent, run / 'traces')):
                    raise AuditError(f'symlinked diagnostic trace: {trace_path}')
                observed_hash = file_hash(trace_path)
                if observed_hash != trace['sha256']:
                    raise AuditError(f'current trace bytes differ: {trace_path}')
                diagnostics = posterior if label == 'posterior' else prior
                if not diagnostics or not diagnostics.get('variables_checked'):
                    raise AuditError(f'fit lacks a recorded convergence inventory: {trace_path}')
                job = {'cell_path': str(path), 'cell_sha256': cell_hash,
                       'cell_id': cell['cell_id'], 'model_key': cell['model_key'],
                       'cell_status': cell['status'], 'attempt': attempt['attempt'],
                       'trace_label': label, 'actual_accepted_fit': accepted,
                       'trace_path': str(trace_path), 'expected_trace_sha256': trace['sha256'],
                       'stored_diagnostics': diagnostics}
                if key(job) in job_keys or str(trace_path) in trace_hashes:
                    raise AuditError(f'duplicate diagnostic job or trace path: {trace_path}')
                job_keys.add(key(job))
                trace_hashes[str(trace_path)] = observed_hash
                jobs.append(job)
    actual_trace_paths = {str(path) for path in (run / 'traces').rglob('*.nc')}
    unreferenced = actual_trace_paths - set(trace_hashes)
    if set(trace_hashes) - actual_trace_paths:
        raise AuditError(f'final trace inventory lacks {len(set(trace_hashes) - actual_trace_paths)} referenced files')
    cell_by_id = {Path(row['path']).stem: row for row in cells}
    unreferenced_artefacts = {}
    for name in sorted(unreferenced):
        path = Path(name)
        if any(parent.is_symlink() for parent in path.parents if parent.is_relative_to(run)):
            raise AuditError(f'symlinked unreferenced trace artefact: {path}')
        owner_id = path.relative_to(run / 'traces').parts[0]
        owner = cell_by_id.get(owner_id)
        unreferenced_artefacts[name] = {
            'sha256': file_hash(path), 'cell_directory_label': owner_id,
            'owning_cell_path': owner['path'] if owner else None,
            'owning_cell_sha256': owner['sha256'] if owner else None,
            'owning_cell_status': owner['status'] if owner else None,
            'matching_recorded_trace_write_error': recorded_trace_write_errors.get(name),
            'worker_log_evidence': 'not inspected by this driver',
            'checkpoint_trace_hash_comparison': 'unavailable: no recorded trace entry',
            'stored_diagnostic_or_gate_comparison': 'unavailable: no recorded trace entry',
            'numerical_diagnostics_inspected': False,
            'scope': 'unreferenced bytes retained separately from the referenced diagnostic audit',
        }
    return {'manifest_sha256': MANIFEST_SHA256, 'planned_cells': EXPECTED_CELLS,
            'source_cells': cells, 'status_counts': dict(Counter(row['status'] for row in cells)),
            'jobs': jobs, 'trace_sha256': trace_hashes,
            'unreferenced_trace_artefacts': unreferenced_artefacts}


def require_trace_inventory(helper: Any, job: dict[str, Any]) -> None:
    """Inspect NetCDF metadata before restricting numerical checks to recorded variables."""
    idata = helper.az.from_netcdf(job['trace_path'])
    try:
        expected = job['stored_diagnostics']
        variables = list(idata.posterior.data_vars)
        count = 0
        for value in idata.posterior.data_vars.values():
            if not {'chain', 'draw'} <= set(value.dims):
                raise AuditError(f'recorded posterior variable lacks chain/draw dimensions: {key(job)}')
            size = 1
            for dim in value.dims:
                if dim not in ('chain', 'draw'):
                    size *= value.sizes[dim]
            count += size
        if variables != expected['variables_checked'] or count != expected['n_parameters_checked']:
            raise AuditError(f'current trace convergence inventory differs: {key(job)}')
        if 'energy' not in idata.sample_stats or not {'chain', 'draw'} <= set(idata.posterior.dims):
            raise AuditError(f'current trace lacks recorded convergence groups: {key(job)}')
        energy = idata.sample_stats['energy']
        if set(energy.dims) != {'chain', 'draw'} or any(
            energy.sizes[dim] != idata.posterior.sizes[dim] for dim in ('chain', 'draw')
        ):
            raise AuditError(f'current energy dimensions differ from the posterior: {key(job)}')
    finally:
        idata.close()


def final_source_check(run: Path, snapshot: dict[str, Any], cache: Path,
                       old: dict[str, Any], driver_sha: str) -> None:
    """Rehash all immutable inputs before permitting a complete receipt."""
    if file_hash(Path(__file__)) != driver_sha:
        raise AuditError('driver bytes changed during inspection')
    if file_hash(run / 'manifest.json') != snapshot['manifest_sha256']:
        raise AuditError('source manifest changed during inspection')
    current_cells = {str(path) for path in (run / 'cells').glob('*.json')}
    if {str(path) for path in (run / 'cells').rglob('*.json')} != current_cells:
        raise AuditError('unexpected nested cell JSON appeared during inspection')
    if current_cells != {row['path'] for row in snapshot['source_cells']}:
        raise AuditError('source cell inventory changed during inspection')
    current_traces = {str(path) for path in (run / 'traces').rglob('*.nc')}
    expected_traces = (set(snapshot['trace_sha256'])
                       | set(snapshot['unreferenced_trace_artefacts']))
    if current_traces != expected_traces:
        raise AuditError('source trace inventory changed during inspection')
    for row in snapshot['source_cells']:
        if file_hash(Path(row['path'])) != row['sha256']:
            raise AuditError(f'source cell changed during inspection: {row["path"]}')
    for name, expected in snapshot['trace_sha256'].items():
        if file_hash(Path(name)) != expected:
            raise AuditError(f'source trace changed during inspection: {name}')
    for name, artefact in snapshot['unreferenced_trace_artefacts'].items():
        if file_hash(Path(name)) != artefact['sha256']:
            raise AuditError(f'unreferenced trace artefact changed during inspection: {name}')
    for name, expected in old['artefact_hashes'].items():
        if file_hash(cache / name) != expected:
            raise AuditError(f'trusted cached artefact changed during inspection: {name}')


def summarise(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Separate complete coverage from observed diagnostic-boundary findings."""
    counts = {
        'traces_with_nonfinite_draws': sum(bool(r['raw_energy_nonfinite_values'])
            or any(v['nonfinite_draw_values'] for v in r['raw_posterior_findings']) for r in records),
        'traces_with_nonfinite_diagnostic_rows': sum(bool(r['nonfinite_diagnostic_rows']) for r in records),
        'traces_with_nonfinite_bfmi': sum(bool(r['nonfinite_bfmi_chains']) for r in records),
        'traces_with_masked_nonfinite_gate': sum(any(f['is_acceptance_gate'] for f in r['masked_nonfinite_fields']) for r in records),
        'actual_accepted_fit_traces_with_masked_gate': sum(r['actual_accepted_fit']
            and any(f['is_acceptance_gate'] for f in r['masked_nonfinite_fields']) for r in records),
        'traces_with_constant_posterior_components': sum(any(v['globally_constant_components']
            or v['chain_constant_components'] for v in r['raw_posterior_findings']) for r in records),
        'traces_with_zero_energy_variance': sum(bool(r['zero_energy_variance_chains']) for r in records),
        'traces_with_reduced_gate_mismatch': sum(not all(r['reduced_gate_statistics_match_stored'].values()) for r in records),
    }
    return {'diagnostic_boundary_clean': not any(counts.values()), **counts,
            'parameter_rows_checked': sum(r['summary_parameter_count'] for r in records),
            'accepted_bayesian_fits_inspected': len({r['cell_id'] for r in records if r['actual_accepted_fit']})}


def main() -> int:
    """Write a fresh full-scope receipt only after immutable exact-grid checks."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, default=DEFAULT_RUN)
    parser.add_argument('--cache', type=Path, default=DEFAULT_CACHE)
    parser.add_argument('--output', type=Path, default=DRIVER_DIR / 'full_grid_result')
    parser.add_argument('--preflight-only', action='store_true', help='verify scope/cache/hash boundaries without writing audit output or computing new diagnostics')
    args = parser.parse_args()
    run, cache, output = args.run.resolve(), args.cache.resolve(), args.output.resolve()
    if not output.is_relative_to(DRIVER_DIR) or output == DRIVER_DIR:
        raise AuditError('output must be a new child directory of this external driver folder')
    if (run.is_relative_to(output) or output.is_relative_to(run)
            or cache.is_relative_to(output) or output.is_relative_to(cache)):
        raise AuditError('audit output overlaps immutable source or cached evidence')
    driver_sha = file_hash(Path(__file__))
    old = load_cache(cache)
    snapshot = current_snapshot(run, old)
    if args.preflight_only:
        print(f'Exact {EXPECTED_CELLS}-cell scope, cache bindings and {len(snapshot["jobs"])} current trace hashes verified; no diagnostic scan or output writes.')
        return 0
    output.mkdir(exist_ok=False)
    snapshot.update({'started_utc': datetime.now(UTC).isoformat(),
                     'scope_status': 'candidate_exact_grid_not_yet_audit_complete',
                     'run_root': str(run), 'cache_root': str(cache),
                     'driver_sha256': driver_sha, 'trusted_helper_sha256': HELPER_SHA256,
                     'cache_artefact_sha256': old['artefact_hashes'],
                     'diagnostic_dependencies': old['versions']})
    write_once(output / 'source_snapshot.json', snapshot)
    spec = importlib.util.spec_from_file_location('frozen_saved_diagnostic_helper', cache / 'audit_saved_diagnostics.py')
    if spec is None or spec.loader is None:
        raise AuditError('cannot load the pinned inspection helper')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    records, bindings = [], []
    reused = newly_checked = 0
    with (output / 'trace_records.jsonl').open('x', encoding='utf-8') as stream:
        for index, job in enumerate(snapshot['jobs'], start=1):
            identity = key(job)
            reused_record = old['records'].get(identity)
            if reused_record is not None and old['jobs'][identity] == job:
                record = reused_record
                origin = 'exact_cached_job_and_bytes'
                cached_line_sha = old['raw_line_hashes'][identity]
                reused += 1
            else:
                require_trace_inventory(helper, job)
                record = helper.inspect_trace(job)
                origin = 'new_pinned_helper_inspection'
                cached_line_sha = None
                newly_checked += 1
            require_record(job, record)
            wrapper = {'job': job, 'job_content_sha256': canonical_hash(job),
                       'record': record, 'record_content_sha256': canonical_hash(record),
                       'origin': origin, 'cached_record_line_sha256': cached_line_sha,
                       'trusted_helper_sha256': HELPER_SHA256}
            line = json.dumps(wrapper, sort_keys=True, allow_nan=False) + '\n'
            stream.write(line)
            stream.flush()
            bindings.append({'cell_id': job['cell_id'], 'attempt': job['attempt'],
                             'trace_label': job['trace_label'], 'origin': origin,
                             'job_content_sha256': wrapper['job_content_sha256'],
                             'record_content_sha256': wrapper['record_content_sha256'],
                             'written_line_sha256': hashlib.sha256(line.encode('utf-8')).hexdigest(),
                             'cached_record_line_sha256': cached_line_sha})
            records.append(record)
            if index % 50 == 0 or index == len(snapshot['jobs']):
                print(f'{index}/{len(snapshot["jobs"])} bound traces: {reused} reused, {newly_checked} newly inspected.', flush=True)
    if len(records) != len(snapshot['jobs']) or len({key(r) for r in records}) != len(records):
        raise AuditError('audit coverage is not exactly one record per referenced trace')
    final_source_check(run, snapshot, cache, old, driver_sha)
    result = {'completed_utc': datetime.now(UTC).isoformat(),
              'audit_complete': True, 'scope_complete': True, 'source_cells': EXPECTED_CELLS,
              'referenced_traces': len(records), 'cached_records_reused': reused,
              'new_traces_inspected': newly_checked, **summarise(records),
              'unreferenced_trace_artefacts': len(snapshot['unreferenced_trace_artefacts']),
              'referenced_diagnostic_scope_complete': True,
              'orphan_trace_diagnostics_verified': False,
              'orphan_diagnostic_scope': 'not inspected; no stored-diagnostic/gate comparison claimed',
              'original_752_cell_cache_unchanged': True,
              'groups_checked': ['posterior', 'sample_stats.energy'],
              'scope': 'all recorded convergence traces of the exact completed 1,625-cell extension grid',
              'primary_full_trace_limitation_unchanged': True,
              'frozen_convergence_gate_changed': False}
    result['status'] = 'complete_clean' if result['diagnostic_boundary_clean'] else 'complete_with_findings'
    result['result_content_sha256'] = canonical_hash(result)
    write_once(output / 'audit_summary.json', result)
    receipt = {'receipt_utc': datetime.now(UTC).isoformat(),
               'status': result['status'], 'audit_complete': True, 'scope_complete': True,
               'source_manifest_sha256': MANIFEST_SHA256, 'driver_sha256': driver_sha,
               'trusted_helper_sha256': HELPER_SHA256,
               'cache_artefact_sha256': old['artefact_hashes'],
               'output_sha256': {name: file_hash(output / name) for name in
                                 ('source_snapshot.json', 'trace_records.jsonl', 'audit_summary.json')},
               'record_bindings': bindings}
    receipt['receipt_content_sha256'] = canonical_hash(receipt)
    write_once(output / 'completion_receipt.json', receipt)
    print(json.dumps(result, indent=2, sort_keys=True), flush=True)
    return 0 if result['diagnostic_boundary_clean'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (AuditError, FileExistsError) as error:
        print(f'AUDIT REFUSED: {error}', file=sys.stderr)
        raise SystemExit(2) from error
