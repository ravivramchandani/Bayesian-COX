#!/usr/bin/env bash
# Execute only after all pending gates in prerequisites.json are complete/reviewed.
set -euo pipefail
set -C
RUNBOOK_DIR=/Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v1
source "$RUNBOOK_DIR/paths.sh"
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
for item in "$RUN/completion.json" "$RUN/verification.json" "$REPRODUCTION/receipts" \
  "$RENDERED/lineage.json" "$QA/review.json" "$QA/visual_qa_receipt.json" \
  "$FAILURE_AUDIT/snapshots" "$VALIDATION_LOGS/bundle_manifest.json" \
  "$EXTENSIONS/diagnostic_boundary_fullgrid_v1/full_grid_result/completion_receipt.json"; do
  test -e "$item"
done
test ! -e "$STAGE"
test ! -e "$TRANSFER_HOME"
mkdir "$TRANSFER_HOME"
"$PYTHON" -B "$TOOLS/scripts/extension_release/stage_extensions.py" \
  --production-code "$PRODUCTION" --analysis-code "$ANALYSIS" \
  --matched "$MATCHED" --matched-manifest "$MATCHED_MANIFEST" \
  --raw-source "$RAW_SOURCE" --source-report "$SOURCE_REPORT" \
  --run "$RUN" --reproduction "$REPRODUCTION" --rendered "$RENDERED" \
  --qa-dir "$QA" --worker-logs "$WORKER_LOGS" \
  --prestage-helper "$PRESTAGE_HELPER" --coordinator-helper "$COORDINATOR_HELPER" \
  --reference-root "$REFERENCE_ROOT" --preparation-dir "$PREPARATION_DIR" \
  --failure-audit "$FAILURE_AUDIT" --validation-logs "$VALIDATION_LOGS" \
  --clone-staging --output "$STAGE" > "$TRANSFER_HOME/stage-record.json"
"$PYTHON" -B "$RUNBOOK_DIR/measure_space.py" before-package "$STAGE" "$TRANSFER_HOME" "$PHYSICAL_VOLUME"
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
"$PYTHON" -B "$TOOLS/scripts/extension_release/package.py" \
  "$STAGE" "$PACKAGE" --max-mib 500 > "$TRANSFER_HOME/package-summary.json"
"$PYTHON" -B "$RUNBOOK_DIR/measure_space.py" before-download "$STAGE" "$TRANSFER_HOME" "$PHYSICAL_VOLUME"
# package-summary.json contains the canonical digest; root records it separately
# in the committed release receipt before the fresh remote verification.
