#!/usr/bin/env bash
# Run once after uploading the finished package to a new private draft release.
set -euo pipefail
set -C
RUNBOOK_DIR=/Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v1
source "$RUNBOOK_DIR/paths.sh"
: "${PUBLISHED_TAG:?Set the exact private extension release tag}"
: "${TRUSTED_CANONICAL_SHA256:?Set the digest from the separately recorded committed release receipt}"
case "$PUBLISHED_TAG" in *pending*|*'<'*|*'>'*) exit 2 ;; esac
[[ "$TRUSTED_CANONICAL_SHA256" =~ ^[0-9a-f]{64}$ ]]
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
test -d "$TRANSFER_HOME"
for target in "$DOWNLOAD" "$RESTORED" "$PRODUCTION_CODE" "$ANALYSIS_CODE" "$RECEIVER_CLONE"; do
  test ! -e "$target"
done
gh auth status
test "$(gh repo view "$GITHUB_REPO" --json isPrivate --jq '.isPrivate')" = true
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
gh repo clone "$GITHUB_REPO" "$RECEIVER_CLONE"
git -C "$RECEIVER_CLONE" checkout --detach "$TOOLS_COMMIT"
# Keep the fixed tested helpers as the execution pin and prove the fresh clone matches.
for name in archive_common.py audit_rank_failures.py audit_support.py failure_transfer.py \
  package.py qa_transfer.py stage_extensions.py verify.py verify_restored_science.py; do
  cmp "$TOOLS/scripts/extension_release/$name" "$RECEIVER_CLONE/scripts/extension_release/$name"
done
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
mkdir "$DOWNLOAD"
gh release download "$PUBLISHED_TAG" --repo "$GITHUB_REPO" --dir "$DOWNLOAD" \
  --pattern inventory.json --pattern 'part-[0-9][0-9][0-9][0-9][0-9][0-9].tar.gz'
"$PYTHON" -B "$RUNBOOK_DIR/measure_space.py" before-restore \
  "$STAGE" "$TRANSFER_HOME" "$PHYSICAL_VOLUME" "$TRUSTED_CANONICAL_SHA256"
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
"$PYTHON" -B "$TOOLS/scripts/extension_release/verify.py" \
  "$DOWNLOAD" "$RESTORED" --expected-sha256 "$TRUSTED_CANONICAL_SHA256" \
  > "$TRANSFER_HOME/remote-archive-verification.json"
"$PYTHON" -B - "$RESTORED/code/production.tar.gz" "$PRODUCTION_COMMIT" \
  "$RESTORED/code/analysis.tar.gz" "$ANALYSIS_COMMIT" \
  > "$TRANSFER_HOME/code-archive-commits.json" <<'PY'
import json
import sys
import tarfile

rows = []
for path, expected in zip(sys.argv[1::2], sys.argv[2::2], strict=True):
    with tarfile.open(path, 'r:gz') as archive:
        observed = archive.pax_headers.get('comment')
    if observed != expected:
        raise SystemExit('Code archive commit differs: ' + path)
    rows.append({'archive': path, 'verified_commit': observed})
print(json.dumps(rows, indent=2, sort_keys=True))
PY
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
mkdir "$PRODUCTION_CODE"
mkdir "$ANALYSIS_CODE"
tar -xzf "$RESTORED/code/production.tar.gz" -C "$PRODUCTION_CODE"
tar -xzf "$RESTORED/code/analysis.tar.gz" -C "$ANALYSIS_CODE"
"$PYTHON" -B "$RUNBOOK_DIR/check_prepared_pins.py"
"$PYTHON" -B "$TOOLS/scripts/extension_release/verify_restored_science.py" \
  --production-code "$PRODUCTION_CODE" --analysis-code "$ANALYSIS_CODE" \
  --restored "$RESTORED" --primary "$PRIMARY" --sampler "$SAMPLER" \
  --robustness "$ROBUSTNESS" --report "$TRANSFER_HOME/restored-science-verified.json" \
  > "$TRANSFER_HOME/restored-science.log"
gh release view "$PUBLISHED_TAG" --repo "$GITHUB_REPO" \
  --json url,tagName,isDraft,assets > "$TRANSFER_HOME/remote-release-assets.json"
