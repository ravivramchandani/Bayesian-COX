# Final extension transfer runbook

**Prepared commands only. No staging, package, download, restore or publication has run.** Existing inputs, observed hashes and all stage arguments are in `prepared_inputs.json`; genuinely pending paths/hashes are in `prerequisites.json`. All output destinations are explicitly new.

The numerical coordinator retains finalization, official 92-refit comparison, rendering and QA preparation ownership. Root controls review/launch of `complete_postfit_support_v1.py`, which supplies the finished-grid rank and diagnostic-boundary audits. Inspect its actual ownership/markers; do not duplicate those jobs. Review supporting findings separately from the frozen fitting gates.

After actual inspection, retain the completed `pdf_qa_v1/review.json` and issue its receipt using **original analysis855**, whose prepared helper hash is `f56cf814…920c7c0` and renderer hash `2155dbe1…ad85cd2`:

```bash
source /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v1/paths.sh
"$PYTHON" -B "$ANALYSIS/scripts/extension_release/extension_pdf_qa.py" receipt \
  --qa-dir "$QA" --review "$QA/review.json"
```

Root seals `integration_validation_bundle_v3` only after completed supporting audits are reviewed. Include all five validation versions, both receiving-guide versions, full boundary driver/preparation/result, original coordinator/support history, old failure-v1 and its exact helper, current transfer-tool receipt, and storage receipts. Preserve failure-v2 separately as the stager's failure input.

Run:

```bash
bash /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v1/stage_package.sh
```

This uses native clone staging at `~/bayes-cox-runs/extensions-20260928/release_stage_v1`, then package storage in the mounted task APFS image. It records source/package/remaining-space measurements for both image and physical backing drive. Mount checks bind the actual APFS device and sparsebundle to the retained preflight receipt immediately before transfer operations. Record the printed canonical digest separately in the committed release receipt. Write factual release notes from verified evidence at `$TRANSFER_HOME/release-notes.md`.

Create a new private draft only after the complete evidence gates:

```bash
source /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v1/paths.sh
PUBLISH_TAG='<pending-new-private-extension-tag>'
test "$(gh repo view "$GITHUB_REPO" --json isPrivate --jq '.isPrivate')" = true
gh release create "$PUBLISH_TAG" "$PACKAGE/inventory.json" "$PACKAGE"/part-*.tar.gz \
  --repo "$GITHUB_REPO" --target "$TOOLS_COMMIT" --draft --latest=false \
  --title 'Post-hoc extension evidence — 2026-09-28' \
  --notes-file "$TRANSFER_HOME/release-notes.md"
PUBLISHED_TAG="$PUBLISH_TAG" \
TRUSTED_CANONICAL_SHA256='<pending-canonical-digest-from-committed-receipt>' \
  bash /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v1/remote_restore.sh
```

The receiving phase creates one fresh clone, downloads only inventory/numeric shards, verifies their trusted digest/all bytes, extracts both commit-identified code archives outside evidence, then rechecks all science and 92 stored trace comparisons without fitting. Commands remain pinned to clean tested transfer commit `2b701a8`; the fresh clone's matching helper bytes are checked.

After the scientific report passes, record remote asset hashes/counts, publication identity and factual close-out in Git; publish the verified private draft with `gh release edit "$PUBLISH_TAG" --repo "$GITHUB_REPO" --draft=false`, verify it, and commit/push final handoff. No output is overwritten; preserve a failed attempt and select fresh destinations for a retry.
