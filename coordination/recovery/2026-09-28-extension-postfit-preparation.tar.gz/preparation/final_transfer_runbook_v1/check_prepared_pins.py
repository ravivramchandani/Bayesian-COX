"""Check immutable preparation bindings without running a scientific stage."""
from __future__ import annotations

import hashlib
import json
import plistlib
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
record = json.loads((ROOT / 'prepared_inputs.json').read_text())
for name, checkout in record['checkouts'].items():
    path = Path(checkout['path'])
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=path, text=True).strip()
    dirty = subprocess.check_output(['git', 'status', '--porcelain'], cwd=path, text=True).strip()
    if commit != checkout['commit'] or dirty:
        raise SystemExit('Immutable checkout identity/cleanliness differs: ' + name)
for path, expected in record['static_small_file_sha256'].items():
    source = Path(path)
    if not source.is_file() or source.is_symlink():
        raise SystemExit('Missing/linked prepared source: ' + path)
    with source.open('rb') as stream:
        observed = hashlib.file_digest(stream, 'sha256').hexdigest()
    if observed != expected:
        raise SystemExit('Prepared source bytes changed: ' + path)
mount = Path(record['storage']['apfs_mount'])
physical = Path(record['storage']['physical_volume'])
if mount.is_symlink() or not mount.is_mount() or not physical.is_mount():
    raise SystemExit('The task APFS image is not mounted')
info = plistlib.loads(subprocess.check_output(['diskutil', 'info', '-plist', str(mount)]))
if str(info.get('FilesystemType', '')).lower() != 'apfs':
    raise SystemExit('Package/restore destination must be the prepared APFS image')
internal_preflight = Path('/Users/macuser/bayes-cox-runs/extensions-20260928/external_volume_preflight.json')
mounted_preflight = mount / 'external_volume_preflight.json'
if (mounted_preflight.is_symlink() or not mounted_preflight.is_file()
        or mounted_preflight.read_bytes() != internal_preflight.read_bytes()):
    raise SystemExit('Mounted image preflight receipt binding differs')
preflight = json.loads(internal_preflight.read_text())
if (preflight['mount_point'] != str(mount)
        or preflight['image'] != record['storage']['sparsebundle']
        or preflight['physical_volume'] != str(physical)):
    raise SystemExit('Retained storage receipt refers to another image/drive')
images = plistlib.loads(subprocess.check_output(['hdiutil', 'info', '-plist']))['images']
if not any(image.get('image-path') == preflight['image'] and any(
    entity.get('mount-point') == str(mount) for entity in image.get('system-entities', [])
) for image in images):
    raise SystemExit('Actual mounted device is not bound to the task sparsebundle')
print('Prepared pins and actual mounted APFS image match the retained storage receipt.')
