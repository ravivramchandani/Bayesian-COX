"""Finish independent source-grid audits after the existing fitting workers exit.

This companion never fits, refits, finalizes, renders or approves visual QA.
The existing numerical coordinator keeps ownership of those stages.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

HOME = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
RUN = HOME / 'run'
TOOLS = Path('/Users/macuser/bayes-cox-runs/extensions-transfer-code-20260928-2b701a8')
PRODUCTION = Path('/Users/macuser/bayes-cox-runs/extensions-code-20260928-119476f')
MATCHED = Path('/Users/macuser/bayes-cox-runs/extension-preparation-20260928/matched_metabric.parquet')
PYTHON = '/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python'
AUDIT = HOME / 'diagnostic_boundary_fullgrid_v1'
WORKERS = (62025, 62026, 62027, 62028, 62029, 62030)
TOOL_COMMIT = '2b701a87a2c8b97b5d4034276a437755e74f1fbd'
RANK_HELPER_SHA = '98cc7563c466e01d5bc72b8ba72a5beda771dceee16aeb3224a9639e1c1030fe'
BOUNDARY_DRIVER_SHA = '20a7e53880c223fafedac7a4ea400399262a28fafba8d908fdced0d1d2841a7b'
MANIFEST_SHA = '83b9049fb6aaaadab576b34de0741e4f510344dcefba9f96198d15b5ab4f49b9'


def now() -> str:
    """Return an explicit UTC timestamp."""
    return datetime.now(timezone.utc).isoformat()


def digest(path: Path) -> str:
    """Hash a fixed input or completed receipt."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_once(path: Path, record: object) -> None:
    """Retain each marker without overwriting earlier bytes."""
    with path.open('x', encoding='utf-8') as handle:
        json.dump(record, handle, indent=2, sort_keys=True)
        handle.write('\n')


def active(pid: int) -> bool:
    """Recognize only the original fitting command, guarding against PID reuse."""
    result = subprocess.run(['ps', '-p', str(pid), '-o', 'command='],
                            capture_output=True, text=True)
    return result.returncode == 0 and 'scripts/run_extensions.py' in result.stdout


def run_step(name: str, command: list[str], allowed: set[int]) -> tuple[int, Path, Path]:
    """Run one independent audit with a new complete log."""
    log = HOME / 'worker_logs' / f'postfit_support_{name}_v1.log'
    errors = HOME / 'worker_logs' / f'postfit_support_{name}_v1.stderr.log'
    print(now(), 'START', name, flush=True)
    environment = {**os.environ, 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
                   'VECLIB_MAXIMUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1',
                   'NUMBA_CACHE_DIR': str(AUDIT / 'numba_cache')}
    with log.open('x', encoding='utf-8') as stream, errors.open('x', encoding='utf-8') as stderr:
        result = subprocess.run(command, cwd=TOOLS, env=environment,
                                stdout=stream, stderr=stderr)
    if result.returncode not in allowed:
        raise RuntimeError(f'{name} exited {result.returncode}; see {log}')
    print(now(), 'DONE', name, result.returncode, flush=True)
    return result.returncode, log, errors


def main() -> None:
    """Require the finished source grid, then retain both audit results."""
    driver_sha = digest(Path(__file__))
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TOOLS, text=True).strip()
    if head != TOOL_COMMIT or subprocess.check_output(['git', 'status', '--porcelain'], cwd=TOOLS, text=True):
        raise RuntimeError('reviewed transfer tool checkout differs')
    if digest(TOOLS / 'scripts/extension_release/audit_rank_failures.py') != RANK_HELPER_SHA:
        raise RuntimeError('reviewed rank helper differs')
    if digest(AUDIT / 'run_full_grid_audit.py') != BOUNDARY_DRIVER_SHA:
        raise RuntimeError('reviewed diagnostic-boundary driver differs')
    if digest(RUN / 'manifest.json') != MANIFEST_SHA:
        raise RuntimeError('source manifest differs')
    print(now(), 'WAITING for existing fitting workers; no new fits', flush=True)
    prior = -1
    while any(active(pid) for pid in WORKERS):
        count = len(list((RUN / 'cells').glob('*.json')))
        if count != prior:
            print(now(), 'source cells', count, '/ 1625', flush=True)
            prior = count
        time.sleep(60)
    if len(list((RUN / 'cells').glob('*.json'))) != 1625:
        raise RuntimeError('fitting workers exited before the complete source grid')
    rank_exit, rank_log, rank_errors = run_step('rank', [PYTHON,
        str(TOOLS / 'scripts/extension_release/audit_rank_failures.py'),
        '--production-code', str(PRODUCTION), '--run', str(RUN),
        '--matched', str(MATCHED), '--output', str(HOME / 'failure_provenance_v2')], {0})
    rank_result = json.loads(rank_log.read_text())
    snapshot_path = Path(rank_result['snapshot'])
    snapshot = json.loads(snapshot_path.read_text())
    if (snapshot['available_source_cells_scanned'] != 1625
            or snapshot['bindings']['audit_helper_sha256'] != RANK_HELPER_SHA
            or digest(snapshot_path) != rank_result['snapshot_sha256']):
        raise RuntimeError('rank audit did not bind the full grid and reviewed helper')
    boundary_exit, boundary_log, boundary_errors = run_step('boundary',
        [PYTHON, '-B', str(AUDIT / 'run_full_grid_audit.py')], {0, 1})
    boundary_receipt_path = AUDIT / 'full_grid_result/completion_receipt.json'
    boundary_summary_path = AUDIT / 'full_grid_result/audit_summary.json'
    boundary_receipt = json.loads(boundary_receipt_path.read_text())
    boundary_summary = json.loads(boundary_summary_path.read_text())
    if (not boundary_receipt['audit_complete'] or not boundary_receipt['scope_complete']
            or boundary_summary['source_cells'] != 1625
            or boundary_receipt['driver_sha256'] != BOUNDARY_DRIVER_SHA):
        raise RuntimeError('diagnostic-boundary receipt lacks complete referenced scope')
    for name, expected in boundary_receipt['output_sha256'].items():
        if digest(boundary_receipt_path.parent / name) != expected:
            raise RuntimeError(f'completed boundary output differs: {name}')
    if digest(Path(__file__)) != driver_sha:
        raise RuntimeError('support companion changed during execution')
    record = {
        'schema_version': 1, 'prepared_utc': now(), 'source_cells': 1625,
        'status': 'postfit_support_complete_review_pending',
        'driver_sha256': driver_sha, 'transfer_tool_commit': TOOL_COMMIT,
        'rank_audit_exit_code': rank_exit, 'rank_result': rank_result,
        'boundary_exit_code': boundary_exit,
        'boundary_completion_receipt_sha256': digest(boundary_receipt_path),
        'boundary_summary_sha256': digest(boundary_summary_path),
        'boundary_diagnostic_findings': not boundary_summary['diagnostic_boundary_clean'],
        'logs_sha256': {str(path): digest(path) for path in
                       (rank_log, rank_errors, boundary_log, boundary_errors)},
        'scientific_completion': 'not_assessed; existing coordinator and final QA/transfer own those gates',
        'models_fitted': False, 'frozen_gate_changed': False,
    }
    write_once(HOME / 'postfit_support_prepared_v1.json', record)
    print(now(), 'PREPARED independent support; root review, actual visual QA and transfer remain', flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        traceback.print_exc()
        write_once(HOME / 'postfit_support_failure_v1.json',
                   {'failed_utc': now(), 'error_type': type(exc).__name__, 'error': str(exc)})
        raise
