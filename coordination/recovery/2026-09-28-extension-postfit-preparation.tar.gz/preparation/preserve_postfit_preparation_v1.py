"""Preserve reviewed post-fit ownership and transfer preparation, without fitting."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
OUTPUT = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
MANIFEST_SHA = '83b9049fb6aaaadab576b34de0741e4f510344dcefba9f96198d15b5ab4f49b9'


def sha(data: bytes) -> str:
    """Hash exact bytes for retained provenance."""
    return hashlib.sha256(data).hexdigest()


def write_once(path: Path, record: object) -> None:
    """Write a new receipt without replacing an earlier record."""
    with path.open('x', encoding='utf-8') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main() -> None:
    """Archive immutable preparation and a dated partial-grid observation."""
    tested_path = OUTPUT / 'transfer_validation_v5_extension_documentation/tested_source.json'
    tested = json.loads(tested_path.read_text())
    if not all(sha((ROOT / name).read_bytes()) == expected for name, expected in tested.items()):
        raise RuntimeError('Previously tested source bytes differ')
    manifest_bytes = (OUTPUT / 'run/manifest.json').read_bytes()
    if sha(manifest_bytes) != MANIFEST_SHA:
        raise RuntimeError('Frozen source manifest differs')
    manifest = json.loads(manifest_bytes)
    planned = {row['cell_id'] for row in manifest['plan']}
    if len(planned) != manifest['planned_fits'] or len(planned) != 1625:
        raise RuntimeError('Unexpected frozen grid')
    cell_rows = []
    status_counts: Counter[str] = Counter()
    group_counts: Counter[str] = Counter()
    for path in sorted((OUTPUT / 'run/cells').glob('*.json')):
        data = path.read_bytes()
        cell = json.loads(data)
        if cell['cell_id'] != path.stem or cell['cell_id'] not in planned:
            raise RuntimeError(f'Unexpected source cell: {path.name}')
        status_counts[cell['status']] += 1
        group_counts[f"{cell['dataset']}/{cell['setting']}"] += 1
        cell_rows.append({'path': f'run/cells/{path.name}', 'sha256': sha(data),
                          'cell_id': cell['cell_id'], 'status': cell['status']})
    source_snapshot = {
        'schema_version': 1, 'observed_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Dated stored-cell accounting only; not deep science verification or completion',
        'manifest_sha256': MANIFEST_SHA, 'planned_source_cells': len(planned),
        'stored_source_cells': len(cell_rows), 'stored_status_counts': dict(status_counts),
        'stored_dataset_setting_counts': dict(group_counts), 'source_cells': cell_rows,
        'candidate_refit_cells': len(list((OUTPUT / 'reproduction/cells').glob('*.json'))),
        'official_refit_receipts': len(list((OUTPUT / 'reproduction/receipts').glob('*.json'))),
        'markers': {name: (OUTPUT / name).exists() for name in [
            'analysis_prepared.json', 'coordinator_failure.json',
            'postfit_support_prepared_v1.json', 'postfit_support_failure_v1.json']},
    }
    processes = []
    for pid in [62025, 62026, 62027, 62028, 62029, 62030, 64406, 64435,
                71385, 71386, 98854, 98855]:
        result = subprocess.run(['ps', '-p', str(pid), '-o', 'pid=,ppid=,etime=,%cpu=,command='],
                                capture_output=True, text=True, check=False)
        processes.append({'pid': pid, 'ps_exit_code': result.returncode,
                          'observed': result.stdout.strip()})
    source_snapshot['observed_processes'] = processes
    members = {}
    for folder in [
        'diagnostic_boundary_fullgrid_v1', 'postfit_support_review_v1',
        'final_transfer_runbook_v1', 'final_transfer_runbook_review_v1',
        'final_transfer_runbook_v2', 'final_transfer_runbook_review_v2',
    ]:
        directory = OUTPUT / folder
        if not directory.is_dir():
            raise RuntimeError(f'Reviewed preparation is not available: {folder}')
        for path in sorted(directory.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                if path.is_symlink() or 'full_grid_result' in path.parts:
                    raise RuntimeError('Unexpected linked or completed evidence in preparation')
                members[f'preparation/{folder}/{path.relative_to(directory)}'] = path.read_bytes()
    for name in ['complete_postfit_support_v1.py', 'postfit_support_process_v1.json',
                 'transfer_tool_worktree_verification.json', 'failure_provenance_v2_initial_verification.json',
                 'preserve_postfit_preparation_v1.py']:
        members[f'preparation/{name}'] = (OUTPUT / name).read_bytes()
    rank = json.loads((OUTPUT / 'failure_provenance_v2_initial_verification.json').read_text())
    partial_snapshot = OUTPUT / 'failure_provenance_v2/snapshots' / (
        'failure_provenance_' + rank['snapshot_content_sha256'] + '.json')
    if sha(partial_snapshot.read_bytes()) != rank['snapshot_sha256']:
        raise RuntimeError('Partial rank snapshot differs')
    members['partial_rank_snapshot/' + partial_snapshot.name] = partial_snapshot.read_bytes()
    for row in rank['all_current_retained_array_hashes_checked']:
        if sha((OUTPUT / 'failure_provenance_v2' / row['path']).read_bytes()) != row['sha256']:
            raise RuntimeError('Partial retained synthetic array differs')
    companion = json.loads((OUTPUT / 'postfit_support_process_v1.json').read_text())
    review = OUTPUT / 'postfit_support_review_v1/review_receipt.json'
    if (sha(review.read_bytes()) != companion['prelaunch_review_sha256']
            or sha((OUTPUT / 'complete_postfit_support_v1.py').read_bytes()) != companion['support_script_sha256']):
        raise RuntimeError('Support ownership/source/review binding differs')
    review_v2 = json.loads((OUTPUT / 'final_transfer_runbook_review_v2/review_receipt.json').read_text())
    if (review_v2.get('findings') != []
            or not str(review_v2.get('status', '')).startswith('bounded_static_review_passed')
            or review_v2.get('actual_stage_package_download_restore_fitting_publication_executed') is not False):
        raise RuntimeError('Corrected transfer preparation still has unresolved findings')
    for name, row in review_v2['reviewed_files'].items():
        if sha((OUTPUT / 'final_transfer_runbook_v2' / name).read_bytes()) != row['sha256']:
            raise RuntimeError('Corrected transfer preparation changed after review')
    members['dated_source_snapshot.json'] = (json.dumps(source_snapshot, indent=2, sort_keys=True) + '\n').encode()
    inventory = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
    members['archive_inventory.json'] = (json.dumps(inventory, indent=2, sort_keys=True) + '\n').encode()
    archive = ROOT / 'coordination/recovery/2026-09-28-extension-postfit-preparation.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        if {item.name for item in tar.getmembers()} != set(members):
            raise RuntimeError('Recovery archive inventory differs')
        for item in tar.getmembers():
            stream = tar.extractfile(item)
            if not item.isfile() or stream is None or stream.read() != members[item.name]:
                raise RuntimeError('Recovery archive retained bytes differ')
    if not all(sha((ROOT / name).read_bytes()) == expected for name, expected in tested.items()):
        raise RuntimeError('Previously tested source changed during preservation')
    receipt = {
        'schema_version': 1, 'verified_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'postfit_preparation_reviewed_scientific_and_transfer_completion_pending',
        'archive': str(archive.relative_to(ROOT)), 'archive_bytes': archive.stat().st_size,
        'archive_sha256': sha(archive.read_bytes()), 'archive_members_verified': len(members),
        'archive_member_inventory_sha256': sha(members['archive_inventory.json']),
        'partial_checkpoint': {k: v for k, v in source_snapshot.items()
                               if k not in ['source_cells', 'observed_processes']},
        'support_process': companion, 'support_review_sha256': sha(review.read_bytes()),
        'full_boundary_driver_sha256': sha(
            (OUTPUT / 'diagnostic_boundary_fullgrid_v1/run_full_grid_audit.py').read_bytes()),
        'transfer_runbook_v1_review_sha256': sha(
            (OUTPUT / 'final_transfer_runbook_review_v1/review_receipt.json').read_bytes()),
        'transfer_runbook_v2_review_sha256': sha(
            (OUTPUT / 'final_transfer_runbook_review_v2/review_receipt.json').read_bytes()),
        'rank_partial_snapshot_sha256': rank['snapshot_sha256'],
        'rank_partial_cases': rank['rank_failed_cases'],
        'rank_partial_retained_arrays_rechecked': len(rank['all_current_retained_array_hashes_checked']),
        'tested_source_files_unchanged': len(tested), 'tested_source_sha256': sha(tested_path.read_bytes()),
        'scientific_completion': 'not_assessed',
        'models_fitted_by_preserver': False, 'transfer_executed_by_preserver': False,
        'remaining': ('Finished 1625-cell accounting/deep analysis, 92 exact comparisons, '
                      'reviewed full support audits, actual visual QA, private release '
                      'and fresh remote science restore'),
    }
    write_once(ROOT / 'coordination/recovery/2026-09-28-extension-postfit-preparation-verification.json', receipt)
    print(json.dumps({k: v for k, v in receipt.items() if k != 'support_process'}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
