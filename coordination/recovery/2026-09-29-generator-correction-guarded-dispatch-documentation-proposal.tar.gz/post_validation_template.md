# Conditional wording for root after actual validation

This is a template, not a factual completion statement. Every brace field is
pending. Use it only after the actual full-suite capture succeeds, its tested
source bytes remain equal, and root explicitly adopts the reviewed engineering
source. Link the real retained validation record, then separately verify the
published commit before adding that publication clause.

Guarded-dispatch V3 is source-integrated at `{{PUBLISHED_COMMIT}}`. Its actual
full locked validation passed {{TEST_COUNT}} tests and {{SUBTEST_COUNT}}
subtests with {{SKIP_COUNT}} skips, genuine exit code {{EXIT_CODE}}, at
{{FINISHED_AT_UTC}}; {{TESTED_SOURCE_FILE_COUNT}} captured files remained
unchanged, and the actual Ruff/schema results are recorded in
[the validation record]({{ACTUAL_VALIDATION_RECORD_RELATIVE_PATH}}).
The remote commit/clean-state check was recorded at {{REMOTE_CHECK_UTC}}.
This adopts the engineering source. The five actual scientific review roles,
corrected numerical freeze, ADR-041 selection/named scope, dispatch adoption
and separately captured source/fresh semantic checks remain pending.

Do not reuse this paragraph's pending metrics for a new numerical run,
completed selection, successful pilot, semantic proof or release. JOURNAL
should append an actual-dated entry rather than change the earlier history.
The current proposal's latest-mirror statement remains the completed a26d5a2
v3 mirror until another document-only mirror is genuinely captured.
