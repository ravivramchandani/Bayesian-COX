# Proposed six-document update

This is an unapplied source-only proposal against the six byte-bound resident
documents. No resident/original document, scientific source, owner, review,
selection, freeze or result was changed. Installation and the new full-suite
validation are still pending. The old 998/157 result remains explicitly the
preceding release-v3 checkpoint.

`proposed_patch.diff` contains the exact edits; `paragraphs.json` identifies
the original line spans and full replacement paragraphs. `mapping.md` is the
short six-file map. JOURNAL only appends: its dated V1/V2 findings stay intact.
The latest completed mirror is the actual v3 record for published a26d5a2,
not a mirror performed by this proposal. The supplied 15:18:40 UTC checkpoint
is dated non-atomic metadata, never completion or a timing forecast.

Root should re-read source hashes/anchors before applying the patch because
integration work may advance. Fill `pending_validation_fields.json` solely
from actual finished installation/validation/publication captures. Do not
publish placeholders, turn nulls into success, or attribute the previous
suite to guarded dispatch. After genuine full-suite success and root source
adoption, replace the pending engineering paragraphs using
`post_validation_template.md`, inserting the actual record/commit and metrics.
Keep the five scientific reviews, freeze, ADR-041 selection/scope, dispatch
adoption and source/fresh semantics pending unless their own evidence exists.
No edits to old pins, config, addendum or DECISIONS are proposed. No tests,
controller, source/receiving semantics or process query was executed here.
