"""Archive a completed actual push; do not call Git or numerical owners."""
import importlib.util
import json
from pathlib import Path
BASE=Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
REPO=Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
HERE=Path(__file__).absolute().parent
spec=importlib.util.spec_from_file_location('_root_archive', BASE/'correction_reporting_release_root_closeout_20260929_v1/preserve_checked_records.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.RECOVERY=REPO/'coordination/recovery'
owner=BASE/'guarded_dispatch_v3_integration_actual_push_20260929_v1'
proof=m.load(owner/'verified_push.json')
assert proof['head']==proof['actual_remote_main']=='bb92d4c7cf32a8b3ac510e9180bc7f72a0eab9f5'
assert proof['ahead']==proof['behind']==0 and proof['resident_worktree_clean']
assert len(proof['changed_paths'])==142 and proof['all116_published_carrier_blobs_equal_reviewed_bytes']
assert not proof['scientific_completion_certified'] and not proof['original_git_or_numerical_owners_modified']
invocations=list(owner.glob('*.invocation.json'))
for path in invocations:
    record=m.load(path)
    assert type(record['exit_code']) is int and record['exit_code']==0,path
    assert record['cwd']==str(REPO) and record['argv'][0]=='git'
    assert record['capture_helper']==m.binding(owner/'capture_checkpoint_push.py')
    prefix=path.name.removesuffix('.invocation.json')
    for role,suffix in [('raw_stdout','stdout.log'),('raw_stderr','stderr.log')]:
        assert record[role]==m.binding(owner/(prefix+'.'+suffix)),path
    if 'raw_stdin' in record:assert record['raw_stdin']==m.binding(owner/(prefix+'.stdin.bin'))
source=m.load(BASE/'correction_guarded_dispatch_integration_validation_v3/make_test.tested_source_after.json')
assert len(source)==752 and {name:m.binding(REPO/name) for name in source}==source
members={str(p.relative_to(owner)):p for p in sorted(owner.rglob('*')) if p.is_file()}
assert all(not p.is_symlink() for p in owner.rglob('*'))
members['archival_control/archive_completed_code_push.py']=Path(__file__).absolute()
result=m.archive('guarded-dispatch-v3-actual-push',members)
m.write_new(HERE/'completed_code_push_archive.json',result)
print(json.dumps({'regular_members':result['regular_members'],'actual_zero_return_invocations':len(invocations),'archive':result['archive'],'sha256':result['sha256'],'source752_unchanged':True},sort_keys=True))
