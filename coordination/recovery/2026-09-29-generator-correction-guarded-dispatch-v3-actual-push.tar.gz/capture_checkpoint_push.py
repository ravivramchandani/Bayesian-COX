"""Commit and push exact validated code, guides and curated evidence on main."""
import datetime
import hashlib
import io
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).absolute().parent
BASE = HERE.parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
EXCEPTION = 'scripts/catalytic_correction/guarded_dispatch/preserved_v2/unit_attempt1.stderr.log'


def bind(path):
    assert path.is_file() and not any(p.is_symlink() for p in (path, *path.parents))
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def write(name, value):
    with (HERE / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def run(label, arguments, input_bytes=None):
    argv = ['git', *arguments]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if input_bytes is not None:
        with (HERE / (label + '.stdin.bin')).open('xb') as stream:
            stream.write(input_bytes)
    with (HERE / (label + '.stdout.log')).open('xb') as out, (HERE / (label + '.stderr.log')).open('xb') as err:
        child = subprocess.run(argv, cwd=REPO, input=input_bytes, stdout=out, stderr=err, check=False)
    record = {'argv': argv, 'cwd': str(REPO), 'started_at_utc': started,
              'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': child.returncode,
              'capture_helper': bind(Path(__file__).absolute()),
              'raw_stdout': bind(HERE / (label + '.stdout.log')), 'raw_stderr': bind(HERE / (label + '.stderr.log'))}
    if input_bytes is not None:
        record['raw_stdin'] = bind(HERE / (label + '.stdin.bin'))
    write(label + '.invocation.json', record)
    assert type(child.returncode) is int and child.returncode == 0, (label, child.returncode)
    return (HERE / (label + '.stdout.log')).read_bytes()


assert run('branch', ['branch', '--show-current']).strip() == b'main'
assert run('before_head', ['rev-parse', 'HEAD']).strip() == b'a26d5a2646b35380b8565e211ece6d36278ec3be'
initial = sorted(run('before_index', ['diff', '--cached', '--name-only']).decode().splitlines())
staging = json.loads((BASE / 'correction_guarded_dispatch_integration_validation_v3/staged_complete_carrier.json').read_text())
assert initial == staging['staged_paths'] and len(initial) == 118
source = json.loads((BASE / 'correction_guarded_dispatch_integration_validation_v3/make_test.tested_source_after.json').read_text())
assert len(source) == 752 and {name: bind(REPO / name) for name in source} == source
guides = json.loads((BASE / 'guarded_dispatch_v3_documentation_validation_20260929_v1/final_documents_verified.json').read_text())
assert {name: bind(REPO / name) for name in guides['current_documents']} == guides['current_documents']
run('unstaged_diffcheck', ['diff', '--check'])
unstaged = run('unstaged_paths', ['diff', '--name-only']).decode().splitlines()
assert set(unstaged) == set(guides['current_documents']) and len(unstaged) == 6
untracked = run('untracked_paths', ['ls-files', '--others', '--exclude-standard']).decode().splitlines()
assert untracked and all(name.startswith('coordination/recovery/2026-09-29-generator-correction-') for name in untracked)
assert all(name.endswith(('.json', '.tar.gz')) for name in untracked)
assert all(bind(REPO / name) for name in untracked)
paths = sorted([*initial, *unstaged, *untracked])
assert len(paths) == len(set(paths))
run('stage_guides_and_records', ['add', '--', *unstaged, *untracked])
assert sorted(run('staged_paths', ['diff', '--cached', '--name-only']).decode().splitlines()) == paths
assert bind(REPO / EXCEPTION) == bind(BASE / 'generator_correction_guarded_dispatch_v2/unit_attempt1.stderr.log')
run('staged_diffcheck', ['diff', '--cached', '--check', '--', '.', ':(exclude)' + EXCEPTION])
carrier_paths = [name for name in initial if name.startswith('scripts/catalytic_correction/guarded_dispatch/')]
assert len(carrier_paths) == 116
stream = io.BytesIO(run('staged_carrier_blobs', ['cat-file', '--batch'], ''.join(':' + name + '\n' for name in carrier_paths).encode()))
blobs = {}
for name in carrier_paths:
    header = stream.readline().decode().strip().split()
    assert len(header) == 3 and header[1] == 'blob'
    raw = stream.read(int(header[2]))
    assert stream.read(1) == b'\n'
    evidence = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    assert evidence == bind(REPO / name), name
    blobs[name] = evidence
assert not stream.read()
write('all116_staged_Git_blobs_exact.json', blobs)
run('commit', ['commit', '-m', 'Integrate reviewed safeguard for corrected fit dispatch'])
head = run('after_head', ['rev-parse', 'HEAD']).decode().strip()
run('push', ['push', 'origin', 'main'])
remote = run('actual_remote_head', ['ls-remote', '--heads', 'origin', 'refs/heads/main']).decode().split()[0]
assert remote == head
assert run('ahead_behind', ['rev-list', '--left-right', '--count', 'HEAD...origin/main']).split() == [b'0', b'0']
assert run('clean', ['status', '--porcelain']) == b''
value = {'status': 'checkpoint_committed_pushed_remote_verified',
         'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'head': head, 'actual_remote_main': remote, 'ahead': 0, 'behind': 0, 'resident_worktree_clean': True,
         'changed_paths': paths, 'all116_published_carrier_blobs_equal_reviewed_bytes': True,
         'guard_engineering_source_integrated_and_validated': True,
         'scientific_completion_certified': False, 'original_git_or_numerical_owners_modified': False}
write('verified_push.json', value)
print(json.dumps({k: v for k, v in value.items() if k != 'changed_paths'}, sort_keys=True))
print('Committed paths:', len(paths))
