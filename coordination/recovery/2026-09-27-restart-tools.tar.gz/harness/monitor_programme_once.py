"""Read-only progress snapshot for the running sealed programme."""
import datetime
import json
import subprocess
from pathlib import Path

root = Path('/Users/macuser/bayes-cox-runs/continuation-20260927')
rob = Path('/Users/macuser/bayes-cox-runs/frozen/reports/robustness/confirmatory_v1_robustness_robustness_702d93af33bf')

state_file = root.parent / 'logs/current_resume.json'
state = json.loads(state_file.read_text())
processes = subprocess.check_output(['ps', '-axo', 'pid=,args='], text=True)
rows = {int(parts[0]): parts[1] for line in processes.splitlines()
        if len(parts := line.strip().split(maxsplit=1)) == 2}

def alive(pid, script):
    return script in rows.get(pid, '')

log = root / 'logs/full_reproduction.log'
report = root / 'reproduction/verification.json'
record = json.loads(report.read_text()) if report.is_file() else {}
print(json.dumps({
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'robustness': sum(1 for _ in (rob / 'cells').rglob('*.json')),
    'robustness_complete': (rob / 'completion.json').is_file(),
    'reproduction': sum(1 for _ in (root / 'reproduction/cells').glob('*/*/*.json')),
    'reproduction_complete': record.get('cells_checked') == 450 and record.get('cells_identical') == 450,
    'sampler': sum(1 for _ in (root / 'posthoc_sampler').glob('*/cells/*/*/*.json')),
    'mismatches': log.read_text(errors='replace').count('identical=False') if log.is_file() else 0,
    'failure': (root / 'programme_failure.json').is_file(),
    'analysis_verified': (root / 'programme_analysis_verified.json').is_file(),
    'coordinator_pid': state['coordinator_pid'],
    'coordinator_alive': alive(state['coordinator_pid'], 'complete_results_programme.py'),
    'robustness_workers_alive': sum(alive(pid, 'shard_worker.py') for pid in state['worker_pids']),
    'supervisor_alive': alive(state['supervisor_pid'], 'wait_for_robustness.py'),
    'reproduction_parent_alive': any('reproduce_confirmatory_cells.py' in row and
                                   str(root) in row for row in rows.values()),
}))
