"""Resume the sealed programme after reboot, preserving previous checkpoints."""
from __future__ import annotations

import datetime
import fcntl
import hashlib
import json
import os
import shlex
import shutil
import subprocess
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs')
FROZEN = BASE / 'frozen'
SEALED = BASE / 'refactored-programme-20260927'
OUTPUT = BASE / 'continuation-20260927'
CLAIMS = BASE / 'robustness-claims'
PYTHON = Path('/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python')
SCRIPTS = {'shard_worker.py', 'complete_results_programme.py', 'wait_for_robustness.py',
           'reproduce_confirmatory_cells.py', 'run_horseshoe_sampler_sensitivity.py',
           'run_robustness.py'}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def active_jobs():
    rows = subprocess.check_output(['ps', '-axo', 'pid=,args='], text=True)
    found = []
    for row in rows.splitlines():
        fields = row.strip().split(maxsplit=1)
        if len(fields) != 2:
            continue
        try:
            argv = shlex.split(fields[1])
        except ValueError:
            continue
        if argv and Path(argv[0]).name.startswith('python') and any(
            Path(token).name in SCRIPTS for token in argv[1:]
        ) and any(
            str(BASE) in token for token in argv
        ):
            found.append(int(fields[0]))
    return found


def launch(arguments, cwd, log, *, lower_priority=False):
    with log.open('xb') as handle:
        child = subprocess.Popen(
            arguments, cwd=cwd, stdin=subprocess.DEVNULL, stdout=handle,
            stderr=subprocess.STDOUT, start_new_session=True, close_fds=True,
            preexec_fn=(lambda: os.nice(10)) if lower_priority else None,
        )
    log.with_suffix('.pid').write_text(str(child.pid) + '\n')
    return child


def main():
    with (BASE / 'logs/resume_launcher.lock').open('a+') as guard:
        fcntl.flock(guard.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if active_jobs():
            raise RuntimeError('numerical jobs already exist; no duplicate launched')
        with (OUTPUT / 'programme.lock').open('a+') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest_path = OUTPUT / 'programme_manifest.json'
        manifest = json.loads(manifest_path.read_text())
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SEALED, text=True).strip()
        if head != manifest['code_commit']:
            raise RuntimeError('sealed code identity changed')
        for name, expected in manifest['code_sha256'].items():
            if digest(SEALED / name) != expected:
                raise RuntimeError('sealed code changed: ' + name)
        for root in (FROZEN, SEALED):
            dirty = subprocess.check_output(
                ['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root, text=True,
            )
            if dirty.strip():
                raise RuntimeError('tracked source changed: ' + str(root))
        if not subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=FROZEN, text=True).startswith('2e55c0b'):
            raise RuntimeError('original frozen checkout changed')
        robust = Path(manifest['robustness_dir'])
        if (robust / 'completion.json').exists():
            raise RuntimeError('robustness already completed; this worker restart is unnecessary')
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        logs = BASE / 'logs' / ('resume_' + stamp)
        logs.mkdir()
        old_logs = list((BASE / 'logs').glob('*.log')) + list((BASE / 'logs').glob('*.pid'))
        old_logs += list((OUTPUT / 'logs').glob('*'))
        preserved = {}
        for source in old_logs:
            if source.is_file():
                target = logs / 'previous_logs' / source.relative_to(BASE)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
                if digest(target) != digest(source):
                    raise RuntimeError('log preservation failed')
                preserved[str(target.relative_to(logs))] = digest(target)
        stale = [p for p in CLAIMS.rglob('*.claim')
                 if not (robust / str(p.relative_to(CLAIMS)).removesuffix('.claim')).is_file()]
        receipt = {str(p.relative_to(CLAIMS)): p.read_text() for p in stale}
        (logs / 'released_claims.json').write_text(json.dumps(receipt, indent=2) + '\n')
        if active_jobs():
            raise RuntimeError('a numerical job appeared before recovery; no claims released')
        for claim in stale:
            claim.unlink()
        workers = [launch(
            [str(PYTHON), '-u', str(BASE / 'harness/shard_worker.py'), str(FROZEN), str(CLAIMS), str(i)],
            FROZEN, logs / f'robustness_worker_{i}.log', lower_priority=True,
        ) for i in range(6)]
        worker_pids = [p.pid for p in workers]
        if any(p.poll() is not None for p in workers) or not set(worker_pids).issubset(active_jobs()):
            raise RuntimeError('not every resumed worker is active; inspect the fresh logs')
        supervisor = launch([
            str(PYTHON), '-u', str(SEALED / 'scripts/wait_for_robustness.py'),
            '--project-root', str(FROZEN), '--run-dir', str(robust), '--claims-dir', str(CLAIMS),
        ], SEALED, logs / 'robustness_supervisor.log')
        coordinator = launch([
            str(PYTHON), '-u', 'scripts/complete_results_programme.py',
            '--source-dir', manifest['source_dir'], '--robustness-dir', str(robust),
            '--explanation', str(FROZEN / 'reports/explainability/confirmatory_v1_confirmatory_cdcdcee84651_explainability_v1.json'),
            '--output-dir', str(OUTPUT), '--reproduction-workers', '2', '--sampler-workers', '6',
            '--robustness-supervisor-pid', str(supervisor.pid),
        ], SEALED, logs / 'programme.log')
        wake = launch(['/usr/bin/caffeinate', '-i', '-w', str(coordinator.pid)],
                      SEALED, logs / 'caffeinate.log')
        state = {
            'status': 'resumed_execution_not_completion', 'started_at_utc': stamp,
            'code_commit': head, 'code_files_verified': len(manifest['code_sha256']),
            'programme_manifest_sha256': digest(manifest_path),
            'robustness_cells_before_resume': len(list((robust / 'cells').rglob('*.json'))),
            'reproduction_cells_before_resume': len(list((OUTPUT / 'reproduction/cells').glob('*/*/*.json'))),
            'stale_missing_claims_released': len(stale), 'preserved_logs_sha256': preserved,
            'worker_pids': worker_pids, 'supervisor_pid': supervisor.pid,
            'coordinator_pid': coordinator.pid, 'caffeinate_pid': wake.pid,
            'logs': str(logs), 'output': str(OUTPUT),
        }
        text = json.dumps(state, indent=2, sort_keys=True) + '\n'
        (logs / 'resume_state.json').write_text(text)
        latest = BASE / 'logs/current_resume.json'
        temp = latest.with_suffix('.tmp')
        temp.write_text(text)
        temp.replace(latest)
        print(text, flush=True)


if __name__ == '__main__':
    main()
