# Prospective guarded corrected-fit dispatch

Design only; no new runtime, actual adoption/review/selection/freeze or dispatch is created. Preserve exact old fit-common/controller/child, reproduction, original scientific and addendum/input bytes. The original account phase remains unchanged and cannot dispatch changed fits (`fit_controller.py:226–229`). The guard is a separately named/pinned engineering addition for **pilot and remaining** dispatch.

## Acyclic authority and exact path binding

Before freezing, root's actual `implementation` review retains its five existing minimum fields and adds `dispatch_guard_implementation={source_sha256,preparation:{path,sha256}}` for the independently tested/reviewed new guard bundle. This does not add future selection hashes to `fit_common.execution_definition`, whose old inputs/pins remain unchanged.

After freeze/manifest assembly and actual named ADR-041 scope review, root supplies a separately reviewed guard request/adoption. It binds the final freeze, manifest, immutable selection, scope-review bytes, original implementation-review bytes, guard preparation/source bytes, exact fit/reproduction directories, corrected output, interpreter and phase. The guard checks the implementation review is precisely the `freeze.review_bindings.implementation` file and that its added guard maps equal the supplied preparation and executing files. Root verifies the owned launcher's actual bytes before execution; the launcher and child each check/recheck their own source/preparation/request binding. Neither writes an approval.

Avoid a request/review cycle: first assemble the unsigned request body; hash its fixed fields excluding the future adoption carrier and its own content seal. Actual named root adoption reviews that digest. The final request adds `{path,sha256}` for that review. Each later phase has its own reviewed body; fixed introduction bindings remain identical.

Proposed sources are a small stdlib owned launcher `capture_guarded_dispatch.py`, child gate `guard_fit_dispatch.py`, and read-only `verify_guarded_dispatch_proof.py`. Their future hashes and tested preparation are pending. The child privately loads exact b17f378 fit support as `_reproduction_bound_common` and exact fa43d4 reproduction core, then calls existing `load_selection(selection,selection_sha,reproduction_code)` before any fit-controller spawn. It invokes no reproduction main, comparator, checker, model or score in-process. That predicate validates the old reproduction/fit/comparison pins, five freeze reviews, exact union/recipes and scope. Refuse foreign `src` namespaces and unsafe aliases; recheck imports/origins/bytes.

Require exact safe canonical path equality, not prefix guesses or file-copy equivalence:

- Selection freeze/manifest paths and hashes equal actual CLI freeze/manifest arguments.
- `selection.paths.fit_code` equals actual CLI fit-code; the dispatched script is its exact old `fit_controller.py`.
- `selection.paths.corrected_run` equals actual CLI output; all fixed definition/inventory/manifest bindings agree.
- Actual locked interpreter is the executing interpreter; all five numeric variables are already one. Preserve old child full-environment checks.

The scope review must have its old status/digest/manifest/pre-score fields plus genuine `reviewer_name`, `reviewer_role="root"`, `reviewed_at_utc`. The adoption also has named actual root review metadata. These additions require root review before use; none is filled by this design. The pre-score boolean alone is never accepted as historical timing proof.

## First introduction and immutable resume

Use only `<corrected_run>/passes/guarded_dispatch_v1/` for introduction/history/captures. Root originally owns the corrected root; old `prepare_output` may create it or validate a matching account-only root. Refuse active controller/cell ownership without taking over. Use an exclusive guard-owned claim inside this namespace, without occupying old `controller.claim.json` ahead of its child.

First introduction requires **no descendant at all under attempts**, including empty attempt directories, request-only failures, traces and orphan/cache bytes. Every existing cell must be an exactly verified account-only reuse/input-failure envelope with `fit_dispatched=false` and `newly_executed_fit=false`; reject any corrected numerical reference, numerical operation or unexpected root/node. Inventory the complete account-only metadata/artifacts, excluding only this newly owned guard namespace to avoid self-reference. Recheck before publication and immediately before spawn. An unclassified prior attempt blocks introduction; no deletion or retrospective adoption is permitted.

Exclusively publish/fsync immutable `introduction.json` with actual selection/scope/freeze/manifest/output/source/preparation/adoption hashes and the zero-corrected-attempt inventory **before** starting the old controller. The positive write-before-spawn order and captured actual child invocation establish prospective timing for this owned run. This is no global claim about unknown other directories; root remains responsible for authentic scope review and sole-owner launch discipline.

Resume requires that original introduction and its bound review/request/preparation bytes still verify, with identical selection, scope, source, freeze, manifest, definition, inventory and output. Keep all history. A new phase/pilot-review/resolution/limit adoption may append only after checking those fixed bindings; it cannot create a new selection or introduction after scores. Old controller rules decide pending owners and prior failed attempts; never substitute smaller pilots or automatically retry an orphan. Remaining phase also passes the actual existing pilot review to the unchanged controller; validate it via the pinned controller predicate before spawn.

## Genuine capture and failures

The owned launcher captures the guard subprocess; the guard captures the old controller subprocess. Each retains actual argv/cwd/interpreter/environment/source/request/start/end/typed return code and raw stdout/stderr. Preparation never invents these values. Publish successful capture only after genuine rc0 and unchanged final gates; nonzero/launch error retains diagnostic capture and no success receipt. Preserve the entire corrected attempts tree, including failed/orphan traces; do not rewrite cells, scientific statuses or controller passes.

Per invocation, retain an exclusive `invocations/<id>/` subtree with request/adoption snapshots, guard launch/raw result, prelaunch proof and controller invocation/raw result. `introduction.json` binds immutable evidence, not later mutable logs or future results. Capture finish records bind their completed logs; they never hash themselves. Partial interrupted streams remain explicitly partial until an actual parent return is captured. No automatic stale-claim clearing, failed-attempt cleanup, signal or restart.

Record complete before/after attempt identity, directory/file roster and request-byte bindings for each controller invocation. Every final corrected attempt must belong to exactly one recorded new-attempt delta; preserve unmatched or interrupted evidence without a successful coverage claim. Final stage inventories bind all retained file bytes, including failures and orphans.

## Reader compatibility confirmed by source inspection

| Reader | Evidence and limit |
|---|---|
| Old fit controller | `prepare_output:60–79` permits safe nested regular trees under existing passes; `run:278–307` writes its own direct UUID passes. |
| Mixed verifier | `verification_gates:198–224` checks corrected cells/claims/controller and pilot envelopes; per-fit checks in `mixed_analysis:70–103` stay inside attempts. Its closed output inventory (`verification_gates:258–267`) describes the separate verifier output, not corrected-run passes. |
| Selected reproduction/receiving | `run_reproduction:133–178` and receiving's corrected-envelope reads consume specific corrected cells/attempts, with no closed corrected passes roster. Its direct-pass restrictions refer to the **selected-reproduction** root, which is not changed. |
| Release v2/v3 and restore | `release_core:149–169,180–197` inventories corrected_run as a full tree; `stage:310–315,343–349` copies and rechecks every nested file/empty directory. Corrected_run maps to `evidence/corrected_run`; v3 delegates this old role. Full trusted directory receiving inventories preserve nested guard bytes. |

These readers transport the namespace but do not validate its semantics. Preserve the exact guard bundle/request/reviews and complete capture history there; whole-tree retention remains mandatory.

## Separate source and fresh-receiving semantic verification

Proposed pure public API: `verify_guarded_dispatch_proof(request, request_sha256, locations) -> factual_receipt`; CLI `verify_guarded_dispatch_proof.py --request ABS --request-sha256 SHA --locations ABS --locations-sha256 SHA --output NEW_EXTERNAL`. All bindings are actual root-supplied values, still pending. The new verifier never dispatches, claims ownership, changes evidence, generates approvals or certifies numerical science.

At source use explicit identity mappings. At receiving use root-trusted stage/archive inventories and explicit historical-to-restored directory/file tuples, covering corrected run, guard bundle and all existing selection/freeze input roles. Require exact files **and directories**, no missing/extra bytes, unsafe nodes, aliases or conflicting nested maps; verify before and after. Mapping provenance must be independently pinned by the actual transport/source-review evidence, never accepted only because a document calls itself trusted. Do not rewrite sealed JSON or recorded argv.

Reuse the byte-pinned receiving `Resolver`/`mapped_common` pattern (`receiving_core.py:114–269`) for isolated stdlib support: map `safe`, `sha`, `read_json`, `file_binding`, `verify_files`, `read_original_manifest` and pinned bootstrap reads, then rerun unchanged `load_selection`/`load_gates`. `safe` alone is insufficient; direct recipe text reads must receive the already resolved path. Ban all writes/copy/claims/dispatch/scientific helpers, including `load_receiving_dependencies` (which imports science/checks the environment). Retain historical strings for request/argv comparisons; resolve physical reads separately and idempotently. The current Resolver checks exact file trees; additionally enforce the release directory roster. Load controller predicates only through a scoped verified support alias, restored in `finally`.

Verify the actual named implementation/scope/adoption review bindings, unchanged execution definition, exact selection and fixed CLI path/hash identities, introduction's zero-attempt account snapshot, and every append-only invocation. First dispatch must cite the already published introduction; completed capture records bind introduction/request bytes and actual argv, sources, interpreter, numeric environment, start/end, typed subprocess return codes and closed raw streams. The two reviewed capture implementations must supply the real launch/wait result chain; a guard's `passed`/`exit_code` field alone is insufficient. Historical failed/partial invocations remain retained and explicitly classified. Reject missing completed parent capture, changed histories or an active guard claim; do not infer rc or success from orphan files. Bind every corrected attempt request to one recorded controller dispatch using the same freeze/manifest/output, while leaving fit/scoring predicates unchanged.

Root must run and independently review this semantic verifier at source before staging, and again against the freshly restored trees before final release completion. Capture each actual invocation/raw stdout/stderr/rc externally, outside immutable restored evidence. These two genuine capture receipts are additional release evidence; preparation creates neither. The fresh receipt cannot enter a presealed source bundle. Unchanged original/mixed/reproduction/QA/restore gates remain separately required and confer no blanket guard approval.

Root reviews this design before implementation. Focused fictional tests must cover every binding mismatch, missing named review, first-introduction orphan/refit refusal, allowed account-only state, write-before-spawn, immutable resume/selection refusal, owner/pilot barriers, two genuine mocked return chains, collision/partial-output retention and unchanged nested-reader inventories. No real dataset, checker, fit or dispatch test is authorised by this document.
