"""Capture genuine sequential checkpoint commit/push; resident checkout only."""
from pathlib import Path
import datetime,hashlib,json,subprocess
HERE=Path(__file__).absolute().parent
REPO=Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
def binding(path):
 raw=path.read_bytes();return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
def run(label,arguments):
 argv=['git',*arguments];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (HERE/(label+'.stdout.log')).open('xb') as out,(HERE/(label+'.stderr.log')).open('xb') as err:
  result=subprocess.run(argv,cwd=REPO,stdout=out,stderr=err,check=False)
 record={'argv':argv,'cwd':str(REPO),'started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'capture_helper':binding(Path(__file__)),'raw_stdout':binding(HERE/(label+'.stdout.log')),'raw_stderr':binding(HERE/(label+'.stderr.log'))}
 with (HERE/(label+'.invocation.json')).open('x') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
 assert type(result.returncode)is int and result.returncode==0,(label,result.returncode)
 return (HERE/(label+'.stdout.log')).read_text().strip()
assert run('branch',['branch','--show-current'])=='main'
assert run('before_head',['rev-parse','HEAD'])=='fe1c26de2c71e91fd026474e412e72343a0153e8'
assert run('before_index',['diff','--cached','--name-only'])==''
run('before_diffcheck',['diff','--check'])
paths=['coordination/HANDOFF.md', 'coordination/JOURNAL.md', 'coordination/TODO.md', 'docs/catalytic_correction_execution.md', 'docs/code_guide.md', 'docs/ravi_handoff.md', 'coordination/recovery/2026-09-29-generator-correction-document-mirror-v2-actual-capture.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-document-mirror-v2.json', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-independent-runtime-review-v1.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-independent-runtime-review-v2.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-portable-adapter-v2.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-portable-test-plan.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-preparation-actual-push.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-preparation-v2.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-v1-independent-review.json', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-v2-documentation-checks.json', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-v2-documentation-checks.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-v2-review.json', 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-v2-root-checkpoint.tar.gz', 'coordination/recovery/2026-09-29-generator-correction-original-checkout-document-mirror-actual-v2.tar.gz']
run('stage',['add','--',*paths])
assert set(run('staged_paths',['diff','--cached','--name-only']).splitlines())==set(paths)
run('staged_diffcheck',['diff','--cached','--check'])
run('commit',['commit','-m','Preserve second dispatch review and simplify Ravi handoff'])
head=run('after_head',['rev-parse','HEAD'])
run('push',['push','origin','main'])
remote=run('actual_remote_head',['ls-remote','--heads','origin','refs/heads/main']).split()[0]
assert remote==head
assert run('ahead_behind',['rev-list','--left-right','--count','HEAD...origin/main']).split()==['0','0']
assert run('clean',['status','--porcelain'])==''
result={'status':'checkpoint_committed_pushed_remote_verified','verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'actual_remote_main':remote,'ahead':0,'behind':0,'resident_worktree_clean':True,'changed_paths':paths,'guard_implementation_adopted':False,'scientific_completion_certified':False,'original_git_or_numerical_owners_modified':False}
with (HERE/'verified_push.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(result,sort_keys=True))
