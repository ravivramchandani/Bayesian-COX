"""Retain the completed finalizer capture after its parent has returned."""
import importlib.util
import json
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
HERE = Path(__file__).absolute().parent
VALIDATION = BASE / 'correction_guarded_dispatch_integration_validation_v3'
spec = importlib.util.spec_from_file_location('_root_completed_archival', BASE / 'correction_reporting_release_root_closeout_20260929_v1/preserve_checked_records.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.RECOVERY = REPO / 'coordination/recovery'
capture = json.loads((VALIDATION / 'integration_final_root.invocation.json').read_text())
assert type(capture['exit_code']) is int and capture['exit_code'] == 0 and capture['tested_source_before_equals_after']
for stream in ('stdout', 'stderr'):
    assert module.binding(VALIDATION / ('integration_final_root.' + stream + '.log')) == {k: capture['logs'][stream][k] for k in ('bytes', 'sha256')}
members = {str(p.relative_to(VALIDATION)): p for p in sorted(VALIDATION.iterdir()) if p.is_file()}
assert len(members) == 87 and not any(p.is_dir() for p in VALIDATION.iterdir())
archive = module.archive('guarded-dispatch-integration-validation-v3-completed', members)
target = REPO / 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-integration-v3.json'
preceding = target.read_bytes()
with (HERE / 'integration_compact_preceding_archival_completion.json').open('xb') as stream:
    stream.write(preceding)
value = json.loads(preceding)
value['preceding_partial_finalizer_self_capture_archive'] = value['integration_validation_archive']
value['integration_validation_archive'] = {k: v for k, v in archive.items() if k != 'members'}
value['integration_archival_completion'] = {
    'completed_final_root_capture': module.binding(VALIDATION / 'integration_final_root.invocation.json'),
    'actual_final_root_exit_code': capture['exit_code'],
    'complete87_file_validation_archived_after_parent_completed': True,
    'preceding85_file_snapshot_contains_dated_in_progress_finalizer_streams': True,
    'preceding_partial_snapshot_retained_and_not_used_as_completed_capture': True,
    'validation_owner_is_now_closed_and_will_not_be_extended': True}
historical = REPO / 'scripts/catalytic_correction/guarded_dispatch/preserved_v2/unit_attempt1.stderr.log'
original = BASE / 'generator_correction_guarded_dispatch_v2/unit_attempt1.stderr.log'
assert module.binding(historical) == module.binding(original)
value['exact_historical_whitespace_exception'] = {
    'path': str(historical.relative_to(REPO)), 'binding': module.binding(historical),
    'preserved_exact_original_attempt_bytes': True, 'only_that_path_excluded_from_git_whitespace_check': True}
target.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
result = {'status': 'completed87_file_validation_snapshot_retained',
          'archive': {k: v for k, v in archive.items() if k != 'members'},
          'actual_final_root_capture_checked': True,
          'preceding_partial_snapshot_explicitly_retained': True,
          'exact_historical_whitespace_exception': value['exact_historical_whitespace_exception'],
          'no_implementation_scientific_or_owner_change': True}
with (HERE / 'completed_validation_archive_check.json').open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(result, sort_keys=True))
