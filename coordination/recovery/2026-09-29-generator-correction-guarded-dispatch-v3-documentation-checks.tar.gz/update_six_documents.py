"""Apply reviewed document spans using the actual completed engineering record."""
import datetime
import hashlib
import json
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
HERE = Path(__file__).absolute().parent
PROPOSAL = BASE / 'generator_correction_guarded_dispatch_documentation_proposal_v1'
RECORD = '2026-09-29-generator-correction-guarded-dispatch-integration-v3.json'


def bind(path):
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


receipt = json.loads((PROPOSAL / 'proposal_receipt.json').read_text())
assert bind(PROPOSAL / 'proposal_receipt.json')['sha256'] == '26f9423b8ef22a48d8508d3254cca730a22e7ff4c646d90e29e44953203e506d'
assert all(bind(PROPOSAL / name) == expected for name, expected in receipt['artifacts'].items())
assert all(bind(REPO / name) == expected for name, expected in receipt['source_documents'].items())
integration = json.loads((REPO / 'coordination/recovery' / RECORD).read_text())
test = integration['full_locked_test']
assert integration['guard_engineering_source_adopted_by_root'] and test['actual_exit_code'] == 0
assert test['passed_tests'] == 1040 and test['passed_subtests'] == 293 and test['skips'] == 0
assert test['tested_source_files'] == 752 and test['source_before_equals_after']
progress = json.loads((HERE / 'dated_checkpoint_after_integration.stdout.log').read_text())
assert progress['checked_at_utc'].startswith('2026-09-29T15:38:44')
assert progress['independent_first_draw_receipts'] == 707 and progress['original_stored_cells'] == 1115
assert progress['original_outcome_status_counts'] == {'complete': 917, 'failed': 170, 'failed_diagnostics': 28}
changes = json.loads((PROPOSAL / 'paragraphs.json').read_text())['changes']
assert len(changes) == 14
root_text = {
0: '''General Git synchronization is deferred while those owners are active;
no stash, fetch or merge has occurred. At 14:55 UTC on 29 September the
six disjoint documents were mirrored from remote-verified `a26d5a2`.
All six matched published bytes; 135 other scoped files, the 141-file backup,
six preceding published variants, 24 selected shared-Git administrative files
and 634 implementation files remained unchanged. Its actual zero-return
capture is retained in
`coordination/recovery/2026-09-29-generator-correction-document-mirror-v3.json`.''',
1: '''The guarded-dispatch design preserves the existing scientific pins and adds
ADR-041's actual selection and named scope review before pilot/remaining
fits. V1 remains preserved and unadopted after three counterexamples involving
input protection, numerical references in no-fit records and account-pass
bindings. V2 remains preserved and unadopted after independent probes accepted
contradictory original-reuse decisions.

V3 closes those gaps and is now integrated as reviewed engineering source at
`scripts/catalytic_correction/guarded_dispatch/`. Its full locked suite passed
1,040 tests and 293 subtests with zero skips at 15:34:34 UTC; all 752 captured
implementation files were unchanged. Repository-wide Ruff passed. All 634
preceding implementation files, 157 original source/build/lock files and
original scientific pins remain unchanged. The exact reviewed carrier and
portable fixtures, all prior failures, independent reviews and completed
validation captures are retained in
`coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-integration-v3.json`.
The separately retained AST convention clarification leaves its metadata's
historical creation interpreter unknown; the actual tests use the locked
Python 3.11 environment.

Pilot/remaining fits must use `capture_guarded_dispatch.py`. The five actual
method, arithmetic, input-witness, implementation and freeze reviews,
corrected numerical freeze, ADR-041 selection/scope and named dispatch
adoption remain pending. First introduction refuses prior numerical attempts;
resume retains the original proof. Separately captured source and genuine
fresh receiving calls to `verify_guarded_dispatch_proof.py` remain required
before release completion. Existing release-v3 transports that history but
does not run those semantic checks. The prior design and exact checkout
backup remain linked from the checkout-preservation record.''',
2: '''passing fictional tests do not certify actual dispatch or scientific results.

At 15:38:44 UTC on 29 September, the non-atomic metadata checkpoint had 707 of
1,650 independently verified first-draw receipts and 1,115 of 1,625 original
outcomes: 917 complete, 170 failed and 28 failed diagnostics. The actual
presence query returned zero with all 15 selected PIDs present. The 634
preceding implementation files and 20 original source pins were unchanged;
the parent capture also bound all 752 current implementation files.
This is a dated progress checkpoint, not a completed grid or numerical
approval. Its capture is retained with the document-validation checkpoint.''',
3: 'Predispatch engineering enforcement is integrated and tested; the actual numerical prerequisites remain pending.',
4: '''  V1/V2 guard carriers, counterexamples and failed preparation attempts remain
  preserved and unadopted. Reviewed V3 is integrated at
  `scripts/catalytic_correction/guarded_dispatch/`. Its actual full locked suite
  passed 1,040 tests/293 subtests with zero skips at 15:34:34 UTC; all 752
  captured files were unchanged and repository-wide Ruff passed. The exact
  reviewed preparations, complete Git roster, failed metadata checks and
  completed captures are linked from the guarded-dispatch integration-v3
  record. All preceding scientific pins/configuration/addendum remain unchanged.
  Before pilot/remaining dispatch, supply the five actual scientific review
  roles, corrected numerical freeze, ADR-041 selection/named scope review and
  named guard request/adoption. Use the guarded launcher; preserve the direct
  account phase. Genuine separate source/fresh receiving semantic captures
  remain required before release completion.''',
5: '''  stash, fetch or merge occurred. At 14:55 UTC on 29 September six disjoint
  documents were mirrored from remote-verified `a26d5a2`. Their published
  bindings, 135 non-target scoped files, preceding backups and selected
  shared-Git metadata stayed unchanged. That actual zero-return mirror and
  parent capture are in the v3 mirror record.''',
6: '''

## 2026-09-29 — Guarded-dispatch V3 integrated and verified

Reviewed V3 is integrated with its complete 116-file carrier and two portable
test sources. The actual full locked suite passed 1,040 tests and 293 subtests,
zero skips, at 15:34:34 UTC. All 752 captured files stayed unchanged; repository-
wide Ruff passed. All 634 preceding implementation files, 157 original
source/build/lock files and old scientific pins/configuration/addendum remain
unchanged. The focused installed fixtures passed 42 tests/136 subtests.

V1/V2 source and failed attempts remain exact. The independent V3 runtime
review checked 41 tests/nine cases; its portable review checked all 497 inputs
unchanged and found no material delta issue. Both stopped metadata validators
remain retained. The separate AST clarification proves equal old/new controls
under locked 3.11 and current 3.14; creation-time metadata interpreter identity
remains unknown. The finalizer's dated partial self-capture is retained beside
the completed 87-file validation snapshot. One exact historical failed-check
log retains trailing whitespace; only that byte-pinned path is excluded from
Git's whitespace check. The complete carrier, including ignored logs, is staged.
Evidence is linked from
`coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-integration-v3.json`.

The five actual scientific review roles, corrected numerical freeze,
ADR-041 selection/scope, named dispatch adoption and actual source/fresh
semantic captures remain pending. No corrected fit or release is certified.
The 14:55 UTC document mirror used published `a26d5a2`; its actual v3 record
is preserved. At 15:38:44 UTC the dated metadata check recorded 707 independent
first-draw receipts and 1,115 original outcomes (917 complete, 170 failed,
28 failed diagnostics). All 15 selected PIDs were present. Original workers,
continuation and observer ownership remain unchanged.
''',
7: '''The corrected launch safeguard is integrated as reviewed engineering source.
Earlier V1/V2 versions and their review failures remain preserved. The five
actual scientific reviews, corrected numerical freeze, ADR-041 selection/named
scope review and dispatch adoption are still pending.

Corrected pilot/remaining fits use the
[guarded launcher](../scripts/catalytic_correction/guarded_dispatch/capture_guarded_dispatch.py).
The separate `verify_guarded_dispatch_proof.py` checks retained dispatch
history. Its actual source and fresh receiving captures remain required
before release completion. Scientific budgets and acceptance gates are unchanged.''',
8: '''components. The full locked suite passed 1,040 tests and 293 subtests with
zero skips at 15:34:34 UTC on 29 September; all 752 captured files remained
unchanged. Repository-wide lint passed. These are implementation checks;
the numerical programme remains in progress.''',
9: '''At 15:38:44 UTC on 29 September, a non-atomic metadata check showed 707 of
1,650 independent input receipts and 1,115 of 1,625 original outcomes:
917 complete, 170 failed and 28 failed diagnostics. All 15 monitored jobs
were present. These are dated progress counts.
Original successes/failures and interrupted storage/replay evidence remain
preserved. Keep SSD980 and its two mounted images available while jobs run.
Owner-side integration uses the resident checkout; only the six published
guide/coordination documents are mirrored into the original IDE checkout
while live worktrees depend on its shared Git metadata. The
[14:55 document mirror](../coordination/recovery/2026-09-29-generator-correction-document-mirror-v3.json)
records that narrow update from published `a26d5a2`.''',
11: '''Guarded-dispatch V3 is integrated and verified engineering source. Its full
locked suite passed 1,040 tests/293 subtests with zero skips; all 752 captured
files were unchanged and repository-wide Ruff passed. The exact reviewed
source, portable fixtures and prior failed checks are retained in the
[integration record](../coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-integration-v3.json).
V1/V2 remain preserved and unadopted. Pilot/remaining work uses the guarded
launcher and still requires the five actual scientific review roles, numerical
freeze, ADR-041 selection/named scope and named dispatch adoption. Existing
release-v3 transports the history but does not invoke its semantic CLI;
genuine source and fresh receiving captures remain separate requirements.
Follow the [execution guide](catalytic_correction_execution.md).''',
}
before = {name: bind(REPO / name) for name in receipt['source_documents']}
texts = {name: (REPO / name).read_text() for name in before}
for index, change in enumerate(changes):
    path = change['file']
    proposed = root_text.get(index, change['proposed'])
    if index == 10:
        proposed = proposed.replace(' fits, after source adoption |', ' fits |')
    elif index == 12:
        proposed = proposed.replace('implementation. Direct `account` remains unchanged. After source adoption,\npilot/remaining calls must use', 'implementation. Direct `account` remains unchanged. Pilot/remaining calls\nmust use')
    elif index == 13:
        proposed = proposed.replace('The V3 guarded-dispatch carrier is reviewed engineering preparation.', 'The V3 guarded-dispatch carrier is integrated and tested engineering source.')
        proposed = proposed.replace('Repository\ninstallation and full-suite validation remain pending before source adoption.\nTheir actual counts, UTC finish, source equality and verified published\ncommit must be recorded separately.', 'Its full locked suite passed 1,040 tests and 293 subtests with zero skips\nat 15:34:34 UTC; all 752 captured files were unchanged and repository-wide\nRuff passed. Actual captures and reviewed-source bindings are in the\n[integration record](../coordination/recovery/' + RECORD + ').')
        proposed = proposed.replace('The future actual launcher is', 'The launcher is')
    original = change['original']
    if original:
        assert texts[path].count(original) == 1, (index, path)
        texts[path] = texts[path].replace(original, proposed, 1)
    else:
        assert path == 'coordination/JOURNAL.md'
        texts[path] += proposed
texts['docs/ravi_handoff.md'] = texts['docs/ravi_handoff.md'].replace('2026-09-29-generator-correction-release-v3-integration.json', RECORD, 1)
marker = '## What is on GitHub'
assert texts['docs/ravi_handoff.md'].split(marker, 1)[1] == (REPO / 'docs/ravi_handoff.md').read_text().split(marker, 1)[1]
backups = HERE / 'documents_before'
backups.mkdir()
for name in before:
    target = backups / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write((REPO / name).read_bytes())
    assert bind(target) == before[name]
    (REPO / name).write_text(texts[name])
after = {name: bind(REPO / name) for name in before}
result = {'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'six_documents_updated_from_actual_reviewed_integration',
          'proposal_receipt': bind(PROPOSAL / 'proposal_receipt.json'),
          'actual_integration_record': bind(REPO / 'coordination/recovery' / RECORD),
          'full_test': test, 'dated_progress': progress,
          'documents_before': before, 'documents_after': after,
          'all_six_preceding_variants_exactly_backed_up': True,
          'Ravi_baseline_body_unchanged': True,
          'original_checkout_numerical_owners_or_scientific_files_modified': False}
with (HERE / 'six_document_update.json').open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('documents_before', 'documents_after', 'dated_progress')}, sort_keys=True))
