"""Archive completed guide checks separately from this archival process."""
import importlib.util
import json
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
HERE = Path(__file__).absolute().parent
DOCS = BASE / 'guarded_dispatch_v3_documentation_validation_20260929_v1'
spec = importlib.util.spec_from_file_location('_root_document_archive', BASE / 'correction_reporting_release_root_closeout_20260929_v1/preserve_checked_records.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.RECOVERY = REPO / 'coordination/recovery'
final = module.load(DOCS / 'final_documents_verified.json')
assert {name: module.binding(REPO / name) for name in final['current_documents']} == final['current_documents']
capture = module.load(DOCS / 'final_document_checks.invocation.json')
assert type(capture['exit_code']) is int and capture['exit_code'] == 0 and capture['tested_source_before_equals_after']
members = {str(p.relative_to(DOCS)): p for p in sorted(DOCS.rglob('*')) if p.is_file()}
members['archival_control/archive_document_checks.py'] = Path(__file__).absolute()
archives = {'actual_document_checks': module.archive('guarded-dispatch-v3-documentation-checks', members)}
for name, owner, pin, count in (
    ('guarded-dispatch-documentation-review', 'generator_correction_guarded_dispatch_documentation_review_v1', '8d2c06c38ffbd15b5348f520740477a57d902e3a8b9b0dc2eb61e5a400a719ba', 4),
    ('guarded-dispatch-documentation-review-followup', 'generator_correction_guarded_dispatch_documentation_review_followup_v1', '0effc9bcc27379374204e0cbf0d4425c0940874faed2cbb8390db29403691f45', 2),
):
    root = BASE / owner
    receipt = module.load(root / 'receipt.json')
    assert {str(p.relative_to(root)): module.binding(p) for p in root.rglob('*') if p.is_file()} == {**receipt['artifacts'], 'receipt.json': module.binding(root / 'receipt.json')}
    archives[name] = module.sealed(name, root, 'receipt.json', pin)
    assert archives[name]['regular_members'] == count
follow = module.load(BASE / 'generator_correction_guarded_dispatch_documentation_review_followup_v1/capture_order_clarification.json')
assert {name: module.binding(REPO / name) for name in follow['checked_document_bindings']} == follow['checked_document_bindings']
compact = {**final, 'schema_version': 1,
           'dated_progress': module.load(DOCS / 'dated_checkpoint_after_integration.stdout.log'),
           'independent_doc_polish_findings_resolved_and_capture_order_clarification_retained': True,
           'new_archives': {name: {k: v for k, v in item.items() if k != 'members'} for name, item in archives.items()}}
target = REPO / 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-v3-documentation-checks.json'
module.write_new(target, compact)
module.write_new(HERE / 'document_archive_members.json', archives)
print(json.dumps({'document_check_archive_members': archives['actual_document_checks']['regular_members'],
                  'compact_record': str(target), 'all_current_documents_unchanged': True}, sort_keys=True))
