"""Clarify current validation and freeze-builder wording in three guides."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).absolute().parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')


def bind(path):
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


edits = {
    'coordination/HANDOFF.md': [
        ('`~/bayes-cox-runs/ravi-main-integration-20260929`. macOS offloaded the original',
         '`~/bayes-cox-runs/ravi-main-integration-20260929`. Current engineering validation\npassed 1,040 tests and 293 subtests with zero skips at 15:34:34 UTC on\n29 September. All 752 captured implementation files were unchanged;\nrepository-wide Ruff passed. The actual scientific reviews, numerical freeze\nand corrected fits remain pending. Details are in the guarded-dispatch\nintegration-v3 record below.\n\nmacOS offloaded the original'),
        ('Fresh production-worktree Git checks return', 'Recorded production-worktree Git checks returned'),
    ],
    'docs/catalytic_correction_execution.md': [
        ('checks; all old scientific pins and predicates remain unchanged. Its full locked suite passed 1,040 tests and 293 subtests with zero skips',
         'checks; all old scientific pins and predicates remain unchanged. Its full\nlocked suite passed 1,040 tests and 293 subtests with zero skips'),
    ],
    'docs/ravi_handoff.md': [
        ('The current implementation includes the reviewed freeze, selective-fitting,',
         'The current implementation includes the reviewed freeze builder, selective-fitting,'),
    ],
}
before = {name: bind(REPO / name) for name in edits}
for name, replacements in edits.items():
    path = REPO / name
    text = path.read_text()
    with (HERE / (name.replace('/', '__') + '.before_polish.md')).open('xb') as stream:
        stream.write(path.read_bytes())
    for old, new in replacements:
        assert text.count(old) == 1
        text = text.replace(old, new, 1)
    path.write_text(text)
record = {'status': 'three_guide_clarifications_applied',
          'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'before': before, 'after': {name: bind(REPO / name) for name in edits},
          'only_document_wording_changed': True,
          'actual_numerical_freeze_still_pending': True}
with (HERE / 'document_polish.json').open('x') as stream:
    json.dump(record, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(record, sort_keys=True))
