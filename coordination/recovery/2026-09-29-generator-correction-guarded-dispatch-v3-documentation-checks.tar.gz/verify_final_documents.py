"""Verify current guide links, tested source bytes and retained whitespace scope."""
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).absolute().parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
VALIDATION = HERE.parent / 'correction_guarded_dispatch_integration_validation_v3'
FILES = ('coordination/HANDOFF.md', 'coordination/TODO.md', 'coordination/JOURNAL.md', 'docs/ravi_handoff.md', 'docs/code_guide.md', 'docs/catalytic_correction_execution.md')


def bind(path):
    assert path.is_file() and not any(p.is_symlink() for p in (path, *path.parents))
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


tested = json.loads((VALIDATION / 'make_test.tested_source_after.json').read_text())
assert len(tested) == 752 and {key: bind(REPO / key) for key in tested} == tested
schema = json.loads((HERE / 'final_document_schemas.invocation.json').read_text())
assert type(schema['exit_code']) is int and schema['exit_code'] == 0 and schema['tested_source_before_equals_after']
unfiltered = json.loads((HERE / 'unfiltered_historical_whitespace.invocation.json').read_text())
filtered = json.loads((HERE / 'filtered_historical_whitespace.invocation.json').read_text())
assert type(unfiltered['exit_code']) is int and unfiltered['exit_code'] == 2
assert type(filtered['exit_code']) is int and filtered['exit_code'] == 0
exception = 'scripts/catalytic_correction/guarded_dispatch/preserved_v2/unit_attempt1.stderr.log'
assert bind(REPO / exception) == bind(HERE.parent / 'generator_correction_guarded_dispatch_v2/unit_attempt1.stderr.log')
lines = (HERE / 'unfiltered_historical_whitespace.stdout.log').read_text().splitlines()
assert lines == [exception + ':32: trailing whitespace.', '+test_legitimate_original_success_and_negative_reuse_kept (test_guarded_dispatch_regressions.GuardV2Regressions.test_legitimate_original_success_and_negative_reuse_kept) ... ']
assert filtered['argv'][-1] == ':(exclude)' + exception
marker = '## What is on GitHub'
ravi = (REPO / 'docs/ravi_handoff.md').read_text()
previous = (HERE / 'documents_before/docs/ravi_handoff.md').read_text()
assert ravi.split(marker, 1)[1] == previous.split(marker, 1)[1]
links = []
for name in FILES:
    text = (REPO / name).read_text()
    # Audit new/updated local guide links without interpreting historical URLs.
    if name == 'docs/ravi_handoff.md':
        text = text.split(marker, 1)[0]
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', text):
        if target.startswith(('https://', 'http://', 'mailto:', '#')):
            continue
        path = (REPO / name).parent / target.split('#', 1)[0]
        assert path.exists(), (name, target)
        links.append({'document': name, 'target': target})
    assert 'v3 correction is being prepared' not in text and 'V3 guard is awaiting repository installation' not in text
for label, arguments in (
    ('unstaged_whitespace', ['git', 'diff', '--check']),
    ('current_diff', ['git', 'diff', '--', *FILES]),
):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (HERE / (label + '.stdout.log')).open('xb') as out, (HERE / (label + '.stderr.log')).open('xb') as err:
        child = subprocess.run(arguments, cwd=REPO, stdout=out, stderr=err, check=False)
    record = {'argv': arguments, 'cwd': str(REPO), 'started_at_utc': started,
              'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual_exit_code': child.returncode,
              'stdout': bind(HERE / (label + '.stdout.log')), 'stderr': bind(HERE / (label + '.stderr.log'))}
    with (HERE / (label + '.invocation.json')).open('x') as stream:
        json.dump(record, stream, sort_keys=True, indent=2)
        stream.write('\n')
    assert type(child.returncode) is int and child.returncode == 0
value = {'status': 'six_current_guides_verified_before_publication',
         'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'current_documents': {name: bind(REPO / name) for name in FILES},
         'current752_implementation_files_equal_successful1040_test_capture': True,
         'Ravi_baseline_body_unchanged': True, 'checked_local_links': links,
         'actual_final_schema_exit_code': schema['exit_code'],
         'only_exact_old_failed_log_whitespace_exception': exception,
         'old_failed_log_byte_binding': bind(REPO / exception),
         'scientific_completion_or_release_certified': False}
with (HERE / 'final_documents_verified.json').open('x') as stream:
    json.dump(value, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps({key: item for key, item in value.items() if key not in ('current_documents', 'checked_local_links')}, sort_keys=True))
print('Verified local guide links:', len(links))
