#!/usr/bin/env python3
"""Summarize completed, strictly verified programme evidence without fitting.

Exit 2 means required completion records do not yet exist. Exit 1 means a
validation failed. No empirical summary is emitted in either case.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
DEFAULT_CODE = Path("/Users/macuser/bayes-cox-runs/refactored-programme-20260927")
DEFAULT_PROGRAMME = Path("/Users/macuser/bayes-cox-runs/continuation-20260927")
SEALED_COMMIT = "11f86ced8735b32767debb58f3cbbefbb5a7b8e6"


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise TypeError(f"expected JSON mapping: {path}")
    return value


def load_driver(project: Path):
    path = project / "scripts/complete_results_programme.py"
    spec = importlib.util.spec_from_file_location("summary_programme_driver", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load pinned verifier: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def counts(cells: list[dict[str, Any]]) -> dict[str, Any]:
    groups: dict[tuple[str, str], Counter] = defaultdict(Counter)
    for cell in cells:
        groups[(cell["dataset"], cell["model_key"])][cell["status"]] += 1
    return {
        "stored_cells": len(cells),
        "status_counts": dict(
            sorted(Counter(cell["status"] for cell in cells).items())
        ),
        "by_cohort_model_prior": [
            {
                "dataset": dataset,
                "model_key": model,
                "prior": model.removeprefix("bayesian_")
                if model.startswith("bayesian_")
                else None,
                "stored_cells": sum(status.values()),
                "status_counts": dict(sorted(status.items())),
            }
            for (dataset, model), status in sorted(groups.items())
        ],
    }


def effect_summary(effect: dict[str, Any] | None, estimate_key: str) -> dict[str, Any]:
    if effect is None:
        return {"available": False, "confidence_interval_direction": "unavailable"}
    lower, upper = effect["confidence_lower"], effect["confidence_upper"]
    if lower > upper:
        raise ValueError("stored confidence interval has reversed endpoints")
    return {
        "available": True,
        "estimate": effect[estimate_key],
        "estimate_key": estimate_key,
        "confidence_lower": lower,
        "confidence_upper": upper,
        "confidence_level": effect["confidence_level"],
        "confidence_interval_direction": (
            "below_zero"
            if upper < 0
            else "above_zero"
            if lower > 0
            else "includes_zero"
        ),
        "raw_p_value": effect.get("p_value"),
        "p_value_recorded": "p_value" in effect,
    }


def primary_rows(inference: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            **{key: row[key] for key in ("dataset", "model_a", "model_b")},
            "direction": row.get("contrast_direction", "model_a minus model_b"),
            "paired_folds": row["n_paired_folds"],
            "expected_paired_folds": row["expected_paired_folds"],
            "status": row.get("status", "complete"),
            "ibs_effect": effect_summary(row.get("ibs"), "mean_difference"),
            "holm_adjusted_p": row.get("holm_adjusted_p"),
            "holm_adjustment_recorded": "holm_adjusted_p" in row,
        }
        for row in inference["primary"]
    ]


def robustness_rows(
    robustness: dict[str, Any], models: tuple[str, ...], design_folds: tuple[int, ...]
):
    planned: dict[tuple[str, str, str, str], set[tuple[int, int]]] = defaultdict(set)
    accepted: dict[tuple[str, str, str, str], set[tuple[int, int]]] = defaultdict(set)
    for cell in robustness["cells"]:
        for analysis in cell["condition"]["analyses"]:
            component = analysis["component"]
            if component in {"design", "feature"} and cell["fold"] not in design_folds:
                continue
            key = (cell["dataset"], component, analysis["condition"], cell["model_key"])
            fold = (cell["repeat"], cell["fold"])
            planned[key].add(fold)
            if cell["status"] == "complete":
                accepted[key].add(fold)
    inference = robustness["paired_ibs_inference"]
    observed = {}
    for row in inference["contrasts"]:
        key = tuple(
            row[field]
            for field in ("dataset", "component", "condition", "model_a", "model_b")
        )
        if key in observed:
            raise ValueError("duplicate robustness aggregate contrast")
        observed[key] = row
    result = []
    for dataset, component, condition in sorted({key[:3] for key in planned}):
        for model_a, model_b in combinations(models, 2):
            key = (dataset, component, condition, model_a, model_b)
            left, right = (*key[:3], model_a), (*key[:3], model_b)
            expected = planned[left] & planned[right]
            paired = accepted[left] & accepted[right]
            row = observed.pop(key, None)
            result.append(contrast_row(key, expected, paired, row))
    if observed:
        raise ValueError(
            "robustness aggregate contains a contrast outside its planned grid"
        )
    observed_did = {}
    for row in inference["difference_in_differences"]:
        key = tuple(
            row[field] for field in ("dataset", "condition", "model_a", "model_b")
        )
        if key in observed_did:
            raise ValueError("duplicate RQ2 difference-in-differences")
        observed_did[key] = row
    did = []
    reference = "fraction_100_observed"
    for dataset, component, condition in sorted({key[:3] for key in planned}):
        if component != "rq2" or condition == reference:
            continue
        for model_a, model_b in combinations(models, 2):
            keys = [
                (dataset, "rq2", name, model)
                for name in (condition, reference)
                for model in (model_a, model_b)
            ]
            expected = set.intersection(*(planned[key] for key in keys))
            paired = set.intersection(*(accepted[key] for key in keys))
            row = observed_did.pop((dataset, condition, model_a, model_b), None)
            key = (
                dataset,
                "rq2_difference_in_differences",
                condition,
                model_a,
                model_b,
            )
            summary = contrast_row(key, expected, paired, row)
            summary["reference_condition"] = reference
            if row is not None and row["reference_condition"] != reference:
                raise ValueError("RQ2 difference-in-differences reference differs")
            did.append(summary)
    if observed_did:
        raise ValueError("RQ2 aggregate contains a contrast outside its planned grid")
    return result, did


def contrast_row(key, expected, paired, row) -> dict[str, Any]:
    if row is None:
        if paired:
            raise ValueError(f"aggregate omits an available robustness contrast: {key}")
        status = "not_emitted_no_accepted_condition"
        effect = None
        direction = "not recorded: no available contrast"
    else:
        registered = [(entry["repeat"], entry["fold"]) for entry in row["paired_folds"]]
        if len(registered) != len(set(registered)) or set(registered) != paired:
            raise ValueError(
                f"robustness paired-fold inventory differs from accepted cells: {key}"
            )
        effect = row.get("effect")
        if isinstance(effect, dict) != bool(paired):
            raise ValueError(
                f"robustness effect availability differs from accepted cells: {key}"
            )
        status, direction = row["status"], row["direction"]
    return {
        **dict(
            zip(
                ("dataset", "component", "condition", "model_a", "model_b"),
                key,
                strict=True,
            )
        ),
        "status": status,
        "direction": direction,
        "paired_folds": len(paired),
        "expected_paired_folds": len(expected),
        "all_planned_pairs_available": paired == expected,
        "ibs_effect": effect_summary(effect, "observed"),
    }


def summarize(project: Path, programme: Path, explanation_path: Path) -> dict[str, Any]:
    identity_path = programme / "programme_manifest.json"
    identity = load(identity_path)
    source_dir = Path(identity["source_dir"])
    robustness_dir = Path(identity["robustness_dir"])
    reproduction = programme / "reproduction/verification.json"
    samplers = sorted((programme / "posthoc_sampler").glob("*/manifest.json"))
    required = [
        source_dir / "completion.json",
        robustness_dir / "completion.json",
        reproduction,
    ]
    if len(samplers) != 1:
        raise FileNotFoundError(
            "requires exactly one posthoc sampler manifest and its completion"
        )
    sampler_dir = samplers[0].parent
    required.append(sampler_dir / "completion.json")
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            "completion records are not ready: " + ", ".join(missing)
        )
    sys.path.insert(0, str(project))
    from src.pipelines.robustness import verify_completed_robustness_run
    from src.pipelines.robustness.protocol import (
        BAYESIAN_MODEL_KEYS,
        DESIGN_FEATURE_FOLD_NUMBERS_PER_REPEAT,
    )
    from src.rendering.verification import (
        verify_explainability_artifact,
        verify_frozen_run,
        verify_robustness_run,
    )
    from src.utils.frozen_evidence import verify_frozen_evidence
    from src.utils.posthoc_evidence import verify_posthoc_run
    from src.utils.reproducibility import canonical_json_hash, sha256_file

    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=project,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    if identity["code_commit"] != SEALED_COMMIT or commit != SEALED_COMMIT:
        raise RuntimeError(
            "summarizer requires the original sealed programme code revision"
        )
    code = {
        str(path.relative_to(project)): sha256_file(path)
        for folder in ("src", "scripts")
        for path in sorted((project / folder).rglob("*.py"))
    }
    if code != identity["code_sha256"]:
        raise RuntimeError("sealed programme source inventory or bytes changed")
    if sha256_file(explanation_path) != identity["explanation_sha256"]:
        raise RuntimeError("explanation differs from the pinned programme input")
    driver = load_driver(project)
    source = verify_frozen_run(source_dir)
    verify_frozen_evidence(project, source.manifest["input_sha256"])
    if source.mode != "confirmatory" or len(source.cells) != 450:
        raise RuntimeError(
            "requires the original complete 450-cell confirmatory source"
        )
    verify_completed_robustness_run(
        robustness_dir, project, confirmatory_run_dir=source_dir
    )
    robust, _ = verify_robustness_run(robustness_dir, source)
    if len(robust["cells"]) != 825:
        raise RuntimeError("requires the entire frozen 825-cell robustness grid")
    posthoc = verify_posthoc_run(sampler_dir, source_dir)
    refits = driver.verify_reproduction(
        source_dir, programme / "reproduction/cells", reproduction
    )
    explanation, _ = verify_explainability_artifact(explanation_path, source)
    original_rows = primary_rows(source.inference)
    posthoc_rows = primary_rows(posthoc["inference"])
    original_available = {
        (row["dataset"], row["model_a"], row["model_b"]): row["ibs_effect"]["available"]
        for row in original_rows
    }
    for row in posthoc_rows:
        key = (row["dataset"], row["model_a"], row["model_b"])
        row["original_confirmatory_comparison_available"] = original_available[key]
        row["became_available_in_posthoc"] = (
            row["ibs_effect"]["available"] and not original_available[key]
        )
    contrasts, did = robustness_rows(
        robust, BAYESIAN_MODEL_KEYS, DESIGN_FEATURE_FOLD_NUMBERS_PER_REPEAT
    )
    result = {
        "status": "completed_numerical_evidence_verified_descriptive_summary",
        "code_commit": commit,
        "summarizer_sha256": sha256_file(Path(__file__)),
        "interpretation": "Descriptive evidence only; no superiority or equivalence claim.",
        "original_confirmatory": {
            **counts([cell for _, cell in source.cells]),
            "holm_family_complete": source.inference["holm_family_complete"],
            "primary_contrasts": original_rows,
            "unchanged_evidence": True,
        },
        "explainability": {
            "convergence_summary": explanation["convergence"]["summary"],
            "interpretation_limits": explanation.get("interpretation_limits"),
            "source_unchanged": True,
        },
        "robustness": {
            **counts(robust["cells"]),
            "prespecified_fit_plan": robust["feasibility_plan"]["fit_plan"],
            "contrasts": contrasts,
            "difference_in_differences": did,
            "contrasts_with_estimates": sum(
                row["ibs_effect"]["available"] for row in contrasts
            ),
            "contrasts_with_all_planned_pairs": sum(
                row["all_planned_pairs_available"] for row in contrasts
            ),
            "analysis_availability": robust["analysis_availability"],
            "ph_covariate_stability_summary": (robust.get("ph_assessment") or {}).get(
                "covariate_stability_summary"
            ),
            "p_value_note": "Robustness bootstrap IBS effects store intervals, not p-values; none are inferred.",
        },
        "posthoc_sampler_sensitivity": {
            **counts(posthoc["cells"]),
            "evidence_status": "posthoc_sampler_sensitivity",
            "holm_family_complete": posthoc["inference"]["holm_family_complete"],
            "primary_contrasts": posthoc_rows,
            "original_confirmatory_outcome_replaced": False,
        },
        "reproduction": {
            "cells_checked": refits["cells_checked"],
            "cells_identical": refits["cells_identical"],
            "all_450_equal": refits["cells_checked"]
            == refits["cells_identical"]
            == 450,
            "ignored_fields": refits["ignored_fields"],
            "evidence_status": "verification_only",
        },
        "source_file_sha256": {
            str(path): sha256_file(path)
            for path in (
                identity_path,
                source_dir / "manifest.json",
                source_dir / "completion.json",
                robustness_dir / "manifest.json",
                robustness_dir / "completion.json",
                sampler_dir / "manifest.json",
                sampler_dir / "completion.json",
                reproduction,
                explanation_path,
            )
        },
        "scope": "Numerical evidence summary; final rendered-artifact visual QA is a separate release requirement.",
    }
    result["summary_content_sha256"] = canonical_json_hash(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=DEFAULT_CODE)
    parser.add_argument("--programme-dir", type=Path, default=DEFAULT_PROGRAMME)
    parser.add_argument("--explanation", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = summarize(
            args.project_root.resolve(),
            args.programme_dir.resolve(),
            args.explanation.resolve(),
        )
    except FileNotFoundError as error:
        print(
            json.dumps({"status": "incomplete_no_summary", "reason": str(error)}),
            file=sys.stderr,
        )
        return 2
    except (
        ImportError,
        KeyError,
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
        subprocess.SubprocessError,
    ) as error:
        print(
            json.dumps(
                {"status": "validation_failed_no_summary", "reason": str(error)}
            ),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
