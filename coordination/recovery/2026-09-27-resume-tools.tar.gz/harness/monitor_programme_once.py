"""Read-only progress snapshot for the running sealed programme."""
import datetime
import json
import os
from pathlib import Path

root = Path('/Users/macuser/bayes-cox-runs/continuation-20260927')
rob = Path('/Users/macuser/bayes-cox-runs/frozen/reports/robustness/confirmatory_v1_robustness_robustness_702d93af33bf')

def alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False

log = root / 'logs/full_reproduction.log'
report = root / 'reproduction/verification.json'
record = json.loads(report.read_text()) if report.is_file() else {}
print(json.dumps({
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'robustness': sum(1 for _ in (rob / 'cells').rglob('*.json')),
    'robustness_complete': (rob / 'completion.json').is_file(),
    'reproduction': sum(1 for _ in (root / 'reproduction/cells').glob('*/*/*.json')),
    'reproduction_complete': record.get('cells_checked') == 450 and record.get('cells_identical') == 450,
    'sampler': sum(1 for _ in (root / 'posthoc_sampler').glob('*/cells/*/*/*.json')),
    'mismatches': log.read_text(errors='replace').count('identical=False') if log.is_file() else 0,
    'failure': (root / 'programme_failure.json').is_file(),
    'analysis_verified': (root / 'programme_analysis_verified.json').is_file(),
    'coordinator_alive': alive(57940),
    'reproduction_parent_alive': alive(58114),
}))
