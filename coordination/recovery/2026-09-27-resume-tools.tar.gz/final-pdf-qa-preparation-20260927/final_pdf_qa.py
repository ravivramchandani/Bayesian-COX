"""External, serial PDF preflight. Visual review is never inferred from a render."""

import argparse
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

REFERENCE = Path('/Users/macuser/bayes-cox-runs/pdf-qa-v3-20260927/pdf_qa_inventory.json')
REFERENCE_SHA = 'be3e1c265a4ebeefb35fca39f3a7781900666d03afc40c50391ca0308e10af6e'
BOX_NAMES = ('MediaBox', 'CropBox', 'BleedBox', 'TrimBox', 'ArtBox')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def command(args):
    result = subprocess.run(args, capture_output=True, text=True, check=True)
    return result.stdout, result.stderr


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def registered_pdfs(root):
    if not root.is_dir() or not (root / 'lineage.json').is_file():
        raise ValueError(f'Final rendered bundle is absent or unfinished: {root}')
    lineage = json.loads((root / 'lineage.json').read_text())
    content = dict(lineage)
    digest = content.pop('lineage_content_sha256', None)
    if canonical(content) != digest:
        raise ValueError(f'Lineage content hash differs: {root}')
    outputs = lineage['outputs']
    if isinstance(outputs, list):
        rows = {x['path']: x['sha256'] for x in outputs}
        if len(rows) != len(outputs):
            raise ValueError(f'Duplicate lineage output registration: {root}')
    elif isinstance(outputs, dict):
        rows = outputs
    else:
        raise ValueError(f'Invalid lineage outputs: {root}')
    registered = {name: digest for name, digest in rows.items() if name.lower().endswith('.pdf')}
    actual = {str(p.relative_to(root)) for p in root.rglob('*')
              if p.is_file() and p.suffix.lower() == '.pdf'}
    if not registered or actual != set(registered):
        raise ValueError(f'Actual PDF set differs from complete lineage: {root}')
    for name, digest in registered.items():
        path = root / name
        if Path(name).is_absolute() or '..' in Path(name).parts or path.is_symlink():
            raise ValueError(f'Unsafe PDF path: {name}')
        if not path.resolve().is_relative_to(root.resolve()) or sha(path) != digest:
            raise ValueError(f'Registered PDF hash/path differs: {name}')
    return registered, sha(root / 'lineage.json')


def structure(path):
    info, error = command(['pdfinfo', '-box', str(path)])
    match = re.search(r'^Pages:\s+(\d+)', info, re.M)
    if not match:
        raise ValueError(f'No PDF page count: {path}')
    count = int(match.group(1))
    info, box_error = command(['pdfinfo', '-f', '1', '-l', str(count), '-box', str(path)])
    font_text, font_error = command(['pdffonts', str(path)])
    fonts = []
    for line in font_text.splitlines()[2:]:
        fields = line.split()
        if len(fields) < 8:
            raise ValueError(f'Unparseable pdffonts row: {line}')
        fonts.append({'name': fields[0], 'type': ' '.join(fields[1:-6]),
                      'embedded': fields[-5] == 'yes', 'unicode_mapping': fields[-3] == 'yes'})
    failures = []
    if any(not f['embedded'] or not f['unicode_mapping'] for f in fonts):
        failures.append('font_not_embedded_or_without_unicode_map')
    pages = []
    for number in range(1, count + 1):
        boxes = {}
        for name in BOX_NAMES:
            pattern = rf'^Page\s+{number}\s+{name}:\s+([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)'
            m = re.search(pattern, info, re.M)
            if not m:
                raise ValueError(f'Missing page {number} {name}: {path}')
            boxes[name] = list(map(float, m.groups()))
            x0, y0, x1, y1 = boxes[name]
            if x1 <= x0 or y1 <= y0:
                failures.append(f'page_{number}_{name}_not_positive')
        if boxes['CropBox'] != boxes['MediaBox']:
            failures.append(f'page_{number}_crop_box_differs_from_media_box')
        pages.append({'page_number': number, 'page_boxes_points': boxes})
    return {'status': 'failed' if failures else 'passed', 'findings': failures,
            'fonts': fonts, 'tool_stderr': [e for e in (error, box_error, font_error) if e]}, pages


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--confirmatory', type=Path, required=True)
    parser.add_argument('--posthoc', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--render-new', action='store_true', help='Render new/changed pages at 150 dpi, one serial worker.')
    parser.add_argument('--reviews', type=Path, help='Completed manual review template; requires --render-new.')
    args = parser.parse_args()
    if args.reviews and not args.render_new:
        parser.error('--reviews requires --render-new')
    if sha(REFERENCE) != REFERENCE_SHA:
        raise ValueError('Passed V3 reference inventory changed')
    reference = json.loads(REFERENCE.read_text())
    if reference['status'] != 'passed' or not reference['all_pages_actually_visually_reviewed']:
        raise ValueError('V3 reference did not pass exhaustive review')
    passed = {}
    for row in reference['pdfs']:
        if row['visual_review_status'] == 'passed' and all(
                p['visual_review_status'] == 'passed' and p['actually_viewed_evidence'] for p in row['pages']):
            passed.setdefault(row['sha256'], row)
    # Both final lineages and complete PDF sets must exist before any QA output or count.
    bundles = [('confirmatory', args.confirmatory.resolve()), ('posthoc', args.posthoc.resolve())]
    inventories = [(label, root, *registered_pdfs(root)) for label, root in bundles]
    output = args.output.resolve()
    if any(output.is_relative_to(root) for _, root in bundles):
        raise ValueError('QA output must be external to rendered bundles')
    output.mkdir(parents=True, exist_ok=True)
    records, review_template, references = [], [], {}
    for label, root, inventory, lineage_sha in inventories:
        references[label] = {'root': str(root), 'lineage_sha256': lineage_sha}
        for name, digest in sorted(inventory.items()):
            path = root / name
            structural, pages = structure(path)
            baseline = passed.get(digest)
            if baseline and len(pages) != baseline['page_count']:
                raise ValueError('Identical PDF hash has a different recorded page count')
            row = {'bundle': label, 'relative_path': name, 'pdf_path': str(path), 'sha256': digest,
                   'page_count': len(pages), 'structural': structural, 'pages': pages}
            if baseline:
                row['visual_review_status'] = 'passed_exact_hash_reuse'
                row['reused_passed_review'] = {'inventory_path': str(REFERENCE), 'inventory_sha256': REFERENCE_SHA,
                                             'reference_index': baseline['index'], 'pdf_sha256': digest}
                for page, previous in zip(pages, baseline['pages']):
                    page.update({'visual_review_status': 'passed_exact_hash_reuse',
                                 'actually_viewed_evidence': previous['actually_viewed_evidence']})
            else:
                row['visual_review_status'] = 'pending_actual_visual_review'
                for page in pages:
                    page['visual_review_status'] = 'pending_actual_visual_review'
                    entry = {'bundle': label, 'relative_path': name, 'pdf_sha256': digest,
                             'page_number': page['page_number'], 'status': 'pending',
                             'actual_visual_review': False, 'reviewer': None, 'reviewed_at_utc': None,
                             'findings': [], 'actually_viewed_evidence': []}
                    if args.render_new:
                        prefix = output / 'pages' / label / Path(name).with_suffix('') / f'page_{page["page_number"]:03d}'
                        prefix.parent.mkdir(parents=True, exist_ok=True)
                        _, render_error = command(['pdftoppm', '-f', str(page['page_number']), '-l', str(page['page_number']),
                                                   '-singlefile', '-r', '150', '-png', str(path), str(prefix)])
                        png = prefix.with_suffix('.png')
                        page['native_png'] = {'path': str(png), 'sha256': sha(png), 'dpi': 150}
                        page['render_stderr'] = render_error
                        entry['native_png'] = page['native_png']
                    review_template.append(entry)
            if sha(path) != digest:
                raise ValueError(f'PDF changed during QA: {path}')
            records.append(row)
    if args.reviews:
        reviews = json.loads(args.reviews.read_text())['pages']
        key = lambda p: (p['bundle'], p['relative_path'], p['pdf_sha256'], p['page_number'])
        supplied = {key(p): p for p in reviews}
        if len(supplied) != len(reviews) or set(supplied) != {key(p) for p in review_template}:
            raise ValueError('Manual review keys do not exactly match all new/changed pages')
        for row in records:
            if row['visual_review_status'] != 'pending_actual_visual_review':
                continue
            for page in row['pages']:
                review = supplied[(row['bundle'], row['relative_path'], row['sha256'], page['page_number'])]
                png = page['native_png']
                if review['native_png'] != png or not review['actual_visual_review'] or not review['reviewer'] or not review['reviewed_at_utc']:
                    raise ValueError('Manual review is missing actual visual review or exact raster identity')
                if review['status'] not in ('passed', 'failed_layout') or not review['actually_viewed_evidence']:
                    raise ValueError('Manual review is incomplete')
                if review['status'] == 'passed' and review['findings']:
                    raise ValueError('A page with layout findings cannot pass')
                for evidence in review['actually_viewed_evidence']:
                    if sha(evidence['path']) != evidence['sha256']:
                        raise ValueError('Actually viewed evidence changed')
                page.update({'visual_review_status': review['status'], 'manual_visual_review': review})
            row['visual_review_status'] = ('passed_actual_visual_review' if all(p['visual_review_status'] == 'passed' for p in row['pages'])
                                           else 'failed_layout')
    for label, root, inventory, lineage_sha in inventories:
        current, current_lineage_sha = registered_pdfs(root)
        if current != inventory or current_lineage_sha != lineage_sha:
            raise ValueError(f'Final bundle changed during QA: {label}')
    pending = sum(r['visual_review_status'] == 'pending_actual_visual_review' for r in records)
    failures = sum(r['structural']['status'] != 'passed' or r['visual_review_status'] == 'failed_layout' for r in records)
    result = {'schema_version': 1, 'status': ('failed' if failures else 'pending_actual_visual_review' if pending else 'passed'),
              'generated_at_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'PDF structure and actual visual layout only; no empirical claim validation.',
              'reference_inventory': {'path': str(REFERENCE), 'sha256': REFERENCE_SHA}, 'bundles': references,
              'pdf_count': len(records), 'page_count': sum(r['page_count'] for r in records),
              'exact_hash_reused_pdf_count': sum(r['visual_review_status'] == 'passed_exact_hash_reuse' for r in records),
              'new_or_changed_pdf_count': len({(p['bundle'], p['relative_path']) for p in review_template}),
              'pending_actual_visual_review_pdf_count': pending, 'failed_pdf_count': failures,
              'all_pages_actually_reviewed_or_exact_hash_reused': pending == 0,
              'actual_new_page_review_count': sum(p['visual_review_status'] in ('passed', 'failed_layout')
                                                for r in records for p in r['pages']),
              'manual_review_file': {'path': str(args.reviews.resolve()), 'sha256': sha(args.reviews)} if args.reviews else None,
              'pdfs': records}
    write(output / 'programme_visual_qa.json', result)
    if not args.reviews:
        write(output / 'reviews.template.json', {'instructions': 'Inspect every listed actual PNG page, full layout and native title/label regions. Fill reviewer/date, exact viewed evidence hashes, findings and actual_visual_review only after inspection. Rendering alone is not review.',
                                                'pages': review_template})
    print(json.dumps({k: result[k] for k in ('status', 'pdf_count', 'page_count', 'exact_hash_reused_pdf_count',
                                           'new_or_changed_pdf_count', 'pending_actual_visual_review_pdf_count', 'failed_pdf_count')}, indent=2))


if __name__ == '__main__':
    main()
