Final PDF QA preparation
========================

This external utility reads final rendered bundles and the fixed passed V3 inventory. It does not import or modify the sealed project, run fitting, change Git, or create a release seal. No final bundle counts have been recorded yet.

Run only after both eventual rendered bundles contain their completed `lineage.json`. The actual PDF set and every PDF hash must match those lineages. The script accepts both confirmatory list outputs and post-hoc dictionary outputs and verifies their canonical lineage hashes. It stops before writing any QA output or counts if either bundle is absent or unfinished.

Use the existing locked Python environment. Poppler `pdfinfo`, `pdffonts`, and `pdftoppm` must be on PATH. Rendering uses one serial process at 150 dpi.

Exact eventual command:

```bash
/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python \
  /Users/macuser/bayes-cox-runs/final-pdf-qa-preparation-20260927/final_pdf_qa.py \
  --confirmatory /Users/macuser/bayes-cox-runs/continuation-20260927/rendered_confirmatory \
  --posthoc /Users/macuser/bayes-cox-runs/continuation-20260927/rendered_posthoc_sampler \
  --output /Users/macuser/bayes-cox-runs/final-pdf-qa-20260927 \
  --render-new
```

The script verifies positive MediaBox, CropBox, BleedBox, TrimBox, and ArtBox dimensions on every actual page, requires CropBox == MediaBox, and checks that every recorded font is embedded and has a Unicode map. It preserves Poppler stderr for inspection. Text/font bounding-box heuristics are not treated as actual visual clipping; the actual page images establish layout.

Reuse is allowed only when the actual current PDF SHA-256 matches a passed record from this fixed exhaustive reference:

`/Users/macuser/bayes-cox-runs/pdf-qa-v3-20260927/pdf_qa_inventory.json`

Reference SHA-256: `be3e1c265a4ebeefb35fca39f3a7781900666d03afc40c50391ca0308e10af6e`.

The resulting `programme_visual_qa.json` contains actual final source roots, lineage byte hashes, every PDF byte hash, page counts/boxes/fonts, exact-hash reuse pointers or pending page records, and current observed totals. Its status remains `pending_actual_visual_review` while any new/changed PDF lacks review. Structural failures yield `failed`.

Every new/changed page is rasterized under external `pages/<bundle>/<PDF relative stem>/page_NNN.png`, with its exact PNG hash recorded. `reviews.template.json` lists precisely those pages; rendering never creates a visual pass. Copy this template to `reviews.completed.json` and inspect every actual full page and the native title/label regions before filling it. Add contact sheets or crops to evidence when useful; retain the native full-page PNG unchanged. No page may be marked passed from filenames, counts, extraction, or structure alone.

Expected completed manual page record (placeholder values must be replaced after actual inspection):

```json
{
  "bundle": "posthoc",
  "relative_path": "<actual registered PDF path>",
  "pdf_sha256": "<actual current PDF SHA-256>",
  "page_number": 1,
  "native_png": {"path": "/absolute/native/page.png", "sha256": "<actual PNG SHA-256>", "dpi": 150},
  "status": "passed",
  "actual_visual_review": true,
  "reviewer": "<actual reviewer>",
  "reviewed_at_utc": "<actual ISO UTC review time>",
  "findings": [],
  "actually_viewed_evidence": [
    {"type": "native_png", "path": "/absolute/native/page.png", "sha256": "<actual viewed image SHA-256>", "view_image_detail": "original"}
  ]
}
```

A confirmed defect uses `status: failed_layout` and describes it in `findings`; it cannot pass. The review file is an object with a `pages` list and must contain each pending current PDF/page key exactly once, with no missing/extra/duplicate entries. Native raster identity and all evidence image hashes are rechecked.

After actual review, rerun the same command with:

```bash
  --reviews /Users/macuser/bayes-cox-runs/final-pdf-qa-20260927/reviews.completed.json
```

Keep `--render-new`; current native PNG hashes must still match the reviewed record. The script checks both final lineages/PDF inventories again before writing the QA result. It produces `status: passed` only when every page has passed exact-hash reuse or completed actual visual review, and structure passed. It records the review file byte hash. Root must still independently verify programme numerical evidence and bind the final QA JSON's exact byte hash into the release-ready seal.

Sealed package descriptor shape:

```json
"visual_qa": {
  "status": "passed",
  "path": "/Users/macuser/bayes-cox-runs/final-pdf-qa-20260927/programme_visual_qa.json",
  "sha256": "<actual final QA JSON byte hash>"
}
```

Validation used external two-PDF fixtures only: one exact V3 reuse; one changed baseline PDF stayed pending with its raster; a false rehashed PDF registration was rejected; a missing bundle was rejected before output/counts. These fixture results are not final programme QA and are kept only in `validation_fixtures/`.
