The published guides retain the scientific rules and pending-completion boundaries. No changed method or actual-completion contradiction was found. The recovered execution guide contains several useful details worth merging back into the current prose.

The actual filename is docs/catalytic_correction_execution.md, confirmed by published HANDOFF line56; code_guide.md is named at line925. The f9f3d02 publication label was supplied by root. This comparison checked exact current file bytes, not Git metadata or a live branch/ref.

Useful omitted details:

- Recovered execution lines326–331 specify1625 ratio rows,123 descriptive comparisons,27 existing formal links, observed means for partial pairs and confidence intervals only with all25 paired folds. Published lines322–330 shorten this to generic complete-pair wording. Restore the exact planned roster and25-pair rule; reporting/interface_contract.json lines118–125 agrees. These are contract counts, not claims that outputs have already been produced.
- Recovered lines332–334 identify corrected_pdf_qa.py prepare, the blank review,32 page renders/four indexed contacts and six bound table inventories. Published lines322–330 retain counts/actual attestation but lose the prepare→actual review→receipt sequence. Restore that sequence. Actual source prepare lines178–215 produces blank pending review evidence; issue_receipt starts at218. No table-verdict or stronger attestation gate should be added.
- Recovered lines335–337 explain source and receiving replay of the four deterministic report artifacts, preservation of the actual review and a separate genuine exit capture for each process. Published release lines332–338 only require general reporting/review/replay proof. Restore the explicit replay and exit distinction; reporting.py lines106–124 confirms the four-artifact comparison. A self-written receipt is not an actual rc0 capture.
- Recovered lines266–274 require the prospective per-entry location plan to bind roots before execution, common declared historical roots across capture/controller/receiving, preserved sealed predecessors and distinct wrapper pins. Published lines266–272 retain eligibility and fresh roots but omit those operational details. Merge them into the newer paragraph while preserving its explicit no-subset/no-launch/no-release-v2-compatibility statement. Do not copy a new refit into an old historical root.
- Recovered lines339–345 explicitly retain the full100-file v2 preparation, original findings and every earlier failed capture separately. Published lines332–338 retain whole-tree/empty-directory/four-capture-group rules; adding the explicit preparation/failed-attempt detail improves the operator checklist without changing a gate.
- Code-guide row90 changed from source capture and private transfer to private transfer. Restore source capture in the label/dependency explanation: release/ also contains constrained actual source gate-capture entrypoints, while staging and receiving use completed gate evidence. The Refits models? answer remains No.

Two scope ambiguities are documentary, not scientific contradictions: published execution lines322–324 can sound as if actual visual review is required before every reporting helper, although QA prepare creates the blank form first; code-guide row90 understates the source-capture part of release/. Clear stage labels resolve both.

Keep the newer published safeguards. Execution lines340–348 correctly distinguish the1339-file forensic sparsebundle and prospective1384-file retention mapping from a current image rehash or staged payload, require actual source/link/collision checks and preserve the count correction/filtered-log provenance. Lines308–314 add explicit ten-verifier-source, locked-interpreter/completed-output and injection boundaries. Do not overwrite these with the recovered shorter prose.

Exact guide SHA256:

| Guide | Recovered | Published bytes inspected |
| --- | --- | --- |
| catalytic_correction_execution.md | cfa768fa3caecbdf74e8d64313ab74d60349b385b01d905b5f83711600dd0f81 | 111307a24fd498e442805bfcc1cbabc535cdf818495bc3e3be77ce4101eb163c |
| code_guide.md | 4834b22fd4a44c51cb6e264028cf4df1a1b59db24276e529cf66fc8bac75970f | 32221b0d9bd4061b8df3b64166e09ff602b32e9666016d4c67c1839969a74e29 |

comparison.json binds every supporting source/HANDOFF hash and exact line ranges; the two patch files retain the complete recovered-to-published differences. No repository or Git metadata was modified, no process/scientific job was queried or invoked, and no actual result/QA/reproduction/receiving/release completion was certified. Root remains the sole integrator.
