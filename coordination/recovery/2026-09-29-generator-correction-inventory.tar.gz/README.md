# Catalytic correction training-context inventory

This directory prepares an exact recipe inventory for ADR-040/T-190. It is
not a real-data feasibility check, a corrected-method freeze or a fit-reuse
decision. The original code, source outcomes and running jobs are unchanged.
Only the manifest, source text and byte hashes were read. No cohort rows were
loaded and no real generator, SVD, optimizer, MCMC or validation score ran.

`contexts.jsonl` enumerates 825 catalytic outer positions and 825 WME inner
generation positions, including positions that the original execution did
not reach after an earlier failure. `source_bindings.json` binds them to the
clean 119476f production checkout, all 118 original inputs, the matched
parquet and the original manifest. `recipes.json` records the exact later
construction route. All actual reconstructed memberships, preprocessing,
design arrays, ranks and compatibility fields are null/pending.

The frozen manifest already contains outer ordered-membership hashes and
administrative cutoffs. These are copied as references, not claimed to have
been independently reconstructed here. Inner membership depends on the
three-fold splitter applied to the already censored outer training time and
event arrays; an uncensored split would give a different experiment.

| Block | Outer generator positions | WME inner generator positions |
|---|---:|---:|
| GBSG2 clinical | 225 | 225 |
| WHAS500 clinical | 225 | 225 |
| Original METABRIC clinical | 225 | 225 |
| Matched METABRIC clinical | 75 | 75 |
| Matched METABRIC expression | 75 | 75 |
| Total | 825 | 825 |

Each WME inner design is generated once before the candidate loop and reused
for tau multipliers 0.25, 1 and 4. The 825 inner designs therefore have 2,475
candidate uses. Candidate fit seeds differ, while their shared prior design
seed does not. Fixed, adaptive and WME outer designs cannot be merged merely
because they share training patients: their cell IDs enter seed derivation.
Read-only processor caching requires proof of identical ordered raw values,
feature declarations, gene budget, censoring context and preprocessing state.

The seed references preserve the original cell ID, cell seed, fit-attempt
seeds and evaluation seed. Giving a correction a new result ID must not
silently change those model seeds when assessing exact reuse. The inventory
contains no selected WME parameter or reused-result verdict. A changed inner
design can change tuning even when the WME outer proposal is unchanged.

## Later serial actual-preflight route

1. Use the exact lock interpreter recorded in `source_bindings.json`, set all
   BLAS/OpenMP/NumExpr thread variables to one, use low scheduling priority,
   one controller and one child at a time. Verify the candidate/source/lock
   byte bindings and original manifest before reading cohorts. Write to a
   new exclusive output directory; never call `initialize_extension_run` or
   an execution/finalization helper against the original run directory.
2. Load cohorts using the frozen `load_extension_cohorts`, then reconstruct
   all jobs with `build_extension_jobs`. Compare the complete ordered plan,
   outer training/validation subject-ID hashes and cutoffs to the manifest.
   No preprocessor or generator sees outer validation rows or scores. The
   splitter may read the full cohort outcomes as prescribed by the original
   fold construction; all later source marginals come only from the current
   training set.
3. For each outer job, retain its ordered `raw.iloc[job.train]`, apply frozen
   administrative censoring to its training outcomes, record the event guard
   and independently fit the original `ExtensionPreprocessor`. Capture the
   exact feature order, full processor metadata, real encoded design and
   censored time/event array hashes. For WME, construct all three original
   inner folds from those censored arrays and independently refit a processor
   and expression selection on each inner training frame. Do not invoke
   `select_parameters`: that function fits and scores models.
4. The candidate preparer's proposed adapter API is
   `IsolatedOriginalAdapter(source_checkout, training, feature_spec, time,
   event, gene_budget=..., python=...)`, followed by
   `generate_rank_conditioned(adapter, original_seed, cap=...)`. This adapter
   reconstructs the original processor inside each proposal child. Compare
   that returned preprocessing metadata with the controller's independently
   fitted state. The candidate cap, retry seed rule, rank tolerance and
   exhaustion handling require review/freeze; a default is not a method
   decision. The adapter and this runner still need integration and direct
   original-import equivalence verification.
5. Compare the independently invoked legacy first proposal with candidate
   attempt zero, including design/time element identity, scaled hazard,
   source order, M/p and returned legacy metadata. A rejected legacy call
   returns no metadata, so reconstructed failed proposals need reviewed
   instrumentation and explicit lineage. Record source-category support,
   missing encoded columns, finite/positive checks and the original rank
   guard. Do not replace its rank decision with a faster support heuristic.
   Capture every attempt/seed/proposal hash, accepted attempt and terminal
   error. Do not condition redraws on optimizer, sampler or validation scores.
6. Process all 1,650 positions independently of whether an original cell or
   later inner fold was reached. Count successful constructions, exhausted
   rank retries and unrelated input failures explicitly. Retain actual
   arrays and their dtype/order/byte hashes as the reviewed artifact scheme
   requires, release per-context working memory, and measure wall time and
   peak memory before scaling. If inputs fail before generation, keep the
   scheduled position and exact failure; do not fabricate a design.
7. Verify completeness, source membership and candidate receipts with a
   separate read-only pass. Mathematical/prior and changed-input arithmetic
   review, a reviewed scope/reuse inventory, separate freeze and full-budget
   pilot remain later gates. No result is reusable solely because this
   feasibility check passes. Full WME tuning contexts, unchanged fit and
   evaluation inputs and actual stored evidence must match too. Preserve
   identical original failures as well as successes.

`build_inventory.py` imports only Python standard-library modules and uses the
exact seed formula checked against the byte-pinned original source AST. It refuses to
replace evidence files. Its checks verify recipe/count consistency, not any
scientific operation. `inventory_validation.json` and
`preparation_receipt.json` state exactly which work remains pending.
