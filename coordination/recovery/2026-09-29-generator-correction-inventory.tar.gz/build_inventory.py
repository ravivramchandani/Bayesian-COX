"""Enumerate frozen generator recipes without reading cohort rows or fitting."""

from __future__ import annotations

import ast
import hashlib
import json
import re
import subprocess
from collections import Counter
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
SOURCE = Path("/Users/macuser/bayes-cox-runs/extensions-code-20260928-119476f")
RUN = Path("/Users/macuser/bayes-cox-runs/extensions-20260928/run")
MATCHED = Path("/Users/macuser/bayes-cox-runs/extension-preparation-20260928/matched_metabric.parquet")
LOCKED_PYTHON = Path("/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python")
PRODUCTION_COMMIT = "119476fef55b1eeb690527f234c1423440720d45"
MANIFEST_SHA256 = "83b9049fb6aaaadab576b34de0741e4f510344dcefba9f96198d15b5ab4f49b9"
MANIFEST_CONTENT_SHA256 = "4577c615486ee871d508837aa812f59539b59338c63834716453a8b03ea394a3"
MODELS = ("catalytic_fixed", "catalytic_adaptive", "catalytic_wme")
NONFULL = ("fraction_0.25", "fraction_0.50", "fraction_0.75", "admin_q0.75", "admin_q0.50")
CELL_RE = re.compile(r"(gbsg2|whas500|metabric|metabric_matched)__(clinical|expression)__r(\d{2})f(\d{2})__(catalytic_fixed|catalytic_adaptive|catalytic_wme)__(full|fraction_0\.(?:25|50|75)|admin_q0\.(?:50|75))")


def sha256_file(path: Path) -> str:
    """Hash bytes without importing the analysis packages."""
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    """Use the frozen source's canonical JSON encoding."""
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def write_json_exclusive(path: Path, value: Any) -> None:
    """Write a new preparation artifact and refuse replacement."""
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def frozen_seed_function() -> tuple[Callable[..., int], dict[str, Any]]:
    """Verify the original seed AST and use its exact pure hash formula."""
    relative = "src/pipelines/confirmatory/options.py"
    source_hash = sha256_file(SOURCE / relative)
    if source_hash != "3b8e03d1f11770be98d4c6c68a21123475a8f3b61a8fe26c55f40e50daafe49e":
        raise ValueError("original seed source bytes differ")
    source = (SOURCE / relative).read_text(encoding="utf-8")
    module = ast.parse(source)
    function = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == "deterministic_seed")
    ast_hash = hashlib.sha256(ast.dump(function, include_attributes=False).encode()).hexdigest()
    if ast_hash != "76b481cb07a294ea743ef6bf70deb275bd4c12f6c57c78a6ea3e88f380a9121a":
        raise ValueError("original seed function AST differs")

    def deterministic_seed(base_seed: int, *parts: object) -> int:
        payload = "|".join([str(base_seed), *(str(part) for part in parts)])
        digest = hashlib.sha256(payload.encode("utf-8")).digest()
        return int.from_bytes(digest[:4], "big") % (2**31 - 1)

    return deterministic_seed, {"path": relative, "function": function.name, "line": function.lineno, "sha256": source_hash, "function_ast_sha256": ast_hash}


def expected_outer_ids() -> set[str]:
    """Independently enumerate the frozen catalytic grid's position labels."""
    labels = set()
    for dataset in ("gbsg2", "whas500", "metabric", "metabric_matched"):
        settings = ("clinical", "expression") if dataset == "metabric_matched" else ("clinical",)
        for repeat in range(1, 6):
            for fold in range(1, 6):
                for setting in settings:
                    for model in MODELS:
                        labels.add(f"{dataset}__{setting}__r{repeat:02}f{fold:02}__{model}__full")
                if dataset != "metabric_matched" and fold in (1, 2):
                    for condition in NONFULL:
                        for model in MODELS:
                            labels.add(f"{dataset}__clinical__r{repeat:02}f{fold:02}__{model}__{condition}")
    return labels


def function_binding(relative: str, name: str) -> dict[str, Any]:
    """Locate an inspected original function or class without executing it."""
    tree = ast.parse((SOURCE / relative).read_text(encoding="utf-8"))
    pieces = name.split(".")
    body = tree.body
    node = None
    for piece in pieces:
        node = next(item for item in body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and item.name == piece)
        body = node.body
    assert node is not None
    return {"path": relative, "name": name, "line": node.lineno, "sha256": sha256_file(SOURCE / relative)}


def source_bindings(manifest: dict[str, Any], seed_binding: dict[str, Any]) -> dict[str, Any]:
    """Verify the original bytes and record function anchors for later work."""
    input_checks = []
    for relative, expected in sorted(manifest["input_sha256"].items()):
        path = SOURCE / relative
        observed = sha256_file(path)
        if observed != expected:
            raise ValueError(f"frozen source/input bytes differ: {relative}")
        input_checks.append({"path": relative, "sha256": observed, "bytes": path.stat().st_size})
    observed_matched = sha256_file(MATCHED)
    if observed_matched != manifest["matched_sha256"]:
        raise ValueError("matched parquet bytes differ")
    git_commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=SOURCE, check=True, capture_output=True, text=True).stdout.strip()
    git_status = subprocess.run(["git", "status", "--porcelain"], cwd=SOURCE, check=True, capture_output=True, text=True).stdout
    if git_commit != PRODUCTION_COMMIT or git_status:
        raise ValueError("sealed production checkout identity or clean status differs")
    anchors = [
        ("src/pipelines/extensions/runner.py", "load_extension_cohorts"),
        ("src/pipelines/extensions/runner.py", "run_extension_cell"),
        ("src/pipelines/extensions/planning.py", "build_extension_jobs"),
        ("src/data/cohorts.py", "load_analysis_dataset"),
        ("src/data/survival_folds.py", "event_time_strata"),
        ("src/data/survival_folds.py", "repeated_survival_folds"),
        ("src/pipelines/robustness/conditions.py", "stratified_training_subsets"),
        ("src/pipelines/robustness/conditions.py", "apply_administrative_censoring"),
        ("src/pipelines/extensions/preprocessing.py", "ExtensionPreprocessor.fit"),
        ("src/pipelines/extensions/preprocessing.py", "ExtensionPreprocessor.transform"),
        ("src/pipelines/extensions/preprocessing.py", "ExtensionPreprocessor.metadata"),
        ("src/data/fold_preprocessing.py", "FoldFeaturePreprocessor.fit"),
        ("src/data/fold_preprocessing.py", "FoldFeaturePreprocessor.transform"),
        ("src/pipelines/extensions/preprocessing.py", "generate_catalytic_data"),
        ("src/models/catalytic.py", "CatalyticData.__post_init__"),
        ("src/pipelines/extensions/fitting.py", "candidates_for"),
        ("src/pipelines/extensions/fitting.py", "select_parameters"),
        ("src/pipelines/extensions/fitting.py", "fit_with_attempts"),
        ("src/utils/reproducibility.py", "canonical_json_hash"),
    ]
    return {
        "schema_version": 1,
        "status": "frozen_byte_bindings_checked_only",
        "sealed_source_root": str(SOURCE),
        "sealed_source_commit": git_commit,
        "sealed_source_clean": True,
        "manifest_path": str(RUN / "manifest.json"),
        "manifest_sha256": sha256_file(RUN / "manifest.json"),
        "manifest_content_sha256": manifest["manifest_content_sha256"],
        "protocol_freeze_content_sha256": manifest["freeze_sha256"],
        "input_sha256": manifest["input_sha256"],
        "input_byte_checks": input_checks,
        "matched_parquet": {"path": str(MATCHED), "sha256": observed_matched, "bytes": MATCHED.stat().st_size},
        "locked_python_for_later_scientific_work": str(LOCKED_PYTHON),
        "environment_verified_in_this_preparation": False,
        "function_bindings": [function_binding(path, name) for path, name in anchors],
        "pure_seed_function": seed_binding,
        "run_config": manifest["run_config"],
    }


def context_rows(manifest: dict[str, Any], seed: Callable[..., int]) -> list[dict[str, Any]]:
    """Enumerate outer and WME inner recipes including unreached positions."""
    rows = []
    config = manifest["run_config"]
    base_seed = config["base_seed"]
    multipliers = config["catalytic"]["wme_tau_multipliers"]
    if config["inner_cv_splits"] != 3 or multipliers != [0.25, 1.0, 4.0]:
        raise ValueError("unexpected frozen inner-fold or candidate recipe")
    outer_ids = set()
    for plan_index, plan in enumerate(manifest["plan"]):
        match = CELL_RE.fullmatch(plan["cell_id"])
        if match is None:
            continue
        dataset, setting, repeat_text, fold_text, model, condition = match.groups()
        repeat, fold = int(repeat_text), int(fold_text)
        cell_id = plan["cell_id"]
        outer_ids.add(cell_id)
        cell_seed = seed(base_seed, "extensions", cell_id)
        inner_cv_seed = seed(cell_seed, "inner_cv")
        common = {
            "outer_cell_id": cell_id,
            "manifest_plan_index_zero_based": plan_index,
            "dataset": dataset,
            "setting": setting,
            "condition": condition,
            "repeat": repeat,
            "fold": fold,
            "model": model,
            "gene_budget": config["gene_budget"] if setting == "expression" else 0,
            "feature_spec_reference": f"config/datasets.yaml:{'metabric' if dataset == 'metabric_matched' else dataset}.primary_features",
            "censoring_cutoff_from_manifest": plan["censoring_cutoff"],
            "outer_train_sha256_from_manifest": plan["train_sha256"],
            "outer_validation_sha256_from_manifest": plan["validation_sha256"],
            "base_seed": base_seed,
            "cell_seed": cell_seed,
            "outer_split_seed": base_seed + 1009 * (repeat - 1),
            "robustness_subset_seed": seed(base_seed, "robustness_subset", dataset, repeat, fold) if condition.startswith("fraction_") else None,
            "inner_cv_seed": inner_cv_seed,
            "original_outer_fit_attempt_seeds": [seed(cell_seed, "fit_attempt", attempt) for attempt in range(1 if model == "catalytic_wme" else 3)],
            "outer_evaluation_seed": cell_seed,
            "source_binding_reference": "source_bindings.json",
            "status": "recipe_enumerated_membership_and_arrays_not_constructed",
            "actual_training_membership_sha256": None,
            "actual_preprocessing_state_sha256": None,
            "actual_real_training_design_sha256": None,
            "actual_training_time_event_sha256": None,
            "actual_legacy_proposal_sha256": None,
            "actual_rank_conditioned_proposal_sha256": None,
            "actual_rank": None,
            "fit_reuse_status": "not_assessed",
        }
        rows.append({
            **common,
            "context_id": f"{cell_id}::outer",
            "context": "outer",
            "inner_fold": None,
            "recipe_reference": "recipes.json:outer_training",
            "generation_seed": seed(cell_seed, "outer_prior"),
            "generation_seed_parts": [cell_seed, "outer_prior"],
            "inner_split_seed": None,
            "shared_tau_candidate_uses": [],
            "reachability": "scheduled_even_when_original_tuning_prevents_outer_generation",
        })
        if model != "catalytic_wme":
            continue
        for inner_fold in range(1, 4):
            rows.append({
                **common,
                "context_id": f"{cell_id}::inner_{inner_fold:02}",
                "context": "inner",
                "inner_fold": inner_fold,
                "recipe_reference": "recipes.json:wme_inner_training",
                "generation_seed": seed(inner_cv_seed, "inner_prior", inner_fold),
                "generation_seed_parts": [inner_cv_seed, "inner_prior", inner_fold],
                "inner_split_seed": inner_cv_seed,
                "shared_tau_candidate_uses": [
                    {"candidate_index_zero_based": ci, "tau_multiplier": multiplier,
                     "inner_fit_seed": seed(inner_cv_seed, "inner_fit", inner_fold, ci)}
                    for ci, multiplier in enumerate(multipliers)
                ],
                "reachability": "scheduled_even_when_original_earlier_inner_generation_failed",
            })
    if outer_ids != expected_outer_ids():
        raise ValueError("manifest catalytic positions differ from the independent grid")
    return rows


def recipes() -> dict[str, Any]:
    """Describe the later scientific construction without invoking it."""
    return {
        "schema_version": 1,
        "status": "implementation_route_only_not_executed",
        "outer_training": {
            "cohort_loader": "src/pipelines/extensions/runner.py:load_extension_cohorts",
            "job_builder": "src/pipelines/extensions/planning.py:build_extension_jobs",
            "memberships": "Rebuild all jobs from unchanged cohorts and config; compare ordered train and validation subject-ID hashes and censoring_cutoff against every frozen manifest plan row.",
            "outer_folds": {"n_splits": 5, "n_repeats": 5, "base_seed": 260817, "max_time_bins": 4},
            "fraction_subset": {"fractions": [0.25, 0.5, 0.75, 1.0], "max_time_bins": 4, "ordering": "original frozen stratified_training_subsets; then fold.train_indices[subsets[fraction]]"},
            "administrative_cutoff": "Frozen float np.quantile of uncensored outer training time, q=0.75 or0.50; apply original censoring before inner splitting and prior hazard/time scale.",
            "generator_raw_rows": "raw.iloc[job.train] in original order; source covariates stay unmodified even when outcomes are censored.",
            "generator_time_event": "apply_administrative_censoring(raw.duration[job.train],raw.event[job.train],job.censoring_cutoff)",
            "processor": "ExtensionPreprocessor(feature_spec,job.gene_budget).fit(raw.iloc[job.train]); metadata and transform(training) must match original.",
            "event_guard": "Record whether censored outer training events sum to at least20; do not silently modify membership or force a generation when required inputs are invalid.",
            "generator": "src/pipelines/extensions/preprocessing.py:generate_catalytic_data; exact original call or separately labelled candidate adapter with original generation seed.",
        },
        "wme_inner_training": {
            "splitter": "src/data/survival_folds.py:repeated_survival_folds on already administratively censored outer tt,ee",
            "n_splits": 3,
            "n_repeats": 1,
            "max_time_bins": 4,
            "base_seed": "deterministic_seed(original_cell_seed,'inner_cv')",
            "generator_raw_rows": "outer_training.iloc[inner_fold.train_indices] in exact ordered local-index sequence",
            "generator_time_event": "censored_outer_tt[inner_fold.train_indices],censored_outer_ee[inner_fold.train_indices]",
            "processor": "New ExtensionPreprocessor(feature_spec,job.gene_budget).fit(inner_training), never outer pre-fitted state; inner gene selection uses inner rows.",
            "prior_seed": "deterministic_seed(inner_cv_seed,'inner_prior',inner_fold.fold)",
            "shared_candidates": [0.25, 1.0, 4.0],
            "candidate_fit_seed": "deterministic_seed(inner_cv_seed,'inner_fit',inner_fold.fold,candidate_index_zero_based)",
            "execution_order": "Original select_parameters creates one design before its candidate loop; enumerate all three inner positions even when the original path stopped early.",
            "preflight_only": "Do not invoke select_parameters because it fits and scores models. Reproduce only its splitter and training input construction.",
        },
        "exact_first_draw_identity": {
            "original_model_seed_namespace": "Original cell_id, cell seed, fit-attempt seeds, inner seeds and evaluation seed stay preserved as the compatibility reference. New corrective result IDs must not silently rederive different model seeds.",
            "inputs": ["ordered subject IDs", "raw source values/dtypes/column order", "censored time and event arrays", "feature spec and gene budget", "complete processor metadata", "encoded feature column order and values", "original generation seed", "synthetic design and time element identity", "scaled hazard", "M and p", "legacy metadata when original generator returned successfully"],
            "rejects": "Original rejected proposals have no returned legacy metadata; capture complete construction inputs/proposal arrays through a reviewed instrumentation boundary and label them reconstructed, not an original saved success.",
            "fit_reuse": "All generation contexts plus exact real/model/optimizer/sampler/evaluation inputs and original evidence hashes are necessary. Same full-rank feasibility or same subjects alone proves no reuse.",
            "deduplication": "One WME inner proposal is shared across its three tau candidates. Distinct cell/model/setting/condition context seeds must not be merged. Read-only training/processor caching is valid only after exact ordered values/state/recipe identity has been proved.",
        },
        "candidate_status": {"rank_retry_cap": "not_frozen", "retry_seed_rule": "not_frozen", "rank_tolerance": "not_frozen", "new_protocol_freeze": False, "method_approval": False},
        "scientific_operations_run": [],
        "forbidden_during_this_preparation": ["load actual cohort rows", "generate real-data synthetic designs", "run matrix_rank or SVD", "fit optimizers or MCMC", "score validation patients", "edit original source or outcomes", "make reuse/refit decisions"],
    }


def validate_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Check complete combinatoric coverage and recorded seed relations."""
    ids = [row["context_id"] for row in rows]
    if len(ids) != 1650 or len(set(ids)) != 1650:
        raise ValueError("context IDs are incomplete or duplicated")
    outer = [row for row in rows if row["context"] == "outer"]
    inner = [row for row in rows if row["context"] == "inner"]
    if len(outer) != 825 or len(inner) != 825:
        raise ValueError("outer or inner inventory count differs")
    by_outer = {row["outer_cell_id"]: row for row in outer}
    if set(by_outer) != expected_outer_ids():
        raise ValueError("outer membership labels differ")
    inner_coverage = Counter(row["outer_cell_id"] for row in inner)
    wme_ids = {row["outer_cell_id"] for row in outer if row["model"] == "catalytic_wme"}
    if set(inner_coverage) != wme_ids or len(wme_ids) != 275 or set(inner_coverage.values()) != {3}:
        raise ValueError("WME inner positions are incomplete")
    for cell_id in wme_ids:
        positions = [row for row in inner if row["outer_cell_id"] == cell_id]
        if {row["inner_fold"] for row in positions} != {1, 2, 3}:
            raise ValueError("WME fold label differs")
        if any(len(row["shared_tau_candidate_uses"]) != 3 for row in positions):
            raise ValueError("WME candidate use count differs")
    if any(row["actual_training_membership_sha256"] is not None or row["actual_rank"] is not None or row["fit_reuse_status"] != "not_assessed" for row in rows):
        raise ValueError("preparation contains an unsupported actual input or reuse claim")
    by_dataset_setting = Counter(f"{row['dataset']}::{row['setting']}::{row['context']}" for row in rows)
    by_condition_context = Counter(f"{row['condition']}::{row['context']}" for row in rows)
    by_model_context = Counter(f"{row['model']}::{row['context']}" for row in rows)
    seed_counts = Counter(row["generation_seed"] for row in rows)
    collisions = {str(value): [row["context_id"] for row in rows if row["generation_seed"] == value] for value, count in seed_counts.items() if count > 1}
    return {
        "context_recipe_count": len(rows), "outer_job_count": len(outer), "wme_outer_job_count": len(wme_ids),
        "wme_inner_generation_count": len(inner), "wme_inner_candidate_use_count": sum(len(row["shared_tau_candidate_uses"]) for row in inner),
        "by_dataset_setting_context": dict(sorted(by_dataset_setting.items())),
        "by_condition_context": dict(sorted(by_condition_context.items())),
        "by_model_context": dict(sorted(by_model_context.items())),
        "generation_seed_collision_groups": collisions,
        "generation_seed_unique_count": len(seed_counts),
        "actual_memberships_constructed": 0, "actual_generators_called": 0, "actual_svd_calls": 0,
        "model_fits": 0, "scored_validation_contexts": 0,
        "exact_input_reuse_proved": False, "corrected_method_frozen": False,
    }


def main() -> None:
    """Write one new source-bound inventory; no analysis package is imported."""
    output_names = ("source_bindings.json", "recipes.json", "contexts.jsonl", "inventory_validation.json", "preparation_receipt.json")
    if any((HERE / name).exists() for name in output_names):
        raise FileExistsError("preparation evidence already exists; do not overwrite")
    manifest_path = RUN / "manifest.json"
    if sha256_file(manifest_path) != MANIFEST_SHA256:
        raise ValueError("original manifest bytes differ")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if canonical_hash({key: value for key, value in manifest.items() if key != "manifest_content_sha256"}) != MANIFEST_CONTENT_SHA256 or manifest["manifest_content_sha256"] != MANIFEST_CONTENT_SHA256:
        raise ValueError("original manifest canonical content differs")
    if manifest["planned_fits"] != 1625 or len(manifest["plan"]) != 1625:
        raise ValueError("original manifest planned fit count differs")
    if manifest["code"]["git_commit"] != PRODUCTION_COMMIT or manifest["code"]["git_dirty"]:
        raise ValueError("original manifest source identity differs")
    seed, seed_binding = frozen_seed_function()
    bindings = source_bindings(manifest, seed_binding)
    rows = context_rows(manifest, seed)
    validation = validate_rows(rows)
    write_json_exclusive(HERE / "source_bindings.json", bindings)
    write_json_exclusive(HERE / "recipes.json", recipes())
    with (HERE / "contexts.jsonl").open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, separators=(",", ":"), sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n")
    write_json_exclusive(HERE / "inventory_validation.json", {"schema_version": 1, "status": "pure_recipe_inventory_checks_passed", **validation})
    artifact_names = ("build_inventory.py", "README.md", *output_names[:-1])
    receipt = {
        "schema_version": 1, "prepared_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "inventory_and_runner_design_prepared_no_actual_preflight",
        "preparation_root": str(HERE), "original_manifest_sha256": MANIFEST_SHA256,
        "source_input_byte_bindings_checked": 118, "matched_parquet_byte_binding_checked": True,
        "counts": validation,
        "artifacts": {name: {"sha256": sha256_file(HERE / name), "bytes": (HERE / name).stat().st_size} for name in artifact_names},
        "claims": {"method_approved": False, "all_grid_training_arrays_constructed": False, "all_grid_preflight_executed": False, "legacy_draw_compatibility_tested": False, "candidate_cap_or_seeds_frozen": False, "fit_reuse_or_refit_proved": False, "corrective_scores_exist": False},
    }
    receipt["content_sha256"] = canonical_hash(receipt)
    write_json_exclusive(HERE / "preparation_receipt.json", receipt)
    print(json.dumps({"status": receipt["status"], "outer": len([row for row in rows if row["context"] == "outer"]), "inner": len([row for row in rows if row["context"] == "inner"]), "candidate_uses": validation["wme_inner_candidate_use_count"], "generation_seed_unique_count": validation["generation_seed_unique_count"]}))


if __name__ == "__main__":
    main()
