"""Preserve exact scoped old local state; never mutate either Git checkout."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
OLD = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
NEW = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
AUDIT = ROOT / 'original_checkout_reconciliation_audit_20260929_v1'
SIDECAR = ROOT / 'original_checkout_reconciliation_archive_collisions_20260929_v1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    target = BASE / name
    with target.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def stamp():
    return datetime.now(timezone.utc).isoformat()


def git_capture(name, args):
    argv = ['git', '-c', 'core.fsmonitor=false', *args]
    start = stamp()
    tick = time.monotonic()
    env = os.environ.copy()
    env['GIT_OPTIONAL_LOCKS'] = '0'
    result = subprocess.run(argv, cwd=OLD, env=env, capture_output=True, timeout=15, check=False)
    for suffix, data in [('stdout.log', result.stdout), ('stderr.log', result.stderr)]:
        with (BASE / (name + '.' + suffix)).open('xb') as stream:
            stream.write(data)
    write(name + '.invocation.json', {
        'argv': argv, 'cwd': str(OLD), 'started_at_utc': start,
        'finished_at_utc': stamp(), 'wall_seconds': time.monotonic() - tick,
        'actual_subprocess_returncode': result.returncode,
        'optional_git_locks': '0', 'core_fsmonitor': False,
        'stdout_sha256': digest(BASE / (name + '.stdout.log')),
        'stderr_sha256': digest(BASE / (name + '.stderr.log')),
    })
    assert type(result.returncode) is int and result.returncode == 0
    return result.stdout


def tree(path):
    assert not path.is_symlink()
    if path.is_file():
        return [], [path]
    assert path.is_dir()
    directories = [path]
    files = []
    for node in sorted(path.rglob('*')):
        assert not node.is_symlink(), node
        if node.is_dir():
            directories.append(node)
        else:
            assert node.is_file(), node
            files.append(node)
    return directories, files


def main():
    assert digest(AUDIT / 'receipt.json') == '439ebfad229c4d040742da95d8e7368f03a79930c1f5253ab7db5ce42cd20f70'
    assert digest(SIDECAR / 'receipt.json') == 'b444627d5d082372fab7c9b3cc0599344bb356894707c3ec26255fa755b77039'
    audit = json.loads((AUDIT / 'audit.json').read_text())
    collisions = json.loads((SIDECAR / 'archive_collisions.json').read_text())
    head = git_capture('original_head_before', ['rev-parse', 'HEAD'])
    status = git_capture('original_status_before', ['status', '--porcelain=v1', '-z'])
    assert head.decode().strip() == audit['original_head']
    assert status == (AUDIT / 'original_status.stdout.log').read_bytes()
    tracked = audit['tracked_dirty_files']
    untracked = [item['path'] for item in audit['untracked_entries']]
    assert len(tracked) == 8 and len(untracked) == 20 and len(set(tracked + untracked)) == 28
    directories, files = [], []
    for name in tracked + untracked:
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        ds, fs = tree(OLD / relative)
        directories += ds
        files += fs
    assert len(files) == len(set(files))
    inventory = {
        str(path.relative_to(OLD)): {'bytes': path.stat().st_size, 'sha256': digest(path)}
        for path in sorted(files)
    }
    directory_roster = sorted(str(path.relative_to(OLD)) for path in directories)
    write('original_local_state_before.json', {
        'original_head': head.decode().strip(), 'observed_at_utc': stamp(),
        'tracked_paths': tracked, 'untracked_status_entries': untracked,
        'complete_scoped_file_inventory': inventory, 'complete_scoped_directories': directory_roster,
        'scientific_data_or_results_included': False,
    })
    snapshot = BASE / 'original_local_state'
    snapshot.mkdir()
    for name in directory_roster:
        (snapshot / name).mkdir(parents=True, exist_ok=True)
    for name, bound in inventory.items():
        source, target = OLD / name, snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not target.exists()
        shutil.copy2(source, target)
        assert digest(target) == bound['sha256'] and target.stat().st_size == bound['bytes']
    rows = []
    for name, bound in inventory.items():
        resident = NEW / name
        assert resident.is_file() and not resident.is_symlink()
        rows.append({'relative_path': name, 'original_sha256': bound['sha256'],
                     'resident_sha256': digest(resident),
                     'byte_equal': digest(resident) == bound['sha256']})
    unequal = sorted(row['relative_path'] for row in rows if not row['byte_equal'])
    expected = sorted(['coordination/HANDOFF.md', 'coordination/JOURNAL.md', 'coordination/TODO.md',
                       'docs/catalytic_correction_execution.md', 'docs/code_guide.md', 'docs/ravi_handoff.md'])
    assert unequal == expected
    for name in untracked:
        assert all(row['byte_equal'] for row in rows if row['relative_path'] == name or row['relative_path'].startswith(name.rstrip('/') + '/'))
        old_dirs, old_files = tree(OLD / name)
        new_dirs, new_files = tree(NEW / name)
        assert [str(x.relative_to(OLD)) for x in old_dirs] == [str(x.relative_to(NEW)) for x in new_dirs]
        assert [str(x.relative_to(OLD)) for x in old_files] == [str(x.relative_to(NEW)) for x in new_files]
    assert len(collisions['rows']) == 14
    archive_rows = []
    for row in collisions['rows']:
        name = row['relative_path']
        old, resident = OLD / name, NEW / name
        assert str(old) == row['original_path'] and str(resident) == row['resident_path']
        assert old.stat().st_size == row['original_bytes_stat_only']
        assert digest(old) == digest(resident) == inventory[name]['sha256']
        archive_rows.append({'relative_path': name, 'bytes': old.stat().st_size,
                             'sha256': digest(old), 'compressed_bytes_equal': True,
                             'archive_decompressed': False})
    write('resident_collision_byte_comparison.json', {
        'observed_at_utc': stamp(), 'rows': rows, 'different_tracked_documents': unequal,
        'all_untracked_files_and_directories_exactly_equal': True,
        'archive_collision_count': 14, 'archive_compressed_byte_checks': archive_rows,
        'archive_compressed_bytes_total': sum(row['bytes'] for row in archive_rows),
        'scientific_data_results_arrays_or_traces_read': False,
        'repository_mutations_performed': False,
    })
    after = {str(path.relative_to(OLD)): {'bytes': path.stat().st_size, 'sha256': digest(path)} for path in sorted(files)}
    assert after == inventory
    assert git_capture('original_head_after', ['rev-parse', 'HEAD']) == head
    assert git_capture('original_status_after', ['status', '--porcelain=v1', '-z']) == status
    for name, bound in inventory.items():
        assert digest(snapshot / name) == bound['sha256']
    write('completed_preservation.json', {
        'status': 'exact_scoped_original_local_state_preserved_and_collisions_byte_verified',
        'completed_at_utc': stamp(), 'files_preserved': len(inventory),
        'directories_preserved': len(directory_roster), 'source_bytes_before_after_unchanged': True,
        'original_head_and_status_unchanged': True, 'all_untracked_collisions_byte_equal': True,
        'original_checkout_synchronized': False, 'git_stash_fetch_or_merge_performed': False,
        'numerical_execution_or_release_approval_conferred': False,
    })
    artifacts = {}
    for path in sorted(BASE.rglob('*')):
        if path.is_file():
            artifacts[str(path.relative_to(BASE))] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    write('receipt.json', {'schema_version': 1, 'status': 'original_local_state_preservation_sealed',
                          'sealed_at_utc': stamp(), 'artifacts': artifacts,
                          'audit_receipt_sha256': digest(AUDIT / 'receipt.json'),
                          'collision_sidecar_receipt_sha256': digest(SIDECAR / 'receipt.json'),
                          'repository_mutations_performed': False})
    print(json.dumps({'files_preserved': len(inventory), 'directories_preserved': len(directory_roster),
                      'all_untracked_collisions_byte_equal': True, 'receipt_sha256': digest(BASE / 'receipt.json')}))


if __name__ == '__main__':
    main()
