"""Capture only portable fictional test/lint/syntax checks outside the repository."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).absolute().parent
SOURCES = ("release_v3_repository_adapter.py", "test_catalytic_correction_release_v3.py", "run_adapter_checks.py")
NUMERIC = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")


def sha(path: Path) -> str:
    """Digest a small source/log member."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value) -> str:
    """Bind canonical source-file witnesses for before/after comparison."""
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def source_inventory(root: Path) -> dict:
    """Read only regular small prepared sources/metadata; no science directory."""
    require = root / "preparation_receipt.json"
    if sha(require) != "5ded4445b5a1488e0ab02a4eadbab43a8159e422a385918a2551e1989d0b5034":
        raise ValueError("exact sealed release-v3 source required")
    files = {str(p.relative_to(root)): {"sha256": sha(p), "bytes": p.stat().st_size}
             for p in root.rglob("*") if p.is_file()}
    if len(files) != 233:
        raise ValueError("exact233 source carrier required before/after tests")
    return files


def install(path: Path, raw: bytes) -> None:
    """Retain each genuine bounded-check artifact exclusively."""
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def main() -> int:
    """Only the four explicit source-only preparation phases can be invoked."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", required=True, choices=("unittest", "pytest", "ruff", "syntax"))
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    args = parser.parse_args()
    if not args.python.is_absolute() or not args.python.samefile(Path(sys.executable)):
        raise ValueError("current requested locked interpreter must be the actual interpreter")
    if any(os.environ.get(name) != "1" for name in NUMERIC):
        raise ValueError("numeric-five must already equal one")
    if Path(args.prefix).name != args.prefix or not args.prefix or ".." in Path(args.prefix).parts or any(ROOT.glob(args.prefix + ".*")):
        raise ValueError("exclusive single-component check prefix required")
    if not args.source.is_absolute() or any(p.is_symlink() for p in (args.source, *args.source.parents)):
        raise ValueError("absolute unlinked sealed source carrier required")
    files_before = source_inventory(args.source)
    source_before = {name: sha(ROOT / name) for name in SOURCES}
    scratch = ROOT / (args.prefix + ".fixtures")
    scratch.mkdir()
    environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "PYTEST_ADDOPTS": "",
        "BAYES_COX_RELEASE_V3_TEST_SOURCE_ROOT": str(args.source), "BAYES_COX_RELEASE_V3_TEST_FIXTURE_ROOT": str(scratch)}
    started, tick = datetime.now(UTC).isoformat(), time.monotonic()
    if args.phase == "syntax":
        argv = [str(args.python), "-I", "-B", str(Path(__file__).absolute()), "--phase", "syntax", "--prefix", args.prefix,
                "--python", str(args.python), "--source", str(args.source)]
        for name in SOURCES:
            raw = (ROOT / name).read_bytes()
            ast.parse(raw, filename=str(ROOT / name))
            compile(raw, str(ROOT / name), "exec", dont_inherit=True)
        rc, stdout, stderr = 0, json.dumps({"ast_compile_sources": len(SOURCES), "source_bodies_executed": False}).encode() + b"\n", b""
    else:
        if args.phase == "unittest":
            argv = [str(args.python), "-I", "-B", str(ROOT / "test_catalytic_correction_release_v3.py")]
        elif args.phase == "pytest":
            argv = [str(args.python), "-I", "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", "--confcutdir", str(ROOT),
                    str(ROOT / "test_catalytic_correction_release_v3.py")]
        else:
            argv = [str(args.python), "-I", "-B", "-m", "ruff", "check", "--no-cache", "--select", "E,F,I,UP,B", "--ignore", "E501",
                    *(str(ROOT / name) for name in SOURCES)]
        result = subprocess.run(argv, cwd=ROOT, capture_output=True, check=False, env=environment)
        rc, stdout, stderr = result.returncode, result.stdout, result.stderr
    paths = {kind: ROOT / (args.prefix + suffix) for kind, suffix in
             (("stdout", ".stdout.txt"), ("stderr", ".stderr.log"), ("invocation", ".invocation.json"))}
    install(paths["stdout"], stdout)
    install(paths["stderr"], stderr)
    files_after, source_after, verification_error = None, None, None
    try:
        files_after = source_inventory(args.source)
        source_after = {name: sha(ROOT / name) for name in SOURCES}
        if list(scratch.iterdir()):
            raise ValueError("bounded child left its own disposable source fixture")
        scratch.rmdir()
    except Exception as error:
        verification_error = {"exception_type": type(error).__name__, "message": str(error)}
    check_ok = verification_error is None and files_before == files_after and source_before == source_after
    record = {"schema_version": 1, "status": "bounded_release_v3_portability_preparation_check", "phase": args.phase,
        "argv": argv, "cwd": str(ROOT), "started_at_utc": started, "finished_at_utc": datetime.now(UTC).isoformat(),
        "wall_seconds": time.monotonic() - tick, "exit_code": rc, "source_sha256_before": source_before,
        "source_sha256_after": source_after, "adapter_sources_unchanged": source_before == source_after,
        "sealed233_source_inventory_digest_before": canonical(files_before), "sealed233_source_inventory_digest_after": canonical(files_after),
        "sealed233_source_unchanged": files_before == files_after, "sealed_source": str(args.source),
        "numeric_thread_environment": {name: environment[name] for name in NUMERIC},
        "portable_fixture_overrides": {name: environment[name] for name in ("BAYES_COX_RELEASE_V3_TEST_SOURCE_ROOT", "BAYES_COX_RELEASE_V3_TEST_FIXTURE_ROOT")},
        "pytest_plugins_and_cache_disabled": True, "owned_disposable_source_fixtures_removed": not scratch.exists(),
        "postcheck_error": verification_error, "check_exit_code": rc if check_ok else 1,
        "stdout_sha256": sha(paths["stdout"]), "stderr_sha256": sha(paths["stderr"]),
        "original32_tests_rewritten": False, "actual_numerical_scientific_source_receiving_producer_or_transfer_dispatch": False}
    record["content_sha256"] = canonical(record)
    install(paths["invocation"], (json.dumps(record, sort_keys=True, indent=2) + "\n").encode())
    print(json.dumps({"phase": args.phase, "exit_code": rc, "adapter_unchanged": source_before == source_after,
        "sealed233_unchanged": files_before == files_after, "invocation_path": str(paths["invocation"]),
        "invocation_sha256": sha(paths["invocation"])}), flush=True)
    return rc if check_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
