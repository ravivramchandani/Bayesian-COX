# Portable release-v3 test preparation

This preparation adds one repository test adapter around the exact sealed release-v3 carrier. It does not install code, approve a location plan or missing-producer subset, or perform numerical, producer, receiving, staging or release operations.

The 32 original `test_release_v3.py` methods are inherited as the same method objects without rewriting. One additional test checks the complete 232-artifact/233-file carrier, original method ASTs, runtime/source pins, repository-relative path selection, refusal of changed/missing/extra files and empty directories, and a genuine fresh `-I -B` import of the three entrypoints without dispatch. It exports exactly one original fixture class. Repository pytest already limits discovery to `tests`, so preserved historical tests inside the source carrier are not separately collected.

All source-only imports use private names. Temporary public aliases, `sys.path` and bytecode settings are restored after collection and every retained test, including exceptions. The guard compares newly introduced scientific module names against the existing process state, so other tests' earlier imports do not create a false failure. Each test process copies only the 1.69 MB prepared carrier to a disposable source fixture; original sealed files are never written. Fixture paths are resolved before byte checks to avoid Darwin `/var` aliases.

## Proposed repository layout

Only the repository owner installs these files after its separate review:

- `release_v3_repository_adapter.py` → `tests/release_v3_repository_adapter.py`
- `test_catalytic_correction_release_v3.py` → `tests/test_catalytic_correction_release_v3.py`
- All exact 233 sealed release-v3 members → `scripts/catalytic_correction/release_v3/`

Do not add a new `__init__.py`, edit the retained files, or omit historical bound cache/log files. The full file and directory inventory is part of `preparation_receipt.json`; a four-file runtime copy is insufficient. The copied predecessor source/receipt bytes remain historical and distinct from v3. The prep-only check runner and check logs stay in recovery evidence, not the test directory.

The test adapter defaults to its repository-relative carrier and has no machine-specific fallback. Optional explicit overrides are `BAYES_COX_RELEASE_V3_TEST_REPOSITORY_ROOT`, `BAYES_COX_RELEASE_V3_TEST_SOURCE_ROOT` and `BAYES_COX_RELEASE_V3_TEST_FIXTURE_ROOT`. These are useful before installation and are not required in an adopted repository. Its private support name is distinct from the existing per-entry `repository_adapter.py`.

After adoption, run with the actual locked interpreter:

```sh
"$CORRECTION_TEST_PYTHON" -I -B -m pytest tests/test_catalytic_correction_release_v3.py -q
```

The complete repository suite and source/environment checks remain the owner's integration work.

## Actual preparation checks

Final `*_attempt3` receipts bind identical start/finish bytes for the three new preparation sources and the unchanged 233-file original source inventory. Unittest passed 33 tests. Pytest collected/passed exactly 33 tests and 17 subtests. Ruff `E,F,I,UP,B` (only line length ignored) passed; AST/compile checked three source bodies without executing them. The fresh child uses the same actual interpreter, privately imports only the pinned prepared stdlib sources, and checks that no scientific packages or public aliases were introduced.

Earlier actual successful checks are preserved. Three attempt2 wrapper errors are preserved as literal tool-result output in `retained_concurrent_check_wrapper_errors.json`, with the initial runner bytes in `preserved_initial_check_runner.txt`. Its global temporary-folder postcheck observed another concurrent fictional test's folder; it did not retain the affected child's raw output, so no successful child exit is claimed for those three attempts. The final runner isolates scratch by check prefix and installs raw stdout/stderr before postchecks. All final owned scratch fixtures were removed.

This receipt certifies bounded engineering preparation only. Actual scientific reviews, plans, production, selected reproduction, visual review, source recapture, fresh receiving verification, packaging and publication remain unassessed by these tests.
