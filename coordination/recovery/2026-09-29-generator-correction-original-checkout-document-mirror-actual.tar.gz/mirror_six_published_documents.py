"""Copy six backed-up disjoint published documents; perform no old Git operation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
OLD = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
NEW = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
TARGETS = ('coordination/HANDOFF.md', 'coordination/JOURNAL.md', 'coordination/TODO.md',
           'docs/catalytic_correction_execution.md', 'docs/code_guide.md', 'docs/ravi_handoff.md')


def binding(path):
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(name, data):
    with (BASE / name).open('x') as handle:
        json.dump(data, handle, sort_keys=True, indent=2)
        handle.write('\n')


def stamp():
    return datetime.now(timezone.utc).isoformat()


def resident_git(name, arguments):
    argv = ['git', *arguments]
    started = stamp()
    child = subprocess.run(argv, cwd=NEW, capture_output=True, check=False)
    for suffix, raw in [('stdout.log', child.stdout), ('stderr.log', child.stderr)]:
        with (BASE / (name + '.' + suffix)).open('xb') as handle:
            handle.write(raw)
    write(name + '.invocation.json', {
        'argv': argv, 'cwd': str(NEW), 'started_at_utc': started, 'finished_at_utc': stamp(),
        'actual_subprocess_returncode': child.returncode,
        'stdout_sha256': hashlib.sha256(child.stdout).hexdigest(),
        'stderr_sha256': hashlib.sha256(child.stderr).hexdigest(),
        'old_repository_git_operation': False,
    })
    assert child.returncode == 0
    return child.stdout


def ordinary_document_path(relative):
    path = OLD / relative
    assert path.resolve(strict=True) == path and path.is_file()
    for node in [path, *path.parents]:
        assert not node.is_symlink(), node
    assert path.is_relative_to(OLD) and path.parent.name in ('coordination', 'docs')
    return path


def admin_paths():
    common = OLD / '.git'
    paths = [common / name for name in ('HEAD', 'index', 'config', 'refs/heads/main')]
    # Use the exact four roots from the sealed topology rather than guessed names.
    topology = json.loads((ROOT / 'original_checkout_execution_dependency_audit_20260929_v1/git_path_topology.json').read_text())
    assert isinstance(topology, list) and len(topology) == 5
    rows = [row for row in topology if row['is_file']]
    assert {row['label'] for row in rows} == {'source119', 'analysis855', 'transfer2b701', 'correction_d332013'}
    codes = [Path(row['root']) for row in rows]
    assert len(codes) == 4
    for code in codes:
        pointer = code / '.git'
        text = pointer.read_text().strip()
        assert text.startswith('gitdir: ')
        admin = Path(text[8:])
        if not admin.is_absolute():
            admin = pointer.parent / admin
        assert (admin / 'commondir').read_text().strip() == '../..'
        assert (admin / '../..').resolve() == common
        paths.extend([pointer, admin / 'HEAD', admin / 'index', admin / 'commondir', admin / 'gitdir'])
    assert len(paths) == len(set(paths))
    return paths


def main():
    push = json.loads((ROOT / 'checkout_preservation_actual_push_20260929_v1/verified_push.json').read_text())
    assert push['local_head'] == push['remote_main_head'] == '023406135ab2a24d0cce912f74f9a3d138e7fa5f'
    assert resident_git('resident_head', ['rev-parse', 'HEAD']).decode().strip() == push['remote_main_head']
    preservation = ROOT / 'original_checkout_preservation_root_20260929_v1'
    assert binding(preservation / 'receipt.json')['sha256'] == 'adc0612217708634401cc1464cc17f2bbeb7da8f9678f69930be58d636020460'
    inventory = json.loads((preservation / 'original_local_state_before.json').read_text())['complete_scoped_file_inventory']
    assert len(inventory) == 141
    for name, expected in inventory.items():
        assert binding(OLD / name) == expected
        assert binding(preservation / 'original_local_state' / name) == expected
    published = {}
    for i, name in enumerate(TARGETS, 1):
        ordinary_document_path(name)
        raw = resident_git('published_document_' + str(i), ['show', push['remote_main_head'] + ':' + name])
        assert raw == (NEW / name).read_bytes()
        published[name] = raw
    admin = admin_paths()
    admin_before = {str(path): binding(path) for path in admin}
    write('before.json', {'observed_at_utc': stamp(), 'targets': {name: binding(OLD / name) for name in TARGETS},
                         'scoped_original_non_target_files': {name: value for name, value in inventory.items() if name not in TARGETS},
                         'selected_shared_git_admin_metadata': admin_before,
                         'published_document_sha256': {name: hashlib.sha256(raw).hexdigest() for name, raw in published.items()},
                         'remote_verified_main': push['remote_main_head'], 'scientific_execution_approval': False})
    # No directory copy, rename, source write, repository command or owner action.
    for name, raw in published.items():
        path = ordinary_document_path(name)
        assert binding(path) == inventory[name]
        with path.open('wb') as handle:
            handle.write(raw)
            handle.flush()
            __import__('os').fsync(handle.fileno())
        assert path.read_bytes() == raw
    assert {str(path): binding(path) for path in admin} == admin_before
    assert all(binding(OLD / name) == expected for name, expected in inventory.items() if name not in TARGETS)
    assert all(binding(preservation / 'original_local_state' / name) == expected for name, expected in inventory.items())
    source = json.loads((ROOT / 'correction_release_v3_integration_validation_v1/make_test.tested_source_after.json').read_text())
    assert len(source) == 634 and {name: binding(NEW / name) for name in source} == source
    write('completed.json', {'status': 'six_published_documents_mirrored_to_original_ide_checkout',
                            'completed_at_utc': stamp(), 'remote_verified_main': push['remote_main_head'],
                            'document_count': len(TARGETS), 'targets': {name: binding(OLD / name) for name in TARGETS},
                            'all_target_bytes_equal_published_main': True, 'all135_scoped_non_target_files_unchanged': True,
                            'all141_prior_versions_remain_preserved': True,
                            'selected_shared_git_admin_metadata_before_after_unchanged': True,
                            'resident634_implementation_files_unchanged': True,
                            'old_git_stash_fetch_merge_reset_or_staging_performed': False,
                            'source_data_results_or_numerical_owners_modified': False,
                            'general_original_checkout_git_synchronization_deferred': True,
                            'numerical_programme_or_release_completed': False})
    artifacts = {str(path.relative_to(BASE)): binding(path) for path in sorted(BASE.rglob('*')) if path.is_file()}
    write('receipt.json', {'schema_version': 1, 'sealed_at_utc': stamp(), 'artifacts': artifacts,
                          'status': 'six_document_only_mirror_records_sealed', 'scientific_approval_created': False})
    print(json.dumps({'status': 'six_published_documents_mirrored', 'receipt_sha256': binding(BASE / 'receipt.json')['sha256']}))


if __name__ == '__main__':
    main()
