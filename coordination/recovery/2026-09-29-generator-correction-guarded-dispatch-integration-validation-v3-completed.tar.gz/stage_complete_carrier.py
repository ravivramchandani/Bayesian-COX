"""Stage the entire reviewed carrier, including historically ignored logs."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).absolute().parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
CARRIER = REPO / 'scripts/catalytic_correction/guarded_dispatch'


def binding(path):
    assert path.is_file() and not any(p.is_symlink() for p in (path, *path.parents))
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def run(label, arguments):
    argv = ['git', *arguments]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (HERE / (label + '.stdout.log')).open('xb') as out, (HERE / (label + '.stderr.log')).open('xb') as err:
        returned = subprocess.run(argv, cwd=REPO, stdout=out, stderr=err, check=False)
    record = {'argv': argv, 'cwd': str(REPO), 'started_at_utc': started,
              'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'actual_exit_code': returned.returncode, 'helper': binding(Path(__file__).absolute()),
              'raw_stdout': binding(HERE / (label + '.stdout.log')), 'raw_stderr': binding(HERE / (label + '.stderr.log'))}
    with (HERE / (label + '.invocation.json')).open('x') as stream:
        json.dump(record, stream, sort_keys=True, indent=2)
        stream.write('\n')
    assert type(returned.returncode) is int and returned.returncode == 0
    return (HERE / (label + '.stdout.log')).read_text()


assert run('stage_before_index', ['diff', '--cached', '--name-only']).strip() == ''
assert run('stage_before_head', ['rev-parse', 'HEAD']).strip() == 'a26d5a2646b35380b8565e211ece6d36278ec3be'
assert binding(CARRIER / 'preparation_receipt.json')['sha256'] == '65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a'
receipt = json.loads((CARRIER / 'preparation_receipt.json').read_text())
expected = {**receipt['artifacts'], 'preparation_receipt.json': binding(CARRIER / 'preparation_receipt.json')}
assert len(expected) == 116 and {str(p.relative_to(CARRIER)): binding(p) for p in CARRIER.rglob('*') if p.is_file()} == expected
prefix = str(CARRIER.relative_to(REPO)) + '/'
paths = sorted([*[prefix + name for name in expected], 'tests/guarded_dispatch_repository_adapter.py', 'tests/test_catalytic_correction_guarded_dispatch.py'])
run('stage_complete_reviewed_carrier', ['add', '-f', '--', *paths])
actual = run('stage_after_index', ['diff', '--cached', '--name-only']).splitlines()
assert sorted(actual) == paths and len(actual) == 118
tracked = run('stage_carrier_roster', ['ls-files', '--', str(CARRIER.relative_to(REPO))]).splitlines()
assert sorted(tracked) == sorted(prefix + name for name in expected)
result = {'status': 'complete116_carrier_and2_tests_staged_before_validation',
          'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'staged_paths': paths, 'all116_carrier_bytes_and_complete_Git_roster_verified': True,
          'ignored_raw_logs_explicitly_included': True, 'scientific_approval_or_execution': False}
with (HERE / 'staged_complete_carrier.json').open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in result.items() if key != 'staged_paths'}, sort_keys=True))
