"""Install root-selected engineering bytes exclusively; create no scientific approval."""

from __future__ import annotations

import argparse
import ast
import datetime
import hashlib
import json
import re
from pathlib import Path
from typing import Any

REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = Path(__file__).absolute().parent
TEST_FILES = ('guarded_dispatch_repository_adapter.py', 'test_catalytic_correction_guarded_dispatch.py')


def safe(path: Path) -> Path:
    assert path.is_absolute() and '..' not in path.parts
    assert not any(node.is_symlink() for node in (path, *path.parents)), path
    return path


def binding(path: Path) -> dict[str, Any]:
    safe(path)
    assert path.is_file()
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def inventory(root: Path) -> dict[str, Any]:
    safe(root)
    assert root.is_dir()
    files, directories = {}, []
    for path in sorted(root.rglob('*')):
        safe(path)
        relative = str(path.relative_to(root))
        if path.is_dir():
            directories.append(relative)
        else:
            files[relative] = binding(path)
    return {'files': files, 'directories': directories}


def preparation(root: Path, pin: str) -> tuple[dict[str, Any], dict[str, Any]]:
    assert re.fullmatch('[0-9a-f]{64}', pin)
    receipt = root / 'preparation_receipt.json'
    assert binding(receipt)['sha256'] == pin
    value = json.loads(receipt.read_text())
    assert value['content_sha256'] == digest({k: v for k, v in value.items() if k != 'content_sha256'})
    expected = {**value['artifacts'], receipt.name: binding(receipt)}
    actual = inventory(root)
    assert actual['files'] == expected
    if 'artifact_directories' in value:
        assert actual['directories'] == value['artifact_directories']
    return value, actual


def copy_new(source: Path, target: Path, expected: dict[str, Any]) -> None:
    assert binding(source) == expected
    safe(target)
    with target.open('xb') as handle:
        handle.write(source.read_bytes())
    assert binding(source) == binding(target) == expected


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--carrier', type=Path, required=True)
    parser.add_argument('--carrier-sha256', required=True)
    parser.add_argument('--test-preparation', type=Path, required=True)
    parser.add_argument('--test-preparation-sha256', required=True)
    args = parser.parse_args()
    carrier, carrier_before = preparation(args.carrier, args.carrier_sha256)
    adapter, adapter_before = preparation(args.test_preparation, args.test_preparation_sha256)
    assert carrier['status'] == 'guarded_dispatch_preparation_sealed'
    assert carrier['implementation_preparation_version'] == 3
    assert carrier['actual_controller_or_scientific_dispatch'] is False
    assert carrier['actual_root_reviews_selection_freeze_adoption_or_approvals_created'] is False
    adapter_source = args.test_preparation / TEST_FILES[0]
    constants = {}
    for node in ast.parse(adapter_source.read_bytes()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in {'PREPARATION_SHA', 'SOURCE_SHA', 'CARRIER_MEMBERS', 'BOUND_ARTIFACTS'}:
                constants[node.targets[0].id] = ast.literal_eval(node.value)
    assert constants['PREPARATION_SHA'] == args.carrier_sha256
    assert constants['SOURCE_SHA'] == carrier['runtime_source_sha256']
    assert constants['CARRIER_MEMBERS'] == len(carrier_before['files'])
    assert constants['BOUND_ARTIFACTS'] == len(carrier['artifacts'])
    reference = BASE / 'correction_release_v3_integration_validation_v1/make_test.tested_source_after.json'
    old = json.loads(reference.read_text())
    assert len(old) == 634 and {key: binding(REPO / key) for key in old} == old
    target = REPO / 'scripts/catalytic_correction/guarded_dispatch'
    assert not target.exists() and target.parent.is_dir()
    assert all(not (REPO / 'tests' / name).exists() for name in TEST_FILES)
    target.mkdir()
    for name in carrier_before['directories']:
        (target / name).mkdir()
    for name, expected in carrier_before['files'].items():
        copy_new(args.carrier / name, target / name, expected)
    for name in TEST_FILES:
        copy_new(args.test_preparation / name, REPO / 'tests' / name, adapter['artifacts'][name])
    assert inventory(target) == carrier_before
    assert inventory(args.carrier) == carrier_before and inventory(args.test_preparation) == adapter_before
    assert {key: binding(REPO / key) for key in old} == old
    record = {'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'status': 'reviewed_engineering_bytes_installed_before_repository_validation',
              'carrier_preparation_sha256': args.carrier_sha256,
              'adapter_preparation_sha256': args.test_preparation_sha256,
              'carrier_files': len(carrier_before['files']), 'carrier_directories': carrier_before['directories'],
              'installed_test_sources': {name: binding(REPO / 'tests' / name) for name in TEST_FILES},
              'all634_prior_implementation_files_unchanged': True,
              'complete_carrier_source_copy_before_after_equal': True,
              'engineering_integration_tested_or_adopted': False,
              'scientific_review_freeze_selection_dispatch_or_release_approval': False}
    with (HERE / 'installed_before_validation.json').open('x') as stream:
        json.dump(record, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps(record, sort_keys=True))


if __name__ == '__main__':
    main()
