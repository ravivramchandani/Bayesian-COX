"""Verify sealed engineering evidence without importing experimental code."""

from __future__ import annotations

import ast
import datetime
import hashlib
import json
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = Path(__file__).absolute().parent
CARRIER = BASE / 'generator_correction_guarded_dispatch_v3'
REVIEW = BASE / 'generator_correction_guarded_dispatch_independent_review_v3'
V2 = BASE / 'generator_correction_guarded_dispatch_v2'
V2_REVIEW = BASE / 'generator_correction_guarded_dispatch_independent_review_v2'


def binding(path):
    assert path.is_absolute() and '..' not in path.parts
    assert not any(item.is_symlink() for item in (path, *path.parents))
    assert path.is_file(), path
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def read(path):
    value = json.loads(path.read_text())
    if 'content_sha256' in value:
        assert value['content_sha256'] == digest({k: v for k, v in value.items() if k != 'content_sha256'}), path
    return value


def sealed(root, filename, pin, count):
    path = root / filename
    assert binding(path)['sha256'] == pin
    value = read(path)
    files = {str(p.relative_to(root)): binding(p) for p in root.rglob('*') if p.is_file()}
    directories = sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_dir())
    assert files == {**value['artifacts'], filename: binding(path)} and len(files) == count
    assert directories == value['artifact_directories']
    return value, files, directories


def methods(path):
    return {node.name: hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
            for node in ast.walk(ast.parse(path.read_bytes()))
            if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}


carrier, files, directories = sealed(CARRIER, 'preparation_receipt.json', '65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a', 116)
review, _, _ = sealed(REVIEW, 'receipt.json', 'a97d6a2b4c5f940141f9dc6d797b5ed6296c63e130b8294874c5c5e67b2e2e3d', 15)
old, oldfiles, olddirs = sealed(V2, 'preparation_receipt.json', '46a95785348e9f54379178caaf728fd863cccef3d133b2f5a3c8116aa5d9e9cc', 79)
_, oldreview, _ = sealed(V2_REVIEW, 'receipt.json', '459403799a2ce70aebb805ddfd0b0a706fd8a1db69776f596884bf44adea5c06', 15)
assert {name: binding(CARRIER / 'preserved_v2' / name) for name in oldfiles} == oldfiles
assert {name: binding(CARRIER / 'preserved_v2_review' / name) for name in oldreview} == oldreview
assert directories == ['preserved_v2', *['preserved_v2/' + name for name in olddirs], 'preserved_v2_review']
source = read(CARRIER / 'source_preservation_receipt.json')
assert source['old20_before'] == source['old20_after'] == carrier['original20_sources_after'] == old['original20_sources_after']
assert len(source['old20_before']) == 20
assert {name: binding(Path(name)) for name in source['old20_before']} == source['old20_before']
classifier = source['old_classifier']
assert binding(Path(classifier['path'])) == classifier['binding'] == carrier['old_classifier_binding']['binding']
assert classifier['binding']['sha256'] == '83cb84002cd9dc447f70d9346baaba16197fa04d5a43e8b2fb500c2ce38f7fef'
for name in ('capture_guarded_dispatch.py', 'verify_guarded_dispatch_proof.py', 'source_bindings.json', 'test_guarded_dispatch.py', 'test_guarded_dispatch_regressions.py'):
    assert binding(CARRIER / name) == binding(V2 / name)
for name, evidence in carrier['retained34_method_surface'].items():
    assert binding(CARRIER / name) == evidence['binding'] and methods(CARRIER / name) == methods(V2 / name) == evidence['method_ASTs']
assert sum(len(item['method_ASTs']) for item in carrier['retained34_method_surface'].values()) == 34
assert methods(CARRIER / 'test_guarded_dispatch_reuse_consistency.py') == carrier['new_consistency_method_ASTs']
assert len(carrier['new_consistency_method_ASTs']) == 7
assert {name: binding(CARRIER / name)['sha256'] for name in carrier['runtime_source_sha256']} == carrier['runtime_source_sha256']
oldtext = (V2 / 'guard_fit_dispatch.py').read_text()
null_rule = '    require(decision["tuning_record_reused_sha256"] is None, "no-fit account decision cannot reuse fitting-stage tuning")\n'
reuse_rule = '                and decision["missing_roles"] == [] and decision["changed_roles"] == [] and decision["generator_failures"] == {}\n'
expected = oldtext.replace('    if terminal:\n        require(decision["action"] == "retain_input_failure"', null_rule + '    if terminal:\n        require(decision["action"] == "retain_input_failure"', 1)
expected = expected.replace('        require(value["operation"] == decision["action"] == "reuse_original_outcome" and source is not None\n', '        require(value["operation"] == decision["action"] == "reuse_original_outcome" and source is not None\n' + reuse_rule, 1)
assert (CARRIER / 'guard_fit_dispatch.py').read_text() == expected and expected != oldtext
assert [name for name in source['production_function_AST_before'] if source['production_function_AST_before'][name] != source['production_function_AST_after'][name]] == ['account_cell']
checks = {}
for label in ('unit_attempt1', 'ruff_attempt1', 'compile_attempt1'):
    capture = read(CARRIER / (label + '.invocation.json'))
    assert type(capture['exit_code']) is int and capture['exit_code'] == 0
    assert capture['source_start'] == capture['source_finish'] and len(capture['source_finish']) == 7
    assert {name: binding(CARRIER / name) for name in capture['source_finish']} == capture['source_finish']
    assert capture['actual_numerical_or_guarded_controller_dispatch'] is False
    for suffix in ('stdout', 'stderr'):
        assert binding(CARRIER / (label + '.' + suffix + '.log')) == capture['raw_' + suffix]
    checks[label] = {'invocation': binding(CARRIER / (label + '.invocation.json')), 'actual_exit_code': capture['exit_code']}
assert 'Ran 41 tests' in (CARRIER / 'unit_attempt1.stderr.log').read_text()
final = read(REVIEW / 'final_verification.json')
observed = final['source_before']
assert len(observed) == 232 and observed == final['source_after']
assert {name: binding(Path(name)) for name in observed} == observed
for label in ('unit', 'consistency_probe'):
    capture = read(REVIEW / (label + '.invocation.json'))
    assert type(capture['exit_code']) is int and capture['exit_code'] == 0
    assert capture['source_before'] == capture['source_after'] == observed
    assert capture['actual_real_controller_scientific_or_checker_dispatch'] is False
    assert all(v == '1' for v in capture['numeric_thread_environment'].values())
    for suffix in ('stdout', 'stderr'):
        assert binding(REVIEW / (label + '.' + suffix + '.log')) == capture['raw_' + suffix]
assert 'Ran 41 tests' in (REVIEW / 'unit.stderr.log').read_text()
probe = read(REVIEW / 'consistency_probe.stdout.log')
assert probe['fictional_only'] and probe['actual_controller_scientific_or_checker_calls'] == 0
assert len(probe['results']) == 9 and all(row['expectation_met'] and row['accepted'] is row['expected_acceptance'] for row in probe['results'])
assert sum(row['accepted'] is False for row in probe['results']) == 5
for item in read(REVIEW / 'source_evidence.json')['evidence']:
    path = Path(item['path'])
    assert binding(path) == {key: item[key] for key in ('sha256', 'bytes')}
    lines = path.read_text().splitlines()
    assert all(lines[row['line'] - 1] == row['text'] for row in item['lines'])
result = {'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'root_reviewed_v3_engineering_preparation_ready_for_portable_integration',
          'carrier_receipt': binding(CARRIER / 'preparation_receipt.json'),
          'independent_review_receipt': binding(REVIEW / 'receipt.json'),
          'complete_carrier_files': len(files), 'complete_carrier_directories': directories,
          'all20_original_pins_and_classifier_unchanged': True, 'whole79_v2_and15_review_preserved': True,
          'retained34_source_and_method_ASTs_unchanged': True, 'separate7_new_methods': True,
          'production_delta_exactly_two_account_cell_requirements': True,
          'producer_actual_checks': checks, 'independent41_methods_and9_cases_actual0': True,
          'independent_all232_inputs_unchanged': True,
          'root_read_scope': ['prior_entire_v2_runtime_and_34_tests', 'entire_v3_runtime_delta', 'all7_v3_tests', 'interface_contract_delta', 'producer_capture_controls_and_final_raws', 'complete_independent_report_capture_and_probe_controls', 'independent_sealing_controls_and_source_line_evidence'],
          'read_only_path_errors_corrected': [{'requested': 'test_guarded_dispatch_consistency.py', 'actual': 'test_guarded_dispatch_reuse_consistency.py'}, {'requested_root_parent': '/Users/macuser/bayes-cox-runs', 'actual_parent': str(BASE)}],
          'engineering_integration_tested_or_adopted': False,
          'scientific_reviews_freeze_selection_dispatch_or_release_approval': False}
with (HERE / 'v3_root_preparation_review.json').open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(result, sort_keys=True))
