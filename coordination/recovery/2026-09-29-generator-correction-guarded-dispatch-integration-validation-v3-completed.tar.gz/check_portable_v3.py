"""Recheck portable adapter bindings without importing the fixtures."""
import ast
import datetime
import json
from pathlib import Path

from install_sealed_preparations import binding, preparation

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = Path(__file__).absolute().parent
ADAPTER = BASE / 'generator_correction_guarded_dispatch_repository_test_adapter_v2'
OLD = BASE / 'generator_correction_guarded_dispatch_repository_test_adapter_v1'
CARRIER = BASE / 'generator_correction_guarded_dispatch_v3'


def nodes(path):
    output = {}
    for node in ast.parse(path.read_bytes()).body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            output[node.name] = ast.dump(node, include_attributes=False)
            if isinstance(node, ast.ClassDef):
                for child in node.body:
                    if isinstance(child, ast.FunctionDef):
                        output[node.name + '.' + child.name] = ast.dump(child, include_attributes=False)
    return output


value, inventory = preparation(ADAPTER, 'cbe9759f9ff529c57555d57a26f2c5a2fabb050d5f6c58a8f292190c86dc6257')
_, old_inventory = preparation(OLD, 'a1ae7162f038e30e1073bbe38492183715be51ee1b36c4f421720a809c0061ab')
_, carrier_inventory = preparation(CARRIER, '65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a')
assert len(inventory['files']) == 251 and len(inventory['directories']) == 9
for subdir, original in [('preserved_v2_adapter', old_inventory), ('sealed_guard_v3', carrier_inventory)]:
    assert {name: binding(ADAPTER / subdir / name) for name in original['files']} == original['files']
    assert sorted(str(p.relative_to(ADAPTER / subdir)) for p in (ADAPTER / subdir).rglob('*') if p.is_dir()) == original['directories']
assert value['retained_method_count'] == 41 and value['adapter_specific_method_count'] == 1
assert value['actual_unittest_count'] == value['actual_pytest_count'] == 42 and value['actual_pytest_subtest_count'] == 136
assert value['production_guard_adopted'] is False and value['programme_or_release_certified'] is False
assert value['main_original_or_sealed_sources_mutated'] is False
helper = 'guarded_dispatch_repository_adapter.py'
old_nodes, new_nodes = nodes(OLD / helper), nodes(ADAPTER / helper)
delta = json.loads((ADAPTER / 'adapter_delta.json').read_text())
for name in delta['unchanged_scope_boundary_ASTs']:
    assert old_nodes[name] == new_nodes[name], name
assert binding(OLD / 'capture_adapter_checks.py') == binding(ADAPTER / 'capture_adapter_checks.py')
checks = {}
for label in value['actual_check_evidence']:
    capture = json.loads((ADAPTER / (label + '.invocation.json')).read_text())
    assert type(capture['returncode']) is int and capture['returncode'] == 0
    assert capture['source_before'] == capture['source_after'] and capture['source_unchanged'] is True
    assert {name: binding(Path(name)) for name in capture['source_after']} == capture['source_after']
    assert capture['scratch_before'] == capture['scratch_after'] == {'files': {}, 'directories': []}
    assert capture['owned_fixture_cleanup_complete'] is True and capture['carrier_unchanged'] is True
    assert capture['actual_controller_scientific_or_original_owner_invoked'] is False
    assert all(item == '1' for item in capture['numeric_environment'].values())
    for stream in ('stdout', 'stderr'):
        assert binding(ADAPTER / (label + '.' + stream + '.log')) == capture['raw_logs'][stream]
    checks[label] = {'invocation': binding(ADAPTER / (label + '.invocation.json')), 'actual_exit_code': capture['returncode']}
assert '42 passed, 136 subtests passed' in (ADAPTER / 'actual_v3_pytest_1.stdout.log').read_text()
result = {'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'root_reviewed_portable_v3_preparation_before_integration',
          'adapter_receipt': binding(ADAPTER / 'preparation_receipt.json'),
          'complete_files': 251, 'complete_directories': 9,
          'whole111_previous_adapter_and116_carrier_exact': True,
          'all9_isolation_and_cleanup_boundary_ASTs_unchanged': True,
          'retained41_methods_once_plus1_adapter_guard': True,
          'root_read_exact_binding_and_5_function_deltas_and_expanded_guard': True,
          'actual_final_checks': checks,
          'engineering_integration_tested_or_adopted': False,
          'scientific_review_freeze_selection_dispatch_or_release_approval': False}
with (HERE / 'v3_root_portable_review.json').open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(result, sort_keys=True))
