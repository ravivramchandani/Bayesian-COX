"""Verify actual engineering results and archive exact reviewed evidence."""
import datetime
import importlib.util
import json
import re
from pathlib import Path

from install_sealed_preparations import binding, digest, inventory, preparation

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = Path(__file__).absolute().parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')


def read(path):
    value = json.loads(path.read_text())
    if 'content_sha256' in value:
        assert value['content_sha256'] == digest({k: v for k, v in value.items() if k != 'content_sha256'})
    return value


def full(root, receipt_name, pin, count, directories):
    receipt = root / receipt_name
    assert binding(receipt)['sha256'] == pin
    value = read(receipt)
    actual = inventory(root)
    assert actual['files'] == {**value['artifacts'], receipt_name: binding(receipt)}
    assert len(actual['files']) == count and actual['directories'] == directories
    return value


def checked_capture(label):
    value = read(HERE / (label + '.invocation.json'))
    assert type(value['exit_code']) is int and value['exit_code'] == 0
    before = read(HERE / (label + '.tested_source_before.json'))
    after = read(HERE / (label + '.tested_source_after.json'))
    assert before == after and value['tested_source_before_equals_after'] is True
    assert {key: binding(REPO / key) for key in after} == after
    for stream in ('stdout', 'stderr'):
        raw = binding(HERE / (label + '.' + stream + '.log'))
        assert raw == {k: value['logs'][stream][k] for k in ('sha256', 'bytes')}
    return value, after


runtime, copied = preparation(BASE / 'generator_correction_guarded_dispatch_v3', '65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a')
assert inventory(REPO / 'scripts/catalytic_correction/guarded_dispatch') == copied
adapter, _ = preparation(BASE / 'generator_correction_guarded_dispatch_repository_test_adapter_v2', 'cbe9759f9ff529c57555d57a26f2c5a2fabb050d5f6c58a8f292190c86dc6257')
for name in ('guarded_dispatch_repository_adapter.py', 'test_catalytic_correction_guarded_dispatch.py'):
    assert binding(REPO / 'tests' / name) == adapter['artifacts'][name]
peer_path = BASE / 'generator_correction_guarded_dispatch_repository_test_adapter_review_v2'
full(peer_path, 'receipt.json', '7d2b1245926222d7687e6323a4283640a6dec38dd7e9e46bc0f48896f1a26360', 10, [])
peer = read(peer_path / 'validation.json')
assert peer['source_before'] == peer['source_after'] and len(peer['source_before']) == 497
assert {path: binding(Path(path)) for path in peer['source_after']} == peer['source_after']
for item in read(peer_path / 'source_evidence.json')['evidence']:
    path = Path(item['path'])
    assert binding(path) == {key: item[key] for key in ('bytes', 'sha256')}
    lines = path.read_text().splitlines()
    assert all(lines[row['line'] - 1] == row['text'] for row in item['lines'])
clarifier_path = BASE / 'generator_correction_guarded_dispatch_adapter_ast_convention_clarification_v1'
full(clarifier_path, 'receipt.json', '2f157282a8cb7746936604c2ece2d66b54cc6be1ad5bd458e8a11653130370ab', 12, [])
for label, match in (('locked311', False), ('python314', True)):
    capture = read(clarifier_path / (label + '.invocation.json'))
    observation = read(clarifier_path / (label + '.stdout.json'))
    assert type(capture['actual_returncode']) is int and capture['actual_returncode'] == 0
    assert capture['stdout'] == binding(clarifier_path / (label + '.stdout.json'))
    assert capture['stderr'] == binding(clarifier_path / (label + '.stderr.log'))
    assert observation['source_before'] == observation['source_after']
    assert observation['all_old_and_new_AST_strings_equal'] is True
    assert observation['all_declared_hashes_match_this_interpreter'] is match
    assert observation['target_import_or_execution'] is False
    for path, expected in observation['source_before'].items():
        assert binding(Path(path)) == expected
suite, tested = checked_capture('make_test')
focused, focused_sources = checked_capture('focused_portable')
ruff, ruff_sources = checked_capture('ruff')
assert tested == focused_sources == ruff_sources and len(tested) == 752
old = read(BASE / 'correction_release_v3_integration_validation_v1/make_test.tested_source_after.json')
assert len(old) == 634 and {key: tested[key] for key in old} == old
original = read(BASE / 'transfer_validation_v5_extension_documentation/tested_source.json')
assert len(original) == 157
assert all(binding(REPO / key)['sha256'] == (value['sha256'] if isinstance(value, dict) else value) for key, value in original.items())
text = (HERE / 'make_test.stdout.log').read_text()
summaries = [line for line in text.splitlines() if re.match(r'^=+\s+\d+ passed', line)]
assert len(summaries) == 1
summary = summaries[0]
tests = int(re.search(r'(\d+) passed', summary).group(1))
subtests = int(re.search(r'(\d+) subtests passed', summary).group(1))
assert tests == 1040 and subtests == 293
assert not re.search(r'\b(?:skipped|failed|xfailed|xpassed|error)\b', summary)
assert not re.search(r'\bSKIPPED\b', text)
assert '42 passed, 136 subtests passed' in (HERE / 'focused_portable.stdout.log').read_text()
spec = importlib.util.spec_from_file_location('_root_exact_archival_helper', BASE / 'correction_reporting_release_root_closeout_20260929_v1/preserve_checked_records.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.RECOVERY = REPO / 'coordination/recovery'
archives = {}
for name, owner, receipt, pin, count in (
    ('guarded-dispatch-preparation-v3', 'generator_correction_guarded_dispatch_v3', 'preparation_receipt.json', '65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a', 116),
    ('guarded-dispatch-independent-runtime-review-v3', 'generator_correction_guarded_dispatch_independent_review_v3', 'receipt.json', 'a97d6a2b4c5f940141f9dc6d797b5ed6296c63e130b8294874c5c5e67b2e2e3d', 15),
    ('guarded-dispatch-portable-adapter-v3', 'generator_correction_guarded_dispatch_repository_test_adapter_v2', 'preparation_receipt.json', 'cbe9759f9ff529c57555d57a26f2c5a2fabb050d5f6c58a8f292190c86dc6257', 251),
    ('guarded-dispatch-portable-adapter-independent-review-v3', 'generator_correction_guarded_dispatch_repository_test_adapter_review_v2', 'receipt.json', '7d2b1245926222d7687e6323a4283640a6dec38dd7e9e46bc0f48896f1a26360', 10),
    ('guarded-dispatch-adapter-ast-clarification', 'generator_correction_guarded_dispatch_adapter_ast_convention_clarification_v1', 'receipt.json', '2f157282a8cb7746936604c2ece2d66b54cc6be1ad5bd458e8a11653130370ab', 12),
    ('guarded-dispatch-documentation-proposal', 'generator_correction_guarded_dispatch_documentation_proposal_v1', 'proposal_receipt.json', '26f9423b8ef22a48d8508d3254cca730a22e7ff4c646d90e29e44953203e506d', 7),
):
    owner_path = BASE / owner
    receipt_value = read(owner_path / receipt)
    owner_inventory = inventory(owner_path)
    assert owner_inventory['files'] == {**receipt_value['artifacts'], receipt: binding(owner_path / receipt)}
    assert len(owner_inventory['files']) == count
    archives[name] = module.sealed(name, owner_path, receipt, pin)
    assert archives[name]['regular_members'] == count
record = {'schema_version': 1, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'root_reviewed_guarded_dispatch_v3_engineering_source_integrated_and_validated',
          'guard_engineering_source_adopted_by_root': True, 'complete_installed_carrier_files': 116,
          'complete_installed_carrier_directories': copied['directories'],
          'exact_runtime_source_sha256': runtime['runtime_source_sha256'],
          'full_locked_test': {'passed_tests': tests, 'passed_subtests': subtests, 'skips': 0, 'actual_exit_code': suite['exit_code'],
                               'finished_at_utc': suite['finished_at_utc'], 'tested_source_files': len(tested), 'source_before_equals_after': True,
                               'invocation': binding(HERE / 'make_test.invocation.json')},
          'focused_portable': {'passed_tests': 42, 'passed_subtests': 136, 'actual_exit_code': focused['exit_code']},
          'whole_repository_ruff_actual_exit_code': ruff['exit_code'],
          'all752_current_files_equal_successful_full_test_capture': True,
          'all634_previous_implementation_and157_original_files_unchanged': True,
          'old_scientific_pins_config_addendum_and_DECISIONS_unchanged': True,
          'all116_carrier_Git_paths_including_ignored_logs_staged_exact': True,
          'independent_runtime_review_receipt': binding(BASE / 'generator_correction_guarded_dispatch_independent_review_v3/receipt.json'),
          'independent_portable_review_receipt': binding(peer_path / 'receipt.json'),
          'portable_review_all497_inputs_unchanged': True,
          'metadata_AST_creation_interpreter_unknown_and_version_sensitive_clarification_retained': True,
          'two_peer_stopped_metadata_validation_attempts_retained_not_scientific_failures': True,
          'root_preparation_path_rc2_attempt_and_actual_retry0_retained': True,
          'source_installation_completed_before_final_portable_review_seal_no_science_or_adoption_until_review_complete': True,
          'numerical_owners_modified': False, 'all_old_failed_or_orphan_evidence_retained': True,
          'five_actual_scientific_execution_reviews_completed': False,
          'actual_corrected_freeze_ADR041_selection_scope_or_dispatch_adoption_completed': False,
          'actual_source_or_genuine_fresh_receiving_guard_semantics_completed': False,
          'corrected_programme_complete': False, 'private_release_or_fresh_restore_completed': False,
          'dated_metadata_checkpoint': read(HERE / 'dated_checkpoint_v3.stdout.log'),
          'new_archives': {key: {k: v for k, v in item.items() if k != 'members'} for key, item in archives.items()}}
with (HERE / 'integration_record.json').open('x') as stream:
    json.dump(record, stream, sort_keys=True, indent=2)
    stream.write('\n')
members = {str(p.relative_to(HERE)): p for p in sorted(HERE.rglob('*')) if p.is_file()}
assert not any(p.is_dir() for p in HERE.rglob('*'))
validation_archive = module.archive('guarded-dispatch-integration-validation-v3', members)
compact = {**record, 'integration_validation_archive': {k: v for k, v in validation_archive.items() if k != 'members'}}
target = REPO / 'coordination/recovery/2026-09-29-generator-correction-guarded-dispatch-integration-v3.json'
with target.open('x') as stream:
    json.dump(compact, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps({'status': record['status'], 'full_locked_test': record['full_locked_test'],
                  'new_archive_member_counts': {key: item['regular_members'] for key, item in archives.items()},
                  'integration_validation_members': validation_archive['regular_members'], 'compact_record': str(target)}, sort_keys=True))
