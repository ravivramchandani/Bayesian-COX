"""Capture the exclusive installation and its exact expected source delta."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).absolute().parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
BASE = HERE.parent
PYTHON = Path(sys.executable).resolve(strict=True)
argv = [str(PYTHON), '-I', '-B', str(HERE / 'install_sealed_preparations.py'),
        '--carrier', str(BASE / 'generator_correction_guarded_dispatch_v3'),
        '--carrier-sha256', '65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a',
        '--test-preparation', str(BASE / 'generator_correction_guarded_dispatch_repository_test_adapter_v2'),
        '--test-preparation-sha256', 'cbe9759f9ff529c57555d57a26f2c5a2fabb050d5f6c58a8f292190c86dc6257']
threads = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', **dict.fromkeys(threads, '1'))


def binding(path):
    assert path.is_file() and not any(p.is_symlink() for p in (path, *path.parents))
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def write(name, value):
    with (HERE / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


old = json.loads((BASE / 'correction_release_v3_integration_validation_v1/make_test.tested_source_after.json').read_text())
before = {key: binding(REPO / key) for key in old}
assert before == old and len(old) == 634
write('install.original634_before.json', before)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (HERE / 'install.stdout.log').open('xb') as stdout, (HERE / 'install.stderr.log').open('xb') as stderr:
    child = subprocess.Popen(argv, cwd=REPO, env=environment, stdout=stdout, stderr=stderr)
    write('install.launch.json', {'argv': argv, 'cwd': str(REPO), 'pid': child.pid, 'started_at_utc': started})
    returned = child.wait()
    assert type(returned) is int
after = {key: binding(REPO / key) for key in old}
write('install.original634_after.json', after)
record = {'argv': argv, 'cwd': str(REPO), 'started_at_utc': started,
          'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'actual_exit_code': returned, 'numeric_thread_environment': {key: environment[key] for key in threads},
          'capture_helper': binding(Path(__file__).absolute()), 'installer_source': binding(HERE / 'install_sealed_preparations.py'),
          'all634_original_source_bytes_unchanged': before == after == old,
          'raw_stdout': binding(HERE / 'install.stdout.log'), 'raw_stderr': binding(HERE / 'install.stderr.log'),
          'scientific_reviews_freeze_selection_dispatch_or_release_approval': False}
write('install.invocation.json', record)
print(json.dumps(record, sort_keys=True))
if returned:
    raise SystemExit(returned)
assert before == after == old
installed = json.loads((HERE / 'installed_before_validation.json').read_text())
assert installed['carrier_files'] == 116 and installed['engineering_integration_tested_or_adopted'] is False
