"""Prove that edits to Python files changed only comments and docstrings.

For every ``.py`` file that differs between a base git revision and the
working tree, both versions are parsed and their docstrings removed. The
remaining syntax trees must be identical. Comments never appear in the syntax
tree, so any difference means executable code changed.

Usage: python ast_equivalence.py <repo_root> <base_revision>
Exit status 0 means every changed file is documentation-only.
"""

from __future__ import annotations

import ast
import subprocess
import sys
from pathlib import Path


def strip_docstrings(tree: ast.AST) -> ast.AST:
    """Remove the leading string literal from every module, class and function body."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            body = node.body
            if (
                body
                and isinstance(body[0], ast.Expr)
                and isinstance(body[0].value, ast.Constant)
                and isinstance(body[0].value.value, str)
            ):
                body = body[1:]
            node.body = body or [ast.Pass()]
    return tree


def normalised_dump(source: str) -> str:
    return ast.dump(strip_docstrings(ast.parse(source)), include_attributes=False)


def main() -> int:
    root, base = Path(sys.argv[1]).resolve(), sys.argv[2]
    changed = subprocess.run(
        ["git", "diff", "--name-only", base, "--", "*.py"],
        cwd=root, check=True, capture_output=True, text=True,
    ).stdout.split()
    failures = []
    for name in changed:
        path = root / name
        old = subprocess.run(["git", "show", f"{base}:{name}"], cwd=root, capture_output=True, text=True)
        if old.returncode != 0 or not path.exists():
            failures.append(f"{name}: added or deleted (not documentation-only)")
            continue
        if normalised_dump(old.stdout) != normalised_dump(path.read_text(encoding="utf-8")):
            failures.append(f"{name}: executable code differs")
    print(f"{len(changed)} changed Python files; {len(changed) - len(failures)} documentation-only")
    for failure in failures:
        print("FAIL", failure)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
