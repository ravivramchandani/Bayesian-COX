"""Record exact source bindings and the required documentation integration gates."""

from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
HOME = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
PYTHON = '/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python'
OUTPUT = HOME / 'transfer_validation_v5_extension_documentation'
PREVIOUS = HOME / 'transfer_validation_v4_documentation/tested_source.json'


def digest(path: Path) -> str:
    """Hash the exact bytes of one retained file."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    """Create one receipt without replacing earlier evidence."""
    with path.open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')


def source_hashes() -> dict[str, str]:
    """Bind the full previously tested source/build/lock scope."""
    names = sorted(json.loads(PREVIOUS.read_text()))
    return {name: digest(ROOT / name) for name in names}


def main() -> int:
    """Run the integration gates and reject any concurrent source change."""
    OUTPUT.mkdir()
    before = source_hashes()
    write_json(OUTPUT / 'tested_source.json', before)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    checks = [
        ('ast_extension_base', [PYTHON, '/Users/macuser/bayes-cox-runs/harness/ast_equivalence.py',
                                '.', 'b4300fcff3fb756a4684b99a28958107792704a1']),
        ('ast_baseline_base', [PYTHON, '/Users/macuser/bayes-cox-runs/harness/ast_equivalence.py',
                               '.', '0ba4c3d3a73e7b5d46830787517764d33dfb6b16']),
        ('full_tests', ['make', 'test', f'PYTHON={PYTHON}']),
        ('schemas', [PYTHON, 'tests/test_coordination_schemas.py']),
        ('ruff', [PYTHON, '-m', 'ruff', 'check', '.']),
        ('diff_check', ['git', 'diff', '--check']),
    ]
    results = {}
    for name, command in checks:
        started = time.monotonic()
        with (OUTPUT / f'{name}.log').open('x', encoding='utf-8') as handle:
            completed = subprocess.run(command, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT)
        results[name] = {'command': command, 'exit_code': completed.returncode,
                         'seconds': round(time.monotonic() - started, 3)}
        print(json.dumps({'check': name, **results[name]}), flush=True)
    after = source_hashes()
    changed = [name for name in before if before[name] != after[name]]
    missing_docs, nodes = [], 0
    for name in before:
        if not name.endswith('.py'):
            continue
        tree = ast.parse((ROOT / name).read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                nodes += 1
                if ast.get_docstring(node) is None:
                    missing_docs.append({'path': name, 'line': getattr(node, 'lineno', 1),
                                         'name': getattr(node, 'name', '<module>')})
    frozen = []
    for path, expected in [
        ('/Users/macuser/bayes-cox-runs/extensions-code-20260928-119476f',
         '119476fef55b1eeb690527f234c1423440720d45'),
        ('/Users/macuser/bayes-cox-runs/extensions-analysis-code-20260928-8551d32',
         '8551d326b02bfe88915cfd9eb50c6ca8e5690e3a'),
    ]:
        observed = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=path, text=True).strip()
        status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=path, text=True)
        frozen.append({'path': path, 'expected_commit': expected, 'observed_commit': observed,
                       'clean': not status, 'status': status})
    passed = (not changed and not missing_docs and all(c['exit_code'] == 0 for c in results.values())
              and all(f['clean'] and f['expected_commit'] == f['observed_commit'] for f in frozen))
    receipt = {
        'schema_version': 1,
        'verified_utc': datetime.now(timezone.utc).isoformat(),
        'source_head_before_checks': head,
        'tested_source_files': len(before),
        'source_unchanged': not changed,
        'concurrently_changed_source': changed,
        'documented_module_class_function_nodes': nodes,
        'missing_docstrings': missing_docs,
        'checks': results,
        'frozen_checkouts': frozen,
        'documentation_integration': 'passed' if passed else 'failed',
        'scientific_programme': 'complete_grid_and_downstream_gates_pending',
        'artifact_sha256': {p.name: digest(p) for p in sorted(OUTPUT.iterdir()) if p.is_file()},
        'driver_sha256': digest(Path(__file__)),
    }
    write_json(OUTPUT / 'validation.json', receipt)
    print(json.dumps({key: receipt[key] for key in ['documentation_integration', 'tested_source_files',
                      'source_unchanged', 'documented_module_class_function_nodes', 'missing_docstrings']}), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
