"""Preserve the fifth source-bound documentation gate and its independent reviews."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
HOME = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
VALIDATION = HOME / 'transfer_validation_v5_extension_documentation'
RECOVERY = ROOT / 'coordination/recovery'


def sha(data: bytes) -> str:
    """Hash exact retained bytes."""
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    """Create and recheck an immutable archive, then write a compact receipt."""
    tested = json.loads((VALIDATION / 'tested_source.json').read_text())
    assert all(sha((ROOT / name).read_bytes()) == value for name, value in tested.items())
    validation = json.loads((VALIDATION / 'validation.json').read_text())
    assert validation['documentation_integration'] == 'passed'
    changed = subprocess.check_output(['git', 'diff', '--name-only',
                                      'b4300fcff3fb756a4684b99a28958107792704a1', '--', '*.py'],
                                     cwd=ROOT, text=True).splitlines()
    assert len(changed) == 25
    tracked_python = set(subprocess.check_output(['git', 'ls-files', '*.py'], cwd=ROOT,
                                                text=True).splitlines())
    assert tracked_python == {name for name in tested if name.endswith('.py')}
    members = {}
    for folder in [
        'transfer_validation_v5_extension_documentation',
        'extension_documentation_review_c317', 'extension_test_documentation_review_v1',
        'extension_documentation_corrections_verified_v1',
        'coordination_consistency_review_v1', 'receiving_guide_validation_v2_apfs',
    ]:
        for path in sorted((HOME / folder).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                assert not path.is_symlink()
                members[f'evidence/{folder}/{path.relative_to(HOME / folder)}'] = path.read_bytes()
    for name in changed:
        members[f'final_sources/{name}'] = (ROOT / name).read_bytes()
    for name in ['verify_extension_documentation_v5.py', 'preserve_extension_documentation_v5.py',
                 'external_volume_preflight.json', 'exfat_preflight_failure.json']:
        members[f'helpers/{name}'] = (HOME / name).read_bytes()
    members['helpers/ast_equivalence.py'] = Path('/Users/macuser/bayes-cox-runs/harness/ast_equivalence.py').read_bytes()
    original_helper = subprocess.check_output(['git', 'show',
        'b4300fcff3fb756a4684b99a28958107792704a1:scripts/extension_release/audit_rank_failures.py'], cwd=ROOT)
    assert sha(original_helper) == '6b6655dd5d24a0f4b36efb55c945dcec2c32d6307eb1e94e906b44e9120883bc'
    members['historical/failure_provenance_v1_audit_rank_failures.py'] = original_helper
    probe_helper = subprocess.check_output(['git', 'show',
        '3a6bc65138d1aca6bdc2f2509eb5b32570642a5c:scripts/extension_release/archive_common.py'], cwd=ROOT)
    assert sha(probe_helper) == json.loads((HOME / 'external_volume_preflight.json').read_text())['helper_sha256']
    members['historical/external_preflight_archive_common.py'] = probe_helper
    review_name = 'coordination/reviews/2026-09-28-extension-documentation-pass.md'
    members[f'review/{Path(review_name).name}'] = (ROOT / review_name).read_bytes()
    inventory = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
    members['archive_inventory.json'] = (json.dumps(inventory, indent=2, sort_keys=True) + '\n').encode()
    archive = RECOVERY / '2026-09-28-extension-documentation-gates.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        assert {m.name for m in tar.getmembers()} == set(members)
        for item in tar.getmembers():
            assert item.isfile()
            extracted = tar.extractfile(item)
            assert extracted is not None and extracted.read() == members[item.name]
    assert all(sha((ROOT / name).read_bytes()) == value for name, value in tested.items())
    corrections = HOME / 'extension_documentation_corrections_verified_v1/verification.json'
    receipt = {
        'schema_version': 1, 'verified_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'extension_documentation_verified_scientific_completion_pending',
        'extension_python_files': len(changed), 'extension_stripped_ast_matches': 25,
        'baseline_and_extension_stripped_ast_matches': 140,
        'documented_modules': len(tracked_python), 'documented_class_function_definitions': 1051,
        'documented_ast_nodes': validation['documented_module_class_function_nodes'],
        'repository_tests_passed': 349, 'repository_tests_seconds': 88.60,
        'ruff_schemas_diff_checks': 'passed', 'tested_source_files': len(tested),
        'tested_source_sha256': sha((VALIDATION / 'tested_source.json').read_bytes()),
        'validation_sha256': sha((VALIDATION / 'validation.json').read_bytes()),
        'independent_corrections_receipt_sha256': sha(corrections.read_bytes()),
        'frozen_checkouts': validation['frozen_checkouts'],
        'source_unchanged_during_and_after_validation': True,
        'failure_audit_original_helper_sha256': sha(original_helper),
        'failure_audit_current_helper_sha256': tested['scripts/extension_release/audit_rank_failures.py'],
        'final_failure_audit_output': 'failure_provenance_v2',
        'archive': str(archive.relative_to(ROOT)), 'archive_sha256': sha(archive.read_bytes()),
        'archive_bytes': archive.stat().st_size, 'archive_members_verified': len(members),
        'archive_member_inventory_sha256': sha(members['archive_inventory.json']),
        'external_validation_path': str(VALIDATION),
        'full_programme_gates': '1625-cell accounting, deep verification, 92 exact refits, actual visual QA, private release and fresh science restore remain pending',
    }
    with (RECOVERY / '2026-09-28-extension-documentation-verification.json').open('x') as handle:
        json.dump(receipt, handle, indent=2, sort_keys=True)
        handle.write('\n')
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
