# Extension self-test/test documentation review

Reviewed fixed commits `d9d629eeaee92afa5588acbc123aa6c22535564c` and `9acef2eb00ecc26bf4ed89f882d06985b6e05527`, their executable test bodies and retained policy. Exact parent/commit/blob IDs, SHA256 values, changed-docstring inventory and replacement wording are retained in `review_receipt.json`. An independent child reviewed the two self-test files.

Four additional factual corrections:

1. **Download size, rather than link** — `audit_support_selftest.py:247`: the body changes `downloaded_size`, refreshes its capture pin and expects a download-manifest mismatch. Suggested wording: “A download-size mismatch is rejected after the capture hash is refreshed.”
2. **Prior reference attribution** — `test_extensions.py:97–101`: the prior fixture contains executed R arithmetic matching the paper and official Stan formula. The authors’ R estimator and CRAN WME code supply the separate WME fixture. Replace the claim that these prior values match “the authors’ R code”; preserve the recorded boundary that Stan was not compiled.
3. **Horseshoe target** — `test_extensions.py:195–197`: the assertion checks `sum(s/(1+s))=p0`, the underlying unregularized horseshoe’s approximate effective dimension at fixed `tau=tau0`. It does not count literally nonzero coefficients or calibrate finite-slab/hyperprior-marginal complexity. The doubling-design/halving-scale description is correct.
4. **Hash rebinding operation** — `test_extension_qa_transfer.py:107–109,192,199,206,217,230,271`: “re-signed” describes an operation the helper does not perform. It refreshes unkeyed SHA256 bindings; use “rehashed” or “rebound”.

The two corrections already identified by root are confirmed: failure provenance retains its supplemental classification without declaring programme completion (`test_extension_failure_transfer.py:79`); the saved-forecast test checks equality of survival values at shared horizon/grid timestamps (`test_extensions.py:351`).

No other concrete factual inaccuracies were found in the new docstrings. No tests, fitting, downloads or repository/source/result edits were performed. This review assesses descriptions of the existing tests; it does not assert a new test pass or expand scientific gates.
