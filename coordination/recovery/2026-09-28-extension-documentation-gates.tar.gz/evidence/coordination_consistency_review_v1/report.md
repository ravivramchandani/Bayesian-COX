# Remaining coordination inconsistencies

1. `coordination/HANDOFF.md:376–378` says unfinished frozen robustness continues, and `:573` says robustness production is running. These sit in the unlabelled Established facts and Authoritative status sections. The same file `:39–42`, `:397–405` and `:502–507` confirms that the baseline 825-cell run is verified and its workers/coordinator exited. Update these two live statements to the completed baseline state; the active 1,625-cell extension is a different run.

2. `docs/extensions_execution.md:140` labels the integration-validation logs optional. For this authorised close-out, `coordination/HANDOFF.md:53–58`, `:77–83`, `:96–103` and `:105–117` explicitly require retaining/staging all four existing validation versions. Clarify that the CLI option is generally optional but inclusion of these existing validation logs is required for this release.
