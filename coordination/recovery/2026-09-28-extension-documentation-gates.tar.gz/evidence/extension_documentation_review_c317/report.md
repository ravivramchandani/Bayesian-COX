# Fixed-commit extension documentation review

Reviewed all eight changed files at `c3175dc65ac8a67b1664a274e883cf45b310ec33` against `b4300fcff3fb756a4684b99a28958107792704a1`, their bodies/callees, the frozen addendum, retained methods reviews and executed-author-reference fixture. Exact before/after Git blob IDs and SHA256 values are in `review_receipt.json`; `reviewed_diff.patch` preserves the reviewed change.

Seven documentation corrections are warranted:

1. **Adaptive catalytic Potential** (`extensions.py:205–207`): the general description says `tau*q`; the adaptive branch uses `tau*(q-kappa)` with `Gamma(p+2, rate=1)`. Describe the fixed and adaptive variants separately. The implemented adaptive joint kernel is `(p+1)*log(tau)+tau*(q-kappa-1)`; the formula in `catalytic.py` is correct.
2. **Horseshoe calibration interpretation** (`extensions.py:61–78`): distinguish the assumed effective dimension of the underlying unregularized horseshoe at fixed `tau=tau0` from the regularized or hyperprior-marginal prior. The function separately records the finite-slab expectation. Call `h` baseline-prior-adjusted profiled local curvature, rather than pure PWE likelihood Fisher information.
3. **Ridge normalization** (`penalized_cox.py:27–32`): CoxPH actually minimizes `-ell/n + alpha*||beta||²/(2*n)`. Its existing `alpha=n_fit*penalty` conversion is correct; the claim that its objective sums over subjects is inaccurate.
4. **Returned risk score** (`penalized_cox.py:69–71`): ridge returns `X beta`; Coxnet lasso/elastic net return `X beta-offset_`. State the centering offset instead of promising raw `X beta` for every estimator.
5. **DCA argument name** (`decision_curves.py:95–107`): use `free_weight`, matching the signature and body, rather than nonexistent `event_free_weight`.
6. **Bootstrap defaults** (`decision_curves.py:137–140`): both `"all"` and `"none"` are required whenever a model strategy is present; both contrasts are always constructed, rather than optionally enabled.
7. **IPCW boundary/support contract** (`decision_curves.py:18–19,45–46,62–64`): censoring at **or before** the horizon receives zero weights. Document the `minimum_at_risk` rejection alongside follow-up and G support failures.

The exponential catalytic kernel, adaptive joint formula in `catalytic.py`, weighted Breslow event/risk terms, pooled survival baseline adaptation, horseshoe variance/MAP/Schur/root formulas, compact PWE likelihood, DCA threshold odds/left-limit event weights and conditional paired bootstrap otherwise match the inspected implementations and frozen record. The new preprocessing, fit-error and saved-forecast constructor descriptions are accurate. No concrete incorrect claim was found in `src/__init__.py`.

All proposed corrections are documentation only. No source/results edits, tests, model fitting or downloads were performed. The retained fixture establishes R prior-arithmetic and WME agreement; it does not establish compiled-Stan or whole-posterior parity.
