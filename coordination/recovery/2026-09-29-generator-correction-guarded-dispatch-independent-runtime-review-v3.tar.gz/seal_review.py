"""Seal this completed bounded V3 review using stdlib source reads only."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).absolute().parent
CARRIER = OUT.parent / "generator_correction_guarded_dispatch_v3"
PREP_SHA = "65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a"
V2 = OUT.parent / "generator_correction_guarded_dispatch_v2"
CLASSIFIER = Path("/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929/scripts/catalytic_correction/correction_fit_contracts.py")


def binding(path):
    assert path.is_absolute() and ".." not in path.parts
    assert not any(item.is_symlink() for item in (path, *path.parents))
    assert path.is_file()
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def read(path, expected=None):
    if expected is not None:
        assert binding(path)["sha256"] == expected
    value = json.loads(path.read_text())
    if "content_sha256" in value:
        assert value["content_sha256"] == digest({key: item for key, item in value.items() if key != "content_sha256"})
    return value


def write(name, value):
    assert "content_sha256" not in value
    raw = (json.dumps({**value, "content_sha256": digest(value)}, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    with (OUT / name).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def evidence(path, first, last):
    lines = path.read_text().splitlines()
    return {"path": str(path), **binding(path), "line_start": first, "line_end": last,
            "lines": [{"line": n, "text": lines[n - 1]} for n in range(first, last + 1)]}


prep = read(CARRIER / "preparation_receipt.json", PREP_SHA)
assert len(prep["artifacts"]) == 115
assert {str(path.relative_to(CARRIER)) for path in CARRIER.rglob("*") if path.is_file()} == set(prep["artifacts"]) | {"preparation_receipt.json"}
assert sorted(str(path.relative_to(CARRIER)) for path in CARRIER.rglob("*") if path.is_dir()) == prep["artifact_directories"] == [
    "preserved_v2", "preserved_v2/preserved_v1", "preserved_v2/preserved_v1_review", "preserved_v2_review"]
for name, expected in prep["artifacts"].items():
    assert binding(CARRIER / name) == expected
initial = read(OUT / "delta_ast_and_initial_inventory.json")
expected_sources = initial["source_before"]
assert len(expected_sources) == 232
observed_sources = {path: binding(Path(path)) for path in expected_sources}
assert observed_sources == expected_sources
unit = read(OUT / "unit.invocation.json")
probe = read(OUT / "consistency_probe.invocation.json")
for label, capture in (("unit", unit), ("consistency_probe", probe)):
    assert type(capture["exit_code"]) is int and capture["exit_code"] == 0
    assert capture["source_before"] == capture["source_after"] == expected_sources
    assert capture["all_sources_unchanged"] is True
    for stream in ("stdout", "stderr"):
        assert binding(OUT / f"{label}.{stream}.log") == capture[f"raw_{stream}"]
assert "Ran 41 tests" in (OUT / "unit.stderr.log").read_text() and (OUT / "unit.stderr.log").read_text().endswith("\nOK\n")
observed = json.loads((OUT / "consistency_probe.stdout.log").read_text())
assert observed["fictional_only"] is True and observed["actual_controller_scientific_or_checker_calls"] == 0
assert len(observed["results"]) == 9 and all(row["expectation_met"] is True for row in observed["results"])
assert sum(row["accepted"] is False for row in observed["results"]) == 5
assert sum(row["accepted"] is True for row in observed["results"]) == 4
assert binding(CLASSIFIER)["sha256"] == "83cb84002cd9dc447f70d9346baaba16197fa04d5a43e8b2fb500c2ce38f7fef"
for name in ("test_guarded_dispatch.py", "test_guarded_dispatch_regressions.py", "capture_guarded_dispatch.py", "verify_guarded_dispatch_proof.py", "source_bindings.json"):
    assert binding(CARRIER / name) == binding(V2 / name)
old = (V2 / "guard_fit_dispatch.py").read_text()
null_marker = '    require(decision["tuning_record_reused_sha256"] is None, "no-fit account decision cannot reuse fitting-stage tuning")\n'
empty_roles = '                and decision["missing_roles"] == [] and decision["changed_roles"] == [] and decision["generator_failures"] == {}\n'
expected_new = old.replace('    if terminal:\n        require(decision["action"] == "retain_input_failure"', null_marker + '    if terminal:\n        require(decision["action"] == "retain_input_failure"', 1)
expected_new = expected_new.replace('        require(value["operation"] == decision["action"] == "reuse_original_outcome" and source is not None\n',
                                    '        require(value["operation"] == decision["action"] == "reuse_original_outcome" and source is not None\n' + empty_roles, 1)
assert (CARRIER / "guard_fit_dispatch.py").read_text() == expected_new and expected_new != old
new_fixture = CARRIER / "test_guarded_dispatch_reuse_consistency.py"
classes = [node for node in ast.parse(new_fixture.read_text()).body if isinstance(node, ast.ClassDef)]
assert len(classes) == 1 and classes[0].name == "GuardV3ReuseConsistency"
assert len(classes[0].bases) == 1 and ast.dump(classes[0].bases[0]) == "Attribute(value=Name(id='unittest', ctx=Load()), attr='TestCase', ctx=Load())"
new_methods = {node.name: hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
               for node in classes[0].body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}
assert len(new_methods) == 7 and new_methods == prep["new_consistency_method_ASTs"]
assert len(initial["original34_method_ASTs"]) == 34 and initial["all34_methods_unchanged"] is True
producer = {}
for name in ("unit_attempt1", "ruff_attempt1", "compile_attempt1"):
    value = read(CARRIER / f"{name}.invocation.json")
    assert type(value["exit_code"]) is int and value["exit_code"] == 0
    assert value["source_start"] == value["source_finish"]
    assert len(value["source_finish"]) == 7
    assert value["actual_numerical_or_guarded_controller_dispatch"] is False
    for source, expected in value["source_finish"].items():
        assert binding(CARRIER / source) == expected
    for stream in ("stdout", "stderr"):
        assert binding(CARRIER / f"{name}.{stream}.log") == value[f"raw_{stream}"]
    producer[name] = {"invocation": binding(CARRIER / f"{name}.invocation.json"), "exit_code": value["exit_code"],
                      "argv": value["argv"], "raw_stdout": value["raw_stdout"], "raw_stderr": value["raw_stderr"],
                      "all7_final_source_pins_match": True}
write("findings.json", {"schema_version": 1, "status": "bounded_v3_delta_review_no_material_gap_identified",
      "subject_preparation_receipt_sha256": PREP_SHA, "material_finding_count": 0, "findings": [],
      "prior_GD_R2a_closed": True, "closure_observations": observed["results"],
      "closure_source_lines": {"null_marker_both_branches": 431, "empty_reuse_lists_and_failures": 442},
      "original34_test_assertions_AST_and_source_bytes_unchanged": True,
      "new7_methods_collected_separately": True, "valid_negative_reuse_and_terminal_missing_changed_roles_preserved": True,
      "all_other_production_text_unchanged": True, "scientific_or_root_adoption_approval": False})
write("source_evidence.json", {"schema_version": 1, "status": "exact_pinned_v3_delta_source_line_evidence",
      "evidence": [evidence(CARRIER / "guard_fit_dispatch.py", 397, 446),
                   evidence(CLASSIFIER, 191, 255),
                   evidence(new_fixture, 1, len(new_fixture.read_text().splitlines()))],
      "new7_method_ASTs": new_methods, "original34_method_ASTs": initial["original34_method_ASTs"]})
write("final_verification.json", {"schema_version": 1, "status": "bounded_v3_review_complete_all_inputs_unchanged",
      "checked_at_utc": datetime.now(UTC).isoformat(), "subject_bound_files": 115, "subject_full_files": 116,
      "subject_directories": prep["artifact_directories"], "source_before": expected_sources, "source_after": observed_sources,
      "all232_captured_inputs_unchanged": True, "classifier_separately_checked_at_sealing": {"path": str(CLASSIFIER), **binding(CLASSIFIER)},
      "classifier_not_among232_per_invocation_captured_inputs": True,
      "independent_unit_actual_exit_code": unit["exit_code"], "independent_unit_methods": 41,
      "independent_consistency_probe_actual_exit_code": probe["exit_code"], "independent_consistency_probe_cases": 9,
      "all9_case_expectations_met": True, "producer_actual_final_captures_checked": producer,
      "exact_original34_method_ASTs": initial["original34_method_ASTs"], "new7_method_ASTs": new_methods,
      "whole_production_text_delta_only_two_added_requirements_in_account_cell": True,
      "whole_V2_79_and_review15_preserved_exact": True, "retained34_sources_byte_exact": True,
      "unchanged_launcher_readonlyCLI_source_bindings_and_old6_pins": True,
      "old20_source_pins_current_exact": True, "gate_relaxation_identified": False,
      "scope": {"bounded_delta_against_finished_v2_only": True, "new_external_review_writes_only": True,
                "fictional_import_and_metadata_helper_tests_only": True, "actual_controller_scientific_environment_checker_execution": False,
                "datasets_arrays_traces_or_owner_queries": False, "resident_original_or_carrier_changes": False,
                "scientific_freeze_scope_retry_release_or_root_adoption_approval": False}})
assert {path: binding(Path(path)) for path in expected_sources} == expected_sources
artifacts = {str(path.relative_to(OUT)): binding(path) for path in sorted(OUT.rglob("*")) if path.is_file()}
assert len(artifacts) == 14 and not any(path.is_dir() for path in OUT.rglob("*"))
write("receipt.json", {"schema_version": 1, "status": "independent_v3_bounded_delta_review_sealed_no_material_gap_identified",
      "sealed_at_utc": datetime.now(UTC).isoformat(), "owner": str(OUT), "subject": str(CARRIER),
      "subject_preparation_receipt": binding(CARRIER / "preparation_receipt.json"), "artifacts": artifacts,
      "artifact_directories": [], "material_finding_count": 0, "prior_GD_R2a_closed": True,
      "scientific_or_root_adoption_approval": False})
assert {str(path.relative_to(OUT)) for path in OUT.rglob("*")} == set(artifacts) | {"receipt.json"}
for name, expected in artifacts.items():
    assert binding(OUT / name) == expected
read(OUT / "receipt.json")
print(json.dumps({"receipt": str(OUT / "receipt.json"), **binding(OUT / "receipt.json"), "bound_files": len(artifacts),
                  "all_files": len(artifacts) + 1, "unchanged_captured_inputs": len(expected_sources), "material_findings": 0}, sort_keys=True))
