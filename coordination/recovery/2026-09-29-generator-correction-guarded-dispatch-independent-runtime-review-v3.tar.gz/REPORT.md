# Independent guarded-dispatch V3 delta review

No material gap remains in the bounded GD-R2a correction. V3 rejects the four contradictory reuse decisions demonstrated by the sealed V2 review and requires a null tuning-reuse marker for terminal-input accounts. Valid original negative reuse and terminal failures with missing or changed roles remain accepted. This conclusion is engineering preparation evidence only; it does not adopt the runtime or approve any scientific dispatch, freeze, scope, retry, or release.

The subject carrier is `/Users/macuser/bayes-cox-runs/extensions-20260928/generator_correction_guarded_dispatch_v3`. Its preparation receipt byte SHA-256 is `65db400992816a3628c0177ee4e90b777be4c8aa6f139add0a7799b434ef176a`: 115 bound files, 116 files including the receipt, and four declared directories. The core pin is `368141f522b8d2d9b4d8829a0c1102d326bd7aafc6b063ee574932f02c33c116`; capture and read-only CLI remain byte-identical to V2 at `f82a7b8d2c65e829a7178c8fb230751bef193356e8589c22512ac229de944611` and `7b19d4c7efa945d22e03cc779e1a1e64a06425f59a7d6b7d862097708ec501a9`.

## Narrow correction and actual independent checks

The whole production source difference is exactly two added requirements inside `account_cell`. Line 431 requires `tuning_record_reused_sha256 is None` for both no-fit branches. Line 442 requires empty reuse `missing_roles`, `changed_roles`, and `generator_failures`. These match pinned original `correction_fit_contracts.py:238–249`. The original generator-failure priority is preserved: terminal-input accounts can still have missing and changed roles. The original classifier pin remains `83cb84002cd9dc447f70d9346baaba16197fa04d5a43e8b2fb500c2ce38f7fef`; it was inspected as source and was not executed by this review.

The genuine independent fictional unit subprocess returned code zero: `Ran 41 tests`, `OK`. All 34 retained V2 method ASTs, including their assertions, are unchanged, and both old test modules are also byte-identical. The seven separately collected V3 methods test the four reuse contradictions, terminal non-null tuning, valid negative reuse, and valid terminal missing/changed roles. Their rejection helper checks `account_only` and the injected launcher, unchanged output bytes, zero controller calls, and absence of an introduction namespace. New tests borrow only lifecycle/fixture helpers and do not inherit the original test collection.

A separate genuine account-only probe returned code zero with these nine observed cases:

| Fictional account case | Required result | Observed result |
|---|---|---|
| Reuse with changed roles | Reject | Rejected |
| Reuse with missing roles | Reject | Rejected |
| Reuse with generator failures | Reject | Rejected |
| Reuse with non-null tuning marker | Reject | Rejected |
| Terminal input failure with non-null tuning marker | Reject | Rejected |
| Original reuse: `complete` | Accept | Accepted |
| Original reuse: `failed` | Accept | Accepted |
| Original reuse: `failed_diagnostics` | Accept | Accepted |
| Terminal input failure with both missing and changed roles | Accept | Accepted |

Both independent captures retain exact argv, locked regular `python3.11`, `-I -B`, cwd, numeric-thread environment, start/finish timestamps, typed actual return code, raw stdout/stderr hashes, and full source maps. The producer's final unit, Ruff, and seven-file AST/compile invocations and raw streams were also checked against the final pinned sources; each actual return code is zero. No check result is inferred from a transport status or a declared result.

## Preservation and limits

All 232 captured inputs remain unchanged before and after both independent subprocesses: the complete 116-file V3 carrier, original 79-file V2 carrier, original 15-file V2 independent review, the 20 bound original sources, and the two independent capture/probe sources. The V2 copy under `preserved_v2/` and review under `preserved_v2_review/` are exact, complete byte matches; both original V2 directories and the nested V1 history remain intact. The original six import pins remain unchanged. The classifier was checked separately against its already sealed pin at review sealing; it is not counted among those 232 per-invocation inputs.

Only the `account_cell` production AST changes. Whole-file comparison verifies that no other source text or module-level gate was changed. The dispatcher, launcher, account-pass/history closure, genuine-return-code chain, remaining-pilot predicate, and source/receiving mapping retain their already reviewed V2 implementation. I found no relaxation of those gates in this delta.

I read the sealed V3 runtime difference, new regression source, README, delta JSON, preparation/preservation metadata and final producer captures, using the prior finished V2 review as the unchanged-code baseline. This was a bounded delta review, not a new scientific audit or a real receiving restore. Runtime imports and metadata helper calls occurred only in disposable fictional fixtures; no real controller, scientific backend, dataset/array/trace, environment checker, process owner, or resident/source/real-run write was used. Every new persistent write belongs to this external review directory. Root still supplies any actual implementation, scope, freeze, selection, adoption, source-verification and receiving-verification decisions and evidence.
