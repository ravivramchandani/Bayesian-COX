"""Bounded account-only metadata checks in disposable fictional guard fixtures."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path

CARRIER = Path(sys.argv[1])
EXPECTED_PREPARATION_SHA = sys.argv[2]
assert CARRIER.is_absolute() and ".." not in CARRIER.parts
assert not any(path.is_symlink() for path in (CARRIER, *CARRIER.parents))
assert hashlib.sha256((CARRIER / "preparation_receipt.json").read_bytes()).hexdigest() == EXPECTED_PREPARATION_SHA
sys.path.insert(0, str(CARRIER))
spec = importlib.util.spec_from_file_location("_independent_v3_fictional_regressions", CARRIER / "test_guarded_dispatch_regressions.py")
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
test = module.GuardV2Regressions()
test.setUp()
try:
    f, g = test.fixture, module.g
    path = f.output / "cells/a.json"
    terminal = g.document(path)
    results = []

    def change(value, **changes):
        candidate = json.loads(json.dumps(value))
        decision = {key: item for key, item in candidate["decision"].items() if key != "decision_content_sha256"}
        decision.update(changes)
        decision["decision_content_sha256"] = g.digest(decision)
        candidate["decision"] = decision
        return candidate

    def observe(name, value, should_accept):
        test.rewrite(path, value)
        try:
            g.account_only(f.output, f.request, f.gates())
        except g.InvalidProof as error:
            result = {"case": name, "accepted": False, "error": str(error)}
        else:
            result = {"case": name, "accepted": True}
        result["expected_acceptance"] = should_accept
        result["expectation_met"] = result["accepted"] is should_accept
        results.append(result)

    for status in ("complete", "failed", "failed_diagnostics"):
        test.rewrite(path, terminal)
        test.make_reuse(status)
        reused = g.document(path)
        observe(f"legitimate_reuse_{status}", reused, True)
    for key, value in (("changed_roles", ["model_sources"]), ("missing_roles", ["model_sources"]),
                       ("generator_failures", {"outer": "input_failure"}), ("tuning_record_reused_sha256", "1" * 64)):
        observe(f"contradictory_reuse_{key}", change(reused, **{key: value}), False)
    observe("terminal_nonnull_tuning_marker", change(terminal, tuning_record_reused_sha256="1" * 64), False)
    observe("legitimate_terminal_missing_and_changed_roles", change(terminal, missing_roles=["model_sources"], changed_roles=["environment"]), True)
    assert f.controller_calls == 0
    assert not any(name == "src" or name.startswith("src.") for name in sys.modules)
    print(json.dumps({"status": "bounded_no_fit_consistency_observed", "results": results,
                      "actual_controller_scientific_or_checker_calls": 0, "fictional_only": True}, sort_keys=True))
    assert all(result["expectation_met"] for result in results)
finally:
    test.tearDown()
