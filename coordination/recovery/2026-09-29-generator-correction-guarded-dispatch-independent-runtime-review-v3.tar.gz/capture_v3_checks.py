"""Capture a sealed V3 delta review without any actual dispatch or science."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).absolute().parent
CARRIER = Path(sys.argv[1])
PREP_SHA = sys.argv[2]
V2 = OUT.parent / "generator_correction_guarded_dispatch_v2"
V2_SHA = "46a95785348e9f54379178caaf728fd863cccef3d133b2f5a3c8116aa5d9e9cc"
V2_REVIEW = OUT.parent / "generator_correction_guarded_dispatch_independent_review_v2"
V2_REVIEW_SHA = "459403799a2ce70aebb805ddfd0b0a706fd8a1db69776f596884bf44adea5c06"


def binding(path):
    assert path.is_absolute() and ".." not in path.parts
    assert not any(item.is_symlink() for item in (path, *path.parents))
    assert path.is_file()
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def document(path, expected):
    assert binding(path)["sha256"] == expected
    value = json.loads(path.read_text())
    assert value["content_sha256"] == digest({key: item for key, item in value.items() if key != "content_sha256"})
    return value


def full_carrier(path, expected_sha, receipt="preparation_receipt.json"):
    value = document(path / receipt, expected_sha)
    result = {str(path / name): evidence for name, evidence in value["artifacts"].items()}
    result[str(path / receipt)] = binding(path / receipt)
    assert {str(member) for member in path.rglob("*") if member.is_file()} == set(result)
    assert sorted(str(member.relative_to(path)) for member in path.rglob("*") if member.is_dir()) == value["artifact_directories"]
    for name, evidence in result.items():
        assert binding(Path(name)) == evidence
    return value, result


def snapshot():
    prep, result = full_carrier(CARRIER, PREP_SHA)
    old, old_files = full_carrier(V2, V2_SHA)
    review, review_files = full_carrier(V2_REVIEW, V2_REVIEW_SHA, "receipt.json")
    assert len(old_files) == 79 and len(review_files) == 15
    for name, evidence in old_files.items():
        assert binding(CARRIER / "preserved_v2" / Path(name).relative_to(V2)) == evidence
    for name, evidence in review_files.items():
        assert binding(CARRIER / "preserved_v2_review" / Path(name).relative_to(V2_REVIEW)) == evidence
    result.update(old_files)
    result.update(review_files)
    assert prep["original20_sources_before"] == prep["original20_sources_after"] == old["original20_sources_after"]
    result.update(prep["original20_sources_after"])
    result[str(OUT / "probe_no_fit_consistency.py")] = binding(OUT / "probe_no_fit_consistency.py")
    result[str(Path(__file__).absolute())] = binding(Path(__file__).absolute())
    for name, evidence in result.items():
        assert binding(Path(name)) == evidence
    return result


def methods(path, classes):
    tree = ast.parse(path.read_text())
    return {f"{cls.name}.{node.name}": hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
            for cls in tree.body if isinstance(cls, ast.ClassDef) and cls.name in classes
            for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}


def nodes(path):
    tree = ast.parse(path.read_text())
    return {node.name: hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
            for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def write(name, value):
    assert "content_sha256" not in value
    with (OUT / name).open("xb") as stream:
        stream.write((json.dumps({**value, "content_sha256": digest(value)}, sort_keys=True, indent=2, allow_nan=False) + "\n").encode())
        stream.flush()
        os.fsync(stream.fileno())


before = snapshot()
old_methods = {**methods(V2 / "test_guarded_dispatch.py", {"GuardTests"}),
               **methods(V2 / "test_guarded_dispatch_regressions.py", {"GuardV2Regressions"})}
new_methods = {**methods(CARRIER / "test_guarded_dispatch.py", {"GuardTests"}),
               **methods(CARRIER / "test_guarded_dispatch_regressions.py", {"GuardV2Regressions"})}
assert len(old_methods) == 34 and old_methods == new_methods
old_nodes, new_nodes = nodes(V2 / "guard_fit_dispatch.py"), nodes(CARRIER / "guard_fit_dispatch.py")
changed_nodes = sorted(name for name in old_nodes if old_nodes[name] != new_nodes[name])
assert changed_nodes == ["account_cell"] and old_nodes.keys() == new_nodes.keys()
assert binding(V2 / "capture_guarded_dispatch.py") == binding(CARRIER / "capture_guarded_dispatch.py")
assert binding(V2 / "verify_guarded_dispatch_proof.py") == binding(CARRIER / "verify_guarded_dispatch_proof.py")
write("delta_ast_and_initial_inventory.json", {"schema_version": 1, "status": "bounded_v3_account_cell_delta_verified",
      "source_before": before, "original34_method_ASTs": new_methods, "all34_methods_unchanged": True,
      "changed_core_nodes": changed_nodes, "capture_byte_unchanged": True, "readonly_cli_byte_unchanged": True,
      "all_v2_79_and_review15_preserved_exact": True, "original20_current_exact": True})
python = Path(sys.executable).resolve(strict=True)
environment = dict(os.environ)
threads = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")
environment.update(dict.fromkeys(threads, "1"))
environment["PYTHONDONTWRITEBYTECODE"] = "1"
for label, argv in (("unit", [str(python), "-I", "-B", "-m", "unittest", "discover", "-s", str(CARRIER), "-p", "test_guarded_dispatch*.py", "-v"]),
                    ("consistency_probe", [str(python), "-I", "-B", str(OUT / "probe_no_fit_consistency.py"), str(CARRIER), PREP_SHA])):
    started = datetime.now(UTC).isoformat()
    start = snapshot()
    with (OUT / f"{label}.stdout.log").open("xb") as stdout, (OUT / f"{label}.stderr.log").open("xb") as stderr:
        returned = subprocess.run(argv, cwd=OUT, env=environment, stdout=stdout, stderr=stderr, check=False)
        assert type(returned.returncode) is int
        for stream in (stdout, stderr):
            stream.flush()
            os.fsync(stream.fileno())
    finish = snapshot()
    write(f"{label}.invocation.json", {"schema_version": 1, "status": "bounded_fictional_v3_check_actual_return_captured",
          "argv": argv, "cwd": str(OUT), "requested_interpreter": str(python), "observed_capture_interpreter": sys.executable,
          "numeric_thread_environment": {key: environment[key] for key in threads},
          "started_at_utc": started, "finished_at_utc": datetime.now(UTC).isoformat(), "exit_code": returned.returncode,
          "raw_stdout": binding(OUT / f"{label}.stdout.log"), "raw_stderr": binding(OUT / f"{label}.stderr.log"),
          "source_before": start, "source_after": finish, "all_sources_unchanged": start == finish,
          "actual_real_controller_scientific_or_checker_dispatch": False})
    assert start == finish == before
    print(json.dumps({"label": label, "actual_exit_code": returned.returncode, "source_files_unchanged": len(finish)}, sort_keys=True))
    if returned.returncode:
        raise SystemExit(returned.returncode)
