"""Capture actual validation subprocesses without opening programme results."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
BASE = Path(__file__).resolve().parent
REPO = Path("/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project")
NUMERIC = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")
name, command = sys.argv[1], sys.argv[2:]
assert name.replace("_", "").isalnum() and command
prefix = BASE / name
assert not Path(str(prefix) + ".invocation.json").exists()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", **{key: "1" for key in NUMERIC})
started = dt.datetime.now(dt.timezone.utc).isoformat()
t0 = time.monotonic()
with Path(str(prefix) + ".stdout.log").open("xb") as out, Path(str(prefix) + ".stderr.log").open("xb") as err:
    child = subprocess.run(command, cwd=REPO, env=env, stdout=out, stderr=err, check=False)
record = {"argv": command, "cwd": str(REPO), "started_at_utc": started, "finished_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "elapsed_seconds": time.monotonic() - t0, "exit_code": child.returncode, "numeric_threads": {key: env[key] for key in NUMERIC}, "logs": {}}
for suffix in ("stdout", "stderr"):
    p = Path(str(prefix) + "." + suffix + ".log")
    raw = p.read_bytes()
    record["logs"][suffix] = {"path": str(p), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
Path(str(prefix) + ".invocation.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
print(json.dumps({"name": name, "exit_code": child.returncode, "elapsed_seconds": record["elapsed_seconds"]}))
print(Path(str(prefix) + ".stdout.log").read_text()[-5000:])
print(Path(str(prefix) + ".stderr.log").read_text()[-1500:])
sys.exit(child.returncode)
