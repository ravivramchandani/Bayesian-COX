"""Root archival checks; never execute numerical or scientific helpers."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
from collections import Counter

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = Path(__file__).resolve().parent
REPO = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
RECOVERY = REPO / 'coordination/recovery'


def binding(path: Path) -> dict:
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def load(path: Path) -> dict:
    return json.loads(path.read_text())


def write_new(path: Path, value: dict) -> None:
    with path.open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write('\n')


def safe_name(value: str) -> str:
    path = PurePosixPath(value)
    assert not path.is_absolute() and '..' not in path.parts and str(path) == value
    return value


def archive(name: str, members: dict[str, Path]) -> dict:
    assert len(members) == len(set(members))
    before = {safe_name(key): binding(path) for key, path in sorted(members.items())}
    output = RECOVERY / f'2026-09-29-generator-correction-{name}.tar.gz'
    with tarfile.open(output, 'x:gz') as handle:
        for key, path in sorted(members.items()):
            handle.add(path, arcname=key, recursive=False)
    with tarfile.open(output, 'r:gz') as handle:
        actual = {}
        for member in handle.getmembers():
            assert member.isfile() and member.name not in actual
            raw = handle.extractfile(member).read()
            actual[member.name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    after = {key: binding(path) for key, path in sorted(members.items())}
    assert before == after == actual
    return {'archive': output.name, **binding(output), 'regular_members': len(members),
            'exact_member_roundtrip_and_source_before_after_verified': True,
            'members': before}


def sealed(name: str, directory: Path, receipt_name: str, expected: str) -> dict:
    receipt = directory / receipt_name
    assert binding(receipt)['sha256'] == expected
    entries = load(receipt)['artifacts']
    for key, spec in entries.items():
        actual = binding(directory / safe_name(key))
        assert actual['sha256'] == spec['sha256'], key
        if 'bytes' in spec:
            assert actual['bytes'] == spec['bytes'], key
    members = {key: directory / key for key in entries}
    assert receipt_name not in members
    members[receipt_name] = receipt
    result = archive(name, members)
    result.update({'preparation_receipt': receipt_name, 'preparation_receipt_sha256': expected,
                   'all_receipt_artifact_hashes_verified': True})
    return result


def main() -> None:
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    validation = BASE / 'correction_final_implementation_validation_v3_original_cache'
    invocation = load(validation / 'make_test.invocation.json')
    assert invocation['exit_code'] == 0 and invocation['tested_source_before_equals_after']
    stdout = (validation / 'make_test.stdout.log').read_text()
    assert '911 passed, 1 warning, 108 subtests passed' in stdout
    assert not any(' skipped' in line for line in stdout.splitlines() if '=====' in line)
    before = load(validation / 'make_test.tested_source_before.json')
    after = load(validation / 'make_test.tested_source_after.json')
    assert before == after and len(after) == 349
    assert {key: binding(REPO / key) for key in after} == after
    reference = BASE / 'transfer_validation_v5_extension_documentation/tested_source.json'
    original = load(reference)
    assert len(original) == 157
    assert all(binding(REPO / key)['sha256'] == value for key, value in original.items())
    write_new(HERE / 'root_unchanged_source_recheck.json', {
        'checked_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'current_349_files_equal_successful_full_test_capture': True,
        'original_157_source_build_lock_files_unchanged': True,
        'original_reference': {'path': str(reference), **binding(reference)},
        'successful_test_invocation': {'path': str(validation / 'make_test.invocation.json'),
                                       **binding(validation / 'make_test.invocation.json')}})

    incident = BASE / 'correction_storage_incident_preservation_preparation_v1'
    plan = load(incident / 'retention_plan.json')
    assert len(plan['retained_files']) == 1384
    assert len({entry['target'] for entry in plan['retained_files']}) == 1384
    source = Path(plan['forensic_source'])
    inventory = load(incident / 'metadata_snapshots/originals/backing_image_snapshot.json')['copied']
    seen = set()
    for entry in plan['retained_files']:
        assert set(entry) == {'source', 'target', 'binding'}
        safe_name(entry['target'])
        path = Path(entry['source'])
        assert path.is_absolute()
        if path.is_relative_to(source):
            relative = str(path.relative_to(source))
            spec = inventory[relative]
            assert entry['binding'] == {key: spec[key] for key in ('sha256', 'bytes')}
            assert entry['target'].endswith('/' + source.name + '/' + relative)
            seen.add(relative)
        else:
            assert binding(path) == entry['binding']
    assert seen == set(inventory) and len(seen) == 1339
    assert sum(entry['bytes'] for entry in inventory.values()) == 5559317478
    write_new(HERE / 'root_incident_retention_map_review.json', {
        'checked_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'prospective_retained_files': 1384, 'curated_small_files_checked_now': 45,
        'forensic_file_bindings_compared_to_saved_inventory': 1339,
        'forensic_files_read_or_rehashed_now': 0, 'actual_staging_or_packaging': False,
        'retention_plan': {'path': str(incident / 'retention_plan.json'), **binding(incident / 'retention_plan.json')},
        'standalone_verifyVolume_capture_not_available': True,
        'five_raw_process_logs_are_dated_partial_snapshots': True,
        'checkpoint2_count_error_and_checkpoint3_correction_retained': True,
        'final_actual_file_no_link_hash_collision_checks_remain_required': True,
        'scientific_or_release_approval_supplied': False})

    results = {}
    results['storage-incident-preparation'] = sealed('storage-incident-preparation', incident,
        'preparation_receipt.json', '50c724ffdcaf6876061c81bf00d4f87dc0534e7527f453e2ae185ccc8262d0ea')
    for name, dirname, receipt_name, sha in (
        ('original-exit-observer-v3-preparation', 'darwin_original_exit_observer_preparation_v3', 'preparation_receipt.json', '459c721257b1eb5f0b7b4ae2dde4082efa966c114b4fc54db8f60a21f442a1b3'),
        ('original-exit-observer-v3-review', 'darwin_original_exit_observer_peer_review_v3', 'receipt.json', '4364d0d52bb7a17a43ff3c72f100fdb465f8b2a3f95d3ba22a615e2251225d89'),
        ('per-entry-io-preparation', 'generator_correction_reproduction_per_entry_io_v1', 'preparation_receipt.json', '6670b27e78fb05f7c266cc52b72241a4b477f5d9a27213e8882bdcbd1038f366')):
        results[name] = sealed(name, BASE / dirname, receipt_name, sha)

    # A dated snapshot of live observation evidence is never a final process result.
    snapshot_root = HERE / 'observer_dated_snapshot'
    snapshot_root.mkdir()
    observer_launch = Path('/Users/macuser/bayes-cox-runs/original-exit-observer-launch-20260929-v3')
    observer_output = Path('/Users/macuser/bayes-cox-runs/original-exit-observer-20260929-v1')
    snapshot_members = {}
    snapshot_bindings = {}
    for label, directory in (('launch', observer_launch), ('observation', observer_output)):
        target = snapshot_root / label
        target.mkdir()
        for path in sorted(directory.iterdir()):
            if not path.is_file():
                continue
            raw = path.read_bytes()
            copied = target / path.name
            copied.write_bytes(raw)
            key = f'{label}/{path.name}'
            snapshot_members[key] = copied
            snapshot_bindings[key] = {'source': str(path), 'captured_sha256': hashlib.sha256(raw).hexdigest(),
                                      'captured_bytes': len(raw), 'live_source_may_change_later': True}
    subscriptions = load(snapshot_root / 'observation/subscriptions.json')
    assert subscriptions['status'] == 'future_exit_subscriptions_accounted'
    assert subscriptions['registered_pids'] == [62025, 62026, 62027, 62028, 62029, 62030, 64406, 71385, 98854]
    assert subscriptions['unavailable_pids'] == [] and subscriptions['test_only'] is False
    assert subscriptions['past_exit_status_inference'] is False
    # Count exact per-PID registrations; a subscription is not an exit event.
    registrations = list((snapshot_root / 'observation').glob('pid_*.registration.json'))
    assert len(registrations) == 9
    assert all(load(path)['status'] == 'future_kernel_exit_subscription_identity_verified' for path in registrations)
    write_new(snapshot_root / 'dated_scope.json', {
        'capture_started_at_utc': started, 'capture_finished_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'snapshot_is_not_atomic': True, 'actual_registered_original_processes': 9,
        'actual_process_exit_events_in_snapshot': len(list((snapshot_root / 'observation').glob('*.event.json'))),
        'observer_finished_receipt_present': (snapshot_root / 'launch/observer.finished.json').exists(),
        'historical_past_exit_codes_inferred': False, 'original_jobs_modified': False,
        'scientific_completion_or_producer_comparison_approval_supplied': False,
        'bindings': snapshot_bindings})
    snapshot_members['dated_scope.json'] = snapshot_root / 'dated_scope.json'
    results['original-exit-observer-actual-launch'] = archive('original-exit-observer-actual-launch', snapshot_members)

    receipts = list(Path('/Volumes/BayesCoxTransfer20260929/correction-20260929/reuse_v2/replay/contexts').glob('*/*/receipt.json'))
    statuses = Counter(load(path).get('status') for path in receipts)
    originals = list((BASE / 'run/cells').glob('*.json'))
    original_statuses = Counter(load(path).get('status') for path in originals)
    progress = Path('/Volumes/BayesCoxTransfer20260929/correction-20260929/continuation_v2/reuse.stdout.log').read_text().splitlines()[-1]
    checkpoint = {
        'created_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'status': 'dated_metadata_checkpoint_not_completion', 'collection_is_not_atomic': True,
        'original_stored_cells': len(originals), 'original_outcome_status_counts': dict(original_statuses),
        'original_expected_cells': 1625,
        'original_complete_grid_present': len(originals) == 1625,
        'independent_first_draw_receipts': len(receipts), 'receipt_status_counts': dict(statuses),
        'last_progress_line': json.loads(progress),
        'volume_available_bytes': {key: os.statvfs(key).f_bavail * os.statvfs(key).f_frsize for key in
                                   ('/Users/macuser','/Volumes/BayesCoxTransfer20260929','/Volumes/SSD980')},
        'array_or_trace_bytes_read': False, 'corrected_freeze_fits_release_complete': False}
    write_new(HERE / 'dated_progress_checkpoint.json', checkpoint)
    validation_members = {}
    for dirname in ('correction_reporting_integration_validation_v1',
                    'correction_release_integration_validation_v2',
                    'correction_final_implementation_validation_v2',
                    'correction_final_implementation_validation_v3_original_cache',
                    'generator_correction_full_suite_stall_source_diagnosis_v1',
                    'generator_correction_full_suite_stall_completion_metadata_v1',
                    'correction_reporting_release_preservation_20260929_v1'):
        for path in sorted((BASE / dirname).rglob('*')):
            if path.is_file() and '.ruff_cache' not in path.parts:
                validation_members[f'{dirname}/{path.relative_to(BASE / dirname)}'] = path
    for name in ('preserve_checked_records.py', 'root_unchanged_source_recheck.json',
                 'root_incident_retention_map_review.json', 'dated_progress_checkpoint.json'):
        validation_members[f'root_closeout/{name}'] = HERE / name
    results['reporting-release-integration-validation'] = archive('reporting-release-integration-validation', validation_members)
    record = {
        'schema_version': 1, 'created_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'status': 'root_checked_reporting_release_implementation_and_archival_records',
        'full_locked_test': {'passed_tests': 911, 'passed_subtests': 108, 'skips': 0,
                             'actual_exit_code': 0, 'source_before_equals_after': True,
                             'finished_at_utc': invocation['finished_at_utc'],
                             'invocation': binding(validation / 'make_test.invocation.json')},
        'reporting_focused': {'tests': 51, 'subtests': 3},
        'release_focused': {'tests': 68, 'subtests': 35},
        'runtime_and_dependency_sources_are_exact_reviewed_bytes': True,
        'source_349_current_equal_tested_bytes': True, 'original_157_unchanged': True,
        'cancelled_attempts_retained_not_classified_as_scientific_failures': True,
        'prior_preparation_archives': load(BASE / 'correction_reporting_release_preservation_20260929_v1/preservation.json')['archives'],
        'new_archives': results, 'dated_progress': checkpoint,
        'per_entry_io_actual_adoption_or_subset_selection': False,
        'observer_registered_nine_original_processes': True,
        'observer_snapshot_supplies_no_past_exit_code_or_scientific_completion': True,
        'final_fresh_remote_restore_or_actual_QA_completed': False,
        'corrected_programme_complete': False}
    write_new(HERE / 'root_verification.json', record)
    compact = dict(record)
    compact['new_archives'] = {key: {field: value for field, value in spec.items() if field != 'members'}
                              for key, spec in results.items()}
    write_new(RECOVERY / '2026-09-29-generator-correction-reporting-release-integration.json', compact)
    print(json.dumps({'status': record['status'], 'full_test': record['full_locked_test'],
                      'archives': {key: value['regular_members'] for key,value in results.items()},
                      'checkpoint': checkpoint}, sort_keys=True))


if __name__ == '__main__':
    main()
