"""Capture actual root implementation validation with isolated external caches."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys
import time
BASE=Path(__file__).resolve().parent
REPO=Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
CACHE=Path('/Volumes/BayesCoxTransfer20260929/implementation-validation-20260929-v2')
NUMERIC=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')
SOURCE='/Users/macuser/bayes-cox-runs/extensions-code-20260928-119476f'
name,command=sys.argv[1],sys.argv[2:]
assert name.replace('_','').isalnum() and command
prefix=BASE/name
assert not Path(str(prefix)+'.invocation.json').exists()
CACHE.mkdir(exist_ok=True)
for child in ('pytensor','matplotlib','xdg'):(CACHE/child).mkdir(exist_ok=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',BAYES_COX_ORIGINAL_SOURCE=SOURCE,
         PYTENSOR_FLAGS='base_compiledir='+str(CACHE/'pytensor'),MPLCONFIGDIR=str(CACHE/'matplotlib'),XDG_CACHE_HOME=str(CACHE/'xdg'),
         **{key:'1' for key in NUMERIC})
source_paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','scripts','tests','config','Makefile','environment.yml','pyproject.toml','ruff.toml','conda-lock.yml','conda-lock.yml.sha256'],cwd=REPO).split(b'\0')
def snapshot():
    output={}
    for raw in source_paths:
        if not raw:continue
        relative=os.fsdecode(raw);path=REPO/relative
        if path.is_file():
            data=path.read_bytes();output[relative]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    return output
before=snapshot()
Path(str(prefix)+'.tested_source_before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
started=dt.datetime.now(dt.timezone.utc).isoformat();t0=time.monotonic()
with Path(str(prefix)+'.stdout.log').open('xb') as out,Path(str(prefix)+'.stderr.log').open('xb') as err:
    child=subprocess.Popen(command,cwd=REPO,env=env,stdout=out,stderr=err)
    Path(str(prefix)+'.launch.json').write_text(json.dumps({'argv':command,'cwd':str(REPO),'pid':child.pid,'started_at_utc':started,'status':'actual_root_validation_child_launched_not_completed'},sort_keys=True,indent=2)+'\n')
    rc=child.wait()
after=snapshot()
Path(str(prefix)+'.tested_source_after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
record={'argv':command,'cwd':str(REPO),'started_at_utc':started,'finished_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'elapsed_seconds':time.monotonic()-t0,'exit_code':rc,'tested_source_before_equals_after':before==after,
        'tested_source_files':len(before),'environment':{key:env[key] for key in (*NUMERIC,'BAYES_COX_ORIGINAL_SOURCE','PYTENSOR_FLAGS','MPLCONFIGDIR','XDG_CACHE_HOME')},'logs':{}}
for suffix in ('stdout','stderr'):
    p=Path(str(prefix)+'.'+suffix+'.log');raw=p.read_bytes();record['logs'][suffix]={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
Path(str(prefix)+'.invocation.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps({'name':name,'exit_code':rc,'elapsed_seconds':record['elapsed_seconds'],'source_unchanged':before==after}))
print(Path(str(prefix)+'.stdout.log').read_text()[-3000:]);print(Path(str(prefix)+'.stderr.log').read_text()[-1000:])
sys.exit(rc if rc else (0 if before==after else 99))
