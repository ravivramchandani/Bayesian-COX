"""Source-only reproduction of sealed adapter AST conventions; no target import."""
from __future__ import annotations
import ast
import hashlib
import json
import sys
from pathlib import Path

def binding(path):
    raw=path.read_bytes()
    return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}

def definitions(path):
    nodes={}
    for node in ast.parse(path.read_bytes()).body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            nodes[node.name]=node
        if isinstance(node,ast.ClassDef):
            for child in node.body:
                if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    nodes[node.name+"."+child.name]=child
    return nodes

old,new,delta=map(Path,sys.argv[1:4])
source_before={str(p):binding(p) for p in (old,new,delta)}
old_nodes,new_nodes=definitions(old),definitions(new)
declared=json.loads(delta.read_bytes())["unchanged_scope_boundary_ASTs"]
results={}
for name,witness in declared.items():
    old_dump=ast.dump(old_nodes[name],include_attributes=False)
    new_dump=ast.dump(new_nodes[name],include_attributes=False)
    old_hash=hashlib.sha256(old_dump.encode()).hexdigest()
    new_hash=hashlib.sha256(new_dump.encode()).hexdigest()
    results[name]={"old_ast_dump_sha256":old_hash,"new_ast_dump_sha256":new_hash,
                   "old_and_new_ast_dumps_exactly_equal":old_dump==new_dump,
                   "declared_sha256":witness,"declaration_matches_this_interpreter":witness==new_hash,
                   "old_ast_dump":old_dump,"new_ast_dump":new_dump}
source_after={str(p):binding(p) for p in (old,new,delta)}
value={"operation":"source_only_ast_parse_dump_no_target_import","python":sys.executable,
       "python_version":sys.version,"python_version_info":list(sys.version_info),
       "algorithm":"hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()",
       "source_before":source_before,"source_after":source_after,"source_unchanged":source_before==source_after,
       "all_old_and_new_AST_strings_equal":all(v["old_and_new_ast_dumps_exactly_equal"] for v in results.values()),
       "all_declared_hashes_match_this_interpreter":all(v["declaration_matches_this_interpreter"] for v in results.values()),
       "boundaries":results,"target_import_or_execution":False}
print(json.dumps(value,sort_keys=True,indent=2))
if not value["source_unchanged"] or not value["all_old_and_new_AST_strings_equal"]:
    raise SystemExit(1)
