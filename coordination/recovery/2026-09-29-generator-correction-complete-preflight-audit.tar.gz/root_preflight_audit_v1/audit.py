from pathlib import Path
from collections import Counter, defaultdict
from datetime import UTC, datetime
import hashlib, json, math, os, subprocess

ROOT=Path('/Volumes/BayesCoxExtensions20260928/correction-20260929')
PF=ROOT/'preflight_v1'
OUT=ROOT/'root_preflight_audit_v1'
started=datetime.now(UTC).isoformat()
def ch(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()
def read(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    d=json.loads(path.read_text())
    assert d['content_sha256']==ch({k:v for k,v in d.items() if k!='content_sha256'}), str(path)
    return d
def write(name,d):
    d={**d,'content_sha256':ch(d)}
    with (OUT/name).open('x') as f:
        json.dump(d,f,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False); f.write('\n'); f.flush();os.fsync(f.fileno())
    return d
manifest=read(PF/'manifest.json');completion=read(PF/'completion.json')
assert completion['status']=='all_scheduled_contexts_accounted'
assert completion['accounted_contexts']==completion['scheduled_contexts']==1650
assert completion['all_contexts_feasible'] is True
assert all(completion[k] is False for k in ['fit_reuse_certified','model_fit_evaluation_identity_certified','scientific_method_approved','new_freeze_created'])
assert completion['run_binding_sha256']==manifest['content_sha256']
assert not list(PF.rglob('*.claim.json'))
recipe=ROOT/'inputs/recipes_v1/contexts.jsonl'
assert sha(recipe)==manifest['contexts_jsonl_sha256']
rows=[json.loads(s) for s in recipe.read_text().splitlines()]
rowmap={r['context_id']:r for r in rows}; assert len(rowmap)==len(rows)==1650
outcomemap={r['context_id']:r for r in completion['outcomes']};assert set(outcomemap)==set(rowmap)
assert len(completion['outcomes'])==1650
files={}; summaries=[]; outcomes=Counter();attempt_statuses=Counter();strata=defaultdict(lambda:Counter());collisions=[]
accepted_support_omissions=[]; min_sigma=math.inf; max_condition=0.0; total_attempts=0
for index,row in enumerate(rows):
    cid=row['context_id'];binding=outcomemap[cid];rel=Path(binding['receipt_path'])
    assert not rel.is_absolute() and '..' not in rel.parts
    path=PF/rel;d=read(path)
    assert sha(path)==binding['receipt_sha256'] and d['content_sha256']==binding['receipt_content_sha256']
    req=d['request']; assert req['context_id']==cid and req['context_row_sha256']==ch(row)
    assert req['original_generation_seed']==row['generation_seed'] and req['run_binding_sha256']==manifest['content_sha256']
    assert req['candidate_cap']==256 and d['status']==binding['status']
    for name,expected in d['artifacts'].items():
        rp=Path(name);assert not rp.is_absolute() and '..' not in rp.parts
        p=path.parent/rp
        assert p.is_file() and not any(x.is_symlink() for x in [p,*p.parents]), str(p)
        size=p.stat().st_size;h=sha(p)
        assert size==expected['bytes'] and h==expected['sha256'],str(p)
        files[str(p.relative_to(PF))]={'bytes':size,'sha256':h}
    inp=read(path.parent/'input.json'); assert inp['request']==req
    iw=inp['input_witness'];assert req['input_witness_sha256']==ch(iw)
    p=iw['real_design']['shape'][1]; assert p==len(iw['feature_names']) and iw['real_design']['shape'][0]==iw['n_train']
    assert len(iw['ordered_training_subject_ids'])==iw['n_train']
    assert ch(iw['ordered_training_subject_ids'])==iw['training_membership_sha256']
    attempts=d['attempts'];accepted=d['accepted_attempt_index']
    assert accepted==len(attempts)-1 and 1<=len(attempts)<=256
    assert d['status']==('accepted_original_first_draw' if accepted==0 else 'accepted_rank_conditioned_redraw')
    existing={x.name for x in path.parent.glob('attempt_*')};assert existing=={f'attempt_{i:03d}' for i in range(len(attempts))}
    seeds=[]
    for i,a in enumerate(attempts):
        seed=row['generation_seed'] if i==0 else int.from_bytes(hashlib.sha256(f"{row['generation_seed']}|rank_conditioned_retry|{i}".encode()).digest()[:4],'big')%(2**31-1)
        assert a['seed']==seed and a['attempt_index']==i and a['request']==req
        ap=path.parent/f'attempt_{i:03d}'/'receipt.json';assert read(ap)==a
        assert a['status']==('accepted_original_constructor' if i==accepted else 'frozen_rank_rejected')
        am=a['actual_metadata'];assert am['seed']==seed and am['p']==p and am['M']==1000 and am['constructor_restored'] is True
        assert a['constructor_inputs']['design']['shape']==[1000,p] and a['constructor_inputs']['time']['shape']==[1000]
        rank=a['rank_measurement'];assert rank['status']=='measured' and len(rank['singular_values'])==p
        assert all(math.isfinite(v) and v>=0 for v in rank['singular_values'])
        assert (rank['rank']==p)==(i==accepted)
        if i==accepted:
            assert not rank['zero_encoded_columns'] and not rank['zero_encoded_column_indices']
            sigma=rank['singular_values'][-1];assert sigma>0
            min_sigma=min(min_sigma,sigma);max_condition=max(max_condition,rank['singular_values'][0]/sigma)
            for support in rank['category_support']:
                if support['omitted_in_proposal']:
                    accepted_support_omissions.append({'context_id':cid,**support})
        seeds.append(seed);attempt_statuses[a['status']]+=1
    if len(set(seeds))!=len(seeds): collisions.append({'context_id':cid,'seeds':seeds})
    cm=d['candidate_metadata'];assert cm['proposal_metadata_sha256']==ch({k:v for k,v in cm.items() if k!='proposal_metadata_sha256'})
    assert cm['attempts_generated']==len(attempts) and cm['accepted_attempt_index']==accepted and cm['attempt_cap']==256
    assert cm['original_seed']==row['generation_seed']
    assert all(d[k] is False for k in ['fit_reuse_certified','new_freeze_created','scientific_method_approved'])
    key=f"{row['dataset']}::{row['setting']}::{row['gene_budget']}"
    strata[key][d['status']]+=1
    strata[key]['max_p']=max(strata[key]['max_p'],p)
    strata[key]['max_n_train']=max(strata[key]['max_n_train'],iw['n_train'])
    strata[key]['max_training_matrix_elements']=max(strata[key]['max_training_matrix_elements'],p*iw['n_train'])
    strata[key]['max_accepted_attempt_index']=max(strata[key]['max_accepted_attempt_index'],accepted)
    summaries.append({'context_id':cid,'status':d['status'],'n_train':iw['n_train'],'events_train':iw['events_train'],'p':p,'accepted_attempt_index':accepted,'attempts_generated':len(attempts),'receipt_sha256':binding['receipt_sha256'],'input_witness_sha256':req['input_witness_sha256']})
    outcomes[d['status']]+=1;total_attempts+=len(attempts)
    if (index+1)%200==0: print(json.dumps({'audited_contexts':index+1,'audited_unique_artifacts':len(files)}),flush=True)
assert dict(outcomes)==completion['outcome_counts']
assert set(str(p.relative_to(PF)) for p in PF.glob('contexts/*/*/receipt.json'))==set(v['receipt_path'] for v in outcomemap.values())
for rel,h in manifest['original_input_sha256'].items():
    p=Path('/Users/macuser/bayes-cox-runs/extensions-code-20260928-119476f')/rel
    assert sha(p)==h,rel
assert sha(Path(manifest['candidate_module_path']))==manifest['candidate_source_sha256']
assert sha(ROOT/'preflight_v1/manifest.json')=='9b3533aa97ad88038e635c4e2cbbe3cc3b001c7e270a21307d8df69b57f6f5be'
process_check=subprocess.run(['ps','-p','81194','-o','pid=,command='],capture_output=True,text=True)
assert not process_check.stdout.strip()
artifacts=write('verified_artifact_inventory.json',{'schema_version':1,'status':'saved_preflight_artifact_bytes_verified','files':files,'contexts':summaries})
receipt=write('audit_receipt.json',{'schema_version':1,'status':'complete_actual_training_preflight_record_audited','started_at_utc':started,'verified_at_utc':datetime.now(UTC).isoformat(),'audit_script_sha256':sha(OUT/'audit.py'),'preflight_root':str(PF),'manifest_sha256':sha(PF/'manifest.json'),'completion_sha256':sha(PF/'completion.json'),'completion_content_sha256':completion['content_sha256'],'recipe_sha256':sha(recipe),'scheduled_contexts':1650,'stored_contexts':1650,'outcome_counts':dict(outcomes),'total_generated_proposals':total_attempts,'attempt_status_counts':dict(attempt_statuses),'max_accepted_attempt_index':max(v['accepted_attempt_index'] for v in summaries),'within_context_retry_seed_collisions':collisions,'accepted_category_omissions':accepted_support_omissions,'accepted_design_min_recorded_singular_value':min_sigma,'accepted_design_max_recorded_condition_ratio':max_condition,'strata':{k:dict(v) for k,v in strata.items()},'verified_artifact_inventory_sha256':sha(OUT/'verified_artifact_inventory.json'),'verified_unique_artifacts':len(files),'verified_artifact_bytes':sum(v['bytes'] for v in files.values()),'original_input_bindings_verified':len(manifest['original_input_sha256']),'preflight_owner_exited':True,'independent_numeric_replay_completed':False,'fit_reuse_certified':False,'arithmetic_review_completed':False,'scientific_method_approved':False,'corrected_fit_freeze_created':False,'corrected_fits_started':False,'programme_complete':False,'scope':'saved training-input feasibility record and bytes; no generator/model/score execution and no scientific approval'})
print(json.dumps({k:v for k,v in receipt.items() if k not in ['accepted_category_omissions','strata']},sort_keys=True),flush=True)
