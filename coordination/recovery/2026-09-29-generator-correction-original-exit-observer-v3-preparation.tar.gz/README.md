# Future Darwin process-exit observer v3 (preparation only)

V3 adds a typed owner-provenance category to the separately prepared read-only observer. It inspected and subscribed no actual process, launched no live toy process, and obtained no new genuine kernel event. Its 36 tests use invented identities and injected queues only. V1 and v2, including v2's genuine same-UID nonchild exit-0/exit-7 fixtures, remain byte-for-byte unchanged. Root must review the actual v3 source and decide whether a future launch is appropriate. Preparation is not a launch authorization or a scientific, numerical-production, QA or release certificate.

## Exact provenance change

A new schema-2 request replaces `launch_receipt` with this exact typed object:

```json
"owner_provenance": {
  "category": "later_owner_runtime_observation",
  "evidence": {"path": "<absolute genuine existing observation file>", "sha256": "<actual byte SHA>"}
}
```

The only other allowed category is `original_launch_receipt`. The caller must identify and review the genuine already-existing record, preserve its bytes, and select the truthful category. A later observation is never relabelled as a launch receipt, and a hash alone cannot authenticate the record's claimed origin. The observer stores the category and file binding separately, reports both category counts, and always records `later_runtime_evidence_relabelled_as_original_launch:false` and `scientific_or_producer_completion_certified:false`. It does not reconstruct missing historical argv, cwd, creation time, launch receipts or exit codes. Legacy schema 1 and the target's old `launch_receipt` key are refused; there is no implicit migration.

The historical launch-evidence review found eight missing original launch receipts. The genuine saved support-98854 launch record lacks launch cwd. Its original category can still describe that record honestly, while fresh exact cwd must be established independently before any subscription. A genuine saved later runtime observation is a different provenance category and cannot repair those missing historical launch fields or satisfy a scientific producer gate. `known_existing_provenance_evidence.json` binds the already-retained metadata records and review; it is historical context, not a new request, fresh process identity or root approval.

## Unchanged identity and future-exit rules

Production scope remains exactly workers 62025–62030, prestage 64406 and coordinators 71385/98854. Each entry independently requires a fresh complete identity and digest: literal argv, exact recorded cwd, UID, executable, microsecond birth time and ps command/start text. UID and birth identity are checked around metadata collection and exact identity is checked before and after filter registration. Same-UID nonchild permission and existing strict source-byte pins remain. An absolute source pin must match a literal absolute argv entry or a literal relative entry joined only to the exact recorded absolute cwd. No argv rewriting, alternate-file search, symlink alias or traversal is accepted.

The pinned SDK and official [Apple XNU source](https://github.com/apple-oss-distributions/xnu/blob/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/kern_event.c) describe `NOTE_EXITSTATUS`. Existing registration requests `EVFILT_PROC` with `NOTE_EXIT|NOTE_EXITSTATUS` and preserves all raw event fields. Only an identity-bound future terminal event with the required flags can be decoded through `os.waitstatus_to_exitcode`. V3's source delta leaves all metadata, argv/source resolution, event-decoding and exclusive-publication functions unchanged; `source_semantics_checks_v3.json` records the AST proof and unchanged registration/loop segments. No signal, ptrace, waitpid, reparenting, priority change or scientific-reader change is introduced.

An explicitly unavailable expected identity uses `expected_identity:null`, `expected_identity_sha256:null` and a nonempty reason. That PID is never probed or subscribed and receives no exit-code value. Changed identities, missing processes, registration errors and invalid events do not earn a verified code; raced raw events remain unattributed. Metadata exceptions can abort a run with partial diagnostic evidence instead of a finished receipt. A partial run or a timeout is not success. Already-zombie status and past exits, including PID 64435, are never used to infer a return code. A future genuine exit 0 certifies only that process exit, not numerical or producer success.

## Stalled-metadata limitation and future root procedure

Do not use v3 while metadata is known to stall. The native libproc/sysctl metadata calls have no Python deadline. The ps/lsof subprocess requests have nominal five-second timeouts, but subprocess cleanup/reaping cannot guarantee a return when a kernel call or its process is uninterruptibly stalled. `max_observation_seconds` applies to the observation loop; it is not a hard global watchdog and cannot interrupt metadata capture or registration. V3 deliberately does not add a process-control workaround. Root may launch only after it establishes genuinely healthy fresh metadata, reviews the source/provenance categories, and chooses a separate new output. No live checks were made during this preparation.

Future commands below are root-owned and were not executed here. Set `PREP` to this exact sealed v3 directory and `PYTHON` to the locked interpreter. If healthy metadata is established, root may retain each actual snapshot exclusively:

```sh
(set -euo pipefail; set -o noclobber; "$PYTHON" -I -B "$PREP/observer.py" snapshot --pid "$PID" > "$NEW_IDENTITY_JSON")
```

Root creates and seals a new schema-2 request following `interface_contract.json`, pins this preparation receipt, selects the truthful owner-provenance category for each actual record, and sets `test_only:false`. Use `identity_digest()` over its fixed identity fields and `canonical()` excluding `content_sha256`. A null observation limit permits waiting for future exits; a positive limit leaves unknowns honestly unavailable. Never substitute a recycled PID or turn a partial historical record into a fresh identity.

The planned output `/Users/macuser/bayes-cox-runs/original-exit-observer-20260929-v1` must still be absent, have an existing parent, and lie outside this preparation and every source/provenance-record parent. It cannot be a child of `extensions-20260928` if a bound provenance record resides there.

```sh
"$PYTHON" -I -B "$PREP/observer.py" observe --request "$NEW_ROOT_REQUEST" --request-sha256 "$REQUEST_BYTE_SHA" --output /Users/macuser/bayes-cox-runs/original-exit-observer-20260929-v1
```

The observer rechecks source and provenance-file bytes before publishing its final write-once receipt. Collisions refuse before registration; failed or partial bytes remain diagnostics and must not be overwritten. The caller separately retains the genuine actual observer return code. No actual owner or current original-run source/output is changed by this preparation.

## Retained checks

All 36 pure tests passed on identical start/finish source hashes. Scoped Ruff E/F/I/UP/B and four AST/in-memory compile checks passed. The first Ruff attempt's one B023 fixture-closure finding and actual rc1 logs are retained; binding the loop's invented queue resolved it before the passing checks. There was no numerical or live-process test failure. `injected_toy_category_evidence` is explicitly test-only and contains invented identities/events, not genuine provenance or kernel evidence. V2's historical real fixture receipt remains in v2 and is byte-bound here; it was not rerun or newly observed. All 53 v1 and 36 v2 archival files are rehashed before sealing. Independent source review, root decision, fresh healthy identity collection and any actual future observation remain separate.
