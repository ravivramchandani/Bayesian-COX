"""Pure guards and injected toy evidence; no actual process or kernel query."""

from __future__ import annotations

import json
import os
import select
import struct
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import observer


class ObserverGuards(unittest.TestCase):
    """No original scientific job PID is inspected or subscribed by these tests."""

    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="disposable-exit-fixture-")
        self.root = Path(self.temporary.name).resolve()

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def event(self, status: int, **changes: int) -> SimpleNamespace:
        value = {"ident": 123456, "filter": select.KQ_FILTER_PROC, "flags": select.KQ_EV_EOF | select.KQ_EV_ONESHOT,
                 "fflags": select.KQ_NOTE_EXIT | observer.NOTE_EXITSTATUS, "data": status, "udata": 0}
        value.update(changes)
        return SimpleNamespace(**value)

    def test_exit_zero_and_seven_wait_status(self) -> None:
        for code in (0, 7):
            with self.subTest(code=code):
                value = observer.decode_exit(self.event(code << 8), 123456)
                self.assertEqual(value["exit_code"], code)
                self.assertEqual(value["raw_wait_status"], code << 8)

    def test_signal_wait_status_is_preserved_not_sent(self) -> None:
        value = observer.decode_exit(self.event(15), 123456)
        self.assertEqual(value["exit_code"], -15)
        self.assertEqual(value["termination_signal"], 15)

    def test_missing_exitstatus_bit_rejected(self) -> None:
        with self.assertRaises(ValueError):
            observer.decode_exit(self.event(0, fflags=select.KQ_NOTE_EXIT), 123456)

    def test_error_and_foreign_pid_rejected(self) -> None:
        with self.assertRaises(ValueError):
            observer.decode_exit(self.event(0, flags=select.KQ_EV_ERROR), 123456)
        with self.assertRaises(ValueError):
            observer.decode_exit(self.event(0, ident=123457), 123456)

    def test_procargs_environment_is_discarded(self) -> None:
        raw = struct.pack("=i", 3) + b"/test/python\0\0\0python\0source.py\0literal argument\0SECRET=not-recorded\0"
        executable, arguments = observer.parse_procargs(raw)
        self.assertEqual(executable, "/test/python")
        self.assertEqual(arguments, ["python", "source.py", "literal argument"])
        self.assertNotIn("SECRET", json.dumps(arguments))

    def test_procargs_malformed_refused(self) -> None:
        for raw in (b"short", struct.pack("=i", 0) + b"/python\0", struct.pack("=i", 3) + b"/python\0one\0"):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                observer.parse_procargs(raw)

    def test_microsecond_pid_reuse_changes_identity_digest(self) -> None:
        value = {name: "fixture" for name in observer.IDENTITY_FIELDS}
        value.update(pid=123456, uid=os.getuid(), start_tvsec=1, start_tvusec=1)
        changed = {**value, "start_tvusec": 2}
        self.assertNotEqual(observer.identity_digest(value), observer.identity_digest(changed))

    def test_parent_and_status_are_not_identity_fields(self) -> None:
        value = {name: "fixture" for name in observer.IDENTITY_FIELDS}
        self.assertEqual(observer.identity_digest(value), observer.identity_digest({**value, "ppid": 1, "status": "sleeping"}))

    def test_write_collision_preserves_first_bytes(self) -> None:
        path = self.root / "evidence.json"
        observer.write_bytes_new(path, b"first")
        with self.assertRaises(FileExistsError):
            observer.write_bytes_new(path, b"second")
        self.assertEqual(path.read_bytes(), b"first")
        self.assertFalse(list(self.root.glob(".observer-pending-*")))

    def test_duplicate_json_refused(self) -> None:
        with self.assertRaises(ValueError):
            observer.strict_json(b'{"x":1,"x":2}')

    def test_symlink_output_refused(self) -> None:
        source = self.root / "source"
        source.mkdir()
        link = self.root / "link"
        link.symlink_to(source, target_is_directory=True)
        with self.assertRaises(ValueError):
            observer.safe(link / "new")

    def test_injected_toy_categories_keep_raw_zero_and_seven(self) -> None:
        """Invented process identities/events only; no kernel/metadata API is called."""
        source = Path(__file__).absolute().parent / 'fixture_launcher.py'
        provenance_root = self.root / 'provenance'
        provenance_root.mkdir()
        identities, targets = {}, []
        categories = ['original_launch_receipt', 'later_owner_runtime_observation']
        for index, category in enumerate(categories):
            pid = 999999991 + index
            identity = {'pid': pid, 'ppid': 1, 'uid': os.getuid(), 'start_tvsec': 1, 'start_tvusec': index + 1,
                'executable': '/invented/python', 'argv': ['/invented/python', source.name], 'cwd': str(source.parent),
                'ps_start': 'invented', 'ps_argv': 'invented toy argv'}
            identities[pid] = identity
            evidence = provenance_root / f'toy_{index}.json'
            observer.write_new(evidence, {'test_only': True, 'dependency_injection': True,
                'fixture_description': 'invented bytes/identity only; no genuine process provenance or launch claimed',
                'schema_category_under_test': category, 'invented_pid': pid})
            targets.append({'pid': pid, 'label': f'injected_toy_{index}', 'expected_identity': identity,
                'expected_identity_sha256': observer.identity_digest(identity),
                'expected_source': {'path': str(source), 'sha256': observer.sha(source.read_bytes())},
                'owner_provenance': {'category': category,
                    'evidence': {'path': str(evidence), 'sha256': observer.sha(evidence.read_bytes())}}})

        class ToyQueue:
            def __init__(self):
                self.changes, self.closed = [], False
                self.events = [self_event(999999991, 0), self_event(999999992, 1792)]

            def control(self, changes, maximum, timeout):
                if changes:
                    self.changes.extend(changes)
                    return []
                values, self.events = self.events[:maximum], self.events[maximum:]
                return values

            def close(self):
                self.closed = True

        def self_event(pid, data):
            return SimpleNamespace(ident=pid, filter=select.KQ_FILTER_PROC, flags=select.KQ_EV_EOF | select.KQ_EV_ONESHOT,
                fflags=select.KQ_NOTE_EXIT | observer.NOTE_EXITSTATUS, data=data, udata=0)

        queue = ToyQueue()
        request = observer.seal({'schema_version': 2, 'status': 'root_bound_future_exit_observer_request',
            'test_only': True, 'targets': targets, 'max_observation_seconds': 0.1})
        output = self.root / 'observed'
        result = observer.observe(request, output, probe=lambda pid: identities[pid], queue_factory=lambda: queue)
        self.assertTrue(queue.closed)
        self.assertEqual(len(queue.changes), 2)
        self.assertEqual([x['genuine_kernel_exit_code'] for x in result['outcomes']], [0, 7])
        self.assertEqual([x['raw_kernel_event']['data'] for x in result['outcomes']], [0, 1792])
        self.assertEqual([x['owner_provenance_category'] for x in result['outcomes']], categories)
        self.assertEqual(result['owner_provenance_categories'], {'original_launch_receipt': 1, 'later_owner_runtime_observation': 1})
        self.assertTrue(result['test_only'])
        self.assertTrue(result['test_only_dependency_injection'])
        self.assertFalse(result['scientific_or_producer_completion_certified'])
        self.assertFalse(result['later_runtime_evidence_relabelled_as_original_launch'])
        destination = Path(__file__).absolute().parent / 'injected_toy_category_evidence'
        destination.mkdir()
        for path in output.iterdir():
            observer.write_bytes_new(destination / path.name, path.read_bytes())
        (destination / 'invented_provenance_records').mkdir()
        for path in provenance_root.iterdir():
            observer.write_bytes_new(destination / 'invented_provenance_records' / path.name, path.read_bytes())
        observer.write_new(destination / 'toy_inputs.json', {'test_only': True, 'dependency_injection': True,
            'actual_processes_queried_or_subscribed': False, 'actual_genuine_kernel_exit_events': 0,
            'targets': targets, 'request': request})


if __name__ == "__main__":
    unittest.main(verbosity=2)
