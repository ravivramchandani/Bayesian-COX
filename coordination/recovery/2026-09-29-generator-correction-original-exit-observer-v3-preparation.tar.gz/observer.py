"""Read-only Darwin kernel exit observation, with before/after PID identity pins."""

from __future__ import annotations

import argparse
import ctypes
import errno
import hashlib
import json
import os
import select
import struct
import subprocess
import sys
import tempfile
import time
from collections.abc import Callable
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

NOTE_EXITSTATUS = 0x04000000  # Local pinned Darwin SDK; not exposed by Python.
ORIGINAL_PIDS = {62025, 62026, 62027, 62028, 62029, 62030, 64406, 71385, 98854}
PROVENANCE_CATEGORIES = {'original_launch_receipt', 'later_owner_runtime_observation'}
IDENTITY_FIELDS = ("pid", "uid", "start_tvsec", "start_tvusec", "executable", "argv", "cwd", "ps_start", "ps_argv")


class ProcessMissing(RuntimeError):
    """The requested PID is absent or already terminated; no exit code inferred."""


class MetadataUnavailable(RuntimeError):
    """A live process could not be fully identified; it must not be certified."""


def require(condition: bool, message: str) -> None:
    """Refuse an unsafe or unbound observation without changing a process."""
    if not condition:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    """Return exact SHA-256 of bytes, distinct from a JSON content seal."""
    return hashlib.sha256(raw).hexdigest()


def canonical(value: Any) -> str:
    """Hash deterministic strict JSON; ASCII escapes preserve unusual argv bytes."""
    return sha(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())


def seal(value: dict[str, Any]) -> dict[str, Any]:
    """Return a new mapping with its exact internal content hash."""
    require("content_sha256" not in value, "cannot replace a stored content seal")
    return {**value, "content_sha256": canonical(value)}


def strict_json(raw: bytes) -> Any:
    """Reject duplicate keys and nonstandard nonfinite JSON constants."""
    def unique(rows: list[tuple[str, Any]]) -> dict[str, Any]:
        output: dict[str, Any] = {}
        for key, value in rows:
            require(key not in output, "duplicate JSON key")
            output[key] = value
        return output

    def invalid(text: str) -> None:
        raise ValueError("invalid JSON constant: " + text)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)


def safe(path: Path) -> Path:
    """Require an absolute path without traversal or symlink ancestors."""
    value = path.absolute()
    require(".." not in value.parts, "path traversal is forbidden")
    require(not any(parent.is_symlink() for parent in (value, *value.parents)), "linked evidence/output path")
    return value


def write_bytes_new(path: Path, raw: bytes) -> None:
    """Fsync and close new bytes, then install atomically without overwriting."""
    safe(path)
    require(path.parent.is_dir(), "output parent missing")
    descriptor, temporary = tempfile.mkstemp(prefix=".observer-pending-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def write_new(path: Path, value: Any) -> None:
    """Publish one exclusive JSON record; partial records never replace evidence."""
    write_bytes_new(path, (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode())


def parse_procargs(raw: bytes) -> tuple[str, list[str]]:
    """Extract executable and exactly argc argv entries; never retain environment."""
    require(len(raw) >= 5, "short KERN_PROCARGS2 response")
    argc = struct.unpack_from("=i", raw)[0]
    require(1 <= argc <= 4096, "invalid KERN_PROCARGS2 argc")
    end = raw.find(b"\0", 4)
    require(end >= 4, "missing executable terminator")
    executable = os.fsdecode(raw[4:end])
    index = end + 1
    while index < len(raw) and raw[index] == 0:
        index += 1
    arguments = []
    for _ in range(argc):
        end = raw.find(b"\0", index)
        require(end >= index, "missing argv terminator")
        arguments.append(os.fsdecode(raw[index:end]))
        index = end + 1
    require(executable and arguments[0], "empty executable/argv zero")
    return executable, arguments


class BsdInfo(ctypes.Structure):
    """Darwin SDK proc_bsdinfo; microsecond birth times avoid ps-second PID reuse."""

    _fields_ = [(name, ctypes.c_uint32) for name in (
        "flags", "status", "xstatus", "pid", "ppid", "uid", "gid", "ruid", "rgid", "svuid", "svgid", "reserved")]
    _fields_ += [("comm", ctypes.c_char * 16), ("name", ctypes.c_char * 32)]
    _fields_ += [(name, ctypes.c_uint32) for name in ("nfiles", "pgid", "jobc", "tdev", "tpgid")]
    _fields_ += [("nice", ctypes.c_int32), ("start_tvsec", ctypes.c_uint64), ("start_tvusec", ctypes.c_uint64)]


def bsd_info(pid: int) -> BsdInfo:
    """Read libproc metadata only; never consume pbi_xstatus as an exit result."""
    require(sys.platform == "darwin" and ctypes.sizeof(BsdInfo) == 136, "unsupported Darwin proc_bsdinfo layout")
    library = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    function = library.proc_pidinfo
    function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
    function.restype = ctypes.c_int
    value = BsdInfo()
    ctypes.set_errno(0)
    count = function(pid, 3, 0, ctypes.byref(value), ctypes.sizeof(value))
    error = ctypes.get_errno()
    if count == 0 and error == errno.ESRCH:
        raise ProcessMissing("PID is no longer present")
    if count != ctypes.sizeof(value):
        raise MetadataUnavailable(f"proc_pidinfo returned {count} bytes, errno {error}")
    require(value.pid == pid, "libproc PID differs")
    if value.status == 5:  # SDK SZOMB; do not infer an already-exited code.
        raise ProcessMissing("PID is already a zombie before subscription")
    return value


def actual_argv(pid: int) -> tuple[str, list[str]]:
    """Read Darwin KERN_PROCARGS2 and discard its environment bytes immediately."""
    library = ctypes.CDLL(None, use_errno=True)
    function = library.sysctl
    function.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p,
                         ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
    function.restype = ctypes.c_int
    names = (ctypes.c_int * 3)(1, 49, pid)
    length = ctypes.c_size_t()
    if function(names, 3, None, ctypes.byref(length), None, 0) != 0:
        raise MetadataUnavailable(f"proc argv size failed, errno {ctypes.get_errno()}")
    require(4 < length.value <= 4 * 1024 * 1024, "unexpected proc argv size")
    buffer = ctypes.create_string_buffer(length.value)
    if function(names, 3, buffer, ctypes.byref(length), None, 0) != 0:
        raise MetadataUnavailable(f"proc argv read failed, errno {ctypes.get_errno()}")
    return parse_procargs(buffer.raw[:length.value])


def ps_value(pid: int, field: str) -> str:
    """Read a complete ps field without signals, tracing, waiting or priorities."""
    result = subprocess.run(["/bin/ps", "-ww", "-p", str(pid), "-o", field + "="],
                            capture_output=True, text=True, check=False, timeout=5)
    if result.returncode != 0 or not result.stdout.strip():
        raise MetadataUnavailable("ps field missing: " + field)
    return result.stdout.rstrip("\n").strip()


def process_identity(pid: int) -> dict[str, Any]:
    """Capture exact argv, ps text, cwd, UID and microsecond process birth identity."""
    require(type(pid) is int and pid > 1, "positive non-system PID required")
    first = bsd_info(pid)
    executable, arguments = actual_argv(pid)
    result = subprocess.run(["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"],
                            capture_output=True, text=True, check=False, timeout=5)
    directories = [line[1:] for line in result.stdout.splitlines() if line.startswith("n")]
    require(result.returncode == 0 and len(directories) == 1 and Path(directories[0]).is_absolute(), "exact process cwd unavailable")
    ps_uid, ps_start, ps_argv = ps_value(pid, "uid"), ps_value(pid, "lstart"), ps_value(pid, "command")
    final = bsd_info(pid)
    require((first.pid, first.uid, first.start_tvsec, first.start_tvusec) ==
            (final.pid, final.uid, final.start_tvsec, final.start_tvusec), "PID identity changed during metadata capture")
    require(int(ps_uid) == final.uid, "ps/libproc UID differs")
    return {"pid": pid, "ppid": final.ppid, "uid": final.uid, "start_tvsec": final.start_tvsec,
            "start_tvusec": final.start_tvusec, "executable": executable, "argv": arguments,
            "cwd": directories[0], "ps_uid": ps_uid, "ps_start": ps_start, "ps_argv": ps_argv,
            "observed_at_utc": datetime.now(UTC).isoformat()}


def identity_digest(value: dict[str, Any]) -> str:
    """Bind stable identity fields; process status/parentage/timestamp may change."""
    return canonical({name: value[name] for name in IDENTITY_FIELDS})


def file_binding(value: dict[str, str]) -> dict[str, Any]:
    """Check one explicit immutable source or owner-provenance evidence byte pin."""
    require(set(value) == {"path", "sha256"}, "exact source/launch byte binding required")
    require(Path(value["path"]).is_absolute(), "explicit absolute source/launch path required")
    path = safe(Path(value["path"]))
    require(path.is_file(), "source/launch file missing")
    raw = path.read_bytes()
    require(sha(raw) == value["sha256"], "source/launch byte pin differs")
    return {"path": str(path), "sha256": value["sha256"], "bytes": len(raw)}


def owner_provenance_category(value: dict[str, Any]) -> str:
    """Keep root-declared launch and later runtime evidence categories distinct.

    The caller identifies genuine existing evidence before use. A byte pin and
    category never prove a missing launch, a past exit or scientific production.
    Fresh target identity checks remain independently mandatory.
    """
    require(isinstance(value, dict) and set(value) == {'category', 'evidence'}, "exact typed owner provenance required")
    category = value['category']
    require(isinstance(category, str) and category in PROVENANCE_CATEGORIES, "unknown owner provenance category")
    require(isinstance(value['evidence'], dict) and set(value['evidence']) == {'path', 'sha256'}, "exact existing provenance file byte pin required")
    return category


def owner_provenance_binding(value: dict[str, Any]) -> dict[str, Any]:
    """Bind the unchanged existing record bytes and retain their declared category."""
    return {'category': owner_provenance_category(value), 'evidence': file_binding(value['evidence'])}


def argv_source_path(expected: dict[str, Any], declared: str) -> Path:
    """Match the absolute pinned source to a literal argv entry using its cwd.

    A relative script entry is joined only to the recorded absolute cwd. No
    argument is rewritten; traversal/symlink paths cannot supply a match, and
    no filename search or alternate source is attempted.
    """
    source = Path(declared)
    require(source.is_absolute(), "expected source must be absolute")
    source = safe(source)
    cwd = Path(expected["cwd"])
    require(cwd.is_absolute(), "recorded cwd must be absolute")
    cwd = safe(cwd)
    require(cwd.is_dir() and source.is_file(), "recorded cwd/source missing")
    arguments = expected["argv"]
    require(isinstance(arguments, list) and all(isinstance(value, str) for value in arguments), "actual argv list required")
    for argument in arguments:
        if not argument or argument.startswith("-"):
            continue
        literal = Path(argument)
        candidate = literal if literal.is_absolute() else cwd / literal
        if ".." in candidate.parts or candidate != source:
            continue
        candidate = safe(candidate)
        require(candidate.resolve(strict=True) == source, "source resolution differs")
        return candidate
    raise ValueError("absolute pinned source does not match a safe literal argv/cwd path")


def validate_request(request: dict[str, Any]) -> None:
    """Require reviewed explicit identities/sources, exact production scope and no inferred past exit."""
    require(request["schema_version"] == 2 and request["status"] == "root_bound_future_exit_observer_request",
            "explicit root-bound observer request required")
    require(type(request["test_only"]) is bool and isinstance(request["targets"], list) and request["targets"], "target/test scope missing")
    require(request["content_sha256"] == canonical({k: v for k, v in request.items() if k != "content_sha256"}), "request content seal differs")
    targets = request["targets"]
    pids = [row["pid"] for row in targets]
    require(all(type(pid) is int and pid > 1 for pid in pids) and len(set(pids)) == len(pids), "duplicate or unsafe target PID")
    if not request["test_only"]:
        require(set(pids) == ORIGINAL_PIDS, "production observer scope must be original nine PIDs")
    for target in targets:
        expected = target["expected_identity"]
        require(target["label"] and isinstance(target["expected_source"], dict)
                and isinstance(target.get("owner_provenance"), dict) and 'launch_receipt' not in target,
                "source/typed owner provenance/role evidence required; legacy launch key is forbidden")
        owner_provenance_category(target['owner_provenance'])
        if expected is None:
            require(target["expected_identity_sha256"] is None
                    and isinstance(target.get("identity_unavailable_reason"), str)
                    and bool(target["identity_unavailable_reason"].strip()), "explicit unavailable identity reason required")
            continue
        require(expected["pid"] == target["pid"] and expected["uid"] == os.getuid()
                and target["expected_identity_sha256"] == identity_digest(expected), "same-UID expected identity is unbound")
        argv_source_path(expected, target["expected_source"]["path"])
    duration = request.get("max_observation_seconds")
    require(duration is None or isinstance(duration, (int, float)) and not isinstance(duration, bool)
            and 0 < duration <= 7 * 24 * 3600, "invalid observation duration")


def raw_event(event: Any) -> dict[str, int]:
    """Preserve exact kernel ident/filter/flags/fflags/data/udata integers."""
    return {name: int(getattr(event, name)) for name in ("ident", "filter", "flags", "fflags", "data", "udata")}


def decode_exit(event: Any, pid: int) -> dict[str, Any]:
    """Decode only a genuine NOTE_EXIT|NOTE_EXITSTATUS event using wait-status rules."""
    value = raw_event(event)
    require(value["ident"] == pid and value["filter"] == select.KQ_FILTER_PROC, "foreign kernel event")
    require(not value["flags"] & select.KQ_EV_ERROR and value["flags"] & select.KQ_EV_EOF, "kernel event error/no exit EOF")
    require(value["fflags"] & (select.KQ_NOTE_EXIT | NOTE_EXITSTATUS) == select.KQ_NOTE_EXIT | NOTE_EXITSTATUS,
            "kernel did not provide exit status")
    status = value["data"]
    require(status >= 0 and (os.WIFEXITED(status) or os.WIFSIGNALED(status)), "not a terminal wait status")
    return {"raw_kernel_event": value, "raw_wait_status": status, "exit_code": os.waitstatus_to_exitcode(status),
            "normal_exit": os.WIFEXITED(status), "termination_signal": os.WTERMSIG(status) if os.WIFSIGNALED(status) else None,
            "source": "Darwin EVFILT_PROC NOTE_EXIT|NOTE_EXITSTATUS kernel event"}


def observe(request: dict[str, Any], output: Path, *, probe: Callable[[int], dict[str, Any]] = process_identity,
            queue_factory: Callable[[], Any] = select.kqueue) -> dict[str, Any]:
    """Observe future exits; unavailable/raced identities remain uncensored unknowns.

    No target is signalled, traced, reparented, waited for or reprioritized.
    Inputs are explicit root-reviewed byte/identity pins with distinct original
    launch or later runtime provenance categories. These do not certify science.
    Injected backends are
    tests; no injected observation can certify production process evidence.
    """
    require(sys.platform == "darwin", "Darwin kqueue required")
    validate_request(request)
    injected = probe is not process_identity or queue_factory is not select.kqueue
    require(not injected or request["test_only"], "injected backend cannot observe production")
    output = safe(output)
    immutable = [Path(__file__).absolute().parent]
    bindings = {}
    for target in request["targets"]:
        bindings[target["pid"]] = {'expected_source': file_binding(target['expected_source']),
                                   'owner_provenance': owner_provenance_binding(target['owner_provenance'])}
        immutable += [Path(target["expected_source"]["path"]).parent,
                      Path(target["owner_provenance"]['evidence']["path"]).parent]
    require(output.parent.is_dir() and not output.exists() and
            all(not output.is_relative_to(safe(root)) and not safe(root).is_relative_to(output) for root in immutable),
            "new output overlaps source/owner provenance evidence or already exists")
    output.mkdir()
    started, tick = datetime.now(UTC).isoformat(), time.monotonic()
    pending: dict[int, dict[str, Any]] = {}
    outcomes: dict[int, dict[str, Any]] = {}
    events_path = output / "events.jsonl"
    with open(events_path, "xb") as log, closing(queue_factory()) as queue:
        def record(value: dict[str, Any]) -> None:
            log.write((json.dumps(value, sort_keys=True, allow_nan=False) + "\n").encode())
            log.flush()
            os.fsync(log.fileno())

        for target in request["targets"]:
            pid = target["pid"]
            state = {"pid": pid, "label": target["label"], "source_and_provenance_bindings": bindings[pid],
                     'owner_provenance_category': target['owner_provenance']['category'],
                     "expected_identity_sha256": target["expected_identity_sha256"], "test_only": request["test_only"],
                     "genuine_kernel_exit_code": None, "scientific_or_producer_completion_certified": False}
            if target["expected_identity"] is None:
                state.update(status="exit_status_unavailable_identity_not_bound_before_subscription", identity_verified=False,
                             reason=target["identity_unavailable_reason"])
                outcomes[pid] = state
                write_new(output / f"pid_{pid}.disposition.json", seal(state))
                record(state)
                continue
            try:
                before = probe(pid)
                state["identity_before"] = before
                require(before["uid"] == os.getuid() and before["ppid"] != os.getpid(), "same-UID nonchild target required")
                require(identity_digest(before) == target["expected_identity_sha256"], "expected PID identity changed")
                change = select.kevent(pid, filter=select.KQ_FILTER_PROC, flags=select.KQ_EV_ADD | select.KQ_EV_ENABLE,
                                       fflags=select.KQ_NOTE_EXIT | NOTE_EXITSTATUS)
                state["registration_requested_at_utc"] = datetime.now(UTC).isoformat()
                queue.control([change], 0, 0)
                state["registration_accepted_at_utc"] = datetime.now(UTC).isoformat()
                after = probe(pid)
                state["identity_after"] = after
                require(identity_digest(after) == identity_digest(before), "PID identity changed after registration")
                state.update(status="future_kernel_exit_subscription_identity_verified", identity_verified=True)
                write_new(output / f"pid_{pid}.registration.json", seal(state))
                pending[pid] = state
                record(state)
            except (ProcessMissing, MetadataUnavailable, OSError, ValueError) as error:
                state.update(status="exit_status_unavailable_registration_not_identity_verified", identity_verified=False,
                             error={"type": type(error).__name__, "message": str(error)})
                outcomes[pid] = state
                write_new(output / f"pid_{pid}.disposition.json", seal(state))
                record(state)
        write_new(output / "subscriptions.json", seal({"status": "future_exit_subscriptions_accounted", "registered_pids": sorted(pending),
            "unavailable_pids": sorted(outcomes), "test_only": request["test_only"], "past_exit_status_inference": False}))
        maximum = request.get("max_observation_seconds")
        while pending:
            if maximum is not None and time.monotonic() - tick >= maximum:
                for pid, state in pending.items():
                    state = {**state, "status": "exit_status_unavailable_observation_timeout"}
                    outcomes[pid] = state
                    write_new(output / f"pid_{pid}.disposition.json", seal(state))
                    record(state)
                pending.clear()
                break
            for event in queue.control(None, max(1, len(pending)), 1.0):
                raw = raw_event(event)
                pid = raw["ident"]
                if pid not in pending:
                    record({"status": "unverified_registration_kernel_event_retained", "raw_kernel_event": raw,
                            "genuine_target_exit_code": None, "test_only": request["test_only"]})
                    continue
                state = pending.pop(pid)
                try:
                    decoded = decode_exit(event, pid)
                    state = {**state, **decoded, "status": "genuine_future_kernel_exit_status_observed",
                             "genuine_kernel_exit_code": decoded["exit_code"], "event_observed_at_utc": datetime.now(UTC).isoformat()}
                except ValueError as error:
                    state = {**state, "status": "exit_status_unavailable_kernel_event_invalid", "raw_kernel_event": raw,
                             "error": {"type": type(error).__name__, "message": str(error)}}
                outcomes[pid] = state
                write_new(output / f"pid_{pid}.event.json", seal(state))
                record(state)
        # Registration races do not earn an identity-bound status, but retain
        # any already queued raw event before this owned queue is closed.
        for event in queue.control(None, max(1, len(request["targets"])), 0):
            record({"status": "unverified_registration_kernel_event_retained", "raw_kernel_event": raw_event(event),
                    "genuine_target_exit_code": None, "test_only": request["test_only"]})
    for target in request["targets"]:
        file_binding(target['expected_source'])
        owner_provenance_binding(target['owner_provenance'])
    observed = [value for value in outcomes.values() if value["status"] == "genuine_future_kernel_exit_status_observed"]
    inventory = {path.name: {"sha256": sha(path.read_bytes()), "bytes": path.stat().st_size} for path in sorted(output.iterdir())}
    result = seal({"status": "future_exit_observer_finished_accounting", "request_content_sha256": request["content_sha256"],
        "started_at_utc": started, "finished_at_utc": datetime.now(UTC).isoformat(), "observer_pid": os.getpid(),
        "target_count": len(request["targets"]), "genuine_future_exit_status_count": len(observed),
        "exit_status_unavailable_count": len(outcomes) - len(observed), "outcomes": [outcomes[pid] for pid in sorted(outcomes)],
        "test_only": request["test_only"], "test_only_dependency_injection": injected, "artifacts": inventory,
        'owner_provenance_categories': {category: sum(target['owner_provenance']['category'] == category
                                                    for target in request['targets']) for category in sorted(PROVENANCE_CATEGORIES)},
        'later_runtime_evidence_relabelled_as_original_launch': False,
        "past_exit_status_inferred": False, "scientific_or_producer_completion_certified": False,
        "no_signal_trace_reparent_waitpid_priority_or_owner_change": True})
    write_new(output / "receipt.json", result)
    return result


def bind_preparation(request: dict[str, Any]) -> None:
    """Require sealed tested observer source before any real target subscription."""
    binding = request["preparation_receipt"]
    path = safe(Path(binding["path"]))
    raw = path.read_bytes()
    require(sha(raw) == binding["sha256"], "observer preparation receipt byte pin differs")
    receipt = strict_json(raw)
    require(receipt["content_sha256"] == canonical({k: v for k, v in receipt.items() if k != "content_sha256"})
            and receipt["status"] == "darwin_future_exit_observer_prepared"
            and receipt["actual_production_processes_subscribed"] is False,
            "tested no-production observer preparation required")
    require(receipt["implementation_source_sha256"] == sha(Path(__file__).absolute().read_bytes()), "observer source byte pin differs")


def main() -> None:
    """Snapshot metadata or observe a reviewed future scope; never retroactively infer rc0."""
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="operation", required=True)
    snapshot = commands.add_parser("snapshot")
    snapshot.add_argument("--pid", type=int, required=True)
    observer = commands.add_parser("observe")
    observer.add_argument("--request", type=Path, required=True)
    observer.add_argument("--request-sha256", required=True)
    observer.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.operation == "snapshot":
        print(json.dumps(process_identity(args.pid), sort_keys=True, allow_nan=False))
        return
    raw = safe(args.request).read_bytes()
    require(sha(raw) == args.request_sha256, "request byte pin differs")
    request = strict_json(raw)
    bind_preparation(request)
    result = observe(request, args.output)
    require(sha(args.request.read_bytes()) == args.request_sha256, "request changed during observation")
    print(json.dumps({"status": result["status"], "receipt_path": str(args.output / "receipt.json"),
        "receipt_sha256": sha((args.output / "receipt.json").read_bytes()), "test_only": result["test_only"],
        "genuine_future_exit_status_count": result["genuine_future_exit_status_count"],
        "exit_status_unavailable_count": result["exit_status_unavailable_count"],
        'owner_provenance_categories': result['owner_provenance_categories'],
        "scientific_or_producer_completion_certified": False}, sort_keys=True))


if __name__ == "__main__":
    main()
