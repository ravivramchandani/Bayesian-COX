"""Disposable same-UID orphan fixture; no production PID is accepted or used."""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path


def main() -> None:
    """Fork one fixture, let its parent exit, and self-exit after a file gate."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pid-file", type=Path, required=True)
    parser.add_argument("--release-file", type=Path, required=True)
    parser.add_argument("--exit-code", type=int, choices=(0, 7), required=True)
    args = parser.parse_args()
    if args.pid_file.exists() or args.release_file.exists():
        raise RuntimeError("exclusive disposable fixture paths required")
    parent_pid = os.getpid()
    child = os.fork()
    if child:
        os._exit(0)
    # The orphan must not retain the launcher's subprocess capture pipes.
    null = os.open(os.devnull, os.O_RDWR)
    for descriptor in (0, 1, 2):
        os.dup2(null, descriptor)
    if null > 2:
        os.close(null)
    deadline = time.monotonic() + 30
    while os.getppid() == parent_pid:
        if time.monotonic() >= deadline:
            os._exit(112)
        time.sleep(0.005)
    with open(args.pid_file, "x") as stream:
        json.dump({"pid": os.getpid(), "ppid": os.getppid(), "uid": os.getuid(),
                   "requested_exit_code": args.exit_code, "test_only": True}, stream)
        stream.flush()
        os.fsync(stream.fileno())
    while not args.release_file.exists():
        if time.monotonic() >= deadline:
            os._exit(113)
        time.sleep(0.005)
    # The fixture, not the observer, decides to terminate itself.
    if args.release_file.read_bytes() != b"disposable-fixture-release\n":
        os._exit(114)
    os._exit(args.exit_code)


if __name__ == "__main__":
    main()
