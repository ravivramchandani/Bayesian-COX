"""Injected guard fixtures; no OS process metadata or kqueue subscription occurs."""

from __future__ import annotations

import json
import os
import select
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import observer


class FakeQueue:
    """Record invented registrations/events while never invoking kernel control."""

    def __init__(self) -> None:
        self.changes = []
        self.events = []
        self.closed = False

    def control(self, changes, maximum, timeout):
        if changes:
            self.changes.extend(changes)
            return []
        result, self.events = self.events[:maximum], self.events[maximum:]
        return result

    def close(self) -> None:
        self.closed = True


class GuardFixtures(unittest.TestCase):
    """Only transparent invented bytes/identities and injected no-kernel backends."""

    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="pure-exit-guards-")
        self.root = Path(self.temp.name).resolve()
        launch = self.root / "launch"
        launch.mkdir()
        self.launch = launch / "fixture.json"
        self.launch.write_text('{"test_only":true}\n')
        self.source = Path(__file__).absolute().parent / "fixture_launcher.py"
        self.identity = {"pid": 999999999, "ppid": 1, "uid": os.getuid(), "start_tvsec": 1, "start_tvusec": 2,
            "executable": "/invented/python", "argv": ["/invented/python", str(self.source)], "cwd": str(self.root),
            "ps_start": "invented start", "ps_argv": "invented argv"}
        self.target = {"pid": self.identity["pid"], "label": "invented_guard_only", "expected_identity": self.identity,
            "expected_identity_sha256": observer.identity_digest(self.identity),
            "expected_source": {"path": str(self.source), "sha256": observer.sha(self.source.read_bytes())},
            "owner_provenance": {"category": "original_launch_receipt",
                "evidence": {"path": str(self.launch), "sha256": observer.sha(self.launch.read_bytes())}}}

    def tearDown(self) -> None:
        self.temp.cleanup()

    def request(self, **changes):
        return observer.seal({"schema_version": 2, "status": "root_bound_future_exit_observer_request",
            "test_only": True, "targets": [self.target], "max_observation_seconds": 0.01, **changes})

    def test_production_scope_is_exact_nine_pids(self):
        with self.assertRaises(ValueError):
            observer.validate_request(self.request(test_only=False))
        self.assertNotIn(64435, observer.ORIGINAL_PIDS)

    def test_duplicate_pid_request_refused(self):
        with self.assertRaises(ValueError):
            observer.validate_request(self.request(targets=[self.target, self.target]))

    def test_uid_and_identity_pin_refused(self):
        self.target["expected_identity_sha256"] = "different"
        with self.assertRaises(ValueError):
            observer.validate_request(self.request())

    def test_expected_source_must_be_actual_argv(self):
        self.identity["argv"] = ["different"]
        self.target["expected_identity_sha256"] = observer.identity_digest(self.identity)
        with self.assertRaises(ValueError):
            observer.validate_request(self.request())

    def test_relative_literal_script_matches_exact_recorded_cwd(self):
        expected = {**self.identity, "cwd": str(self.source.parent), "argv": ["python", "-B", self.source.name]}
        before = list(expected["argv"])
        self.assertEqual(observer.argv_source_path(expected, str(self.source)), self.source)
        self.assertEqual(expected["argv"], before)

    def test_relative_script_mismatched_cwd_refused(self):
        expected = {**self.identity, "cwd": str(self.root), "argv": ["python", self.source.name]}
        with self.assertRaises(ValueError):
            observer.argv_source_path(expected, str(self.source))

    def test_relative_script_traversal_refused(self):
        expected = {**self.identity, "cwd": str(self.source.parent), "argv": ["python", "../" + self.source.parent.name + "/" + self.source.name]}
        with self.assertRaises(ValueError):
            observer.argv_source_path(expected, str(self.source))

    def test_script_symlink_alias_refused(self):
        alias = self.root / "alias.py"
        alias.symlink_to(self.source)
        expected = {**self.identity, "cwd": str(self.root), "argv": ["python", "alias.py"]}
        with self.assertRaises(ValueError):
            observer.argv_source_path(expected, str(self.source))

    def test_recorded_cwd_symlink_refused(self):
        alias = self.root / "cwd_alias"
        alias.symlink_to(self.source.parent, target_is_directory=True)
        expected = {**self.identity, "cwd": str(alias), "argv": ["python", self.source.name]}
        with self.assertRaises(ValueError):
            observer.argv_source_path(expected, str(self.source))

    def test_expected_source_relative_pin_refused(self):
        with self.assertRaises(ValueError):
            observer.argv_source_path(self.identity, self.source.name)

    def test_unavailable_identity_never_probes_or_subscribes(self):
        self.target.update(expected_identity=None, expected_identity_sha256=None,
                           identity_unavailable_reason="invented past absence; status unknown")
        queue = FakeQueue()
        def forbidden(pid):
            raise AssertionError("an unbound unavailable PID must never be probed")
        result = observer.observe(self.request(), self.root / "output", probe=forbidden, queue_factory=lambda: queue)
        self.assertEqual(queue.changes, [])
        self.assertTrue(queue.closed)
        self.assertEqual(result["genuine_future_exit_status_count"], 0)
        self.assertIsNone(result["outcomes"][0]["genuine_kernel_exit_code"])

    def test_expected_identity_change_blocks_registration(self):
        queue = FakeQueue()
        result = observer.observe(self.request(), self.root / "output",
            probe=lambda pid: {**self.identity, "start_tvusec": 3}, queue_factory=lambda: queue)
        self.assertEqual(queue.changes, [])
        self.assertEqual(result["exit_status_unavailable_count"], 1)

    def test_after_registration_race_retains_raw_unknown_event(self):
        queue = FakeQueue()
        queue.events = [SimpleNamespace(ident=self.identity["pid"], filter=select.KQ_FILTER_PROC,
            flags=select.KQ_EV_EOF, fflags=select.KQ_NOTE_EXIT | observer.NOTE_EXITSTATUS, data=7 << 8, udata=0)]
        rows = iter([self.identity, {**self.identity, "start_tvusec": 3}])
        output = self.root / "output"
        result = observer.observe(self.request(), output, probe=lambda pid: next(rows), queue_factory=lambda: queue)
        self.assertEqual(len(queue.changes), 1)
        self.assertEqual(result["genuine_future_exit_status_count"], 0)
        self.assertIsNone(result["outcomes"][0]["genuine_kernel_exit_code"])
        raw = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]
        self.assertEqual(raw[-1]["raw_kernel_event"]["data"], 1792)
        self.assertIsNone(raw[-1]["genuine_target_exit_code"])

    def test_pending_observation_timeout_has_unknown_status(self):
        queue = FakeQueue()
        result = observer.observe(self.request(), self.root / "output",
            probe=lambda pid: self.identity, queue_factory=lambda: queue)
        self.assertEqual(result["outcomes"][0]["status"], "exit_status_unavailable_observation_timeout")
        self.assertIsNone(result["outcomes"][0]["genuine_kernel_exit_code"])

    def test_collision_refused_before_registration(self):
        output = self.root / "output"
        output.mkdir()
        queue = FakeQueue()
        with self.assertRaises(ValueError):
            observer.observe(self.request(), output, probe=lambda pid: self.identity, queue_factory=lambda: queue)
        self.assertEqual(queue.changes, [])

    def test_source_pin_mismatch_refused_before_registration(self):
        self.target["expected_source"]["sha256"] = "different"
        queue = FakeQueue()
        with self.assertRaises(ValueError):
            observer.observe(self.request(), self.root / "output", probe=lambda pid: self.identity, queue_factory=lambda: queue)
        self.assertEqual(queue.changes, [])


    def test_later_runtime_category_kept_without_launch_claim(self):
        self.target['owner_provenance']['category'] = 'later_owner_runtime_observation'
        queue = FakeQueue()
        result = observer.observe(self.request(), self.root / 'output',
            probe=lambda pid: self.identity, queue_factory=lambda: queue)
        state = result['outcomes'][0]
        self.assertEqual(state['owner_provenance_category'], 'later_owner_runtime_observation')
        self.assertEqual(state['source_and_provenance_bindings']['owner_provenance']['category'], 'later_owner_runtime_observation')
        self.assertEqual(result['owner_provenance_categories'], {'original_launch_receipt': 0, 'later_owner_runtime_observation': 1})
        self.assertNotIn('source_and_launch_bindings', state)
        self.assertFalse(result['later_runtime_evidence_relabelled_as_original_launch'])
        self.assertFalse(result['scientific_or_producer_completion_certified'])
        self.assertIsNone(state['genuine_kernel_exit_code'])

    def test_unknown_provenance_category_refused_before_registration(self):
        self.target['owner_provenance']['category'] = 'invented_launch_reconstruction'
        queue = FakeQueue()
        with self.assertRaises(ValueError):
            observer.observe(self.request(), self.root / 'output',
                probe=lambda pid: self.identity, queue_factory=lambda: queue)
        self.assertEqual(queue.changes, [])

    def test_missing_category_and_legacy_launch_key_refused(self):
        binding = self.target.pop('owner_provenance')
        self.target['launch_receipt'] = binding['evidence']
        with self.assertRaises(ValueError):
            observer.validate_request(self.request())
        self.target.pop('launch_receipt')
        self.target['owner_provenance'] = {'evidence': binding['evidence']}
        with self.assertRaises(ValueError):
            observer.validate_request(self.request())
        self.target['owner_provenance'] = binding
        with self.assertRaises(ValueError):
            observer.validate_request(self.request(schema_version=1))

    def test_provenance_pin_mismatch_refused_before_registration(self):
        self.target['owner_provenance']['category'] = 'later_owner_runtime_observation'
        self.target['owner_provenance']['evidence']['sha256'] = 'different'
        queue = FakeQueue()
        with self.assertRaises(ValueError):
            observer.observe(self.request(), self.root / 'output',
                probe=lambda pid: self.identity, queue_factory=lambda: queue)
        self.assertEqual(queue.changes, [])

    def test_both_provenance_categories_require_fresh_identity(self):
        for category in sorted(observer.PROVENANCE_CATEGORIES):
            with self.subTest(category=category):
                self.target['owner_provenance']['category'] = category
                queue = FakeQueue()
                result = observer.observe(self.request(), self.root / category,
                    probe=lambda pid: {**self.identity, 'start_tvusec': 3}, queue_factory=lambda queue=queue: queue)
                self.assertEqual(queue.changes, [])
                self.assertEqual(result['genuine_future_exit_status_count'], 0)
                self.assertIsNone(result['outcomes'][0]['genuine_kernel_exit_code'])

    def test_later_runtime_provenance_output_overlap_refused(self):
        self.target['owner_provenance']['category'] = 'later_owner_runtime_observation'
        queue = FakeQueue()
        with self.assertRaises(ValueError):
            observer.observe(self.request(), self.launch.parent / 'output',
                probe=lambda pid: self.identity, queue_factory=lambda: queue)
        self.assertEqual(queue.changes, [])

    def test_later_runtime_unavailable_identity_never_probes(self):
        self.target['owner_provenance']['category'] = 'later_owner_runtime_observation'
        self.test_unavailable_identity_never_probes_or_subscribes()

    def test_later_runtime_registration_race_remains_unknown(self):
        self.target['owner_provenance']['category'] = 'later_owner_runtime_observation'
        self.test_after_registration_race_retains_raw_unknown_event()


if __name__ == "__main__":
    unittest.main(verbosity=2)
