"""Capture genuine portable-fixture checks; no controller or scientific dispatch."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

THREADS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")


def safe(path: Path) -> Path:
    if not path.is_absolute() or ".." in path.parts or any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError("absolute unlinked check path required")
    return path


def binding(path: Path) -> dict:
    safe(path)
    if not path.is_file():
        raise ValueError("regular check source required")
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def tree(path: Path) -> dict:
    safe(path)
    files, directories = {}, []
    for member in sorted(path.rglob("*")):
        if member.is_symlink() or not (member.is_file() or member.is_dir()):
            raise ValueError("unsafe source/scratch node")
        relative = str(member.relative_to(path))
        if member.is_file():
            files[relative] = binding(member)
        else:
            directories.append(relative)
    return {"files": files, "directories": directories}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("python", "repository-root", "source-root", "scratch-root"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--check", choices=("unittest", "pytest", "ruff", "ast"), required=True)
    args = parser.parse_args()
    supplied_python = args.python
    if not supplied_python.is_absolute() or not supplied_python.is_file() or not os.path.samefile(supplied_python, sys.executable):
        raise ValueError("same executing locked interpreter required")
    repository, source, scratch = map(safe, (args.repository_root, args.source_root, args.scratch_root))
    here = safe(Path(__file__).absolute().parent)
    if not scratch.is_dir() or any(scratch == role or scratch.is_relative_to(role) or role.is_relative_to(scratch)
                                   for role in (source, repository)):
        raise ValueError("disjoint existing check scratch required")
    if not args.prefix or any(ch not in "abcdefghijklmnopqrstuvwxyz0123456789_" for ch in args.prefix):
        raise ValueError("owned ordinary capture prefix required")
    outputs = {role: here / (args.prefix + "." + suffix) for role, suffix in
               (("stdout", "stdout.log"), ("stderr", "stderr.log"), ("invocation", "invocation.json"))}
    if any(path.exists() for path in outputs.values()):
        raise ValueError("fresh capture prefix required")
    sources = [here / name for name in ("guarded_dispatch_repository_adapter.py", "test_catalytic_correction_guarded_dispatch.py", "capture_adapter_checks.py")]
    support = repository / "scripts/catalytic_correction"
    predecessors = [support / name for name in ("fit_common.py", "fit_controller.py", "fit_child.py")]
    predecessors += [support / "reproduction" / name for name in ("reproduction_core.py", "run_reproduction.py", "terminal_replay_child.py")]
    before = {str(path): binding(path) for path in [*sources, *predecessors]}
    carrier_before, scratch_before = tree(source), tree(scratch)
    environment = {**os.environ, **{key: "1" for key in THREADS}, "PYTHONDONTWRITEBYTECODE": "1",
                   "BAYES_COX_GUARD_TEST_REPOSITORY_ROOT": str(repository),
                   "BAYES_COX_GUARD_TEST_SOURCE_ROOT": str(source),
                   "BAYES_COX_GUARD_TEST_FIXTURE_ROOT": str(scratch)}
    if args.check == "unittest":
        driver = (
            "import importlib.util,json,sys,types,unittest;from pathlib import Path;"
            "pre={n:types.ModuleType(n) for n in ('src','src.__fictional_caller','fit_common','_reproduction_bound_common','_fictional_guard_core','_fictional_guard_capture')};"
            "sys.modules.update(pre);p=Path(sys.argv[1]);s=importlib.util.spec_from_file_location('_captured_guard_adapter_tests',p);"
            "m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);"
            "assert all(sys.modules[n] is v for n,v in pre.items());suite=unittest.defaultTestLoader.loadTestsFromModule(m);"
            "expected=len(m._retained.original_methods)+1;assert suite.countTestCases()==expected;"
            "r=unittest.TextTestRunner(verbosity=2).run(suite);"
            "assert all(sys.modules[n] is v for n,v in pre.items());v=m._retained.report();m._retained.close();"
            "v.update({'tests_run':r.testsRun,'errors':len(r.errors),'failures':len(r.failures),'expected_tests':expected,'preexisting_src_and_alias_objects_restored':True});"
            "print(json.dumps(v,sort_keys=True));raise SystemExit(0 if r.wasSuccessful() else 1)"
        )
        argv = [str(supplied_python), "-I", "-B", "-c", driver, str(sources[1])]
    elif args.check == "pytest":
        argv = [str(supplied_python), "-I", "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", str(sources[1])]
    elif args.check == "ruff":
        argv = [str(supplied_python), "-I", "-B", "-m", "ruff", "check", "--no-cache", *map(str, sources)]
    else:
        driver = "import ast,sys;from pathlib import Path;[ast.parse(Path(p).read_bytes(),filename=p) for p in sys.argv[1:]];print('AST3 source-only parse passed')"
        argv = [str(supplied_python), "-I", "-B", "-c", driver, *map(str, sources)]
    started, error, returncode = datetime.now(UTC).isoformat(), None, None
    with outputs["stdout"].open("xb") as stdout, outputs["stderr"].open("xb") as stderr:
        try:
            result = subprocess.run(argv, cwd=here, env=environment, stdout=stdout, stderr=stderr, check=False, timeout=60)
            if type(result.returncode) is not int:
                raise ValueError("typed actual check return required")
            returncode = result.returncode
        except BaseException as exception:  # noqa: BLE001 - retain interrupted owned check evidence
            error = {"type": type(exception).__name__, "message": str(exception)}
    after = {str(path): binding(path) for path in [*sources, *predecessors]}
    value = {"schema_version": 1, "operation": "portable_guard_fictional_implementation_check", "check": args.check,
             "argv": argv, "cwd": str(here), "python": str(supplied_python), "samefile_current_interpreter": True,
             "numeric_environment": {name: environment[name] for name in THREADS}, "started_at_utc": started,
             "finished_at_utc": datetime.now(UTC).isoformat(), "returncode": returncode, "error": error,
             "source_before": before, "source_after": after, "source_unchanged": before == after,
             "carrier_unchanged": carrier_before == tree(source), "scratch_before": scratch_before,
             "scratch_after": tree(scratch), "owned_fixture_cleanup_complete": scratch_before == tree(scratch),
             "raw_logs": {role: binding(outputs[role]) for role in ("stdout", "stderr")},
             "actual_controller_scientific_or_original_owner_invoked": False, "actual_approval_created": False}
    value["content_sha256"] = hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    with outputs["invocation"].open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"returncode": returncode, "error": error, "source_unchanged": value["source_unchanged"],
                      "carrier_unchanged": value["carrier_unchanged"], "owned_fixture_cleanup_complete": value["owned_fixture_cleanup_complete"]}, sort_keys=True))
    if returncode != 0 or error is not None or not all(value[name] for name in ("source_unchanged", "carrier_unchanged", "owned_fixture_cleanup_complete")):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
