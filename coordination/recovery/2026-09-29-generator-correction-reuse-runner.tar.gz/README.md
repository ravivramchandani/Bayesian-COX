# Independent original-first-draw and exact input reuse runner

This prepares a concrete, serial, threads1 implementation for the full1,650
generator contexts and1,625 original outer jobs. The preparer ran only
invented/injected tests, including tiny fake-source normal-import child
fixtures. No programme data/arrays/traces/generator/SVD/model/optimizer/MCMC,
predictions, new scores, full-grid replay or reuse acquisition ran here.
Root owns review, integration, actual execution and any later freeze.

## Invocation and dependencies

Keep the three implementation files as siblings and invoke `run_reuse.py`
directly using the exact lock Python with `-B`. The controller refuses a
preloaded `src` namespace. Helpers are loaded from explicit byte-pinned
files under private names; science is normally imported only from the clean
sealed119476f checkout. There are no local username defaults.

Required path arguments are `--source`, `--run`, `--matched`, `--inventory`
(unchanged recipe preparation), `--candidate-module`, `--correction-config`,
`--correction-addendum`, `--preflight-output`, `--preflight-core`,
`--preflight-runner`, `--contracts-module`, `--output` and `--python`.

Explicit reviewed SHA arguments are `--candidate-sha256`,
`--preflight-core-sha256`, `--preflight-runner-sha256`, `--contracts-sha256`,
`--reuse-core-sha256`, `--reuse-runner-sha256`, `--first-draw-child-sha256`,
`--preflight-manifest-sha256`, `--preflight-completion-sha256`,
`--correction-config-sha256` and `--correction-addendum-sha256`.

Set `OPENBLAS_NUM_THREADS`, `OMP_NUM_THREADS`, `MKL_NUM_THREADS`,
`VECLIB_MAXIMUM_THREADS` and `NUMEXPR_NUM_THREADS` to1 before Python starts.
Use a supporting external APFS directory separate from source, original run,
preflight and preparation modules. Writable caches stay in the output.
The same resolved lock interpreter runs each child. The unchanged original
259-package environment verifier must pass and its complete report must
equal the actual preflight report before cohort construction.

There is no partial-production coverage option. Complete ordered1,650
preflight contexts, all retained attempts and every numeric archive are
checked. Original source/data/config/manifest/matched hashes are verified by
the pinned preflight binding API, and all1,625 original jobs are rebuilt
normally against the frozen manifest.

## Independent first-draw replay

The controller reconstructs original outer or WME inner training using
original functions, with administrative censoring before inner splitting.
Ordered membership, local preprocessing, encoded training and source-value
witnesses must equal the completed preflight input exactly.

For each constructable context a new owned `-I -B` child receives only its
full raw training frame, censored training time/event and feature recipe.
No heldout rows/arrays are transported. It independently fits the original
preprocessor by a normal original-source import. The full raw and learned
state/real-design/source values are checked before the untouched generator
runs once with the original generation seed. The only scoped alias captures
constructor inputs and delegates the unchanged original `CatalyticData`
constructor; the alias is restored in `finally`. The exact original rank
guard is identified by exception type/message and terminal traceback code
identity. It does not draw again or use candidate adapter/helper code.

The accepted first proposal, rejected original constructor arrays and
nonrank/input failures are compared with preflight attempt000. Equality
requires exact dtype, shape and C-order element bytes for design/time/hazard/
scale, complete processor state and actual returned metadata or its genuine
absence. A matching legacy JSON hash alone is insufficient. A first input
failure is explicitly accounted as no generator call, rather than pretending
that a constructor array exists. Supplementary preflight SVD measurements
do not control this replay; the original constructor itself supplies its
original rank decision during actual execution.

Each child has an exclusive owned claim. Temporary, locally created pickle
transport is byte-bound before use; no external pickle input is accepted.
Only that verified temporary transport is discarded after its completed
child receipt is acquired. The immutable request binds its bytes and all
input witnesses. Full raw expression transport and independent rebuilding
may cost memory/time; no candidate restoration optimization is substituted
in this independent route. Parent/controller and per-context claims serialize
ownership. Valid completed receipts resume; a partial child without a
completed receipt stops for explicit review instead of being overwritten.
`--recover-stale-claims` covers only proven-dead local owned controller/
context claims, never original run claims or partial child evidence.

## Whole-cell input witnesses

The builder reconstructs all825 catalytic and800 comparator jobs. Each role
has a transparent sealed proof JSON containing both original and corrected
values/digests. The nineteen common roles cover ordered raw training/heldout
values/dtypes/index, censored outcomes, full preprocessing/feature order,
encoded arrays, source closures, model/fit/config, environment, seed ledger,
ordered tuning candidates, all inner dependencies and input-only evaluation
horizons/grid/IPCW truncation. These horizon/truncation helpers never predict
or calculate a new score.

Fixed/adaptive roles add the outer constructor and legacy metadata/absence.
WME adds seven roles for each of three inner folds, totaling42. All three
shared inner designs and all nine candidate recipe/seed slots are explicit,
including unreachable stages. Original/corrected ordinary input roles use
exact pinned-source reconstruction, labelled as such; an old cell is never
said to have saved an array that it did not save.

Fresh original acquisition validates cell byte/content, saved ordered
memberships/header/processor/legacy synthetic metadata/prediction outcomes
where available, actual referenced traces and retained orphan bytes. Trace
keys are run-relative `traces/<original_cell_id>/<filename>`. Original trace
content is only stream hashed by this builder; deep diagnostics belong to
the separate mixed verifier. The original fit attempt rows do not normally
record seeds: their ordering/budget is checked and the seed ledger is an
explicit source-bound reconstruction, not invented stored seed evidence.

Saved tuning is checked against original candidate order, the exact NumPy
mean of already recorded score values and stable ties. It never generates
fresh scores. The tuning digest is canonical JSON of
`{"selected_parameters": ..., "inner_tuning": ...}` only when both fields
are genuinely recorded. Missing original candidate records remain missing.

The pinned contracts classify exact unchanged complete/failed/diagnostic
outcomes equally. Changed inner WME inputs require retuning; an outer-only
change may retain a genuinely saved selection after complete dependency
proof. A terminal corrected input failure is retained with no fit. Missing
or claimed original cells never launch a changed fit or duplicate work.
The immutable `selection_scope` records ID/model/setting/gene budget/n_train/p
independently of original availability, so a pending larger pilot position
cannot be silently replaced by a smaller ready one.

## Artifact/schema contract

All sealed JSON uses `content_sha256` over strict canonical JSON excluding
that field. Array witnesses are `dtype`, `shape` and `values_sha256`; scalars
preserve shape `[]`. Artifact maps use `{sha256,bytes}`.

- `definition.json`: scientific source/input/config/environment/correction
  policy and implementation hashes. It excludes actual original outcome
  snapshots, reuse classifications and any future freeze, preventing a cycle.
- `manifest.json`: separately binds that definition, actual complete preflight
  manifest/completion bytes, source paths and current implementation bytes.
- `replay/contexts/<id>/<outer|inner_01..03>/receipt.json`: independent actual
  original replay plus exact first-draw assessment and child artifacts.
- `replay/completion.json`: all1,650 ordered replay positions. Outcome receipt
  paths are relative to overall output; its artifact map is relative to the
  owning `replay` directory, as required by generic artifact verification.
- `arithmetic_selector.json`: all1,650 context entries separate changed accepted
  inputs, unchanged first draws and terminal input/rank/nonrank outcomes.
  Every changed accepted context binds original/accepted array witnesses and
  preflight/replay receipts. Fixed and adaptive contexts both require kappa
  validation; WME requires q/gradient/tau and weighted merged Breslow checks.
  Selection neither executes nor certifies arithmetic.
- `cells/<id>/input_witness.json`: `fit_witness` carrier with19/21/42 Comparison
  records, unchanged original/corrected seed ledgers, generator receipt pairs
  and `original_evidence:null`; immutable selection scope and all nine WME
  recipe slots. `proof_artifacts`/`artifacts` paths are relative to this file's
  parent, for example `roles/encoded_validation.json`.
- `cells/<id>/roles/<role>.json`: role identity, basis, transparent original/
  corrected values and their digests, plus definition/cell/content bindings.
- `cells/<id>/source_snapshots/<digest>.json`: standalone source-verification
  receipt with saved cell, actual cell/trace/tuning/claim bindings. Its byte
  hash becomes SourceEvidence.verification_receipt_sha256; there is no cycle.
- `cells/<id>/snapshots/<digest>.json`: fresh SourceEvidence, contracts decision,
  `potential_action` and owner-blocked `action`, selection and input witness
  hashes. Artifact paths are relative to the cell directory, not this nested
  snapshot directory; consumers must normalize against that documented base.
- `inventories/<content_digest>/inventory.json`: complete1,625 ordered entries,
  definition/preflight/replay/arithmetic-selector hashes, witness/snapshot
  output-relative paths/byte hashes, decisions and original acquisition state.
  Its top-level `selection_scope` keeps complete changed accepted input
  positions, including pending/claimed original owners. Arithmetic accounting
  is bound by the selector; actual arithmetic review remains a separate gate.

Pending source acquisition adds new immutable source snapshots/classifications
and a new inventory version pointing to the same input witness and definition.
It does not rewrite an existing inventory or automatically update a chosen
freeze. Root reviews and binds the chosen version before dispatch. Invalid,
altered, linked, incomplete or extra proposal checkpoints stop verification;
they are never silently skipped or overwritten.

## Runtime bridge for a later independently owned fit

Inject byte-pinned helper modules into `sys.modules['_reuse_bound_core']` and
`['_reuse_bound_contracts']` before loading `reuse_core.py` privately. Its
`reconstruction_inputs(job,raw,backend,ledger)` and
`common_role_values(job,context,backend)` expose reconstruction-only inputs.

`verify_execution_inputs` accepts original job/raw/normal runner/fitting,
primary/config manifest, the sealed witness and its actual file byte SHA,
cell-parent `witness_directory`, a fresh exact259 report and hash-verified
accepted `preflight_contexts`. It reconstructs every corrected common/inner
role, compares full transparent proof values/digests, validates real/synthetic
array inputs and original/retry seeds, and returns small corrected role
hashes plus ephemeral training/processor/time/event objects for each generator
context. It never draws, fits, predicts, selects parameters or scores. The
caller must verify actual original source/data/environment boundaries first
and must not serialize the returned training objects into user reports.

This preparation does not approve methodology, certify real reuse counts,
create a correction freeze, dispatch a fit, alter old results, or replace
deep verification/selected reproduction/analysis/release transfer gates.
