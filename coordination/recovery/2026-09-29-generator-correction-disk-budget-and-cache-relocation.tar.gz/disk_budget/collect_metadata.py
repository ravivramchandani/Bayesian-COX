"""Collect file statistics and saved JSON dimensions; never open traces/arrays."""

from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BASE = Path('/Users/macuser/bayes-cox-runs')
HOME = BASE / 'extensions-20260928'
OUTPUT = HOME / 'generator_correction_disk_budget_v1'
APFS = Path('/Volumes/BayesCoxExtensions20260928')
PREFLIGHT = APFS / 'correction-20260929/preflight_v1'
SOURCE = BASE / 'extensions-code-20260928-119476f'


def file_stat(path: Path) -> dict[str, Any]:
    """Observe only a regular file's logical and reported allocated bytes."""
    value = path.lstat()
    if not stat.S_ISREG(value.st_mode):
        raise ValueError(f'nonregular file: {path}')
    return {'bytes': value.st_size, 'allocated_bytes': value.st_blocks * 512,
            'mtime_ns': value.st_mtime_ns, 'inode': value.st_ino,
            'device': value.st_dev, 'link_count': value.st_nlink}


def read_metadata(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    """Read JSON metadata only, binding current bytes and observing races."""
    before = file_stat(path)
    raw = path.read_bytes()
    after = file_stat(path)
    if before != after:
        raise ValueError(f'metadata changed while reading: {path}')
    return json.loads(raw), {**before, 'sha256': hashlib.sha256(raw).hexdigest()}


def tree_stats(root: Path) -> dict[str, Any]:
    """Sum metadata; APFS shared clone extents are deliberately not inferred."""
    logical = allocated = files = links = directories = 0
    hardlinked_files = 0
    errors = []
    for directory, names, filenames in os.walk(root, followlinks=False):
        directories += 1
        for name in list(names):
            path = Path(directory) / name
            if path.is_symlink():
                links += 1
                names.remove(name)
        for name in filenames:
            path = Path(directory) / name
            try:
                value = path.lstat()
                if stat.S_ISLNK(value.st_mode):
                    links += 1
                elif stat.S_ISREG(value.st_mode):
                    files += 1
                    logical += value.st_size
                    allocated += value.st_blocks * 512
                    hardlinked_files += value.st_nlink > 1
            except OSError as error:
                errors.append({'path': str(path), 'type': type(error).__name__})
    return {'regular_file_count': files, 'directory_count': directories,
            'logical_bytes': logical, 'allocated_bytes_sum_not_exclusive_extents': allocated,
            'symlink_count_not_followed': links, 'hardlinked_file_count': hardlinked_files,
            'scan_errors': errors}


def scan_run(root: Path, *, manifest_root: Path | None = None) -> dict[str, Any]:
    """Read saved p/attempt metadata; stat referenced and orphan trace files."""
    manifest_path = (root if manifest_root is None else manifest_root) / 'manifest.json'
    manifest, manifest_binding = read_metadata(manifest_path)
    plan = [row['cell_id'] for row in manifest['plan']]
    if manifest_root is not None:
        new_models = {'ridge', 'lasso', 'elastic_net', 'pv_horseshoe', 'catalytic_fixed', 'catalytic_adaptive', 'catalytic_wme'}
        selected = []
        for identity in plan:
            dataset, setting, fold, model, condition = identity.split('__')
            if fold == 'r01f01' and ((dataset == 'metabric_matched') or
                (condition == 'full' and model in new_models) or
                (condition != 'full' and model in {'catalytic_fixed', 'catalytic_adaptive', 'catalytic_wme'})):
                selected.append(identity)
        if len(selected) != 92:
            raise ValueError('metadata-derived original92 selection differs')
        plan = selected
    cells = []
    errors = []
    for path in sorted((root / 'cells').glob('*.json')):
        try:
            value, binding = read_metadata(path)
            attempts = [{'attempt': row.get('attempt'), 'tune': row.get('tune'),
                         'noncentered_baseline': row.get('noncentered_baseline'),
                         'traces': row.get('traces', {}),
                         'trace_write_errors': row.get('trace_write_errors', [])}
                        for row in value.get('fit_attempts', [])]
            cells.append({'file': str(path.relative_to(root)), 'binding': binding,
                **{key: value.get(key) for key in ('cell_id', 'dataset', 'setting', 'model_key',
                    'condition', 'gene_budget', 'status', 'p', 'n_train', 'n_validation')},
                'fit_attempts': attempts})
        except (OSError, ValueError) as error:
            errors.append({'path': str(path), 'type': type(error).__name__, 'message': str(error)})
    lookup = {row['cell_id']: row for row in cells}
    traces = []
    for directory, names, files in os.walk(root / 'traces', followlinks=False):
        names[:] = [name for name in names if not (Path(directory) / name).is_symlink()]
        for name in sorted(files):
            path = Path(directory) / name
            if path.suffix != '.nc':
                continue
            try:
                metadata = file_stat(path)
                identity = path.parent.name
                cell = lookup.get(identity)
                declared = [label for row in (cell or {}).get('fit_attempts', [])
                            for label, value in row['traces'].items() if value['filename'] == name]
                traces.append({'file': str(path.relative_to(root)), 'cell_id': identity,
                    **metadata, 'referenced_by_saved_cell': bool(declared), 'recorded_labels': declared,
                    'saved_cell_present': cell is not None, 'saved_cell_status': (cell or {}).get('status'),
                    'saved_p': (cell or {}).get('p'), 'saved_model': (cell or {}).get('model_key')})
            except OSError as error:
                errors.append({'path': str(path), 'type': type(error).__name__})
    claims = []
    for path in sorted((root / 'claims').glob('*.json')):
        value, binding = read_metadata(path)
        claims.append({'path': str(path.relative_to(root)), 'binding': binding, 'record': value})
    return {'root': str(root), 'manifest_binding': manifest_binding,
        'planning_manifest_path': str(manifest_path), 'plan': plan, 'run_config': manifest['run_config'],
        'saved_cells': cells, 'traces': traces, 'claims': claims,
        'saved_cell_count': len(cells), 'planned_cell_count': len(plan),
        'remaining_cell_count': len(plan) - len(cells),
        'saved_status_counts': dict(Counter(row['status'] for row in cells)),
        'trace_file_count': len(traces), 'trace_logical_bytes': sum(row['bytes'] for row in traces),
        'trace_allocated_bytes_sum': sum(row['allocated_bytes'] for row in traces), 'errors': errors}


def main() -> None:
    """Create one external metadata snapshot; never certify numerical results."""
    started = datetime.now(timezone.utc).isoformat()
    if (OUTPUT / 'metadata_snapshot.json').exists():
        raise ValueError('write-once output already exists')
    volumes = {}
    for root in (HOME, APFS, Path('/Volumes/SSD980')):
        fs = os.statvfs(root)
        volumes[str(root)] = {'available_bytes': fs.f_bavail * fs.f_frsize,
            'total_bytes': fs.f_blocks * fs.f_frsize, 'device': root.stat().st_dev}
    observed = {'schema_version': 1, 'started_at_utc': started,
        'scope': 'current nontransactional regular file metadata and saved JSON dimensions only',
        'volumes_start': volumes, 'original_run': scan_run(HOME / 'run'),
        'original_reproduction': scan_run(HOME / 'reproduction', manifest_root=HOME / 'run'),
        'top_level_internal_trees': {}, 'preflight_inputs': [], 'preflight_tree': tree_stats(PREFLIGHT)}
    for root in sorted(BASE.iterdir()):
        if root.is_dir() and not root.is_symlink():
            observed['top_level_internal_trees'][str(root)] = tree_stats(root)
    for path in sorted((PREFLIGHT / 'contexts').glob('*/*/input.json')):
        try:
            value, binding = read_metadata(path)
            witness = value['input_witness']
            observed['preflight_inputs'].append({'path': str(path), 'binding': binding,
                'context_id': witness['context_id'], 'gene_budget': witness['gene_budget'],
                'n_train': witness['n_train'], 'real_design': witness['real_design']})
        except (OSError, ValueError) as error:
            observed.setdefault('preflight_read_errors', []).append({'path': str(path), 'type': type(error).__name__})
    process_result = subprocess.run(['ps', '-axo', 'pid,ppid,state,etime,command'],
                                    capture_output=True, text=True, check=True)
    observed['observed_task_processes'] = [line for line in process_result.stdout.splitlines()
        if ('/Users/macuser/bayes-cox-runs' in line or '/Volumes/BayesCoxExtensions20260928' in line)
        and '/bin/zsh' not in line and 'collect_metadata.py' not in line]
    observed['git_source_commit'] = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip()
    observed['git_source_tracked_status'] = subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'], text=True).strip()
    observed['df_current'] = subprocess.check_output(['df', '-k', str(HOME), str(APFS), '/Volumes/SSD980'], text=True)
    observed['apfs_diskutil_info'] = subprocess.check_output(['diskutil', 'info', '-plist', str(APFS)], text=True)
    observed['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    observed['trace_or_npz_files_opened'] = 0
    observed['scientific_modules_imported'] = False
    observed['source_data_or_owner_mutation'] = False
    with (OUTPUT / 'metadata_snapshot.json').open('x') as stream:
        json.dump(observed, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'source_cells': observed['original_run']['saved_cell_count'],
        'remaining_cells': observed['original_run']['remaining_cell_count'],
        'trace_bytes': observed['original_run']['trace_logical_bytes'],
        'preflight_context_inputs': len(observed['preflight_inputs']),
        'top_internal_trees': len(observed['top_level_internal_trees'])}, sort_keys=True))


if __name__ == '__main__':
    main()
