"""Record bounded process/source closure and archive metadata without payload reads."""

from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BASE = Path('/Users/macuser/bayes-cox-runs')
HOME = BASE / 'extensions-20260928'
OUTPUT = Path(__file__).absolute().parent
MAIN = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
APFS = Path('/Volumes/BayesCoxExtensions20260928')
SOURCE = BASE / 'extensions-code-20260928-119476f'
CANDIDATE_ROOTS = [BASE / name for name in (
    'private-programme-release-20260927', 'private-programme-download-20260927',
    'private-programme-audit-20260928', 'private-programme-audit-download-20260928',
)]
OLD_RESTORE = BASE / 'private-programme-restore-20260927'
OWNER_NAMES = (
    'run_extensions.py', 'prestage_refits.py', 'coordinate_after_fits_v2.py',
    'complete_postfit_support_v1.py', 'run_preflight.py',
    'correction_continuation_v1.py',
)


def metadata(path: Path) -> dict[str, Any]:
    """Stat a regular file; never read its archive/trace/array payload."""
    value = path.lstat()
    if not stat.S_ISREG(value.st_mode):
        raise ValueError(f'nonregular file: {path}')
    return {'path': str(path), 'bytes': value.st_size,
            'allocated_bytes_sum_not_exclusive_extents': value.st_blocks * 512,
            'device': value.st_dev, 'inode': value.st_ino,
            'mtime_ns': value.st_mtime_ns, 'link_count': value.st_nlink}


def small_binding(path: Path) -> dict[str, Any]:
    """Bind small source or JSON/text metadata, rejecting unexpected large files."""
    before = metadata(path)
    if before['bytes'] > 5 * 1024**2 or path.suffix in ('.nc', '.npz', '.parquet', '.gz'):
        raise ValueError(f'not approved small source/metadata: {path}')
    raw = path.read_bytes()
    if before != metadata(path):
        raise ValueError(f'changed during metadata read: {path}')
    return {**before, 'sha256': hashlib.sha256(raw).hexdigest()}


def command(argv: list[str]) -> dict[str, Any]:
    """Capture a read-only operating-system or source-text observation."""
    result = subprocess.run(argv, text=True, capture_output=True, check=False)
    return {'argv': argv, 'exit_code': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr}


def main() -> None:
    """Retain process ownership and bounded absence checks; never remove files."""
    destination = OUTPUT / 'ownership_snapshot.json'
    if destination.exists():
        raise ValueError('write-once destination exists')
    started = datetime.now(timezone.utc).isoformat()
    ps = command(['ps', '-axo', 'pid,ppid,state,etime,command'])
    if ps['exit_code'] != 0:
        raise ValueError('ps observation failed')
    owners = [line for line in ps['stdout'].splitlines() if any(
        name in line for name in OWNER_NAMES) and '/bin/zsh' not in line
        and 'collect_ownership_metadata.py' not in line]
    pids = [line.split()[0] for line in owners]
    lsof = command(['lsof', '-n', '-P', '-p', ','.join(pids)]) if pids else None
    if lsof is not None:
        lsof['stdout'] = '\n'.join(line for line in lsof['stdout'].splitlines()
            if ' cwd ' in line or str(BASE) in line or str(APFS) in line) + '\n'
    closure = [SOURCE / 'src', SOURCE / 'scripts', MAIN / 'scripts/catalytic_correction',
        HOME / 'coordinate_after_fits_v2.py', HOME / 'complete_postfit_support_v1.py',
        HOME / 'correction_continuation_v1.py', HOME / 'final_transfer_runbook_v2',
        HOME / 'final_validation_bundle_preparation_v1',
        HOME / 'final_validation_bundle_preparation_v2',
        APFS / 'correction-20260929/continuation_v1_request.json']
    pattern = '|'.join(str(path) for path in [*CANDIDATE_ROOTS, OLD_RESTORE])
    source_search = command(['rg', '-l', '-F', *sum((['-e', str(path)]
        for path in [*CANDIDATE_ROOTS, OLD_RESTORE]), []), *map(str, closure)])
    if source_search['exit_code'] not in (0, 1):
        raise ValueError('bounded source reference search failed')
    historical_search = command(['rg', '-l', '-F', *sum((['-e', str(path)]
        for path in [*CANDIDATE_ROOTS, OLD_RESTORE]), []),
        str(MAIN / 'coordination'), str(MAIN / 'docs'), str(BASE / 'harness')])
    if historical_search['exit_code'] not in (0, 1):
        raise ValueError('historical reference search failed')
    closeout_path = MAIN / 'coordination/recovery/2026-09-28-programme-closeout.json'
    closeout = json.loads(closeout_path.read_text())
    expected = {row['name']: (row['bytes'], closeout['supplementary_release']['remote_verification']['asset_sha256'][row['name']])
        for row in closeout['supplementary_release']['assets'] if row['name'].endswith('.tar.gz')}
    expected['programme-audit-evidence.tar.gz'] = (496134676,
        closeout['audit_release']['remote_verification']['asset_sha256']['programme-audit-evidence.tar.gz'])
    archives = []
    for root in CANDIDATE_ROOTS:
        declared = dict((line.split(None, 1)[1], line.split(None, 1)[0])
            for line in (root / 'SHA256SUMS').read_text().splitlines())
        for path in sorted(root.glob('*.tar.gz')):
            row = metadata(path)
            expected_bytes, expected_sha = expected[path.name]
            if row['bytes'] != expected_bytes or declared.get(path.name) != expected_sha:
                raise ValueError('historical declared archive metadata differs')
            archives.append({**row, 'historically_verified_sha256': expected_sha,
                'current_archive_payload_sha256': None,
                'current_payload_byte_match_verified': False,
                'historical_receipt': str(closeout_path)})
    owning_rows = owners + ([] if lsof is None else lsof['stdout'].splitlines())
    candidate_owner_matches = {str(root): [line for line in owning_rows if str(root) in line]
        for root in [*CANDIDATE_ROOTS, OLD_RESTORE]}
    pinned_small = [closeout_path, *(root / 'SHA256SUMS' for root in CANDIDATE_ROOTS),
        HOME / 'coordinate_after_fits_v2.py', HOME / 'complete_postfit_support_v1.py',
        HOME / 'correction_continuation_v1.py', HOME / 'final_transfer_runbook_v2/paths.sh',
        HOME / 'final_validation_bundle_preparation_v2/input_manifest_v2.json',
        APFS / 'correction-20260929/continuation_v1_request.json',
        OLD_RESTORE / 'release_metadata/programme_release_manifest.json',
        BASE / 'student-programme-results-20260928/release_metadata/programme_release_manifest.json']
    bindings = [small_binding(path) for path in pinned_small]
    restore_bindings = {row['path']: row for row in bindings if 'release_metadata/programme_release_manifest.json' in row['path']}
    report = {'schema_version': 1, 'started_at_utc': started,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'metadata-only bounded process and current-source closure; no global future-reference guarantee',
        'owner_process_rows': owners, 'lsof_filtered_task_paths': lsof,
        'candidate_owner_matches': candidate_owner_matches,
        'current_source_reference_search': source_search,
        'historical_reference_search': historical_search,
        'small_source_and_metadata_bindings': bindings,
        'archive_candidates': archives,
        'archive_candidate_logical_bytes': sum(row['bytes'] for row in archives),
        'archive_candidates_current_payloads_verified': False,
        'archive_candidates_may_be_reviewed_for_verified_external_copy': not source_search['stdout'].strip()
            and not any(candidate_owner_matches.values()),
        'old_restore_manifest_same_bytes_as_protected_student_restore': len({row['sha256'] for row in restore_bindings.values()}) == 1,
        'old_restore_current_payload_inventory_verified': False,
        'old_restore_relocation_qualified': False,
        'minimum_8GiB_relocation_pool_qualified': False,
        'archive_trace_npz_payload_reads': 0, 'scientific_modules_imported': False,
        'owners_stopped_or_modified': False, 'files_moved_or_removed': 0,
        'required_before_any_archive_removal': [
            'root-owned fresh process/cwd/open-file/source-input recheck',
            'copy each selected regular archive onto actual mounted APFS with sufficient capacity',
            'freshly hash source and destination, require both equal retained historical declared SHA256',
            'retain exact small manifests/SHA256SUMS and relocation receipt; preserve historical evidence bytes',
            'root decides any internal removal; reclaimable unique APFS extents must be measured, not inferred from logical bytes']}
    with destination.open('x') as stream:
        json.dump(report, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'owner_processes': len(owners), 'archive_candidates': len(archives),
        'archive_candidate_GiB': sum(row['bytes'] for row in archives) / 1024**3,
        'current_source_reference_matches': source_search['stdout'].splitlines(),
        '8GiB_qualified': False}, sort_keys=True))


if __name__ == '__main__':
    main()
