# Conditional disk budget — metadata-only review

The original run can plausibly exhaust the internal disk under its existing
three-attempt budget. At the retained 2026-09-29 08:23:24–08:23:33 UTC snapshot,
35.017 GiB was available internally. The conditional remaining original output
budget is 32.597 GiB, leaving 2.419 GiB before swap growth, staging, archives,
downloads, restores or other writes. A 5 GiB operating reserve is therefore short
by 2.581 GiB. This is a resource warning for the owner, not an instruction to stop
workers or change any scientific gate.

The snapshot records 1,089/1,625 original cells and 89/92 prestaged refits. The
536 remaining outer cells comprise 266 matched-clinical and 270 matched-expression
jobs. The original run holds 946 regular NetCDF files (3.902 GiB); prestaging
holds 77 (0.718 GiB). The largest observed individual trace is 93.76 MiB.
These are file statistics and cell metadata; numerical or trace contents were
not read. Prestaging counts do not certify the official 92 reproduction gate.

| Conditional additional output | GiB |
| --- | ---: |
| Remaining 536 original cells, one attempt | 11.027 |
| Remaining 536 original cells, all three attempts | 32.278 |
| Remaining three selected original refits, all three attempts | 0.319 |
| All 825 catalytic corrected outer outputs, all three attempts | 20.513 |
| All 60 catalytic selections from the original selected rule | 1.190 |
| Up to six additional distinct Bayesian pilot reproductions | 1.234 |

The corrected total of 22.938 GiB is a declared-scope scenario, **not an actual
selective refit count**. Reuse, failure retention and changed-input decisions
remain governed by full preflight/replay/witness/arithmetic evidence and actual
root reviews. APFS had 198.826 GiB free on the actual mounted `/dev/disk6s1`;
the external sparse image is backed by SSD980, which had 929.726 GiB free.
Current preflight files occupy about 0.807 GiB at this earlier snapshot.

Projection method: frozen `config/extensions.yaml:11–18` and
`src/pipelines/extensions/fitting.py:61–81,143–201` retain four chains × 2,000
draws, with up to three attempts. Tuning is 2,000 then 4,000/4,000 and discarded
by the pinned PyMC default. Each saved coefficient/baseline value is budgeted as
eight bytes. Per draw, normal/fixed store `p` coefficient values; adaptive
`p+1`; horseshoe `3p+2`; spike-slab `3p`; survival horseshoe `3p+1`; all include
six baseline values, and attempt three includes six additional offsets.
`src/models/bayesian/model.py:217–271` and
`src/models/bayesian/extensions.py:123–171` declare these variables. Catalytic
Bayesian variants save separate prior and posterior NUTS traces. Other variants'
temporary prior-predictive draws are not saved as separate prior traces. WME and
other non-Bayesian models write no NetCDF traces through this pipeline.

The calculation adds 2 MiB per trace for sampler statistics/NetCDF/observed-data
overhead and twice the largest existing cell JSON size per new cell. The overhead
exceeds 1.25 × the largest observed positive file-size excess over the nominal
coefficient payload. Already present pending-cell traces are deducted without
removing unreferenced evidence. Compressed NetCDF sizes are not predicted exactly.
For 429 pending cells without corresponding-fold `p`, it uses the observed
matched-setting maxima, clinical 15 and expression 527 (512 genes + 15 clinical
columns). Those maxima are **conditional estimates, not verified mathematical
upper bounds**. Refresh dimensions after the complete preflight before launch
budgeting. Final retained proposals, independent input/replay proofs, QA/support
evidence and package/download/restore multiplicities need their own budget;
this report does not certify that the APFS volume can hold every final copy.

No 8–12 GiB inactive pool was qualified. The bounded process/source check instead
identifies 12 lower-risk historical archive blobs totalling **2.690 GiB**:

- `private-programme-release-20260927/*.tar.gz`: five, 0.883 GiB.
- `private-programme-download-20260927/*.tar.gz`: the same five, 0.883 GiB.
- `private-programme-audit-20260928/programme-audit-evidence.tar.gz`: 0.462 GiB.
- `private-programme-audit-download-20260928/programme-audit-evidence.tar.gz`: 0.462 GiB.

Their current regular-file sizes and declared checksums match the exact assets
in `coordination/recovery/2026-09-28-programme-closeout.json`, which records the
historical fresh remote verification. `ownership_snapshot.json` retains actual
argv/cwd/open-file observations for all 11 task processes and the bounded current
source/input search, with no candidate matches. It lists each exact file, size
and expected checksum. The archive payloads were **not freshly hashed**: root
must recheck ownership, copy selected archives to the still-mounted APFS volume,
hash source and destination against those retained checksums, and retain an
actual relocation receipt before deciding any internal removal. Logical bytes
and `st_blocks` do not prove exclusive reclaimable APFS extents. Keep all small
historical manifests and receipts.

The old `private-programme-restore-20260927` is another 1.932 GiB and has the exact
same manifest bytes as the protected student restore, with no observed live
owner or current input reference. Its current payload inventory was not verified,
so it is explicitly unqualified. Historical render/QA copies were also left
unqualified because their evidence/reference closure and byte duplication were
not established. Protected paths include the active original run/reproduction,
source119, matched preparation, coordinators/support, `extension-reference-20260928`,
`student-restore-check-20260928` primary baseline and
`student-programme-results-20260928` sampler/robustness inputs. No file was moved
or removed, no process was altered, and no scientific operation was executed.
