"""Source-dimension storage scenarios from the retained metadata snapshot only."""

from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).absolute().parent
GIB, MIB = 1024**3, 1024**2
MODELS = {
    'bayesian_normal': (1, 0, False),
    'bayesian_horseshoe': (3, 2, False),
    'bayesian_spike_slab': (3, 0, False),
    'pv_horseshoe': (3, 1, False),
    'catalytic_fixed': (1, 0, True),
    'catalytic_adaptive': (1, 1, True),
}


def group_key(identity: str) -> tuple[str, ...]:
    parts = identity.split('__')
    return tuple(parts[:3] + parts[4:])


def coefficient_payload(model: str, p: int, attempt: int) -> int:
    """Float64 coefficient/baseline values; six extra offsets in attempt3."""
    vectors, scalars, _ = MODELS[model]
    return 4 * 2000 * 8 * (vectors * p + scalars + 6 + (6 if attempt == 3 else 0))


def main() -> None:
    """Write labelled conditional scenarios; never certify an actual fit count."""
    snapshot = json.loads((ROOT / 'metadata_snapshot.json').read_text())
    run = snapshot['original_run']
    cells = {row['cell_id']: row for row in run['saved_cells']}
    known = {identity: row['p'] for identity, row in cells.items() if row['p'] is not None}
    for row in snapshot['preflight_inputs']:
        if row['context_id'].endswith('::outer'):
            known[row['context_id'].split('::')[0]] = row['real_design']['shape'][1]
    groups: dict[tuple[str, ...], set[int]] = defaultdict(set)
    strata: dict[tuple[str, str], list[int]] = defaultdict(list)
    for identity, p in known.items():
        groups[group_key(identity)].add(p)
        strata[tuple(identity.split('__')[:2])].append(p)
    if any(len(values) != 1 for values in groups.values()):
        raise ValueError('observed corresponding-fold encoded dimensions conflict')
    dimension_sources = Counter()

    def dimension(identity: str) -> tuple[int, str]:
        if identity in known:
            return known[identity], 'actual_saved_cell_or_outer_input_dimension'
        key = group_key(identity)
        if key in groups:
            return next(iter(groups[key])), 'observed_other_model_same_planned_fold_dimension'
        setting = tuple(identity.split('__')[:2])
        return max(strata[setting]), 'observed_same_dataset_setting_maximum_projection_not_hard_bound'

    extras = []
    for role in ('original_run', 'original_reproduction'):
        observed = snapshot[role]
        for trace in observed['traces']:
            model, p = trace['saved_model'], trace['saved_p']
            match = re.match(r'attempt_(\d+)_', Path(trace['file']).name)
            if model in MODELS and p is not None and match:
                extras.append(max(0, trace['bytes'] - coefficient_payload(model, p, int(match[1]))))
    # Covers known sampler stats, observed-data/NetCDF metadata and compression
    # variation without assuming future traces reproduce the current compression.
    overhead = max(2 * MIB, math.ceil(max(extras, default=0) * 1.25))
    cell_allowance = 2 * max(row['binding']['bytes'] for row in run['saved_cells'])

    def new_cell_budget(identity: str, attempts: int) -> dict[str, Any]:
        model = identity.split('__')[3]
        p, basis = dimension(identity)
        trace_count = 0
        trace_bytes = 0
        if model in MODELS:
            trace_count = attempts * (2 if MODELS[model][2] else 1)
            trace_bytes = sum((coefficient_payload(model, p, index) + overhead)
                              * (2 if MODELS[model][2] else 1)
                              for index in range(1, attempts + 1))
        return {'cell_id': identity, 'model': model, 'p': p, 'dimension_basis': basis,
                'potential_trace_count': trace_count, 'trace_budget_bytes': trace_bytes,
                'saved_json_allowance_bytes': cell_allowance, 'total_budget_bytes': trace_bytes + cell_allowance}

    def scenario(identities: list[str], attempts: int, *, existing: list[dict[str, Any]] = ()) -> dict[str, Any]:
        rows = [new_cell_budget(identity, attempts) for identity in identities]
        current = defaultdict(int)
        for trace in existing:
            current[trace['cell_id']] += trace['bytes']
        for row in rows:
            row['already_present_trace_bytes'] = current[row['cell_id']]
            row['additional_budget_bytes'] = max(0, row['trace_budget_bytes'] - current[row['cell_id']]) + cell_allowance
        return {'attempts_per_bayesian_cell': attempts, 'cells': len(rows),
                'bayesian_cells': sum(row['model'] in MODELS for row in rows),
                'additional_bytes': sum(row['additional_budget_bytes'] for row in rows),
                'dimension_basis_counts': dict(Counter(row['dimension_basis'] for row in rows)),
                'model_counts': dict(Counter(row['model'] for row in rows)), 'rows': rows}

    pending = [identity for identity in run['plan'] if identity not in cells]
    for identity in pending:
        dimension_sources[dimension(identity)[1]] += 1
    reproduction = snapshot['original_reproduction']
    reproduced = {row['cell_id'] for row in reproduction['saved_cells']}
    pending_reproduction = [identity for identity in reproduction['plan'] if identity not in reproduced]
    all_catalytic = [identity for identity in run['plan'] if identity.split('__')[3] in
                    {'catalytic_fixed', 'catalytic_adaptive', 'catalytic_wme'}]
    selected_catalytic = [identity for identity in reproduction['plan'] if identity in set(all_catalytic)]
    # At most nine groups: clinical0/matched clinical0/matched expression512 for
    # each catalytic variant. Extra distinct Bayesian pilots can contribute at
    # most six more reproduction fits, all budgeted at largest observed p.
    largest = max(known.values())
    extra_pilot_bytes = sum(3 * 2 * (coefficient_payload(model, largest, 3) + overhead) + cell_allowance
                            for model in ('catalytic_fixed', 'catalytic_adaptive') for _ in range(3))
    output = {'schema_version': 1, 'scope': 'conditional_source_dimensions_and_current_file_metadata_not_exact_future_allocation',
        'source_variable_rules': MODELS, 'retained_draws_per_trace': 8000, 'float64_bytes_per_value': 8,
        'baseline_intervals': 6, 'attempt3_extra_log_lambda_offset_values': 6,
        'maximum_attempts': 3, 'catalytic_models_save_separate_prior_and_posterior': True,
        'tuning_samples_saved': False, 'prior_predictive200_draws_not_saved_as_trace_for_other_variants': True,
        'measured_largest_positive_trace_over_coefficient_payload_bytes': max(extras, default=0),
        'per_trace_overhead_allowance_bytes': overhead, 'per_new_cell_json_allowance_bytes': cell_allowance,
        'original_remaining_one_attempt': scenario(pending, 1, existing=run['traces']),
        'original_remaining_three_attempts': scenario(pending, 3, existing=run['traces']),
        'original_selected_remaining_three_attempts': scenario(pending_reproduction, 3, existing=reproduction['traces']),
        'corrected_all825_catalytic_new_outputs_three_attempts': scenario(all_catalytic, 3),
        'corrected_all60_catalytic_original_selection_new_refits_three_attempts': scenario(selected_catalytic, 3),
        'corrected_extra_distinct_pilot_reproduction_allowance_bytes': extra_pilot_bytes,
        'corrected_actual_new_fit_and_reuse_counts': 'pending; full preflight/replay/witness/arithmetic/root reviews decide',
        'noncat_and_unchanged_failure_refits_assumed': False,
        'projection_limitations': ['429 pending outer cells have no observed corresponding-fold p at this snapshot; use observed matched setting maximum15/527, not a verified mathematical cohort bound',
            'compressed NetCDF allocation is not predicted exactly; no trace or array content read',
            'metadata snapshot is not transactional while owners continue',
            'APFS clones/snapshots share extents; st_blocks sums do not establish reclaimable unique bytes',
            'corrected825/60 plus pilot allowance are worst declared-scope scenarios, not launch/refit counts',
            'generation/input/archive/restore/OS swap capacity budgets remain separate'],
        'actual_model_generation_optimizer_mcmc_scoring_operations': 0}
    with (ROOT / 'budget_scenarios.json').open('x') as stream:
        json.dump(output, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: round(output[key]['additional_bytes'] / GIB, 3) for key in output
        if key.endswith('attempt') or key.endswith('attempts') and isinstance(output[key], dict)}, sort_keys=True))


if __name__ == '__main__':
    main()
