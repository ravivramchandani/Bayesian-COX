# Accepted-input arithmetic preparation

This external preparation implements finite-design arithmetic checks for
ADR-040/T-190. No real cohort, generator, constructor/rank check, optimizer,
MCMC or predictive metric has been executed by this preparation. Synthetic
tests use tiny fictional arrays and an analytic mocked kappa-returning stub.
The root owns actual preflight, scientific review, invocation, correction
scope/reuse proof, freeze and fitting.

`independent_arithmetic.py` evaluates the catalytic kernel and gradient,
fixed-prior differences and gradients, the adaptive expression, and weighted
merged Cox Breslow value/score independently. `bound_arithmetic.py` binds those
checks to actual accepted preflight artifacts; its default `validate` command
has no optimizer access. `compute-kappa` is a separately named, optional,
root-controlled original optimizer stage. It is not executed by these tests.

## Exact scope and arithmetic

Each requested accepted context is checked one at a time. The four coefficient
vectors are zero; alternating +/-0.001 components; its negative; and
0.001*sin(j+1). For every vector the checks use tau=p*0.25, p and p*4, the
existing WME candidate multipliers. These are finite arithmetic test points;
they do not change the fixed prior's actual tau=p or select a fit/hyperparameter.

For M synthetic rows with design X, times t and rate h,

```
q(beta) = mean(X beta - h t exp(X beta))
gradient q = X.T (1 - h t exp(X beta)) / M
fixed prior difference = tau [q(beta) - q(0)]
adaptive joint expression = (p+alpha-1) log(tau) + tau [q(beta)-kappa-1/gamma]
alpha = 2; gamma = 1
```

The independent q uses scalar `math.fsum` reductions rather than the original
NumPy mean/GEMV reductions. The omitted beta-independent log(h) cancels in
fixed differences; adding the same constant to q and kappa cancels in the
adaptive expression. Synthetic checks verify both cancellations and analytic
gradients against central differences. This is not numerical integration of a
normalizing constant or a new prior/method correctness theorem.

The merged design uses real times divided by the bound original time scale,
real case/risk weights 1, synthetic times and events 1, synthetic case/risk
weights tau/M. The independent Cox calculation visits descending tied-time
groups, adds all rows at that time before their event contribution, and keeps
compensated O(p) running risk numerators and scores. It creates no n-by-n risk
matrix. It retains only one context's design and one merged array set at a
time; the original reference function necessarily allocates its existing
n-by-p cumulative numerator for comparison. No contexts' large arrays are
cached. Only small supplied kappa coefficient vectors may be held together.

Training units are independently recomputed from the bound observed training
arrays: time scale is the median event time, and hazard is
sum(events)/sum(real_time/time_scale). No evaluation patients are supplied.
These checks supplement the preflight's membership/source reconstruction;
they do not independently reprocess the cohort or certify fit/evaluation reuse.

## Original reference isolation and tolerances

The source commit is `119476fef55b1eeb690527f234c1423440720d45`.
The loader checks the entire original `src/models/catalytic.py` byte hash and
compiles only its unchanged `catalytic_kernel`, `adaptive_log_kernel`,
`weighted_breslow_objective`, and `catalytic_kappa` function AST nodes. It does
not import the project package, instantiate `CatalyticData`, invoke an SVD or
execute eager PyMC/package initializers. The source annotations remain deferred.
This is explicitly a byte-bound pure-function reference, not a normal-package
import or all-fitting-dependency certificate.

The CLI also pins the original preprocessing source for its time units and the
Bayesian extension source for initialization. **Both catalytic_fixed and
catalytic_adaptive outer contexts call the original kappa optimizer to obtain
prior_mode.** Both therefore require a supplied checked finite kappa/optimum
witness. Adaptive outer contexts additionally require the adaptive expression
checks. A supplied kappa is checked against independent q and original q, the
independent/original gradients, and the unchanged original maximum absolute
score threshold 1e-6. No optimizer runs during `validate`.

Arithmetic comparisons use elementwise
`absolute_error <= absolute_tolerance + relative_tolerance*max(abs(a),abs(b))`:

| Quantity | Absolute tolerance | Relative tolerance |
| --- | ---: | ---: |
| q, q gradient, kappa witness value/gradient | 1e-9 | 1e-11 |
| tau-scaled prior differences/gradients, adaptive expression, merged Cox value/score | 2e-8 | 3e-11 |
| Training median scale and reference hazard | 0 | 1e-11 |

These tolerances accommodate different float64 summation and BLAS reduction
orders on the same finite small-beta inputs. Their absolute floors are below
the original 1e-6 kappa and 1e-4 WME optimizer score criteria; the relative term
scales larger likelihood sums and neither term replaces either fit gate.
Absolute tolerance handles quantities close to zero. Every check records maximum absolute and relative error,
maximum allowed-error ratio and element count. Nonfinite values, overflow,
shape/domain errors and underflowing event-risk denominators refuse the stage.
There is no clipping, tolerance relaxation, arithmetic retry or new proposal.
Passing a few finite points is bounded arithmetic evidence; it is not a proof
of every beta, mathematical properness or all-grid execution readiness.

## Input contract

The production CLI requires a byte-pinned sealed preflight `completion.json`
with `all_scheduled_contexts_accounted`, 1650 outcomes, 825 outer and 825 WME
inner contexts (all three folds), unique IDs and matching status counts. Its
reuse/approval/freeze flags remain false. This prerequisite is **context
accounting**, not a declaration that all contexts succeeded. Arithmetic is
requested only for accepted contexts; terminal preflight failures remain
separate retained findings and are never replaced or optimized here.

The root supplies a new sealed selection JSON. Its strict canonical content
hash is stored as `content_sha256`; the command also requires its whole-file
byte SHA-256. Example body before adding `content_sha256`:

```json
{
  "schema_version": 1,
  "kind": "root_requested_arithmetic_contexts",
  "preflight_completion_sha256": "<actual completion byte SHA-256>",
  "run_binding_sha256": "<actual preflight run binding>",
  "contexts": [
    {
      "context_id": "<original cell ID>::outer",
      "context_receipt_sha256": "<actual context receipt byte SHA-256>",
      "kappa_required": true,
      "adaptive_required": true
    }
  ]
}
```

Use `kappa_required=true` for both Bayesian catalytic outer variants;
`adaptive_required=true` is mandatory for adaptive outer contexts. WME outer
and inner arithmetic can use both flags false. Additional kappa/adaptive checks
may be requested explicitly on other contexts; there is no automatic fit or
scientific-scope inference from these flags. Array equality/changed-fit scope
must be established by the separate root-reviewed complete witness inventory.

The loader verifies the selected completion outcome, context receipt bytes and
content, `input.json` byte/content/request/input-witness bindings, `inputs.npz`
byte size/hash, all small attempt receipt files and exact first/retry seed and
original-only rank rejection history, and accepted `proposal.npz` byte size/hash.
It checks exact NPZ keys, dtype/shape/C-order values and scalar shape `[]` for
hazard/time_scale. It binds real_design, real_time, real_event to the witness's
real_design, training_time, training_event fields and checks ordered training
membership, actual feature count and preprocessing metadata hashes.

Only small selector/completion rows are retained for all requested contexts;
full proposal/processor receipt histories are reread one context at a time.
Rejected proposal arrays are not reloaded/hashed by this arithmetic stage.
Their artifact bindings remain in the byte-pinned context history; full
proposal/rank/source replay belongs to the separate preflight review. This
module does not claim to replace that review or independent normal-import
first-proposal compatibility. Every consumed file/source is rechecked before
final receipt publication. Only array witnesses are included in facts; patient
IDs and arrays are not copied into the arithmetic output.

## Root-controlled actual invocation, after complete preflight

Do not run the following against the current partial programme or substitute
example hashes. These are future invocation templates; the root must bind
actual paths/hashes and retain stdout/stderr/actual exit code. Set numeric
threads to 1 in the invocation environment and use the frozen locked Python.

```text
python -B bound_arithmetic.py compute-kappa
  --preflight-root <actual complete preflight root>
  --completion-sha256 <actual completion byte hash>
  --selection <root requested-context JSON>
  --selection-sha256 <actual selection byte hash>
  --source-checkout <frozen 119476f checkout>
  --destination <new external kappa attempt directory>

python -B bound_arithmetic.py validate
  --preflight-root <same complete preflight root>
  --completion-sha256 <same actual completion byte hash>
  --selection <same requested-context JSON>
  --selection-sha256 <same actual selection byte hash>
  --source-checkout <frozen 119476f checkout>
  --kappa-root <completed separate kappa attempt directory>
  --kappa-receipt-sha256 <actual kappa receipt byte hash>
  --destination <new external arithmetic attempt directory>
```

`compute-kappa` processes only the requested `kappa_required` contexts. It runs
the exact original L-BFGS-B routine and options once on each already accepted
proposal and records the finite optimum witness plus independent checks. Its
per-context start/finish/wall time is retained in invocation metadata. It must
stop on the original optimizer failure or failed witness check. The accepted
proposal and preflight attempt history are unchanged; optimizer success or
failure cannot select or regenerate a synthetic proposal. This stage computes
an initialization witness only: it runs no sampler, WME optimizer or evaluation.

The kappa receipt is separately byte-bound when loading it into `validate`.
The loader also verifies its sealed optimizer invocation bytes, matching
implementation/source hashes, exact required context/stage inventory and each
recorded completed optimizer stage. These records still require the root's
separate actual rc0 stdout/stderr capture; a self-written receipt is not an
independent process-success certificate.
Every kappa context record must have the same accepted-input lineage and
original function source as the current requested context. Its beta_hat
dimensionality, finite q/kappa identity and original score threshold are
checked again. If no requested context needs kappa, omit the two kappa options.

## Output, failure and evidence boundaries

A new output directory contains:

- `contexts/<SHA256 of canonical logical context ID>.json`: deterministic
  scientific checks/optimum witnesses and logical relative lineage. Kappa
  records contain `kappa`, `beta_hat` and independent witness checks; validation
  records contain every comparison and training-unit check.
- `invocation.json`: actual command, host-absolute paths, UTC timing, elapsed
  time, source hashes and optional optimizer-stage timings. Host paths/timing
  stay outside scientific context facts.
- `receipt.json`: final exact context artifacts, input/selection/source hashes,
  invocation binding, requested/reported counts and bounded stage status.

Publication writes closed, fsynced JSON bytes through an exclusive atomic
hard link. Existing destinations/receipts are never overwritten. The helper
checks the exact file/directory inventory and rejects residual temporary files,
unknown directories or links. It returns rc0 only after the final inventory
passes. No success receipt is created for a comparison/domain/optimizer failure;
the output attempt, available failed comparison row and a separate
`failure.json` are retained. Link/fsync/cleanup failures propagate; a committed
receipt followed by a cleanup/inventory error is not CLI success, so an actual
rc0 invocation and exact final inventory are required alongside any receipt.

The statuses are `requested_context_arithmetic_passed` or
`requested_kappa_witnesses_computed`, not “all corrected science complete”.
Every final receipt explicitly has `fit_reuse_certified=false`,
`method_freeze_certified=false`, `programme_completion_certified=false`,
`rank_check_invoked=false`, `new_proposals_generated=false`,
`proposals_selected_by_optimizer=false`, and `predictive_metrics_computed=false`.
The `optimizer_invoked` flag is true only in the separately named kappa stage.
Requested arithmetic scope does not automatically certify coverage of all
changed accepted outer/inner contexts or all WME uses; the root must reconcile
actual requested IDs, terminal failures and the complete fit-witness inventory
before freezing or launching any corrected score.

Run the included synthetic checks only from this preparation directory:

```text
python -B -m unittest -v test_independent_arithmetic.py test_bound_arithmetic.py
```

The tests replace the production expected-context count with two only inside
their fictional fixture calls; the production CLI fixes 1650 and rejects those
partial fixtures before output creation. Tests use the pinned original pure
functions and never enable its real optimizer. The optional kappa CLI branch
is checked with an explicitly mocked analytic return, labelled in test receipts.
The first full test attempt failed because macOS's default /var temp ancestor
is a symlink; tests now resolve their private temp root rather than weakening
runtime symlink refusal. All earlier attempt logs remain unchanged. Ruff's
initial unused import/loop-binding findings and their corrections are retained.
Actual changed inputs, original kappa convergence, tolerance errors on the real
grid, resource cost and complete changed-input coverage remain unexecuted here.
