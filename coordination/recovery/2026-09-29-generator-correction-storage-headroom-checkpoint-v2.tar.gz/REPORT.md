# Read-only storage checkpoint

The internal filesystem reported **77.026 GiB available** at the timestamped
2026-09-29 12:20:54 UTC checkpoint. Earlier in this same audit, actual `df` reported
6.598 GiB, then a refreshed `statvfs` reported 77.713 GiB. Exact acquisition times
of those first two individual commands were not captured. The large free-space
fluctuation is real across successive tool observations, but its cause is
**unknown**. No cloud, OS, VM, cache or job cause is inferred.

The project run/evidence tree currently holds 18.056 GiB allocated by `du`,
close to the prior metadata-only report's rounded 17.850 GiB at 10:33 UTC. This
small difference does not explain a roughly 30 GiB decline and subsequent
roughly 70 GiB recovery. APFS independently reported free container capacity;
there were no Data-volume snapshots in the observed snapshot query.

The earlier storage plan measured 52.21 GiB free on September 28 and 35.017 GiB
on September 29 at 08:23. Its maximum three-attempt remaining original/selected
output scenario was 32.597 GiB, before a 5 GiB reserve and later writes.
That scenario remains conditional, uses observed dimensions rather than proven
upper bounds, and is not a refreshed completion forecast. The current 77 GiB
availability removes the immediate premise for extra relocation. Recheck actual
space before the next major execution or transfer phase; do not claim that all
future retained copies fit from this checkpoint alone.

No additional bytes are qualified for relocation or deletion. The protected old
private restore is 2,079,780,864 allocated bytes (1.937 GiB); owner instruction
keeps it intact despite a historical duplicate-byte proof. The three historical
render candidates total 1,843,769,344 bytes (1.717 GiB),
but only metadata overlaps were previously established. They lack a new complete
byte/reference disposition and remain unqualified. The 12 historical compressed
release/download blobs already moved to the old external APFS image are not
counted again. Downloads were observed only as an aggregate in this report;
unrelated personal filenames and broad raw process paths are excluded.

OS swap held 11 GiB allocated in 11 swapfiles at this checkpoint. It is protected
OS state. All live scientific caches, locked environments, original runs/data,
matched inputs, production source119, reproduction, both protected student
baseline inputs, old restore, replay, observer, and forensic/read-only image
remain intact. `du` and `st_blocks` do not prove exclusive reclaimable APFS extents.

Actual bounded argv and corrected `lsof -a ... -d cwd` observations cover all nine
original owners. They do not prove global file inactivity or authorize cleanup.
The first `lsof` call omitted `-a` and produced wider metadata; its exact raw
record is privately retained outside this sealed small report, with its hash and
invocation bound here. The corrected selection genuinely returned 0 and exactly
the nine intended PIDs. Only the audit-owned stalled read-only `du` PID66048 was
freshly verified and SIGTERM'd under root instruction; its tool returned 143.
No interpretation of incomplete Library metadata is used.

No scientific arrays/traces were loaded or hashed, no scientific modules were
imported, no existing result/source/file was moved or deleted, no scientific
owner was signalled/restarted, and no setting changed. `collect_headroom.py`
records the original historical capture attempt and is not a reusable launcher.
No numerical, reproduction, reporting or release completion is claimed.

This v2 report corrects two prose rounding transcriptions in the untouched v1
report. Integer measurements and timestamps are unchanged. The initial values
are 7,084,568,576 bytes (6.598 GiB) and 83,443,273,728 bytes (77.713 GiB).
It also omits the unnecessary initial owner descriptor listing while preserving
its hash and the actual corrected nine-owner cwd query. The prior v1 record
remains byte-verified and its receipt is bound in revision_provenance.json.
