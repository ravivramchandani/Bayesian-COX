"""Collect a bounded metadata-only storage checkpoint without changing owners."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess

OUT = Path(__file__).resolve().parent
BASE = Path('/Users/macuser/bayes-cox-runs')
EXT = BASE / 'extensions-20260928'
GIB = 1024 ** 3


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(name, value):
    p = OUT / name
    with p.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


def command(argv, timeout=15):
    begin = utc()
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        return {'argv': argv, 'started_at_utc': begin, 'finished_at_utc': utc(),
                'actual_returncode': p.returncode, 'stdout': p.stdout,
                'stderr': p.stderr, 'timed_out': False}
    except subprocess.TimeoutExpired as e:
        return {'argv': argv, 'started_at_utc': begin, 'finished_at_utc': utc(),
                'actual_returncode': None, 'timed_out': True,
                'stdout': (e.stdout or b'').decode() if isinstance(e.stdout, bytes) else e.stdout,
                'stderr': (e.stderr or b'').decode() if isinstance(e.stderr, bytes) else e.stderr}


def binding(path):
    s = path.stat()
    return {'path': str(path), 'size_bytes': s.st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


start = utc()
cleanup = json.loads((OUT / 'owned_query_cleanup.json').read_text())
cleanup['actual_tool_return_pending'] = False
cleanup['actual_tool_returncode'] = 143
cleanup['actual_tool_completion_observed_at_utc'] = start
cleanup['incomplete_library_scan_used_to_qualify_candidates'] = False
write('owned_query_terminal_accounting.json', cleanup)

commands = {
    'df': command(['/bin/df', '-k', '/Users/macuser', '/System/Volumes/VM',
                   '/Volumes/SSD980', '/Volumes/BayesCoxTransfer20260929']),
    'apfs': command(['/usr/sbin/diskutil', 'apfs', 'list', 'disk3']),
    'data_snapshots': command(['/usr/sbin/diskutil', 'apfs', 'listSnapshots', '/System/Volumes/Data']),
    'swap': command(['/usr/sbin/sysctl', 'vm.swapusage']),
}
current_volumes = {}
for p in ['/Users/macuser', '/System/Volumes/VM', '/Volumes/SSD980', '/Volumes/BayesCoxTransfer20260929']:
    s = os.statvfs(p)
    current_volumes[p] = {'observed_at_utc': utc(), 'available_bytes': s.f_bavail*s.f_frsize,
                          'free_bytes': s.f_bfree*s.f_frsize, 'total_bytes': s.f_blocks*s.f_frsize}
vm_files = []
for p in sorted(Path('/System/Volumes/VM').iterdir()):
    s = p.lstat()
    vm_files.append({'name': p.name, 'size_bytes': s.st_size, 'allocated_bytes': s.st_blocks*512,
                     'mtime_ns': s.st_mtime_ns, 'regular_file': stat.S_ISREG(s.st_mode)})

aggregate_scopes = {
    'project_run_evidence': BASE,
    'original_workspace': Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease'),
    'downloads_aggregate_only_unqualified_personal_scope': Path('/Users/macuser/Downloads'),
    'pytensor_active_cache_protected': Path('/Users/macuser/.pytensor'),
}
aggregates = {}
for key, p in aggregate_scopes.items():
    r = command(['/usr/bin/du', '-sk', str(p)], timeout=20)
    commands[key] = r
    if r['actual_returncode'] == 0:
        aggregates[key] = {'path': str(p), 'allocated_bytes_from_du': int(r['stdout'].split()[0])*1024,
                           'started_at_utc': r['started_at_utc'], 'finished_at_utc': r['finished_at_utc']}

candidates = []
for label, relative in [
    ('protected_old_private_restore', 'private-programme-restore-20260927'),
    ('historical_render_metadata_overlap_only', 'agent-scratch/render/old'),
    ('historical_confirmatory_render_metadata_overlap_only', 'continuation-20260927/rendered_confirmatory'),
    ('historical_v3_trace_figures_metadata_overlap_only', 'render-equivalence-20260927/refactored_v3/figures/traces'),
]:
    p = BASE / relative
    r = command(['/usr/bin/du', '-sk', str(p)], timeout=10)
    commands[label] = r
    candidates.append({'label': label, 'path': str(p),
                       'allocated_bytes': int(r['stdout'].split()[0])*1024 if r['actual_returncode'] == 0 else None,
                       'cleanup_or_relocation_qualified': False,
                       'protected_by_owner': label == 'protected_old_private_restore',
                       'current_content_hash_verification_performed': False})

owners = [62025, 62026, 62027, 62028, 62029, 62030, 64406, 71385, 98854]
commands['nine_original_owner_argv'] = command(['/bin/ps', '-ww', '-p', ','.join(map(str, owners)),
                                               '-o', 'pid=,ppid=,uid=,lstart=,command='], timeout=10)
commands['nine_original_owner_cwd'] = command(['/usr/sbin/lsof', '-n', '-P', '-p', ','.join(map(str, owners)),
                                              '-d', 'cwd', '-Fpcfn'], timeout=10)

prior_paths = [
    EXT/'generator_correction_disk_budget_v1'/'REPORT.md',
    EXT/'generator_correction_disk_budget_v1'/'metadata_snapshot.json',
    EXT/'generator_correction_disk_budget_v1'/'budget_scenarios.json',
    EXT/'storage_refresh_v1'/'report.md',
    EXT/'storage_refresh_v1'/'size_receipt.json',
    BASE/'project_storage_metadata_inventory_20260929_v1'/'REPORT.md',
    BASE/'inactive_restore_qualification_20260929_v1'/'REPORT.md',
]
prior = [binding(p) for p in prior_paths]
old_budget = json.loads(prior_paths[2].read_text())
old_meta = json.loads(prior_paths[1].read_text())
old_refresh = json.loads(prior_paths[4].read_text())
historical_comparison = {
    '2026_09_28_0206_available_bytes': old_refresh['free_space_bytes'],
    '2026_09_29_0823_available_bytes': old_meta['volumes_start'][str(EXT)]['available_bytes'],
    '2026_09_29_1033_available_bytes_from_prior_report': 17017192448,
    'initial_this_audit_df_available_bytes': 6918524*1024,
    'initial_this_audit_exact_timestamp': None,
    'initial_this_audit_source': 'earlier tool-observed df; exact command acquisition timestamp was not captured',
    'earlier_refresh_statvfs_available_bytes': 83443273728,
    'earlier_refresh_exact_timestamp': None,
    'earlier_refresh_source': 'earlier tool-observed statvfs immediately after APFS showed 78,495,756,288 unallocated bytes',
    '08_23_original_remaining_three_attempts_conditional_bytes': old_budget['original_remaining_three_attempts']['additional_bytes'],
    '08_23_selected_remaining_three_attempts_conditional_bytes': old_budget['original_selected_remaining_three_attempts']['additional_bytes'],
    'old_project_evidence_regular_file_allocation_gib_rounded_from_prior_report': 17.850,
    'cause_of_large_available_space_change_verified': False,
    'old_forecast_is_not_a_fresh_run_completion_budget': True,
}
write('command_observations.json', commands)
write('prior_source_bindings.json', prior)
write('storage_checkpoint.json', {
    'schema_version': 1, 'started_at_utc': start, 'finished_at_utc': utc(),
    'status': 'metadata_only_current_space_recovered_no_relocation_justified',
    'current_volume_statvfs': current_volumes, 'vm_file_metadata': vm_files,
    'aggregates': aggregates, 'candidates': candidates,
    'historical_comparison': historical_comparison,
    'qualified_relocation_or_deletion_bytes': 0,
    'twelve_historical_compressed_archives_already_moved': True,
    'those_archives_counted_as_new_internal_candidates': False,
    'protected': ['original run and reproduction', 'all original code/data/matched inputs and coordinators',
                  'old private restore and both protected student baseline inputs',
                  'active scientific caches and locked environments', 'OS swap/VM',
                  'observer and replay trees', 'read-only old image and forensic preservation'],
    'unrelated_personal_filenames_or_paths_retained': False,
    'scientific_arrays_traces_read_or_hashed': False,
    'scientific_modules_imported': False, 'files_moved_deleted_or_relocated': False,
    'scientific_owners_signalled_or_restarted': False, 'settings_changed': False,
    'only_process_signal': 'freshly verified audit-owned stalled du PID66048, SIGTERM, actual tool exit143',
    'allocation_interpretation': 'du and st_blocks do not prove exclusive reclaimable APFS extents',
    'cause_of_free_space_fluctuation': 'unknown; no attribution to cloud, swap, tests, or any process was established',
})
print(json.dumps({'output': str(OUT), 'internal_available_bytes': current_volumes['/Users/macuser']['available_bytes'],
                  'project_run_evidence_allocated_bytes': aggregates.get('project_run_evidence',{}).get('allocated_bytes_from_du'),
                  'candidates': candidates, 'qualified_bytes': 0}, indent=2))
