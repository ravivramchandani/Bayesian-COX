# Mixed correction verification preparation v1

This is an external, prospective implementation. It has not been run on real
cohorts, source outcomes, corrective proposals, traces or forecasts. It does
not approve a method, create a freeze, certify reuse, fit a model, select a
proposal or claim that the programme is complete.

The sole numerical owner remains root. The original production commit is
`119476fef55b1eeb690527f234c1423440720d45`; frozen analysis is
`8551d326b02bfe88915cfd9eb50c6ca8e5690e3a`. `source_pins.json` records all small
production/analysis source bytes used by this adapter. The source baseline
references and the scientific contrast definitions remain unchanged.

## Scientific scope and prerequisites

The actual verifier requires the complete original 1625-cell grid and the
complete corrected 1625 logical outcomes, not just a count. It independently
reconstructs the original plan in order, including exact ordered patients,
the original censoring/subset rules, training-event counts, feature choices,
training-only preprocessing and encoded training/validation designs.

It requires a separate actual reviewed correction freeze and immutable
scientific definition, full 1650-context preflight (825 outer plus 825 WME
inner), independent normal-source first-draw replay receipts, transparent
complete 19/21/42 input roles, original seed identities and frozen method,
arithmetic, input-witness, implementation and freeze review bindings. It
delegates the existing byte-pinned pure arithmetic/pilot/freeze guards from
the reviewed fit runner; preparation itself cannot satisfy or approve them.
The maximum-dimension pilot list is independently reconstructed without
using original outcome availability or predictive performance. A pending
original pilot waits. A nonpilot changed fit needs the actual existing
full-budget pilot review authorising scale-up.

There are three truthful correction operations:

* `reuse_original_outcome` references original bytes, content, status and all
  referenced/orphan trace bytes. Identical original failures are reused as
  failures. No new execution is claimed.
* `fit_corrected_inputs` requires actual child rc0, its raw compatible cell,
  request, stdout/stderr, original environment-check invocation, actual
  interpreter/numeric-thread metadata, all role digests, generator usages,
  optimizer observations and complete child artifact inventory. WME changed
  inner inputs retain all nine candidate slots; verified cached inner tuning
  is distinguished from retuning.
* `retain_corrected_input_failure` records no fit. The reducer receives an
  explicitly derived failed analysis view without metrics, forecasts or
  invented sampler diagnostics. The original outcome is independently
  preserved/deep-checked. An earlier immutable pending-origin envelope keeps
  its null source evidence; it needs a separately reviewed later finished
  source snapshot before full closeout. No earlier envelope is rewritten.

Every original extension outcome is deep-checked, including changed cells'
original failures. Every newly fitted outcome is checked separately. All
stored posterior/joint-prior diagnostics are recomputed from the actual
available traces using frozen `check_convergence` and
`verify_trace_diagnostics`; the original target/tune/noncentering/remedy and
acceptance rules stay fixed. Failed partial chains keep their honest actual
dimensions. Referenced traces without stored diagnostics and orphan files are
audited without fabricating original diagnostic records; unreadable ones
remain explicit audit findings and their bytes are retained.

Stored numerical diagnostics are compared at the unchanged855 tolerance
`1e-10`. Deterministic verification reports record the verified stored
diagnostic digest and actual trace dimensions after that comparison, rather
than imposing an extra exact-float diagnostic gate. Unstored/orphan diagnostic
computation is availability-only audit evidence. Source trace bytes remain the
underlying record. Error messages replace the current trace-root prefix with a
logical label to permit restored-path replay.

All accepted original/new forecasts are rescored through the exact855
`SavedForecast` and unchanged evaluation function using independently
reconstructed ordered censored outcomes and encoded validation features.
No generator, SVD/rank call, optimizer, model fitting, MCMC or new prediction
call is made by the verification stage. AST loading selects only the exact
source-pinned verification or existing pure gate definitions; shared
scientific modules are normally imported from119 and their origins/bytes
are rechecked.

The mixed certificate is this implementation's own certificate. It never
inherits an original855 certificate for modified evidence. Primary, ADR-032
sampler and robustness references use their existing unchanged frozen
baseline verifiers; this scope is explicit and does not imply new baseline
trace calculations. Primary negative/incomplete findings are retained
separately. DCA keeps original horseshoe as `bayesian_horseshoe_original`
and the ADR-032 substituted horseshoe as a different reference arm.

## Frozen analysis and factual accounting

Only the existing reducers are delegated: the four formal families with
27/3/27/13 contrasts, existing RQ2 effects and existing DCA. Their missing-pair,
patient/train/horizon alignment, diagnostic exclusions, support gates,
Nadeau–Bengio intervals, Holm family definitions and cluster-bootstrap rules
remain the original rules. No new estimand, test, multiplicity family,
diagnostic/optimizer gate or unconditional iid interpretation is introduced.

`comparison_accounting.json` records old versus mixed statuses, operation
counts, changed-input roles, execution/diagnostic/terminal-input failure
classes and dataset/setting/model/condition coverage. These are factual
counts, not evidence that a failed original experiment was successful or
that the correction improves performance.

## Actual input-bindings document

Root supplies an ordinary finite JSON mapping with `content_sha256` equal to
the original canonical SHA256 of all other fields (sorted keys, compact
separators, UTF-8, no NaNs). It records schema version1 and the exact
`verification_preparation_receipt_sha256` from this preparation.

`roots` must supply explicit absolute, unlinked paths for exactly:

```
production analysis original_run corrected_run preflight witness_root
context_inventory fit_code contracts preflight_code reuse_code
candidate_module correction_config correction_addendum matched
primary sampler robustness
```

`contracts` and `candidate_module` are files; correction config/addendum and
matched are files. Code roots contain the original reviewed files. The
context inventory contains `contexts.jsonl` and `preparation_receipt.json`.
Previously released frozen primary/sampler/robustness directories are
supplied directly; no unnecessary duplicate baseline copies are required.

`files` supplies exactly these `{path, sha256}` bindings:

```
freeze definition inventory manifest arithmetic_accounting
```

The definition is `witness_root/definition.json`; manifest is the separately
frozen corrected-fit manifest, also copied byte-identically to corrected_run.
Arithmetic-account artifacts resolve relative to its bound parent. Each
review path in `review_paths` resolves the unchanged hash stored by freeze for
`method arithmetic input_witness implementation freeze`. Actual restored
locations may differ from freeze's historical path text; hashes are checked
and frozen bytes are not rewritten.

Optional `resolution_review` and `pilot_review` are `{path,sha256}` bindings.
They use the exact reviewed source-resolution/scale-up schemas of the fit
runner. A source-resolution review is required for pending-origin terminal
envelopes, and must cover their later exact finished-source snapshots. The
existing pilot review is required where a completed changed nonpilot fit is
present. The verifier does not invent either review.

All source/input/outcome/trace bytes are rechecked before and after completion
publication. Symlinks, conflicting pins, partial/extra cells, active owners,
missing/changed records, unbound raw/partial/orphan child files and unknown
output namespaces are refused. Original processes/files are never modified.

## Invocation and replay

Use the original locked Python. Root must retain the actual command, stdout,
stderr and exit code. The wrapper sets all five numeric-thread variables to
one and captures genuine verifier rc0; a leftover positive completion alone
is insufficient. The initial output and capture prefix must be new and
outside immutable inputs/preparation. Braced values below are placeholders.

```
{locked_python} -I -B {prep}/capture_verification.py \
  --preparation-receipt {prep}/preparation_receipt.json \
  --preparation-receipt-sha256 {receipt_byte_sha256} \
  --input-bindings {actual_bindings.json} \
  --input-bindings-sha256 {bindings_byte_sha256} \
  --output {new_verified_mixed_directory} \
  --capture-prefix {external_capture_prefix}
```

No placeholder invocation was executed during preparation. A direct actual
`verify_mixed_extensions.py` invocation requires all five of
`OMP_NUM_THREADS OPENBLAS_NUM_THREADS MKL_NUM_THREADS
VECLIB_MAXIMUM_THREADS NUMEXPR_NUM_THREADS` already set to `1`.

The initial CLI creates a new destination only. Closed/fsynced records publish
by exclusive atomic hard link. Finished per-cell checkpoints are write-once;
publication failures retain partial evidence and create no claim of completed
science. A failed initial attempt is retained and root chooses a fresh
destination after review; the tool does not repair or recover stale claims.

Fresh restored evidence can be deeply replayed without fitting or modifying
the restored payload:

```
{locked_python} -I -B {restored_prep}/verify_mixed_extensions.py \
  --preparation-receipt {restored_prep}/preparation_receipt.json \
  --preparation-receipt-sha256 {receipt_byte_sha256} \
  --input-bindings {receiving_bindings.json} \
  --input-bindings-sha256 {receiving_bindings_byte_sha256} \
  --output {restored_verified_mixed_directory} \
  --verify-existing --replay-prefix {fresh_external_replay_prefix}
```

Set numeric variables to1 for this direct replay. Receiving bindings resolve
restored extension/source/preflight/witness evidence and previously released
baseline directories. Scientific cells, aggregates, check reports, lineage and
the own completion are compared to unchanged payload bytes. Original actual
argv/path/timing metadata stays preserved. Fresh environment logs, claim and
replay receipt remain outside restored/source/baseline roots. A receiver must
capture actual CLI rc0; the replay receipt does not assert a future process exit.

## Rendering adapter and remaining closeout

`render_input.json` binds compatible scientific cells, exact aggregates and
the separate correction lineage. `render_verified_mix.py` later delegates the
pinned855 renderer after a complete own certificate and genuine verifier rc0
capture. It resolves the own `aggregates/` namespace, reads only byte-bound
mixed cells without copying traces, and adds an explicit correction footer.
The original source is not edited. It writes its own
`mixed_correction_lineage.json` alongside original renderer lineage. Raw capture
logs resolve by logical sibling filenames, not original Mac paths.

Actual rendering is invoked with explicit `--verified`, `--analysis`, new
`--output`, `--completion-sha256`, `--verification-capture`,
`--verification-capture-sha256` and the preparation-receipt path/hash. It was
not invoked in preparation. Figure creation remains distinct from actual
visual review. The old original-certificate-only reporting/claim/reproduction
helpers must not automatically certify this new mixed view.

Completion always keeps `programme_complete=false`. Corrected visual QA,
selected reproduction, a corrected reporting sidecar/final claim review and
private packaging/fresh remote restore replay remain pending. Release
packaging is root-owned and outside this module's scope.

## Preparation verification and history

Tests use fictional tiny receipts/trace bytes, injected diagnostic/scoring
callbacks and mocked child/environment invocations. They do not instantiate
the actual scientific backend, load real cohorts/arrays/traces, run source
preflight/generation/rank/SVD, optimize, fit, sample, score real forecasts,
reduce real cohorts or render figures. Source-only AST tests read small frozen
code and compile selected definitions; their pilot example uses fictional
dimensions and their forecast object merely stores a fictional mapping.

The guard suite covers accepted/failed/diagnostic-failed outcomes, diagnostic
remedy exhaustion, partial/unreadable/orphan traces, original negative/failure
accounting, patient/outcome/metric mismatch, complete/partial/duplicate scope,
all replay-request fields, WME nine-slot/cached-tuning distinctions, unchanged
NaN optimizer-predicate semantics, source-surface omissions, historical child
runtime/version/thread mismatch, byte changes, overwrite/collision/link/cleanup
failures and relocated-root exact scientific replay. Final stdout/stderr,
actual rc and start/finish source hashes are retained with scoped Ruff/syntax
checks. Prior failed attempts are retained, including the initial JSON parser
exception-type fix and import-format/unused-import lint findings.

Two independent bounded source-only interoperability reviews found and
resolved the replay-request and guard-source/runtime binding omissions.
These reviews and synthetic checks are preparation evidence, not numerical,
method, freeze, reuse or thesis-completion approval.
