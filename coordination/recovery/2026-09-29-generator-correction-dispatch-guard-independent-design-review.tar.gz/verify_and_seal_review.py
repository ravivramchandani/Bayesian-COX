"""Hash small source/design bytes and seal an external source-only review."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).absolute().parent
DESIGN = OUT.parent / "generator_correction_dispatch_guard_design_v1"
DESIGN_RECEIPT_SHA = "be9b8f6346b796e7b44f7935a12808669a00e8dbd99c822b99ae794fc572fb82"


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def binding(path):
    assert path.is_absolute() and ".." not in path.parts
    assert not any(item.is_symlink() for item in (path, *path.parents))
    assert path.is_file()
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def read_sealed(path):
    before = binding(path)
    value = json.loads(path.read_text())
    assert value["content_sha256"] == digest({key: item for key, item in value.items() if key != "content_sha256"})
    assert before == binding(path)
    return value


def write(name, value):
    assert "content_sha256" not in value
    value = {**value, "content_sha256": digest(value)}
    with (OUT / name).open("xb") as stream:
        stream.write((json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode())


def snapshot(expected):
    result = {}
    for path, source in expected.items():
        actual = binding(Path(path))
        assert actual == source["binding"], f"design-bound source changed: {path}"
        result[path] = actual
    return result


def main():
    assert binding(DESIGN / "receipt.json")["sha256"] == DESIGN_RECEIPT_SHA
    receipt = read_sealed(DESIGN / "receipt.json")
    expected_names = {"receipt.json", *receipt["artifacts"]}
    assert {item.name for item in DESIGN.iterdir()} == expected_names
    carrier = {}
    for name, expected in receipt["artifacts"].items():
        actual = binding(DESIGN / name)
        assert actual == expected, f"sealed design artifact changed: {name}"
        carrier[name] = actual
    carrier["receipt.json"] = binding(DESIGN / "receipt.json")
    design_bindings = read_sealed(DESIGN / "source_bindings_after.json")
    assert design_bindings["source_file_count"] == 20
    assert design_bindings["all_source_bytes_unchanged"] is True
    before = snapshot(design_bindings["files"])
    write("source_bindings_before.json", {"schema_version": 1, "status": "small_source_bytes_verified_before_review_seal", "created_at_utc": datetime.now(UTC).isoformat(), "files": before, "source_file_count": len(before), "target_imports_or_execution": False})
    write("design_carrier_verification.json", {"schema_version": 1, "status": "sealed_prospective_design_exact_bytes_verified", "design_path": str(DESIGN), "expected_receipt_sha256": DESIGN_RECEIPT_SHA, "artifacts": carrier, "artifact_count_including_receipt": len(carrier), "target_imports_or_execution": False})
    write("findings.json", {"schema_version": 1, "status": "additional_implementation_requirements_identified", "design_receipt_sha256": DESIGN_RECEIPT_SHA, "new_findings": [{"id": "DG-I1", "title": "Protect new immutable guard and reproduction directory roles before first writes", "kind": "prospective_launch_separation", "design_lines": [15, 30], "source_lines": {"fit_controller.py": [[60, 79], [331, 342]], "reproduction_core.py": [[94, 102]]}, "actual_implementation_status": "not_read_or_executed"}, {"id": "DG-I2", "title": "Receiving mode must exclude original-machine fallback reads", "kind": "fresh_restore_authority_and_physical_mapping", "design_lines": [55, 63], "source_lines": {"receiving_core.py": [[127, 185], [195, 208]]}, "actual_implementation_status": "not_read_or_executed"}], "previous_seven_crosscheck_findings_repeated_as_new": False, "actual_scientific_scope_freeze_adoption_or_release_approval": False})
    after = snapshot(design_bindings["files"])
    assert after == before
    assert binding(DESIGN / "receipt.json")["sha256"] == DESIGN_RECEIPT_SHA
    write("source_bindings_after.json", {"schema_version": 1, "status": "small_source_bytes_verified_after_review_seal", "created_at_utc": datetime.now(UTC).isoformat(), "files": after, "source_file_count": len(after), "source_bytes_unchanged": True, "target_imports_or_execution": False})
    artifacts = {str(path.relative_to(OUT)): binding(path) for path in sorted(OUT.iterdir()) if path.is_file()}
    write("receipt.json", {"schema_version": 1, "status": "independent_prospective_dispatch_guard_source_only_design_review_sealed", "created_at_utc": datetime.now(UTC).isoformat(), "design_receipt_sha256": DESIGN_RECEIPT_SHA, "reviewer_agent": "/root/dispatch_guard_independent_design_review", "new_findings": ["DG-I1", "DG-I2"], "source_file_count": len(after), "source_bytes_unchanged": True, "unsealed_runtime_draft_read": False, "target_imports_or_execution": False, "datasets_arrays_traces_checkers_numerical_owners_or_git_inspected_or_changed": False, "actual_approval_selection_freeze_dispatch_or_release_created": False, "engineering_review_only": True, "artifacts": artifacts, "artifact_count": len(artifacts), "archival_file_count_including_receipt": len(artifacts) + 1})
    print(json.dumps({"status": "sealed", "receipt_path": str(OUT / "receipt.json"), "receipt_binding": binding(OUT / "receipt.json"), "artifact_count_including_receipt": len(artifacts) + 1, "source_file_count": len(after), "source_bytes_unchanged": True, "new_findings": ["DG-I1", "DG-I2"]}, sort_keys=True))


if __name__ == "__main__":
    main()
