"""Preserve reviewed v2 bundle preparation and exact historical input bytes."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import sys
import tarfile
import types
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
ROOT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
DEPENDENCY_SHA = '2f4700bc6afaa49e996f77f9335261888cfd1e470967712c567cc0c8b3f62c64'
V1_SHA = 'b3a9ad2eaf7663a95ffc8d1987918567586bffbfd899445316ee49fae0da7dab'


def main() -> None:
    """Check prepared inputs, retain dated accounting and byte-roundtrip once."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reviewed-receipt-sha256', required=True)
    args = parser.parse_args()
    if len(args.reviewed_receipt_sha256) != 64 or any(
        c not in '0123456789abcdef' for c in args.reviewed_receipt_sha256
    ):
        raise ValueError('A reviewed receipt SHA-256 is required')
    dependency = BASE / 'preserve_reporting_preparation_v1.py'
    dependency_bytes = dependency.read_bytes()
    if hashlib.sha256(dependency_bytes).hexdigest() != DEPENDENCY_SHA:
        raise ValueError('Pinned preservation functions differ')
    s = types.ModuleType('_reviewed_preservation_functions')
    exec(compile(dependency_bytes, str(dependency), 'exec'), s.__dict__)
    archive = ROOT / 'coordination/recovery/2026-09-28-extension-bundle-v2-preparation.tar.gz'
    verification = ROOT / 'coordination/recovery/2026-09-28-extension-bundle-v2-preparation-verification.json'
    if archive.exists() or verification.exists():
        raise ValueError('Recovery output already exists; preserve its bytes')
    tested_bytes = (BASE / 'transfer_validation_v5_extension_documentation/tested_source.json').read_bytes()
    tested = json.loads(tested_bytes)
    s.check_tested_source(tested)
    preparation = BASE / 'final_validation_bundle_preparation_v2'
    prepared, files = s.checked_preparation(preparation, args.reviewed_receipt_sha256)
    if prepared['status'] != 'validation_bundle_v2_preparation_validated':
        raise ValueError('Preparation is not sealed and validated')
    commands = json.loads(files['preparation_command_evidence.json'])['commands']
    if any(row['exit_code'] != 0 for row in commands) or [r['check_count'] for r in commands] != [43, 20]:
        raise ValueError('Prepared guard checks did not pass')
    for row in commands:
        for stream in ('stdout', 'stderr'):
            if s.sha(files[Path(row[f'{stream}_path']).name]) != row[f'{stream}_sha256']:
                raise ValueError('Guard output bytes differ')
    syntax = json.loads(files['syntax_checks.json'])
    if syntax['status'] != 'passed' or syntax['source_count'] != 6:
        raise ValueError('Prepared syntax checks did not pass')
    previous, previous_files = s.checked_preparation(BASE / 'final_validation_bundle_preparation_v1', V1_SHA)
    old_manifest = json.loads(previous_files['input_manifest.json'])
    new_manifest = json.loads(files['input_manifest_v2.json'])
    for row in (*old_manifest['files'], *new_manifest['files']):
        s.check_bytes(Path(row['source']), row)
    for row in old_manifest['archive_members']:
        path = Path(row['archive'])
        if s.sha(path.read_bytes()) != row['archive_sha256']:
            raise ValueError('Historical archive differs')
        with tarfile.open(path, 'r:gz') as tar:
            item = tar.getmember(row['member'])
            stream = tar.extractfile(item)
            if not item.isfile() or stream is None:
                raise ValueError('Historical member is not an ordinary file')
            raw = stream.read()
            if len(raw) != row['bytes'] or s.sha(raw) != row['sha256']:
                raise ValueError('Historical archived member differs')
    for rel, spec in new_manifest['original_v1_files'].items():
        s.check_bytes(BASE / 'final_validation_bundle_preparation_v1' / rel, spec)
    manifest_raw = (BASE / 'run/manifest.json').read_bytes()
    if s.sha(manifest_raw) != s.MANIFEST_SHA:
        raise ValueError('Frozen numerical manifest differs')
    planned = {row['cell_id'] for row in json.loads(manifest_raw)['plan']}
    start = datetime.now(timezone.utc).isoformat()
    statuses: Counter[str] = Counter()
    settings: Counter[str] = Counter()
    cells = []
    for path in sorted((BASE / 'run/cells').glob('*.json')):
        raw = path.read_bytes()
        cell = json.loads(raw)
        if cell['cell_id'] != path.stem or cell['cell_id'] not in planned:
            raise ValueError('Unexpected stored numerical cell')
        statuses[cell['status']] += 1
        settings[f"{cell['dataset']}/{cell['setting']}"] += 1
        cells.append({'path': str(path.relative_to(BASE)), 'sha256': s.sha(raw)})
    snapshot = {
        'observation_started_utc': start, 'observed_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Partial stored-cell accounting while workers run; completion unassessed',
        'planned_cells': len(planned), 'stored_cells': len(cells),
        'statuses': dict(statuses), 'settings': dict(settings), 'cell_bytes': cells,
        'candidate_refits': len(list((BASE / 'reproduction/cells').glob('*.json'))),
        'official_refit_receipts': len(list((BASE / 'reproduction/receipts').glob('*.json'))),
        'markers': {name: (BASE / name).exists() for name in (
            'analysis_prepared.json', 'coordinator_failure.json',
            'postfit_support_prepared_v1.json', 'postfit_support_failure_v1.json',
        )},
    }
    review = {
        'schema_version': 1, 'verified_utc': datetime.now(timezone.utc).isoformat(), 'reviewer': 'root',
        'status': 'bundle_v2_preparation_reviewed_actual_outputs_and_transfer_pending',
        'preparation_receipt_sha256': args.reviewed_receipt_sha256,
        'preparation_bound_files_verified': len(prepared['files']),
        'assembler_sha256': prepared['v2_assembler_sha256'],
        'synthetic_metadata_checks_passed': prepared['synthetic_metadata_checks'],
        'mocked_capture_io_checks_passed': prepared['mocked_capture_io_checks'],
        'syntax_sources_checked': prepared['syntax_sources'],
        'independent_review_sha256': prepared['independent_review_sha256'],
        'root_review': 'Read wrapper, captures, IO, contract, README and review; verified staging namespace compatibility',
        'original_v1_receipt_sha256': V1_SHA, 'original_v1_bound_files_unchanged': len(previous['files']),
        'original_v1_total_files_unchanged': len(new_manifest['original_v1_files']),
        'historical_files_verified': len(old_manifest['files']),
        'historical_archive_members_verified': len(old_manifest['archive_members']),
        'new_static_reporting_recovery_files_verified': len(new_manifest['files']),
        'tested_source_files_unchanged': len(tested), 'tested_source_sha256': s.sha(tested_bytes),
        'reviewed_invocation': sys.argv, 'actual_reporting_or_claim_helpers_invoked': False,
        'actual_validation_bundle_assembled': False, 'models_fitted': False,
        'release_download_restore_executed': False, 'scientific_completion_certified': False,
    }
    members = {f'preparation/final_validation_bundle_preparation_v2/{rel}': raw for rel, raw in files.items()}
    members['root_preparation_review.json'] = s.encoded(review)
    members['dated_source_snapshot.json'] = s.encoded(snapshot)
    members['preparation/preserve_bundle_v2_preparation.py'] = Path(__file__).read_bytes()
    members['preparation/preserve_reporting_preparation_v1.py'] = dependency_bytes
    members['archive_inventory.json'] = s.encoded({
        rel: {'bytes': len(raw), 'sha256': s.sha(raw)} for rel, raw in sorted(members.items())
    })
    with archive.open('xb') as output, gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for rel, raw in sorted(members.items()):
                item = tarfile.TarInfo(rel)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                tar.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive, 'r:gz') as tar:
        if len(tar.getmembers()) != len(members) or {p.name for p in tar.getmembers()} != set(members):
            raise ValueError('Recovery member inventory differs')
        for item in tar.getmembers():
            stream = tar.extractfile(item)
            if not item.isfile() or stream is None or stream.read() != members[item.name]:
                raise ValueError('Recovery member byte roundtrip differs')
    if s.checked_preparation(preparation, args.reviewed_receipt_sha256)[1] != files:
        raise ValueError('V2 preparation changed during preservation')
    if s.checked_preparation(BASE / 'final_validation_bundle_preparation_v1', V1_SHA)[1] != previous_files:
        raise ValueError('V1 preparation changed during preservation')
    s.check_tested_source(tested)
    review.update({
        'archive': str(archive.relative_to(ROOT)), 'archive_sha256': s.sha(archive.read_bytes()),
        'archive_bytes': archive.stat().st_size, 'archive_members_verified': len(members),
        'archive_inventory_sha256': s.sha(members['archive_inventory.json']),
        'dated_partial_checkpoint': {key: value for key, value in snapshot.items() if key != 'cell_bytes'},
    })
    with verification.open('xb') as stream:
        stream.write(s.encoded(review))
    print(s.encoded(review).decode(), end='')


if __name__ == '__main__':
    main()
