"""Check reporting metadata with invented in-memory artifacts only."""

from __future__ import annotations

import copy
import json

import assemble_validation_bundle_v2 as m


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()


def resign(value, field):
    value[field] = m.canonical({k: v for k, v in value.items() if k != field})


def fixture():
    """Invent all table/receipt contents; no actual results are read."""
    marker_paths = [m.BASE / 'run' / n for n in ['manifest.json', 'completion.json', 'verification.json',
                    'paired_families.json', 'rq2_effects.json', 'decision_curves.json']]
    marker_paths += [m.PRIMARY / 'manifest.json', m.PRIMARY / 'completion.json',
                     m.BASE / 'rendered_v1/lineage.json', m.BASE / 'pdf_qa_v1/visual_qa_receipt.json']
    inputs = {str(path): 'a' * 64 for path in marker_paths}
    roles = {'preparation/generate_reporting_sidecar.py': m.REPORTING_HELPER_SHA,
             'preparation/scope.json': m.SCOPE_SHA,
             'preparation/summarize_verified_claim_inputs.py': m.CLAIM_HELPER_SHA,
             'preparation/frozen_repeated_cv.py': m.INTERVAL_SHA}
    roles.update({'extension/' + path.name: inputs[str(path)] for path in marker_paths[:6]})
    roles.update({'primary/' + path.name: inputs[str(path)] for path in marker_paths[6:8]})
    counts = {'extension_cells': 1625, 'primary_cells_required': 450, 'descriptive_rows': 123,
              'clinical_rows': 63, 'matched_rows': 60, 'planned_fold_pairs': 3075,
              'dimension_availability_groups': [], 'included_fold_pairs': 1, 'excluded_fold_pairs': 3074}
    report = {'schema_version': 1, 'evidence_status': 'post_hoc_extension',
              'report_kind': 'descriptive_reporting_sidecar', 'scope_sha256': m.SCOPE_SHA,
              'production_commit': '119476fef55b1eeb690527f234c1423440720d45',
              'analysis_commit': m.ANALYSIS_COMMIT, 'counts': counts,
              'dimension_ratios': [{'synthetic': i} for i in range(1625)],
              'descriptive_catalytic_pairs': [{'synthetic': i} for i in range(123)],
              'formal_clinical_prior_family': {'logical_source': 'extension/paired_families.json',
                  'family': 'catalytic_vs_original_priors', 'expected_contrasts': 27,
                  'contrasts': [{'synthetic': i} for i in range(27)]}}
    lineage = {'schema_version': 1, 'evidence_status': 'post_hoc_extension', 'source_roles': roles,
               'scope_sha256': m.SCOPE_SHA, 'production_commit': report['production_commit'],
               'analysis_commit': m.ANALYSIS_COMMIT, 'interval_source_sha256': m.INTERVAL_SHA,
               'numerical_prerequisite_helper_sha256': m.CLAIM_HELPER_SHA}
    generated = {'schema_version': 1, 'status': 'reporting_sidecar_generated', 'operation': 'generate',
                 'evidence_status': 'post_hoc_extension', 'scientific_completion_certified': False,
                 'helper_sha256': m.REPORTING_HELPER_SHA}
    replay = {'schema_version': 1, 'status': 'reporting_sidecar_replayed', 'operation': 'verify_existing',
              'evidence_status': 'post_hoc_extension', 'scientific_completion_certified': False,
              'helper_sha256': m.REPORTING_HELPER_SHA, 'deterministic_artifacts_compared': 4,
              'invocation': {'argv': m.REPLAY_COMMAND[3:], 'resolved_roots': {
                  'extension': str(m.BASE / 'run'), 'primary': str(m.PRIMARY), 'sidecar': str(m.SIDECAR)},
                  'resolved_inputs': {'helper': str(m.REPORTING_PREP / 'generate_reporting_sidecar.py'),
                      'scope': str(m.REPORTING_PREP / 'scope.json'),
                      'claim_helper': str(m.REPORTING_PREP / 'summarize_verified_claim_inputs.py'),
                      'interval_source': str(m.REPORTING_PREP / 'frozen_repeated_cv.py')}}}
    claim = {'schema_version': 1, 'evidence_status': 'post_hoc_extension',
             'production_code_commit': report['production_commit'], 'analysis_code_commit': m.ANALYSIS_COMMIT,
             'source_manifest_sha256': inputs[str(m.BASE / 'run/manifest.json')],
             'source_completion_sha256': inputs[str(m.BASE / 'run/completion.json')],
             'source_verification_sha256': inputs[str(m.BASE / 'run/verification.json')],
             'aggregate_sha256': {n: inputs[str(m.BASE / 'run' / n)] for n in
                                 ['paired_families.json', 'rq2_effects.json', 'decision_curves.json']},
             'separate_receipts': {'official_selected_reproduction_receipts': 92,
                 'visual_qa_status_as_recorded': 'passed',
                 'render_lineage_sha256': inputs[str(m.BASE / 'rendered_v1/lineage.json')],
                 'visual_qa_receipt_sha256': inputs[str(m.BASE / 'pdf_qa_v1/visual_qa_receipt.json')]}}
    launch = {'schema_version': 1, 'status': 'claim_summary_invocation_passed',
              'helper_sha256': m.CLAIM_HELPER_SHA, 'command': m.CLAIM_COMMAND, 'exit_code': 0,
              'stdout_path': str(m.CLAIM_SUMMARY), 'started_utc': '2026-09-28T00:00:00Z',
              'finished_utc': '2026-09-28T00:00:01Z', 'input_sha256': inputs,
              'source_replay_invocation': {'command': m.REPLAY_COMMAND, 'exit_code': 0,
                  'stdout_path': str(m.SOURCE_REPLAY), 'started_utc': '2026-09-28T00:00:00Z',
                  'finished_utc': '2026-09-28T00:00:01Z'}}
    return {'report': report, 'lineage': lineage, 'generated': generated, 'replay': replay,
            'claim': claim, 'launch': launch, 'inputs': inputs,
            'csv_dimensions': ('synthetic\n' + ''.join(f'{i}\n' for i in range(1625))).encode(),
            'csv_comparisons': ('synthetic\n' + ''.join(f'{i}\n' for i in range(123))).encode()}


def payload(case):
    """Bind synthetic values consistently, allowing semantic guard testing."""
    payloads = {'dimension_ratios.csv': case['csv_dimensions'],
                'descriptive_catalytic_pairs.csv': case['csv_comparisons'], 'report.json': encode(case['report'])}
    lineage = copy.deepcopy(case['lineage'])
    lineage['source_binding_sha256'] = m.canonical(lineage['source_roles'])
    lineage['artifacts_sha256'] = {k: m.sha(v) for k, v in payloads.items()}
    payloads['lineage.json'] = encode(lineage)
    hashes = {k: m.sha(v) for k, v in payloads.items()}
    compact = {k: v for k, v in case['report']['counts'].items() if k != 'dimension_availability_groups'}
    generated, replay, launch = [copy.deepcopy(case[k]) for k in ['generated', 'replay', 'launch']]
    for value in (generated, replay):
        value['source_binding_sha256'] = lineage['source_binding_sha256']
        value['artifact_sha256'] = hashes
        value['counts'] = compact
    resign(generated, 'receipt_content_sha256')
    payloads['receipt.json'] = encode(generated)
    replay['original_receipt_sha256'] = m.sha(payloads['receipt.json'])
    resign(replay, 'receipt_content_sha256')
    replay_bytes, claim_bytes = encode(replay), encode(case['claim'])
    launch['stdout_sha256'] = m.sha(claim_bytes)
    launch['source_replay_invocation']['stdout_sha256'] = m.sha(replay_bytes)
    resign(launch, 'invocation_content_sha256')
    return payloads, replay_bytes, claim_bytes, encode(launch), case['inputs']


def main():
    passed = []
    valid = fixture()

    def good(name, operation):
        operation()
        passed.append({'name': name, 'outcome': 'accepted_expected_synthetic_metadata'})

    def bad(name, operation):
        try:
            operation()
        except (ValueError, KeyError, TypeError, OSError, RuntimeError):
            passed.append({'name': name, 'outcome': 'refused_expected_invalid_synthetic_metadata'})
        else:
            raise AssertionError(f'guard failed: {name}')

    def change(name, mutation):
        case = copy.deepcopy(valid)
        mutation(case)
        bad(name, lambda: m.validate_reporting(*payload(case)))

    good('valid_complete_roster_with_partial_descriptive_pairs_no_new_acceptance_gate',
         lambda: m.validate_reporting(*payload(valid)))
    change('missing_dimension_row', lambda c: c['report']['dimension_ratios'].pop())
    change('missing_comparator_row', lambda c: c['report']['descriptive_catalytic_pairs'].pop())
    change('dimension_csv_row_count', lambda c: c.update(csv_dimensions=b'id\n1\n'))
    change('comparator_csv_row_count', lambda c: c.update(csv_comparisons=b'id\n1\n'))
    change('report_roster_122', lambda c: c['report']['counts'].update(descriptive_rows=122))
    change('missing_formal_27_link', lambda c: c['report']['formal_clinical_prior_family']['contrasts'].pop())
    change('report_scope_pin', lambda c: c['report'].update(scope_sha256='b' * 64))
    change('sidecar_helper_role_pin', lambda c: c['lineage']['source_roles'].update({'preparation/generate_reporting_sidecar.py': 'b' * 64}))
    change('source_cell_metadata_binding', lambda c: c['lineage']['source_roles'].update({'extension/completion.json': 'b' * 64}))
    change('current_family_binding', lambda c: c['lineage']['source_roles'].update({'extension/paired_families.json': 'b' * 64}))
    change('generation_status', lambda c: c['generated'].update(status='pending'))
    change('replay_status', lambda c: c['replay'].update(status='reporting_sidecar_generated'))
    change('replay_operation', lambda c: c['replay'].update(operation='generate'))
    change('replay_only_three_artifacts', lambda c: c['replay'].update(deterministic_artifacts_compared=3))
    change('replay_certifies_science', lambda c: c['replay'].update(scientific_completion_certified=True))
    change('actual_replay_exit_nonzero', lambda c: c['launch']['source_replay_invocation'].update(exit_code=1))
    change('actual_claim_exit_nonzero', lambda c: c['launch'].update(exit_code=1))
    change('actual_claim_invocation_pending', lambda c: c['launch'].update(status='pending'))
    change('actual_claim_helper_changed', lambda c: c['launch'].update(helper_sha256='b' * 64))
    change('actual_claim_timestamp_naive', lambda c: c['launch'].update(started_utc='2026-09-28T00:00:00'))
    change('actual_claim_timestamp_reversed', lambda c: c['launch'].update(finished_utc='2026-09-27T00:00:00Z'))
    change('actual_claim_stdout_path_wrong', lambda c: c['launch'].update(stdout_path=str(m.SOURCE_REPLAY)))
    change('actual_source_replay_stdout_inside_five_file_sidecar', lambda c: c['launch']['source_replay_invocation'].update(stdout_path=str(m.SIDECAR / 'extra.json')))
    change('actual_claim_source_completion_changed', lambda c: c['claim'].update(source_completion_sha256='b' * 64))
    change('actual_claim_partial_official91', lambda c: c['claim']['separate_receipts'].update(official_selected_reproduction_receipts=91))
    change('actual_claim_visualqa_pending', lambda c: c['claim']['separate_receipts'].update(visual_qa_status_as_recorded='pending'))
    change('actual_claim_missing_aggregate', lambda c: c['claim']['aggregate_sha256'].pop('decision_curves.json'))
    change('actual_claim_extra_input_hash', lambda c: c['launch'].update(input_sha256={**c['launch']['input_sha256'], '/synthetic/unbound': 'a' * 64}))
    change('actual_source_replay_wrong_host_root', lambda c: c['replay']['invocation']['resolved_roots'].update(primary='/synthetic/wrong'))
    change('actual_source_replay_wrong_dependency', lambda c: c['replay']['invocation']['resolved_inputs'].update(scope='/synthetic/wrong'))
    change('actual_claim_cli_duplicate_flag', lambda c: c['launch']['command'].extend(['--run', str(m.BASE / 'run')]))
    change('actual_replay_cli_missing_verify_flag', lambda c: c['launch']['source_replay_invocation']['command'].remove('--verify-existing'))

    args = list(payload(valid))
    changed = m.strict(args[1]);changed['original_receipt_sha256'] = 'b' * 64;resign(changed, 'receipt_content_sha256')
    args[1] = encode(changed)
    bad('original_generation_receipt_byte_changed', lambda: m.validate_reporting(*args))
    args = list(payload(valid));args[0] = dict(args[0]);args[0]['extra.json'] = b'{}'
    bad('sixth_sidecar_file', lambda: m.validate_reporting(*args))
    for name, raw in [('duplicate_json_key', b'{"x":1,"x":2}'), ('nan_literal', b'{"x":NaN}'),
                      ('float_overflow', b'{"x":1e999}'), ('json_not_object', b'[]')]:
        bad(name, lambda data=raw: m.strict(data))
    a = m.load_v1()  # byte-pinned static preparation only, no v1 plan/science invocation
    good('pinned_original_v1_static_checks_loaded', lambda: m.require(callable(a.prepare_plan) and callable(a.copy_checked), 'missing original checks/copier'))
    good('v1_fresh_output_policy_reused', lambda: a.output_policy(a.DEFAULT_OUTPUT, False, True))
    bad('v1_existing_destination_refused_before_output', lambda: a.output_policy(a.DEFAULT_OUTPUT, True, True))
    bad('v1_unsafe_output_parent_refused_before_output', lambda: a.output_policy(a.DEFAULT_OUTPUT, False, False))
    print(json.dumps({'status': 'v2_static_pins_and_synthetic_metadata_guards_passed', 'checks_passed': len(passed),
                      'checks': passed, 'actual_results_or_cells_traces_read': False,
                      'actual_sidecar_claim_helpers_invoked': False, 'v1_plan_or_v2_assembler_executed': False,
                      'filesystem_output_created_by_checks': False, 'actual_review_or_receipts_created': False},
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
