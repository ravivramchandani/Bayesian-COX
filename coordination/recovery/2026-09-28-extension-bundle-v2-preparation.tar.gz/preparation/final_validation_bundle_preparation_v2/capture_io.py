"""Exclusive capture publication and separate failure retention; no science."""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def install_once(path: Path, data: bytes) -> None:
    """Fsync and close a temporary file, then hard-link without replacement."""
    require(path.is_absolute() and '..' not in path.parts and path.parent.is_dir()
            and not path.exists() and not path.is_symlink()
            and not any(p.is_symlink() for p in path.parents), 'capture destination must be fresh and safe')
    pending = path.with_name('.' + path.name + '.pending-' + uuid.uuid4().hex)
    # Retain any failed pending bytes. They never use a successful fixed name.
    with pending.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.link(pending, path)  # atomic exclusive installation; a collision is refused
    pending.unlink()
    require(path.read_bytes() == data, 'installed capture byte roundtrip differs')


def preserve_failure(parent: Path, prefix: str, *, command: list[str],
                     started: str, finished: str, exit_code: int | None,
                     stdout: bytes, stderr: bytes, error: str) -> Path:
    """Retain actual failed stdout/stderr/rc under a separate exclusive prefix."""
    require(parent.is_dir() and not any(p.is_symlink() for p in (parent, *parent.parents)),
            'failure-retention parent is unsafe')
    require(prefix and all(c.isalnum() or c in '_-' for c in prefix), 'unsafe diagnostic prefix')
    output = parent / (prefix + '_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
                       + '_' + uuid.uuid4().hex)
    output.mkdir(exist_ok=False)
    record = {'schema_version': 1, 'status': 'failed_capture_diagnostic_only',
              'command': command, 'started_utc': started, 'finished_utc': finished,
              'exit_code': exit_code, 'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr),
              'error': error, 'successful_output_installed_by_failure_retention': False}
    for name, data in [('stdout.bin', stdout), ('stderr.bin', stderr),
                       ('failure_invocation.json', (json.dumps(record, sort_keys=True, indent=2) + '\n').encode())]:
        with (output / name).open('xb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    return output
