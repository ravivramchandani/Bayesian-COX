"""Later replay driver: capture genuine relocated helper stdout and rc0 outside evidence.

Do not run on the active partial programme. Root invokes this only after fresh
archive/scientific restore; it computes reporting alone and never publishes.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

PREP_RECEIPT = '3c71be36cf4f95029da1a724f730de8242bb461de65a87e5eabe41c69f6c4952'
HELPER_SHA = 'e8930fc49b1d5f81ae85d98fd1492a6a2209d31ddb8b66b7ff828d7d36bf89f8'
IO_SHA = 'ee526b0cbc1e96d6886a1ab69a9d9f836c0514e44e9cc1225d49064e13db8acc'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode())


def bytes_at(path):
    require(path.is_file() and not any(p.is_symlink() for p in (path, *path.parents)), f'unsafe input: {path}')
    return path.read_bytes()


def pinned_preparation(root):
    """Verify every sealed reporting dependency before launching its command."""
    data = bytes_at(root / 'preparation_receipt.json')
    require(sha(data) == PREP_RECEIPT, 'restored reporting preparation receipt differs')
    receipt = json.loads(data)
    require(receipt['receipt_content_sha256'] == canonical({k: v for k, v in receipt.items() if k != 'receipt_content_sha256'}), 'reporting preparation content digest differs')
    for name, row in receipt['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'unsafe preparation inventory name')
        data = bytes_at(root / name)
        require(sha(data) == row['sha256'] and len(data) == row['bytes'], f'restored reporting dependency differs: {name}')
    require(sha(bytes_at(root / 'generate_reporting_sidecar.py')) == HELPER_SHA, 'restored helper differs')


def load_io():
    source = Path(__file__).absolute().parent / 'capture_io.py'
    require(sha(bytes_at(source)) == IO_SHA, 'restored replay capture IO source differs')
    spec = importlib.util.spec_from_file_location('_pinned_restored_replay_io', source)
    require(spec is not None and spec.loader is not None, 'cannot load pinned replay IO')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('restored', 'primary', 'python', 'receipt', 'invocation-receipt'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    io = load_io()
    for path in (args.restored, args.primary):
        require(path.is_absolute() and '..' not in path.parts and path.is_dir()
                and not any(p.is_symlink() for p in (path, *path.parents)), 'restored/primary root is unsafe')
    require(args.python.is_absolute() and args.python.is_file(), 'verified frozen Python path must be absolute')
    outputs = (args.receipt, args.invocation_receipt)
    require(outputs[0] != outputs[1], 'raw and invocation receipts must be distinct')
    for path in outputs:
        require(path.is_absolute() and '..' not in path.parts and path.parent.is_dir()
                and not path.exists() and not path.is_symlink()
                and not any(p.is_symlink() for p in path.parents), 'external receipt path must be fresh and safe')
        require(not path.is_relative_to(args.restored) and not path.is_relative_to(args.primary),
                'fresh replay receipts must remain outside immutable restored/baseline roots')
    support = args.restored / 'execution/current_integration_validation'
    prep = support / 'reporting_sidecar_preparation_v1'
    sidecar = support / 'final_reporting_sidecar'
    pinned_preparation(prep)
    command = [str(args.python), '-B', str(prep / 'generate_reporting_sidecar.py'),
               '--run', str(args.restored / 'evidence/run'), '--primary', str(args.primary),
               '--output', str(sidecar), '--verify-existing']
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, capture_output=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, check=False)
    finished = datetime.now(timezone.utc).isoformat()
    if result.returncode != 0:
        diagnostic = io.preserve_failure(args.receipt.parent, 'restored_reporting_replay_failure',
                                         command=command, started=started, finished=finished,
                                         exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr,
                                         error='actual subprocess returned nonzero; no successful replay outputs installed')
        raise RuntimeError(f'actual restored reporting replay exited {result.returncode}; diagnostics: {diagnostic}')
    try:
        raw = json.loads(result.stdout)
        require(raw.get('status') == 'reporting_sidecar_replayed' and raw.get('operation') == 'verify_existing'
                and raw.get('deterministic_artifacts_compared') == 4 and raw.get('helper_sha256') == HELPER_SHA
                and raw.get('original_receipt_sha256') == sha(bytes_at(sidecar / 'receipt.json'))
                and raw.get('scientific_completion_certified') is False
                and raw.get('receipt_content_sha256') == canonical({k: v for k, v in raw.items() if k != 'receipt_content_sha256'}),
                'actual fresh replay stdout lacks the expected passed deterministic reporting binding')
        require(set(raw['artifact_sha256']) == {'dimension_ratios.csv', 'descriptive_catalytic_pairs.csv', 'report.json', 'lineage.json'},
                'fresh replay artifact inventory differs')
        for name, expected in raw['artifact_sha256'].items():
            require(sha(bytes_at(sidecar / name)) == expected, 'fresh sidecar bytes changed after replay')
        pinned_preparation(prep)
        invocation = {'schema_version': 1, 'status': 'restored_reporting_replay_invocation_passed',
                      'command': command, 'started_utc': started, 'finished_utc': finished,
                      'exit_code': result.returncode, 'stdout_path': str(args.receipt), 'stdout_sha256': sha(result.stdout),
                      'stderr_sha256': sha(result.stderr), 'helper_sha256': HELPER_SHA,
                      'reporting_preparation_receipt_sha256': PREP_RECEIPT,
                      'publication_performed': False, 'overall_programme_completion_certified': False}
        invocation['invocation_content_sha256'] = canonical(invocation)
        io.install_once(args.receipt, result.stdout)
        io.install_once(args.invocation_receipt, (json.dumps(invocation, indent=2, sort_keys=True) + '\n').encode())
    except Exception as error:
        io.preserve_failure(args.receipt.parent, 'restored_reporting_validation_or_install_failure',
                            command=command, started=started, finished=finished, exit_code=result.returncode,
                            stdout=result.stdout, stderr=result.stderr, error=str(error))
        raise
    print(json.dumps(invocation, indent=2, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        raise SystemExit(f'RESTORED REPORTING REPLAY REFUSED: {error}') from error
