"""Exercise exclusive capture/failure guards using memory and mocked processes."""

from __future__ import annotations

import contextlib
import hashlib
import io
import json
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import capture_io as storage
import capture_source_reporting_claims as source
import replay_restored_reporting as remote


class MemoryFiles:
    """A tiny in-memory filesystem; no scientific files or processes are used."""

    def __init__(self, failure=None):
        self.files = {}
        self.dirs = {Path('/'), Path('/synthetic')}
        self.links = set()
        self.events = []
        self.failure = failure

    def open(self, path, mode):
        if mode != 'xb' or path in self.files or path in self.dirs:
            raise FileExistsError(path)
        self.files[path] = b''
        self.events.append('open')
        fs = self

        class Stream:
            def __enter__(self):
                return self

            def write(self, data):
                fs.events.append('write')
                if fs.failure == 'write':
                    raise OSError('synthetic write failure')
                fs.files[path] += data

            def flush(self):
                fs.events.append('flush')
                if fs.failure == 'flush':
                    raise OSError('synthetic flush failure')

            def fileno(self):
                return 1

            def __exit__(self, *_args):
                fs.events.append('close')
                if fs.failure == 'close':
                    raise OSError('synthetic close failure')

        return Stream()

    def fsync(self, _fd):
        self.events.append('fsync')
        if self.failure == 'fsync':
            raise OSError('synthetic fsync failure')

    def link(self, pending, target):
        self.events.append('link')
        if self.failure == 'collision':
            self.files[target] = b'competing bytes'
        if target in self.files or target in self.dirs:
            raise FileExistsError(target)
        self.files[target] = self.files[pending]

    def mkdir(self, path, exist_ok=False):
        if path in self.files or path in self.dirs:
            raise FileExistsError(path)
        if exist_ok:
            raise AssertionError('diagnostic creation must be exclusive')
        self.dirs.add(path)

    @contextlib.contextmanager
    def mounted(self):
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(Path, 'exists', lambda p: p in self.files or p in self.dirs))
            stack.enter_context(patch.object(Path, 'is_dir', lambda p: p in self.dirs))
            stack.enter_context(patch.object(Path, 'is_symlink', lambda p: p in self.links))
            stack.enter_context(patch.object(Path, 'open', lambda p, mode: self.open(p, mode)))
            stack.enter_context(patch.object(Path, 'read_bytes', lambda p: self.files[p]))
            stack.enter_context(patch.object(Path, 'unlink', lambda p: self.files.pop(p)))
            stack.enter_context(patch.object(Path, 'mkdir', lambda p, exist_ok=False: self.mkdir(p, exist_ok)))
            stack.enter_context(patch.object(storage.os, 'fsync', self.fsync))
            stack.enter_context(patch.object(storage.os, 'link', self.link))
            stack.enter_context(patch.object(storage.uuid, 'uuid4', lambda: SimpleNamespace(hex='a' * 32)))
            yield


def main():
    checks = []

    def checked(name, function):
        function()
        checks.append({'name': name, 'outcome': 'passed_expected_synthetic_guard'})

    def refuses(function):
        try:
            function()
        except (ValueError, RuntimeError, OSError, json.JSONDecodeError):
            return
        raise AssertionError('invalid synthetic operation was accepted')

    target = Path('/synthetic/passed.json')

    def install_success():
        fs = MemoryFiles()
        with fs.mounted():
            storage.install_once(target, b'actual mocked stdout\n')
        assert fs.files == {target: b'actual mocked stdout\n'}
        assert fs.events.index('fsync') < fs.events.index('close') < fs.events.index('link')

    checked('fsync_close_before_exclusive_link_byte_roundtrip', install_success)

    def install_refused(kind):
        fs = MemoryFiles()
        path = target
        if kind == 'existing':
            fs.files[target] = b'preserved old bytes'
        elif kind == 'relative':
            path = Path('synthetic/passed.json')
        elif kind == 'linked_parent':
            fs.links.add(target.parent)
        elif kind == 'missing_parent':
            fs.dirs.remove(target.parent)
        with fs.mounted():
            refuses(lambda: storage.install_once(path, b'new bytes'))
        assert not fs.events
        if kind == 'existing':
            assert fs.files[target] == b'preserved old bytes'

    for kind in ('existing', 'relative', 'linked_parent', 'missing_parent'):
        checked('install_refuses_' + kind + '_before_open', lambda k=kind: install_refused(k))

    def install_failure(kind):
        fs = MemoryFiles(failure=kind)
        with fs.mounted():
            refuses(lambda: storage.install_once(target, b'new bytes'))
        assert any(p.name.startswith('.passed.json.pending-') for p in fs.files)
        if kind == 'collision':
            assert fs.files[target] == b'competing bytes'
        else:
            assert target not in fs.files and 'link' not in fs.events

    for kind in ('write', 'flush', 'fsync', 'close', 'collision'):
        checked('failed_' + kind + '_does_not_replace_successful_name', lambda k=kind: install_failure(k))

    def retained_failure():
        fs = MemoryFiles()
        with fs.mounted():
            output = storage.preserve_failure(Path('/synthetic'), 'synthetic_failure', command=['synthetic'],
                        started='start', finished='finish', exit_code=7, stdout=b'failed stdout',
                        stderr=b'failed stderr', error='actual mocked nonzero')
        assert output.name.startswith('synthetic_failure_') and output != target
        record = json.loads(fs.files[output / 'failure_invocation.json'])
        assert fs.files[output / 'stdout.bin'] == b'failed stdout'
        assert fs.files[output / 'stderr.bin'] == b'failed stderr'
        assert record['exit_code'] == 7 and record['stdout_sha256'] == storage.sha(b'failed stdout')
        assert record['stderr_sha256'] == storage.sha(b'failed stderr')
        assert record['successful_output_installed_by_failure_retention'] is False
        assert target not in fs.files

    checked('failure_retains_raw_bytes_and_actual_rc_under_separate_prefix', retained_failure)

    def invalid_prefix():
        fs = MemoryFiles()
        with fs.mounted():
            refuses(lambda: storage.preserve_failure(Path('/synthetic'), '../passed.json', command=[],
                      started='', finished='', exit_code=2, stdout=b'x', stderr=b'y', error='failure'))
        assert not fs.files and fs.dirs == {Path('/'), Path('/synthetic')}

    checked('unsafe_diagnostic_prefix_refused_before_creation', invalid_prefix)

    def captured_success():
        fake = Mock()
        process = subprocess.CompletedProcess(['synthetic'], 0, stdout=b'raw stdout\n', stderr=b'note')
        with patch.object(source.subprocess, 'run', return_value=process) as run:
            data, record, stderr = source.capture(['synthetic'], fake, Path('/synthetic'), 'failure')
        assert data == process.stdout and stderr == process.stderr and record['exit_code'] == 0
        assert record['stderr_sha256'] == hashlib.sha256(process.stderr).hexdigest()
        assert record['started_utc'] <= record['finished_utc']
        assert run.call_count == 1 and run.call_args.kwargs['check'] is False
        fake.install_once.assert_not_called()
        fake.preserve_failure.assert_not_called()

    checked('source_capture_records_real_mock_rc0_and_raw_stdout', captured_success)

    def captured_nonzero():
        fake = Mock()
        fake.preserve_failure.return_value = Path('/synthetic/separate_failure')
        process = subprocess.CompletedProcess(['synthetic'], 9, stdout=b'failed stdout', stderr=b'failed stderr')
        with patch.object(source.subprocess, 'run', return_value=process):
            refuses(lambda: source.capture(['synthetic'], fake, Path('/synthetic'), 'failure'))
        fake.install_once.assert_not_called()
        fake.preserve_failure.assert_called_once()
        actual = fake.preserve_failure.call_args.kwargs
        assert actual['exit_code'] == 9 and actual['stdout'] == process.stdout and actual['stderr'] == process.stderr

    checked('source_nonzero_cannot_install_fixed_success_names', captured_nonzero)

    def restored_case(kind):
        args = SimpleNamespace(restored=Path('/synthetic/restored'), primary=Path('/synthetic/primary'),
                               python=Path('/synthetic/python'), receipt=Path('/synthetic/replay.json'),
                               invocation_receipt=Path('/synthetic/replay_invocation.json'))
        fake = Mock()
        fake.preserve_failure.return_value = Path('/synthetic/separate_failure')
        if kind == 'inside_restored':
            args.receipt = args.restored / 'replay.json'
        elif kind == 'same_name':
            args.invocation_receipt = args.receipt
        elif kind == 'existing':
            pass
        original = b'original generation receipt'
        artifacts = {name: name.encode() for name in
                     ('dimension_ratios.csv', 'descriptive_catalytic_pairs.csv', 'report.json', 'lineage.json')}
        raw = {'status': 'reporting_sidecar_replayed', 'operation': 'verify_existing',
               'deterministic_artifacts_compared': 4, 'helper_sha256': remote.HELPER_SHA,
               'original_receipt_sha256': remote.sha(original), 'scientific_completion_certified': False,
               'artifact_sha256': {name: remote.sha(data) for name, data in artifacts.items()}}
        raw['receipt_content_sha256'] = remote.canonical(raw)
        stdout = json.dumps(raw).encode()
        rc = 0
        if kind == 'nonzero':
            rc, stdout = 7, b'failed raw stdout'
        elif kind == 'invalid_stdout':
            stdout = b'invalid JSON'
        process = subprocess.CompletedProcess(['synthetic'], rc, stdout=stdout, stderr=b'actual mocked stderr')
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(remote, 'load_io', return_value=fake))
            prep_check = stack.enter_context(patch.object(remote, 'pinned_preparation'))
            stack.enter_context(patch.object(remote.argparse.ArgumentParser, 'parse_args', return_value=args))
            stack.enter_context(patch.object(Path, 'is_dir', lambda _p: True))
            stack.enter_context(patch.object(Path, 'is_file', lambda _p: True))
            stack.enter_context(patch.object(Path, 'is_symlink', lambda _p: False))
            stack.enter_context(patch.object(Path, 'exists', lambda p: kind == 'existing' and p == args.receipt))
            stack.enter_context(patch.object(remote, 'bytes_at', lambda p: original if p.name == 'receipt.json' else artifacts[p.name]))
            run = stack.enter_context(patch.object(remote.subprocess, 'run', return_value=process))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            if kind == 'success':
                remote.main()
            else:
                refuses(remote.main)
        if kind in ('inside_restored', 'same_name', 'existing'):
            run.assert_not_called()
            fake.install_once.assert_not_called()
            fake.preserve_failure.assert_not_called()
        elif kind in ('nonzero', 'invalid_stdout'):
            assert run.call_count == 1
            fake.install_once.assert_not_called()
            fake.preserve_failure.assert_called_once()
            actual = fake.preserve_failure.call_args.kwargs
            assert actual['exit_code'] == rc and actual['stdout'] == stdout and actual['stderr'] == process.stderr
        else:
            assert run.call_count == 1 and prep_check.call_count == 2
            assert fake.install_once.call_count == 2
            installed = fake.install_once.call_args_list
            assert installed[0].args == (args.receipt, stdout)
            invocation = json.loads(installed[1].args[1])
            assert installed[1].args[0] == args.invocation_receipt
            assert invocation['exit_code'] == 0 and invocation['stdout_sha256'] == remote.sha(stdout)
            assert invocation['stdout_path'] == str(args.receipt)
            assert invocation['publication_performed'] is False
            assert invocation['overall_programme_completion_certified'] is False
            fake.preserve_failure.assert_not_called()
            command = run.call_args.args[0]
            support = args.restored / 'execution/current_integration_validation'
            assert command[2] == str(support / 'reporting_sidecar_preparation_v1/generate_reporting_sidecar.py')
            assert command[command.index('--output') + 1] == str(support / 'final_reporting_sidecar')
            assert command[command.index('--run') + 1] == str(args.restored / 'evidence/run')

    for kind in ('inside_restored', 'same_name', 'existing', 'nonzero', 'invalid_stdout', 'success'):
        checked('restored_replay_' + kind + '_mock_guard', lambda k=kind: restored_case(k))

    print(json.dumps({'schema_version': 1, 'status': 'passed_synthetic_capture_guards',
                      'checks': checks, 'check_count': len(checks), 'actual_helpers_invoked': False,
                      'subprocesses_mocked': True, 'filesystem_operation_tests_in_memory': True,
                      'actual_results_or_receipts_created': False}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
