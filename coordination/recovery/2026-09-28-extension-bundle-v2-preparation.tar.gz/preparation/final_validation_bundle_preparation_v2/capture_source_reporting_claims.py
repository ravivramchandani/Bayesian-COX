"""Later owner launch: retain actual source replay/claim stdout and invocation.

This helper is prepared only and must not run before genuine official92 and
passed visual QA. It does not generate the sidecar, fit, stage or publish.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928/final_validation_bundle_preparation_v2')
WRAPPER_SHA = '866739127dff7500e9d2046015b36661b70a8addbf4d354366ce35478087db15'
IO_SHA = 'ee526b0cbc1e96d6886a1ab69a9d9f836c0514e44e9cc1225d49064e13db8acc'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_wrapper():
    """Import the exact reviewed wrapper, never a mutable unchecked module."""
    source = HERE / 'assemble_validation_bundle_v2.py'
    require(source.is_file() and not any(p.is_symlink() for p in (source, *source.parents)), 'unsafe wrapper source')
    require(hashlib.sha256(source.read_bytes()).hexdigest() == WRAPPER_SHA, 'reviewed wrapper source changed')
    spec = importlib.util.spec_from_file_location('_pinned_v2_owner_capture', source)
    require(spec is not None and spec.loader is not None, 'cannot load pinned wrapper')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_io():
    source = HERE / 'capture_io.py'
    require(source.is_file() and not any(p.is_symlink() for p in (source, *source.parents))
            and hashlib.sha256(source.read_bytes()).hexdigest() == IO_SHA, 'capture IO source changed')
    spec = importlib.util.spec_from_file_location('_pinned_owner_capture_io', source)
    require(spec is not None and spec.loader is not None, 'cannot load pinned capture IO')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def capture(command, io, parent, prefix):
    """Record real subprocess boundaries and require genuine successful stdout."""
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, capture_output=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, check=False)
    finished = datetime.now(timezone.utc).isoformat()
    if result.returncode != 0:
        diagnostic = io.preserve_failure(parent, prefix, command=command, started=started, finished=finished,
                                         exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr,
                                         error='actual subprocess returned nonzero; no successful fixed output installed')
        raise RuntimeError(f'actual command exited {result.returncode}; retained diagnostics: {diagnostic}')
    record = {'command': command, 'started_utc': started, 'finished_utc': finished,
              'exit_code': result.returncode, 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    return result.stdout, record, result.stderr


def main():
    require(Path(__file__).absolute().parent == HERE, 'capture helper must run from prepared owner directory')
    m = load_wrapper()
    io = load_io()
    a = m.load_v1()
    own = m.strict(a.file_bytes(HERE / 'preparation_receipt.json'))
    m.self_hash(own, 'receipt_content_sha256')
    for name, row in own['files'].items():
        require(a.safe_name(name) and m.sha(a.file_bytes(HERE / name)) == row['sha256'], 'owner capture preparation changed')
    outputs = (m.SOURCE_REPLAY, m.CLAIM_SUMMARY, m.CLAIM_INVOCATION)
    for path in outputs:
        require(path.parent.is_dir() and not path.exists() and not path.is_symlink()
                and not any(p.is_symlink() for p in path.parents), 'source stdout/invocation outputs must all be fresh')
    require(m.sha(a.file_bytes(m.CLAIM_HELPER)) == m.CLAIM_HELPER_SHA, 'original factual claim helper differs')
    prep_bytes = a.file_bytes(m.REPORTING_PREP / 'preparation_receipt.json')
    require(m.sha(prep_bytes) == m.REPORTING_RECEIPT_SHA, 'reporting final preparation receipt differs')
    prep = m.strict(prep_bytes)
    m.self_hash(prep, 'receipt_content_sha256')
    for name, row in prep['files'].items():
        require(a.safe_name(name) and m.sha(a.file_bytes(m.REPORTING_PREP / name)) == row['sha256'], 'reporting helper/dependency differs')
    a.unlinked(m.SIDECAR, directory=True)
    require({p.name for p in m.SIDECAR.iterdir()} == set(m.SIDECAR_FILES), 'actual five-file sidecar is not ready')
    replay_bytes, replay_launch, replay_stderr = capture(m.REPLAY_COMMAND, io, m.BASE, 'source_reporting_replay_failure')
    claim_bytes, launch, claim_stderr = capture(m.CLAIM_COMMAND, io, m.BASE, 'source_claim_summary_failure')
    try:
        claim = m.strict(claim_bytes)
        inputs = m.current_claim_bindings(a, claim)
        replay_launch.update(stdout_path=str(m.SOURCE_REPLAY), stdout_sha256=m.sha(replay_bytes))
        launch.update(schema_version=1, status='claim_summary_invocation_passed', helper_sha256=m.CLAIM_HELPER_SHA,
                      stdout_path=str(m.CLAIM_SUMMARY), stdout_sha256=m.sha(claim_bytes), input_sha256=inputs,
                      source_replay_invocation=replay_launch)
        launch['invocation_content_sha256'] = m.canonical(launch)
        launch_bytes = a.encoded(launch)
        payloads = {name: a.file_bytes(m.SIDECAR / name) for name in m.SIDECAR_FILES}
        m.validate_reporting(payloads, replay_bytes, claim_bytes, launch_bytes, inputs)
        require(hashlib.sha256((HERE / 'assemble_validation_bundle_v2.py').read_bytes()).hexdigest() == WRAPPER_SHA,
                'reviewed wrapper changed during actual capture')
        for name, row in prep['files'].items():
            require(m.sha(a.file_bytes(m.REPORTING_PREP / name)) == row['sha256'], 'reporting preparation changed during actual capture')
        require(m.sha(a.file_bytes(m.CLAIM_HELPER)) == m.CLAIM_HELPER_SHA, 'claim helper changed during actual capture')
        # Raw stdout is preserved exactly; fsynced/closed exclusive links only.
        io.install_once(m.SOURCE_REPLAY, replay_bytes)
        io.install_once(m.CLAIM_SUMMARY, claim_bytes)
        io.install_once(m.CLAIM_INVOCATION, launch_bytes)
    except Exception as error:
        io.preserve_failure(m.BASE, 'source_claim_capture_validation_or_install_failure',
                            command=m.CLAIM_COMMAND, started=launch['started_utc'], finished=launch['finished_utc'],
                            exit_code=launch['exit_code'], stdout=claim_bytes, stderr=claim_stderr, error=str(error))
        io.preserve_failure(m.BASE, 'source_replay_capture_validation_or_install_failure',
                            command=m.REPLAY_COMMAND, started=replay_launch['started_utc'], finished=replay_launch['finished_utc'],
                            exit_code=replay_launch['exit_code'], stdout=replay_bytes, stderr=replay_stderr, error=str(error))
        raise
    print(json.dumps({'status': 'actual_source_reporting_and_claim_stdout_captured',
                      'source_replay': str(m.SOURCE_REPLAY), 'claim_summary': str(m.CLAIM_SUMMARY),
                      'invocation': str(m.CLAIM_INVOCATION), 'input_byte_bindings': len(inputs),
                      'publication_performed': False}, indent=2, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        raise SystemExit(f'SOURCE REPORTING/CLAIM CAPTURE REFUSED: {error}') from error
