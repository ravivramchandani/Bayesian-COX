# Bounded v2 preparation result

Prepared v2 assembler/capture/replay sources are sealed separately from v1.
No actual numerical/reporting/claim/audit helper, bundle assembly, staging,
download, restore, fitting or publication was invoked. No repo files changed.

The reviewed wrapper is unchanged (`866739127dff7500e9d2046015b36661b70a8addbf4d354366ce35478087db15`).
It verifies the original v1 source, receipt, manifest and all 16 preparation
files before import, reuses its support gates/copier/archive checks, and copies
original preparation/history without modification. The 359-file historical
manifest and six archive members remain the original inventory. The new static
manifest binds 20 additions: sealed 15-file reporting preparation, three
commit-7173 recovery/review files, and two commit-9db7 reporting recovery files.

Dynamic actual inputs remain absent: five-file sidecar, separate source-replay
stdout, claim stdout, actual claim invocation receipt, genuine root support
review and final v3 output. Later actual support/rank/boundary and companion logs
must satisfy the unchanged v1 gates. No findings-clean-only science gate added.

The later source capture records actual rc0/raw stdout, UTC process boundaries,
stderr hashes and 111 input bindings (19 metadata plus 92 official receipts).
Its receipt has 13 owner fields and a nested seven-field source-replay record.
Nonzero/invalid stdout is retained only as diagnostic evidence; fixed successful
names require actual rc0 and validated bindings. Fsync/close precedes exclusive
atomic installation; collisions preserve existing bytes.

Six sources parsed successfully; 43 synthetic metadata guards and 20 mocked
capture/I/O guards passed. Independent source review found no material wrapper
or capture defect. Test artifacts are synthetic, never actual programme output.

The receiving addendum uses exactly the restored support preparation/output and
`RESTORED/evidence/run`, with primary baseline restored separately. A fresh replay
must pass after archive/scientific restore. Its raw stdout and process receipt
remain outside immutable extension/primary and are retained in final Git/release
evidence before publication. Private draft/overall completion remain unassessed.
