"""Preserve actual reporting/claim evidence with unchanged v1 support gates.

This standard-library wrapper never generates results, audits science, invokes
reporting helpers, stages transfers or writes a root review. It requires later
actual outputs and invocation receipts before creating a fresh v3 directory.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import io
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = BASE / 'final_validation_bundle_preparation_v2'
V1 = BASE / 'final_validation_bundle_preparation_v1'
REPORTING_PREP = BASE / 'final_reporting_sidecar_preparation_v1'
SIDECAR = BASE / 'reporting_sidecar_v1'
SOURCE_REPLAY = BASE / 'reporting_sidecar_source_replay_v1.json'
CLAIM_SUMMARY = BASE / 'final_claim_summary_v1.json'
CLAIM_INVOCATION = BASE / 'final_claim_summary_invocation_v1.json'
CLAIM_HELPER = BASE / 'final_claim_review_preparation_v1/summarize_verified_claim_inputs.py'
PYTHON = '/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python'
PRIMARY = Path('/Users/macuser/bayes-cox-runs/student-restore-check-20260928/reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651')
PROGRAMME = Path('/Users/macuser/bayes-cox-runs/student-programme-results-20260928')
EXPLANATION = PROGRAMME / 'explanation/confirmatory_v1_confirmatory_cdcdcee84651_explainability_v1.json'
QA_REVIEW = BASE / 'pdf_qa_v1/review.json'
V1_SOURCE_SHA = '7053925e73806b908bf36f9d1aba06514b926e03582b90005d3edd75f577cb02'
V1_RECEIPT_SHA = 'b3a9ad2eaf7663a95ffc8d1987918567586bffbfd899445316ee49fae0da7dab'
V1_MANIFEST_SHA = '170874703c5397e21672569f18c82667972fb61e65833b4050b549a1aa59ff98'
REPORTING_RECEIPT_SHA = '3c71be36cf4f95029da1a724f730de8242bb461de65a87e5eabe41c69f6c4952'
REPORTING_HELPER_SHA = 'e8930fc49b1d5f81ae85d98fd1492a6a2209d31ddb8b66b7ff828d7d36bf89f8'
SCOPE_SHA = '1cbdacdbd29a51b00011be33933efd84448b28afc58386ac90b5d31142e8f59f'
CLAIM_HELPER_SHA = '378861de7036344e0272da8b27701f1c96bad3558e88247dd18e00ac795d338d'
INTERVAL_SHA = '2cc04e2af5f3685c07cee5e79ce83fe5fd7df2f772dba3d84f43562236ab8004'
ANALYSIS_COMMIT = '8551d326b02bfe88915cfd9eb50c6ca8e5690e3a'
ARTIFACTS = ('dimension_ratios.csv', 'descriptive_catalytic_pairs.csv', 'report.json', 'lineage.json')
SIDECAR_FILES = (*ARTIFACTS, 'receipt.json')
CLAIM_ARGUMENTS = {
    '--run': str(BASE / 'run'), '--reproduction': str(BASE / 'reproduction'),
    '--rendered': str(BASE / 'rendered_v1'), '--qa-dir': str(BASE / 'pdf_qa_v1'),
    '--qa-review': str(QA_REVIEW), '--primary': str(PRIMARY),
    '--sampler': str(PROGRAMME / 'sampler_run'), '--robustness': str(PROGRAMME / 'robustness'),
    '--explanation': str(EXPLANATION),
}
CLAIM_COMMAND = [PYTHON, '-B', str(CLAIM_HELPER),
                 *[value for pair in CLAIM_ARGUMENTS.items() for value in pair]]
REPLAY_ARGUMENTS = {'--run': str(BASE / 'run'), '--primary': str(PRIMARY), '--output': str(SIDECAR)}
REPLAY_COMMAND = [PYTHON, '-B', str(REPORTING_PREP / 'generate_reporting_sidecar.py'),
                  *[value for pair in REPLAY_ARGUMENTS.items() for value in pair], '--verify-existing']
BASELINE_PINS = {
    PRIMARY / 'manifest.json': '2a1817365675aa179174b5edf5b3da67bbcb2be1b2eb4143347e4b295052ce02',
    PRIMARY / 'completion.json': '44d5d6e2c3cf4d0350c3bc8cb27291436c9934b219c4c895cb139525e6fa25f6',
    PROGRAMME / 'sampler_run/manifest.json': '76acf071cf41f5456538799625979775ad00a5ab699b55b88987fee7ed6c5d00',
    PROGRAMME / 'sampler_run/completion.json': '0684ca1e61ef8492f27c79f486ea8e57cc75e139808f9a15535f426e82d4833a',
    PROGRAMME / 'robustness/manifest.json': '0fc556b803da4f37daa9a63dbddc5ce5ffd350aa2b2831b0a6546b634c36139f',
    PROGRAMME / 'robustness/completion.json': '8f136a6b2f9cf0a18308db71d63a69b1b145b0c767548cc7465d4af73e781152',
    EXPLANATION: '120984c7edfac468f471b9f500470623689b2647e4bde56d271cc9623346ecd5',
}


def require(condition: bool, message: str) -> None:
    """Reject unsafe, absent, mismatched or unexecuted reporting evidence."""
    if not condition:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value: Any) -> str:
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'),
                          ensure_ascii=False, allow_nan=False).encode('utf-8'))


def strict(data: bytes) -> dict[str, Any]:
    """Reject duplicate keys, nonfinite literals and floating overflow."""
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f'duplicate JSON key: {key}')
            result[key] = value
        return result

    def number(value):
        result = float(value)
        require(math.isfinite(result), 'nonfinite/overflowing JSON number')
        return result

    def constant(value):
        raise ValueError(f'nonfinite JSON literal: {value}')

    result = json.loads(data, object_pairs_hook=unique, parse_float=number, parse_constant=constant)
    require(isinstance(result, dict), 'evidence JSON is not an object')
    return result


def self_hash(record: dict[str, Any], field: str) -> None:
    require(record.get(field) == canonical({k: v for k, v in record.items() if k != field}),
            f'content digest differs: {field}')


def ordinary_bytes(path: Path) -> bytes:
    """Read only nonlinked regular files with mutation-sensitive stat checks."""
    require(path.is_absolute() and '..' not in path.parts and path.is_file()
            and not any(p.is_symlink() for p in (path, *path.parents)), f'unsafe/missing static input: {path}')
    a = path.stat()
    data = path.read_bytes()
    b = path.stat()
    require((a.st_dev, a.st_ino, a.st_size, a.st_mtime_ns, a.st_ctime_ns)
            == (b.st_dev, b.st_ino, b.st_size, b.st_mtime_ns, b.st_ctime_ns), f'input changed: {path}')
    return data


def load_v1():
    """Import the exact immutable owner-approved v1 checks/copier."""
    require(sha(ordinary_bytes(V1 / 'assemble_validation_bundle.py')) == V1_SOURCE_SHA,
            'v1 assembler bytes differ')
    data = ordinary_bytes(V1 / 'preparation_receipt.json')
    require(sha(data) == V1_RECEIPT_SHA, 'v1 receipt bytes differ')
    receipt = strict(data)
    self_hash(receipt, 'receipt_content_sha256')
    for name, row in receipt['files'].items():
        data = ordinary_bytes(V1 / name)
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], f'v1 preparation changed: {name}')
    require(sha(ordinary_bytes(V1 / 'input_manifest.json')) == V1_MANIFEST_SHA,
            'v1 historical manifest differs')
    spec = importlib.util.spec_from_file_location('_immutable_bundle_v1', V1 / 'assemble_validation_bundle.py')
    require(spec is not None and spec.loader is not None, 'cannot load v1 checks')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def utc(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.utcoffset() == timezone.utc.utcoffset(parsed), 'invocation time is not explicit UTC')
    return parsed


def command_arguments(command: list[str], helper: Path, expected: dict[str, str], *, replay: bool = False) -> None:
    """Allow CLI flag ordering while requiring the actual intended fixed roots."""
    require(isinstance(command, list) and command[:3] == [PYTHON, '-B', str(helper)],
            'invocation interpreter/helper does not match the filled reviewed command')
    tokens = command[3:]
    if replay:
        require(tokens.count('--verify-existing') == 1, 'source replay command lacks exactly one verify-existing')
        tokens = [t for t in tokens if t != '--verify-existing']
    require(len(tokens) == 2 * len(expected), 'invocation CLI flags/count differ')
    flags = dict(zip(tokens[::2], tokens[1::2], strict=True))
    require(len(flags) == len(expected) and flags == expected, 'invocation CLI roots/options differ')


def invocation(record: dict[str, Any], helper: Path, expected: dict[str, str],
               stdout_path: Path, stdout_bytes: bytes, *, replay: bool = False) -> None:
    """Bind actual zero exit, UTC timing, argv and captured stdout bytes."""
    require(type(record.get('exit_code')) is int and record['exit_code'] == 0,
            'actual reporting/claim subprocess did not exit zero')
    require(record.get('stdout_path') == str(stdout_path) and record.get('stdout_sha256') == sha(stdout_bytes),
            'actual invocation stdout path/hash differs')
    require(utc(record['finished_utc']) >= utc(record['started_utc']), 'invocation times are reversed')
    command_arguments(record['command'], helper, expected, replay=replay)


def validate_reporting(payloads: dict[str, bytes], replay_bytes: bytes,
                       claim_bytes: bytes, invocation_bytes: bytes,
                       expected_inputs: dict[str, str]) -> dict[str, Any]:
    """Verify reporting metadata/bytes only, without recomputing any effect."""
    require(set(payloads) == set(SIDECAR_FILES), 'actual sidecar is not exactly its five files')
    report, lineage, generated, replay = [strict(data) for data in
        (payloads['report.json'], payloads['lineage.json'], payloads['receipt.json'], replay_bytes)]
    artifact_hashes = {name: sha(payloads[name]) for name in ARTIFACTS}
    roles = lineage['source_roles']
    require(lineage.get('source_binding_sha256') == canonical(roles), 'portable sidecar source hash differs')
    for key, expected in {'preparation/generate_reporting_sidecar.py': REPORTING_HELPER_SHA,
                          'preparation/scope.json': SCOPE_SHA,
                          'preparation/summarize_verified_claim_inputs.py': CLAIM_HELPER_SHA,
                          'preparation/frozen_repeated_cv.py': INTERVAL_SHA}.items():
        require(roles.get(key) == expected, f'sidecar source dependency differs: {key}')
    for key, path in {'extension/manifest.json': BASE / 'run/manifest.json',
                      'extension/completion.json': BASE / 'run/completion.json',
                      'extension/verification.json': BASE / 'run/verification.json',
                      'extension/paired_families.json': BASE / 'run/paired_families.json',
                      'extension/rq2_effects.json': BASE / 'run/rq2_effects.json',
                      'extension/decision_curves.json': BASE / 'run/decision_curves.json',
                      'primary/manifest.json': PRIMARY / 'manifest.json',
                      'primary/completion.json': PRIMARY / 'completion.json'}.items():
        require(roles.get(key) == expected_inputs[str(path)], f'sidecar current source binding differs: {key}')
    require(lineage.get('scope_sha256') == report.get('scope_sha256') == SCOPE_SHA
            and lineage.get('production_commit') == report.get('production_commit') == '119476fef55b1eeb690527f234c1423440720d45'
            and lineage.get('analysis_commit') == report.get('analysis_commit') == ANALYSIS_COMMIT
            and lineage.get('interval_source_sha256') == INTERVAL_SHA
            and lineage.get('numerical_prerequisite_helper_sha256') == CLAIM_HELPER_SHA,
            'sidecar frozen source/scope classification differs')
    require(lineage.get('artifacts_sha256') == {name: artifact_hashes[name] for name in ARTIFACTS[:3]},
            'sidecar lineage CSV/JSON byte bindings differ')
    require(report.get('schema_version') == lineage.get('schema_version') == 1
            and report.get('evidence_status') == lineage.get('evidence_status') == 'post_hoc_extension'
            and report.get('report_kind') == 'descriptive_reporting_sidecar', 'sidecar report identity differs')
    counts = report['counts']
    require(counts.get('extension_cells') == 1625 and counts.get('primary_cells_required') == 450
            and counts.get('descriptive_rows') == 123 and counts.get('clinical_rows') == 63
            and counts.get('matched_rows') == 60 and counts.get('planned_fold_pairs') == 3075,
            'sidecar required reporting roster/counts differ')
    require(len(report['dimension_ratios']) == 1625 and len(report['descriptive_catalytic_pairs']) == 123,
            'sidecar report arrays are incomplete')
    formal = report['formal_clinical_prior_family']
    require(formal.get('logical_source') == 'extension/paired_families.json'
            and formal.get('family') == 'catalytic_vs_original_priors'
            and formal.get('expected_contrasts') == 27 and len(formal['contrasts']) == 27,
            'sidecar links to the 27 existing formal prior contrasts are incomplete')
    for name, size in [('dimension_ratios.csv', 1625), ('descriptive_catalytic_pairs.csv', 123)]:
        require(len(list(csv.DictReader(io.StringIO(payloads[name].decode('utf-8'), newline='')))) == size,
                f'sidecar CSV row inventory is incomplete: {name}')
    compact_counts = {k: v for k, v in counts.items() if k != 'dimension_availability_groups'}
    for receipt in (generated, replay):
        self_hash(receipt, 'receipt_content_sha256')
        require(receipt.get('schema_version') == 1 and receipt.get('evidence_status') == 'post_hoc_extension'
                and receipt.get('scientific_completion_certified') is False
                and receipt.get('helper_sha256') == REPORTING_HELPER_SHA
                and receipt.get('source_binding_sha256') == lineage['source_binding_sha256']
                and receipt.get('artifact_sha256') == artifact_hashes
                and receipt.get('counts') == compact_counts, 'sidecar generation/replay metadata differs')
    require(generated.get('status') == 'reporting_sidecar_generated' and generated.get('operation') == 'generate',
            'original sidecar receipt is not successful generation')
    require(replay.get('status') == 'reporting_sidecar_replayed' and replay.get('operation') == 'verify_existing'
            and replay.get('deterministic_artifacts_compared') == 4
            and replay.get('original_receipt_sha256') == sha(payloads['receipt.json']),
            'actual source reporting replay is missing or not byte matched')
    claim, launch = strict(claim_bytes), strict(invocation_bytes)
    self_hash(launch, 'invocation_content_sha256')
    require(launch.get('schema_version') == 1 and launch.get('status') == 'claim_summary_invocation_passed'
            and launch.get('helper_sha256') == CLAIM_HELPER_SHA, 'actual claim invocation is not the pinned passed helper')
    invocation(launch, CLAIM_HELPER, CLAIM_ARGUMENTS, CLAIM_SUMMARY, claim_bytes)
    invocation(launch['source_replay_invocation'], REPORTING_PREP / 'generate_reporting_sidecar.py',
               REPLAY_ARGUMENTS, SOURCE_REPLAY, replay_bytes, replay=True)
    replay_host = replay['invocation']
    require(replay_host.get('argv') == launch['source_replay_invocation']['command'][3:]
            and replay_host.get('resolved_roots') == {'extension': str(BASE / 'run'), 'primary': str(PRIMARY),
                                                     'sidecar': str(SIDECAR)}
            and replay_host.get('resolved_inputs') == {
                'helper': str(REPORTING_PREP / 'generate_reporting_sidecar.py'),
                'scope': str(REPORTING_PREP / 'scope.json'),
                'claim_helper': str(REPORTING_PREP / 'summarize_verified_claim_inputs.py'),
                'interval_source': str(REPORTING_PREP / 'frozen_repeated_cv.py')},
            'source replay stdout invocation does not match the actual captured command/roots')
    require(launch.get('input_sha256') == expected_inputs,
            'actual claim invocation input byte bindings differ from current metadata')
    require(claim.get('schema_version') == 1 and claim.get('evidence_status') == 'post_hoc_extension'
            and claim.get('production_code_commit') == '119476fef55b1eeb690527f234c1423440720d45'
            and claim.get('analysis_code_commit') == ANALYSIS_COMMIT,
            'actual claim summary scope/code pins differ')
    for key, name in [('source_manifest_sha256', 'manifest.json'), ('source_completion_sha256', 'completion.json'),
                      ('source_verification_sha256', 'verification.json')]:
        require(claim.get(key) == expected_inputs[str(BASE / 'run' / name)], f'claim source binding differs: {key}')
    require(claim['separate_receipts']['official_selected_reproduction_receipts'] == 92
            and claim['separate_receipts']['visual_qa_status_as_recorded'] == 'passed',
            'claim summary lacks actual official92/passed QA records')
    require(claim['separate_receipts']['render_lineage_sha256'] == expected_inputs[str(BASE / 'rendered_v1/lineage.json')]
            and claim['separate_receipts']['visual_qa_receipt_sha256'] == expected_inputs[str(BASE / 'pdf_qa_v1/visual_qa_receipt.json')],
            'claim render/QA metadata byte bindings differ')
    require(set(claim['aggregate_sha256']) == {'paired_families.json', 'rq2_effects.json', 'decision_curves.json'}
            and all(claim['aggregate_sha256'][name] == expected_inputs[str(BASE / 'run' / name)]
                    for name in claim['aggregate_sha256']), 'actual claim aggregate roster/bytes differ')
    return {'dimension_rows': 1625, 'descriptive_rows': 123, 'planned_descriptive_fold_pairs': 3075,
            'sidecar_source_binding_sha256': lineage['source_binding_sha256'],
            'sidecar_generation_receipt_sha256': sha(payloads['receipt.json']),
            'source_replay_receipt_sha256': sha(replay_bytes), 'claim_summary_sha256': sha(claim_bytes),
            'claim_invocation_sha256': sha(invocation_bytes),
            'fresh_remote_reporting_replay': 'pending separate receipt outside immutable payload; required before draft publication',
            'numerical_effects_recomputed_by_assembler': False}


def current_claim_bindings(a, claim: dict[str, Any]) -> dict[str, str]:
    """Bind compact metadata only; no cells, predictions, PDFs or traces read."""
    paths = [BASE / 'run' / n for n in ['manifest.json', 'completion.json', 'verification.json',
              'paired_families.json', 'rq2_effects.json', 'decision_curves.json']]
    paths += [*BASELINE_PINS, PRIMARY / 'inference.json', PROGRAMME / 'sampler_run/inference.json',
              BASE / 'rendered_v1/lineage.json', BASE / 'pdf_qa_v1/qa_inventory.json',
              BASE / 'pdf_qa_v1/visual_qa_receipt.json', QA_REVIEW]
    result = {str(path): sha(a.file_bytes(path)) for path in paths}
    for path, expected in BASELINE_PINS.items():
        require(result[str(path)] == expected, 'previously released baseline metadata differs')
    receipt_hashes = claim['separate_receipts']['receipt_sha256']
    require(len(receipt_hashes) == 92, 'claim official receipt inventory is not 92')
    actual = {p.stem for p in (BASE / 'reproduction/receipts').glob('*.json')}
    require(actual == set(receipt_hashes), 'claim and actual official receipt identities differ')
    for identity, expected in receipt_hashes.items():
        require(a.safe_name(identity) and '/' not in identity, 'unsafe official receipt identity')
        path = BASE / 'reproduction/receipts' / (identity + '.json')
        result[str(path)] = sha(a.file_bytes(path))
        require(result[str(path)] == expected, 'official receipt bytes differ from actual claim summary')
    for name, expected in claim['aggregate_sha256'].items():
        require(name in ('paired_families.json', 'rq2_effects.json', 'decision_curves.json')
                and result[str(BASE / 'run' / name)] == expected, 'claim aggregate byte binding differs')
    return result


def plan(a, output: Path):
    """Require all v1 and dynamic reporting gates before any output directory."""
    rows, members, detail = a.prepare_plan(output)
    static = strict(a.file_bytes(HERE / 'input_manifest_v2.json'))
    self_hash(static, 'manifest_content_sha256')
    for row in static['files']:
        require(a.file_row(Path(row['source']), row['target']) == row, 'v2 static reporting preparation changed')
    actual_prep = {p.relative_to(REPORTING_PREP).as_posix() for p in REPORTING_PREP.rglob('*') if p.is_file()
                   and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    require(actual_prep == set(static['reporting_preparation_files']), 'sealed reporting preparation inventory differs')
    receipt_bytes = a.file_bytes(REPORTING_PREP / 'preparation_receipt.json')
    require(sha(receipt_bytes) == REPORTING_RECEIPT_SHA, 'reporting preparation final receipt differs')
    receipt = strict(receipt_bytes)
    self_hash(receipt, 'receipt_content_sha256')
    require(receipt.get('status') == 'reporting_sidecar_preparation_validated'
            and receipt.get('helper_sha256') == REPORTING_HELPER_SHA and receipt.get('scope_sha256') == SCOPE_SHA,
            'reporting preparation is not the final reviewed schema')
    a.unlinked(SIDECAR, directory=True)
    require({p.name for p in SIDECAR.iterdir()} == set(SIDECAR_FILES), 'sidecar actual directory must have exactly five files')
    payloads = {name: a.file_bytes(SIDECAR / name) for name in SIDECAR_FILES}
    claim_bytes = a.file_bytes(CLAIM_SUMMARY)
    inputs = current_claim_bindings(a, strict(claim_bytes))
    reporting = validate_reporting(payloads, a.file_bytes(SOURCE_REPLAY), claim_bytes,
                                   a.file_bytes(CLAIM_INVOCATION), inputs)
    rows += static['files']
    rows += [a.file_row(SIDECAR / name, 'final_reporting_sidecar/' + name) for name in SIDECAR_FILES]
    rows += [a.file_row(SOURCE_REPLAY, 'reporting_sidecar_source_replay_receipt.json'),
             a.file_row(CLAIM_SUMMARY, 'final_claim_summary/final_claim_summary_v1.json'),
             a.file_row(CLAIM_INVOCATION, 'final_claim_summary/final_claim_summary_invocation_v1.json')]
    own = strict(a.file_bytes(HERE / 'preparation_receipt.json'))
    self_hash(own, 'receipt_content_sha256')
    for name, expected in own['files'].items():
        require(a.safe_name(name) and sha(a.file_bytes(HERE / name)) == expected['sha256'], 'v2 assembler preparation changed')
    for path in sorted(HERE.rglob('*')):
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        require(not path.is_symlink(), 'linked v2 preparation member')
        if path.is_file():
            rows.append(a.file_row(path, 'bundle_preparation_v2/' + path.relative_to(HERE).as_posix()))
    targets = [row['target'] for row in (*rows, *members)]
    require(len(set(targets)) == len(targets) and all(a.safe_name(p) for p in targets), 'duplicate/unsafe v2 payload target')
    require(not any(Path(row['source']).is_relative_to(output) for row in rows), 'v2 output overlaps required source')
    detail['v1_assembler_sha256'] = detail['assembler_sha256']
    detail['v2_assembler_sha256'] = sha(a.file_bytes(Path(__file__).absolute()))
    detail['v2_input_manifest_sha256'] = sha(a.file_bytes(HERE / 'input_manifest_v2.json'))
    detail['reporting_and_actual_claims'] = reporting
    return rows, members, detail


def main() -> None:
    """Create only a new content-addressed support payload with actual reporting."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=BASE / 'integration_validation_bundle_v3')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    require(Path(__file__).absolute().parent == HERE, 'v2 wrapper must run from its prepared external source')
    a = load_v1()
    rows, members, detail = plan(a, args.output)
    inventory = sorted([{'path': r['target'], 'bytes': r['bytes'], 'sha256': r['sha256']}
                        for r in (*rows, *members)], key=lambda r: r['path'])
    content = canonical(inventory)
    if args.check_only:
        print(json.dumps({'status': 'ready_to_preserve_actual_reporting_support', 'payload_files': len(inventory),
                          'payload_content_sha256': content, 'gates': detail}, indent=2, sort_keys=True))
        return
    args.output.mkdir(exist_ok=False)
    for row in rows:
        a.copy_checked(row, args.output)
    for row in members:
        a.write_once(args.output / row['target'], a.archive_member(row))
    recheck = args.output.with_name(args.output.name + '_v2_recheck_' + str(os.getpid()))
    last_rows, last_members, last_detail = plan(a, recheck)
    require((last_rows, last_members, last_detail) == (rows, members, detail), 'v2 source/reporting gates changed during copying')
    for row in inventory:
        data = a.file_bytes(args.output / row['path'])
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'v2 final copied bytes differ')
    inventory_path = f'inventories/payload_{content}.json'
    inventory_bytes = a.encoded({'schema_version': 2, 'files': inventory, 'payload_content_sha256': content,
                                  'scope': 'payload only; inventory/manifest/finalreceipt separately bound'})
    a.write_once(args.output / inventory_path, inventory_bytes)
    manifest = {'schema_version': 2, 'classification': 'supporting_audit_and_verified_reporting_preservation',
                'created_utc': datetime.now(timezone.utc).isoformat(), 'content_sha256': content, 'files': inventory,
                'content_addressed_inventory': inventory_path, 'inventory_sha256': sha(inventory_bytes),
                'completed_support': detail, 'original_v1_preparation': 'bundle_preparation/; exact bytes preserved',
                'numerical_programme_completion': 'not_assessed',
                'publication_gate': 'fresh restored reporting replay pass required; receipt retained outside this payload',
                'private_draft_may_be_published': False}
    manifest_bytes = a.encoded(manifest)
    a.write_once(args.output / 'bundle_manifest.json', manifest_bytes)
    receipt = {'schema_version': 2, 'verified_utc': datetime.now(timezone.utc).isoformat(),
               'status': 'support_and_actual_reporting_bundle_byte_roundtrip_verified', 'output': str(args.output),
               'payload_files_verified': len(inventory), 'payload_bytes_verified': sum(r['bytes'] for r in inventory),
               'payload_content_sha256': content, 'inventory_path': inventory_path, 'inventory_sha256': sha(inventory_bytes),
               'bundle_manifest_sha256': sha(manifest_bytes), 'v2_assembler_sha256': detail['v2_assembler_sha256'],
               'v1_assembler_sha256': V1_SOURCE_SHA, 'completed_support_review_sha256': detail['completed_support_review_sha256'],
               'reporting_and_actual_claims': detail['reporting_and_actual_claims'],
               'actual_scientific_or_reporting_helpers_invoked_by_assembler': False,
               'qa_official92_science_transfer_overall_completion_certified': False}
    receipt['receipt_content_sha256'] = canonical(receipt)
    a.write_once(args.output / 'bundle_receipt.json', a.encoded(receipt))
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        raise SystemExit(f'V2 SUPPORT/REPORTING BUNDLE REFUSED: {error}') from error
