# Prepared v2 supporting/reporting bundle

Prepared only: no actual reporting helper, claim helper, audit, bundle assembly,
transfer or publication was invoked here. The original v1 preparation, its
359-file historical manifest, and both existing bundles remain byte-identical.
The reviewed v2 wrapper imports the exact pinned v1 implementation and reuses
its completed-support gates, archive checks, copier and write-once receipt.

The v2 static manifest adds 20 files: the 15-file sealed reporting preparation,
the final-closeout archive/verification/review from commit `7173d19`, and the
reporting archive/verification committed at `9db7e69`. Its initial 18-file draft
is retained as historical evidence. No baseline traces are duplicated.

## Later source reporting and capture

Root owns these launches. First finish the 1,625-cell programme, official 92
receipts, rendering and actual passed visual QA. The completed supporting
rank/boundary results and genuine root support-review record remain the
unchanged v1 assembler prerequisites. Do not duplicate coordinator jobs.

```bash
PYTHON=/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python
BASE=/Users/macuser/bayes-cox-runs/extensions-20260928
PREP="$BASE/final_validation_bundle_preparation_v2"
PRIMARY=/Users/macuser/bayes-cox-runs/student-restore-check-20260928/reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651

# Root's actual generation, into a new five-file directory:
"$PYTHON" -B "$BASE/final_reporting_sidecar_preparation_v1/generate_reporting_sidecar.py" \
  --run "$BASE/run" --primary "$PRIMARY" --output "$BASE/reporting_sidecar_v1"

# Only after actual generation and all claim prerequisites:
"$PYTHON" -B "$PREP/capture_source_reporting_claims.py"

# Both require actual support/review/reporting/claim evidence; first writes no bundle:
"$PYTHON" -B "$PREP/assemble_validation_bundle_v2.py" --check-only
"$PYTHON" -B "$PREP/assemble_validation_bundle_v2.py" \
  --output "$BASE/integration_validation_bundle_v3"
```

Before invoking a prepared source, root verifies the preparation receipt and
its byte inventory against the trusted recovery checkpoint. The capture
launcher pins the v2 wrapper (`866739…db15`) before importing it; the wrapper
pins the original v1 source/receipt/manifest and checks all 16 original bytes.
Both capture launchers pin `capture_io.py` before importing it. No unchecked
reporting or claim module is imported by the assembler/capture launcher.

The source capture launches the exact commands in
`pending_invocation_contract.json`: original claim helper with actual extension,
official reproduction, render/QA, restored primary, released sampler/robustness,
and the verified programme explanation file. It captures actual process start
and finish, integer exit code, raw stdout/stderr hashes and the current 111
compact input hashes (19 metadata files plus 92 official receipts). It checks
the deterministic reporting receipt, original generation receipt, source roles,
all four artifact bytes, full counts, formal 27 links, and actual claim bindings.
It installs these three new files only after genuine rc0 and validation:

- `reporting_sidecar_source_replay_v1.json` (raw source replay stdout);
- `final_claim_summary_v1.json` (raw factual claim stdout);
- `final_claim_summary_invocation_v1.json` (actual claim process metadata with
  nested actual source-replay process metadata).

`pending_invocation_contract.json` is a schema/command plan, never an actual
invocation receipt. Nonzero stdout/stderr and actual exit code are retained
under an exclusive diagnostic prefix, outside successful fixed filenames.
An install fsyncs/closes a separate pending file before an exclusive atomic
hard link; existing paths and concurrent collisions are refused. A partial
capture cannot pass the assembler without all genuine byte-bound receipts.

The actual sidecar directory contains exactly five files: `dimension_ratios.csv`
(1,625 rows), `descriptive_catalytic_pairs.csv` (123 rows), `report.json`,
`lineage.json`, and preserved `receipt.json`. Source replay stays its sibling.
It recomputes and compares four deterministic artifacts, without refitting or
altering frozen fitting/aggregate gates. Partial descriptive pairs remain
explicitly partial; supporting diagnostic findings remain findings for review.

## Mandatory receiving addendum before publication

Use the preserved `final_transfer_runbook_v2` for staging, package, private draft,
download and scientific restore. Its final publication instruction is subject
to this additional fresh reporting replay gate. A private draft must remain a
draft until the fresh downloaded evidence passes both scientific restore and
this reporting replay. Baseline programme evidence is restored separately.

The stager copies the complete bundle to
`RESTORED/execution/current_integration_validation`. After successful fresh
archive/scientific restore, the concrete local receiving command is:

```bash
(
  set -euo pipefail
  source /Users/macuser/bayes-cox-runs/extensions-20260928/final_transfer_runbook_v2/paths.sh
  SUPPORT="$RESTORED/execution/current_integration_validation"
  "$PYTHON" -B "$SUPPORT/bundle_preparation_v2/replay_restored_reporting.py" \
    --restored "$RESTORED" --primary "$PRIMARY" --python "$PYTHON" \
    --receipt "$TRANSFER_HOME/restored_reporting_replay_v1.json" \
    --invocation-receipt "$TRANSFER_HOME/restored_reporting_replay_invocation_v1.json"
  shasum -a 256 "$TRANSFER_HOME/restored_reporting_replay_v1.json" \
    "$TRANSFER_HOME/restored_reporting_replay_invocation_v1.json"
)
```

The fresh driver verifies the byte-pinned sealed reporting preparation at
`SUPPORT/reporting_sidecar_preparation_v1`; its command uses
`RESTORED/evidence/run`, separately restored `PRIMARY`, and
`SUPPORT/final_reporting_sidecar`. Both new receipts remain outside `RESTORED`
and `PRIMARY`; they are not inserted into the immutable restored payload.
On another Apple Silicon laptop, pass that laptop's actual validated Python,
extension restore and separately restored primary paths to the same portable
driver. No sampler/robustness trace copy is needed for reporting replay itself.

Retain the actual fresh rc0 process record and stdout bytes/hashes in final
Git/release evidence before publishing the private draft. No capture helper or
support bundle certifies publication or overall programme completion.

The preparation receipt certifies only six source syntax checks, 43 synthetic
metadata guards, 20 mocked capture/atomic I/O guards, static pins, and independent
source review. Actual numerical/support/root-review/reporting/claim/QA/remote
receipts remain pending and are never invented by the preparation.
