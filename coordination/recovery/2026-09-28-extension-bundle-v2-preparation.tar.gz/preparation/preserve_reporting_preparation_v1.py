"""Preserve reviewed reporting preparation without invoking actual results."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project')
OUTPUT = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
PREPARATION = OUTPUT / 'final_reporting_sidecar_preparation_v1'
RECEIPT_SHA = '3c71be36cf4f95029da1a724f730de8242bb461de65a87e5eabe41c69f6c4952'
CLAIM_RECEIPT_SHA = '6c71cfa31b97ed0e50f285150bf07caf3c149bfb48be7dfed26d27f47ce46ed0'
MANIFEST_SHA = '83b9049fb6aaaadab576b34de0741e4f510344dcefba9f96198d15b5ab4f49b9'


def sha(raw: bytes) -> str:
    """Return the digest of exact retained bytes."""
    return hashlib.sha256(raw).hexdigest()


def encoded(value: object) -> bytes:
    """Serialize a retained readable record with a final newline."""
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def check_bytes(path: Path, spec: dict) -> bytes:
    """Read an ordinary file and reject changed size or digest."""
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'Unavailable ordinary input: {path}')
    raw = path.read_bytes()
    if len(raw) != spec['bytes'] or sha(raw) != spec['sha256']:
        raise RuntimeError(f'Input bytes differ: {path}')
    return raw


def checked_preparation(directory: Path, expected_sha: str) -> tuple[dict, dict[str, bytes]]:
    """Check the canonical receipt and every file bound by its exact bytes."""
    receipt_raw = (directory / 'preparation_receipt.json').read_bytes()
    if sha(receipt_raw) != expected_sha:
        raise RuntimeError('Reviewed preparation receipt differs')
    receipt = json.loads(receipt_raw)
    canonical = {k: v for k, v in receipt.items() if k != 'receipt_content_sha256'}
    canonical_raw = json.dumps(canonical, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    if sha(canonical_raw) != receipt['receipt_content_sha256']:
        raise RuntimeError('Canonical preparation receipt differs')
    members = {rel: check_bytes(directory / rel, spec) for rel, spec in receipt['files'].items()}
    members['preparation_receipt.json'] = receipt_raw
    return receipt, members


def check_tested_source(tested: dict) -> None:
    """Verify all source/build/lock bytes covered by the existing test run."""
    for name, expected in tested.items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise RuntimeError(f'Previously tested source differs: {name}')


def main() -> None:
    """Archive exact prepared files and dated observations once, without fitting."""
    archive = ROOT / 'coordination/recovery/2026-09-28-extension-reporting-preparation.tar.gz'
    verification = ROOT / 'coordination/recovery/2026-09-28-extension-reporting-preparation-verification.json'
    if archive.exists() or verification.exists():
        raise RuntimeError('Recovery output already exists; preserve its bytes')
    tested_path = OUTPUT / 'transfer_validation_v5_extension_documentation/tested_source.json'
    tested_raw = tested_path.read_bytes()
    tested = json.loads(tested_raw)
    check_tested_source(tested)
    receipt, prepared_files = checked_preparation(PREPARATION, RECEIPT_SHA)
    previous, previous_files = checked_preparation(OUTPUT / 'final_claim_review_preparation_v1', CLAIM_RECEIPT_SHA)
    if len(receipt['files']) != 14 or receipt['synthetic_test_method_count'] != 21:
        raise RuntimeError('Unexpected reviewed preparation inventory')
    validation = json.loads(prepared_files['validation_record.json'])
    if validation['status'] != 'pure_preparation_validated' or any(
        row['exit_code'] != 0 for row in validation['commands']
    ):
        raise RuntimeError('Preparation validation did not pass')
    for row in validation['commands']:
        for stream in ('stdout', 'stderr'):
            if sha(prepared_files[f"{row['name']}_{stream}.txt"]) != row[f'{stream}_sha256']:
                raise RuntimeError('Preparation validation output differs')
    if receipt['actual_extension_result_invocation'] or receipt['numerical_or_transfer_operations']:
        raise RuntimeError('Unexpected actual-result invocation in preparation')
    manifest_raw = (OUTPUT / 'run/manifest.json').read_bytes()
    if sha(manifest_raw) != MANIFEST_SHA:
        raise RuntimeError('Frozen numerical manifest differs')
    planned = {row['cell_id'] for row in json.loads(manifest_raw)['plan']}
    statuses: Counter[str] = Counter()
    settings: Counter[str] = Counter()
    rows = []
    for path in sorted((OUTPUT / 'run/cells').glob('*.json')):
        raw = path.read_bytes()
        cell = json.loads(raw)
        if cell['cell_id'] != path.stem or cell['cell_id'] not in planned:
            raise RuntimeError('Unexpected stored numerical cell')
        statuses[cell['status']] += 1
        settings[f"{cell['dataset']}/{cell['setting']}"] += 1
        rows.append({'path': str(path.relative_to(OUTPUT)), 'sha256': sha(raw)})
    snapshot = {
        'observed_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Dated stored-cell accounting only; numerical and transfer completion unassessed',
        'planned_cells': len(planned), 'stored_cells': len(rows),
        'statuses': dict(statuses), 'settings': dict(settings), 'cell_bytes': rows,
        'candidate_refits': len(list((OUTPUT / 'reproduction/cells').glob('*.json'))),
        'official_refit_receipts': len(list((OUTPUT / 'reproduction/receipts').glob('*.json'))),
        'markers': {name: (OUTPUT / name).exists() for name in (
            'analysis_prepared.json', 'coordinator_failure.json',
            'postfit_support_prepared_v1.json', 'postfit_support_failure_v1.json',
        )},
    }
    review = {
        'schema_version': 1, 'verified_utc': datetime.now(timezone.utc).isoformat(),
        'reviewer': 'root', 'status': 'reporting_preparation_reviewed_actual_invocation_pending',
        'preparation_receipt_sha256': RECEIPT_SHA,
        'bound_preparation_files_verified': len(receipt['files']),
        'helper_sha256': receipt['helper_sha256'], 'scope_sha256': receipt['scope_sha256'],
        'synthetic_test_methods_passed': 21,
        'independent_review_sha256': receipt['independent_review_sha256'],
        'independent_review': 'Receipt-publication IO finding resolved; no unresolved static issue',
        'root_review': 'Reviewed helper, README, validation and independent review; rehashed exact preparation',
        'expected_ratio_rows': 1625, 'expected_descriptive_rows': 123,
        'existing_formal_rows_linked': 27, 'new_formal_tests_or_families': 0,
        'previous_claim_receipt_sha256': CLAIM_RECEIPT_SHA,
        'previous_claim_bound_files_unchanged': len(previous['files']),
        'tested_source_files_unchanged': len(tested), 'tested_source_sha256': sha(tested_raw),
        'models_fitted': False, 'actual_reporting_helper_invoked': False,
        'actual_reporting_tables_produced': False, 'validation_bundle_assembled': False,
        'release_download_restore_executed': False, 'scientific_completion_certified': False,
    }
    members = {f'preparation/final_reporting_sidecar_preparation_v1/{name}': raw
               for name, raw in prepared_files.items()}
    members['root_preparation_review.json'] = encoded(review)
    members['dated_source_snapshot.json'] = encoded(snapshot)
    members['preparation/preserve_reporting_preparation_v1.py'] = Path(__file__).read_bytes()
    inventory = {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())}
    members['archive_inventory.json'] = encoded(inventory)
    with archive.open('xb') as output, gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                tar.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive, 'r:gz') as tar:
        if len(tar.getmembers()) != len(members) or {item.name for item in tar.getmembers()} != set(members):
            raise RuntimeError('Recovery member inventory differs')
        for item in tar.getmembers():
            stream = tar.extractfile(item)
            if not item.isfile() or stream is None or stream.read() != members[item.name]:
                raise RuntimeError('Recovery archive byte roundtrip differs')
    if checked_preparation(PREPARATION, RECEIPT_SHA)[1] != prepared_files:
        raise RuntimeError('Reviewed preparation changed during preservation')
    if checked_preparation(OUTPUT / 'final_claim_review_preparation_v1', CLAIM_RECEIPT_SHA)[1] != previous_files:
        raise RuntimeError('Previous claim preparation changed during preservation')
    check_tested_source(tested)
    review.update({
        'archive': str(archive.relative_to(ROOT)), 'archive_sha256': sha(archive.read_bytes()),
        'archive_bytes': archive.stat().st_size, 'archive_members_verified': len(members),
        'archive_inventory_sha256': sha(members['archive_inventory.json']),
        'dated_partial_checkpoint': {key: value for key, value in snapshot.items() if key != 'cell_bytes'},
    })
    with verification.open('xb') as output:
        output.write(encoded(review))
    print(encoded(review).decode(), end='')


if __name__ == '__main__':
    main()
