"""Build source-only dependency evidence from this audit's owned snapshots."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

ROOT = Path(__file__).resolve().parent
SNAPSHOTS = ROOT / 'snapshots'
ORIGINAL = '/Users/macuser/Documents/Github/bayesian_survival_for_prediction-disease/project'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode())

def read(name):
    return json.loads((SNAPSHOTS / name).read_text())

def evidence(name, first, last):
    raw = (SNAPSHOTS / name).read_bytes()
    lines = raw.decode().splitlines()
    assert 1 <= first <= last <= len(lines)
    return {'snapshot_path': 'snapshots/' + name, 'file_sha256': digest(raw),
            'first_line': first, 'last_line': last,
            'lines': [{'line': n, 'text': lines[n - 1]} for n in range(first, last + 1)]}

def publish(name, value):
    path = ROOT / name
    with path.open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        handle.write('\n')

sources = json.loads((ROOT / 'source_files.json').read_text())
for name, record in sources.items():
    raw = (ROOT / record['snapshot_path']).read_bytes()
    assert len(raw) == record['bytes'] and digest(raw) == record['sha256']
reconciliation = read('reconciliation_audit.json')
assert reconciliation['tracked_dirty_count'] == 8
assert reconciliation['untracked_status_entry_count'] == 20
manifest = read('source_manifest_metadata.json')
assert manifest['code']['git_commit'] == '119476fef55b1eeb690527f234c1423440720d45'
original_inputs = manifest['input_sha256']
changed = [{'kind': 'tracked_dirty', 'relative_path': name} for name in reconciliation['tracked_dirty_files']]
changed += [{'kind': 'untracked_status_entry', 'relative_path': row['path']} for row in reconciliation['untracked_entries']]
for row in changed:
    path = row['relative_path']
    row['original_absolute_path'] = ORIGINAL + '/' + path
    row['retained_source119_input_path_matches'] = [p for p in original_inputs if p == path or (path.endswith('/') and p.startswith(path))]
    assert not row['retained_source119_input_path_matches']
    row['registered_dispatch_to_this_original_main_path_found'] = False
    row['archive_bytes_opened_or_equivalence_certified'] = False

continuation = read('continuation_v2_request.json')
code_checks = []
for relative, expected in continuation['code_sha256'].items():
    matching = [r for r in sources.values() if r['path'] == continuation['paths']['code'] + '/' + relative]
    assert len(matching) == 1 and matching[0]['sha256'] == expected
    code_checks.append({'relative_path': relative, 'sha256': expected, 'snapshot_path': matching[0]['snapshot_path'], 'matches_request': True})
assert len(code_checks) == 16
observer = read('observer_request.json')
assert len(observer['targets']) == 9
fields = None
for node in ast.parse((SNAPSHOTS / 'observer.py').read_text()).body:
    if isinstance(node, ast.Assign) and any(isinstance(n, ast.Name) and n.id == 'IDENTITY_FIELDS' for n in node.targets):
        fields = ast.literal_eval(node.value)
assert fields
registrations = []
for target in observer['targets']:
    pid = target['pid']
    reg = read(f'observer_pid_{pid}.registration.json')
    assert reg['content_sha256'] == canonical({k:v for k,v in reg.items() if k != 'content_sha256'})
    assert reg['expected_identity_sha256'] == target['expected_identity_sha256']
    assert reg['status'] == 'future_kernel_exit_subscription_identity_verified'
    assert reg['identity_verified'] is True and reg['test_only'] is False
    for moment in ['identity_before', 'identity_after']:
        assert canonical({field: reg[moment][field] for field in fields}) == target['expected_identity_sha256']
    source = target['expected_source']
    matching = [r for r in sources.values() if r['path'] == source['path']]
    assert len(matching) == 1 and matching[0]['sha256'] == source['sha256']
    registrations.append({'pid':pid, 'label':target['label'], 'recorded_argv':target['expected_identity']['argv'],
        'recorded_cwd':target['expected_identity']['cwd'], 'recorded_source_binding':source,
        'registration_accepted_at_utc':reg['registration_accepted_at_utc'],
        'registration_byte_sha256':sources[f'observer_pid_{pid}.registration.json']['sha256'],
        'provenance_category':reg['owner_provenance_category'], 'current_live_identity_certified_by_this_audit':False})
subscriptions = read('observer_subscriptions.json')
assert subscriptions['registered_pids'] == [62025,62026,62027,62028,62029,62030,64406,71385,98854]
ps_invocation = read('continuation_reuse_identity.invocation.json')
assert ps_invocation['actual_subprocess_returncode'] == 0
assert ps_invocation['stdout_sha256'] == sources['continuation_reuse_identity.stdout.log']['sha256']
assert ps_invocation['stderr_sha256'] == sources['continuation_reuse_identity.stderr.log']['sha256']
ps_text = (SNAPSHOTS / 'continuation_reuse_identity.stdout.log').read_text()
assert ps_text.startswith('29125 29120 ') and continuation['paths']['source'] in ps_text
assert continuation['paths']['code'] + '/scripts/catalytic_correction/run_reuse.py' in ps_text
assert ORIGINAL not in ps_text

literal_hits = []
ast_sources = []
for path in sorted(SNAPSHOTS.glob('*.py')):
    ast.parse(path.read_text(), filename=path.name)
    ast_sources.append(path.name)
    for number, line in enumerate(path.read_text().splitlines(), 1):
        if ORIGINAL in line or any(token in line for token in ['HANDOFF.md', 'DECISIONS.md', 'JOURNAL.md', 'TODO.md', 'code_guide.md', 'ravi_handoff.md', 'catalytic_correction_execution.md', 'ruff.toml']):
            literal_hits.append({'file':path.name, 'line':number, 'text':line})
assert not literal_hits

topology = json.loads((ROOT / 'git_path_topology.json').read_text())
linked = [row for row in topology if row['label'] != 'original_main']
assert len(linked) == 4 and all(row['resolved_common_dir'] == ORIGINAL + '/.git' for row in linked)

edges = {
 'original_workers': [evidence('source119_run_extensions.py',9,22), evidence('source119_runner.py',133,157), evidence('source119_reproducibility.py',104,122)],
 'prestage_64406': [evidence('prestage_refits.py',25,48), evidence('prestage_refits.py',61,79)],
 'coordinator_71385': [evidence('coordinate_after_fits_v2.py',16,30), evidence('coordinate_after_fits_v2.py',57,64), evidence('coordinate_after_fits_v2.py',84,97), evidence('analysis855_finalize_extensions.py',38,50), evidence('analysis855_verification.py',98,108)],
 'support_98854': [evidence('complete_postfit_support_v1.py',18,29), evidence('complete_postfit_support_v1.py',73,84), evidence('complete_postfit_support_v1.py',95,107), evidence('transfer_rank_audit.py',190,224), evidence('boundary_driver.py',23,29), evidence('boundary_driver.py',405,409), evidence('cached_audit_saved_diagnostics.py',16,18), evidence('cached_audit_saved_diagnostics.py',117,120)],
 'observer_48620_48621': [evidence('capture_owned_observer.py',10,22), evidence('observer.py',328,336), evidence('observer.py',420,422), evidence('observer.py',439,450)],
 'continuation_29118_29120_29125': [evidence('owned_continuation_capture_v2.py',9,21), evidence('correction_continuation_v1.py',98,107), evidence('correction_continuation_v1.py',180,210), evidence('correction_continuation_v1.py',218,228), evidence('correction_run_preflight.py',88,102), evidence('correction_run_preflight.py',193,211), evidence('correction_normal_first_draw_child.py',48,64), evidence('correction_run_arithmetic.py',343,347), evidence('correction_run_arithmetic.py',375,385)],
}
publish('line_evidence.json', edges)
publish('changed_path_comparison.json', {'tracked_dirty_count':8,'untracked_status_entry_count':20,
    'retained_source119_manifest_input_path_count':len(original_inputs), 'original_manifest_input_bytes_rehashed':False,
    'source_manifest_metadata_sha256':sources['source_manifest_metadata.json']['sha256'],
    'reconciliation_receipt_sha256':sources['reconciliation_receipt.json']['sha256'], 'entries':changed})

owners = [
 {'pids':[62025,62026,62027,62028,62029,62030],'role':'original_numerical_workers','source_roots':['SOURCE119'],
  'direct_original_main_working_file_dependency_found':False,'shared_original_git_dependency':'manifest initialization uses source worktree Git status/HEAD; no new worker initialization observed',
  'input_output_paths':'SOURCE119 config/freeze/raw input paths; external matched input and original run outputs; scientific files not opened'},
 {'pids':[64406],'role':'prestage_numerical_worker0','source_roots':['SOURCE119','external prestage_refits.py'],
  'direct_original_main_working_file_dependency_found':False,'shared_original_git_dependency':'explicit SOURCE119 HEAD check at helper initialization',
  'input_output_paths':'external original run and distinct reproduction root; scientific files not opened'},
 {'pids':[71385],'role':'original_postfit_coordinator','source_roots':['SOURCE119','analysis855','external coordinate_after_fits_v2.py'],
  'direct_original_main_working_file_dependency_found':False,'shared_original_git_dependency':'explicit HEAD/status for both worktrees at initialization; child stages use frozen code/input hash guards',
  'input_output_paths':'external original/reproduction/render/QA and baseline run roots; scientific files not opened'},
 {'pids':[98854],'role':'original_postfit_support','source_roots':['SOURCE119','transfer2b701','external boundary driver','external cached diagnostic helper'],
  'direct_original_main_working_file_dependency_found':False,'shared_original_git_dependency':'transfer HEAD/status at initialization; future rank audit reads SOURCE119 HEAD before reconstructing',
  'input_output_paths':'external original run, matched input, provenance and diagnostic cache/audit roots; scientific files not opened'},
 {'pids':[48620,48621],'role':'owned_future_exit_observer_wrapper_and_child','source_roots':['external observer v3 preparation','external launch/request/provenance records','nine external monitored source paths'],
  'direct_original_main_working_file_dependency_found':False,'shared_original_git_dependency':'no observer Git command found; monitored owners have separate Git dependencies',
  'input_output_paths':'external observer output; source/provenance files rehashed at beginning/end; no exit events inspected'},
 {'pids':[29118,29120,29125],'role':'owned_prefit_wrapper_continuation_and_reuse_child','source_roots':['external wrapper/helper','APFS code_d332013','SOURCE119'],
  'direct_original_main_working_file_dependency_found':False,'shared_original_git_dependency':'code_d332013 HEAD/status rechecked before/after stages; run_reuse preflight backend checks SOURCE119 HEAD/status and pinned input bytes',
  'input_output_paths':'read-only old APFS code/recipes/preflight, external original/matched input paths, new APFS witness/arithmetic/continuation roots; no scientific artifacts opened'},
 {'pids':[29119],'role':'caffeinate_bound_to_continuation_wrapper','source_roots':[],
  'association_evidence':'retained owned_wrapper_v2_launch.json explicitly records caffeinate_pid29119',
  'direct_original_main_working_file_dependency_found':False,'shared_original_git_dependency':'no code dependency established; launch association only'},
 {'pids':[29121,29122,29123,29124],'role':'unresolved_pid_to_role_association','source_roots':[],
  'current_identity_or_argv_evidence_found_in_bounded_scope':False,'safe_dependency_independence_proved':False,
  'reason':'root supplied range; no matching small retained launch/identity record supplied; no process query or broad process log search performed'},
]
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
audit={
 'schema_version':1,'status':'bounded_original_checkout_execution_dependencies_audited_no_synchronization_approval','created_at_utc':now,
 'recommendation':'defer_general_original_checkout_git_synchronization_until_exact_operation_preserves_shared_worktree_metadata_and_retained_collisions',
 'main_finding':'reviewed numerical/source dispatch is outside ORIGINAL main working files, but all four used code worktrees share ORIGINAL/.git',
 'owners':owners,'registrations':registrations,
 'actual_root_provided_ps_observation':{'pid':29125,'ppid':29120,'observed_at_utc':ps_invocation['observed_at_utc'],
   'query_returncode':0,'query_rc_is_not_child_exit_code':True,'actual_raw_stdout_sha256':ps_invocation['stdout_sha256'],
   'current_identity_verified_by_reviewer':False,'historical_launch_or_exit_code_inferred':False},
 'continuation_code_pins':code_checks,'tracked_dirty_count':8,'untracked_status_entry_count':20,
 'retained_source119_input_path_count':len(original_inputs),'changed_paths_intersect_retained_source119_input_paths':0,
 'reviewed_runtime_source_ast_count':len(ast_sources),'direct_original_main_or_changed_guide_literals_in_reviewed_runtime_sources':literal_hits,
 'source_content_scans_are_not_exhaustive_environment_or_all_transitive_dependency_proof':True,
 'shared_git_worktree_count':4,'git_path_topology_sha256':digest((ROOT/'git_path_topology.json').read_bytes()),
 'unresolved_pid_associations':[29121,29122,29123,29124],
 'sync_prerequisites':[
  'Preserve all eight dirty tracked and twenty untracked entries, the six differing guide/coordination versions and every archive collision before any reconciliation.',
  'Keep SOURCE119, analysis855, transfer2b701 and APFS code_d332013 source trees and detached HEAD/index/admin records unchanged.',
  'Specify exact intended Git operation; assess shared config/objects/worktrees administration and any maintenance/prune/relink side effects before touching ORIGINAL/.git.',
  'Do not equate shared .git with proof that disjoint main guide edits alter numerical inputs; no such direct dependency was found in reviewed paths.',
  'Continue using the already verified resident integration checkout while general old-checkout synchronization safety remains unresolved.',
 ],
 'limitations':[
  'Registered source/argv/cwd metadata is dated; this audit made no live PID query and certifies no present process state or future/historical exit.',
  'The root-provided ps rc0 certifies only that metadata query, never the numerical or continuation process return code.',
  'No exact synchronization command was proposed or executed. Detached worktree HEAD/status is separate from main working-file status; changing main alone is not shown to change frozen source inputs.',
  'The retained source-manifest map was compared as metadata only. This audit did not rehash data, fit results, arrays, trace containers, full scientific receipts or archives.',
  'No bulk recovery archives, unfiltered owner logs, event logs or result-cell directories were opened. Absolute input/output paths are path evidence only, not science validation.',
  'Snapshot captures are bounded per-file reads, not an atomic snapshot of all running owners or the shared Git store.',
 ],
 'reviewer_actions':{'target_helpers_imported_or_executed':False,'tests_checkers_or_science_executed':False,'processes_queried_or_changed':False,
  'git_commands_executed':False,'repo_or_git_modified':False,'remote_contacted':False,'data_arrays_traces_or_bulk_archives_opened':False,
  'small_git_pointer_HEAD_commondir_gitdir_files_read':True},
 'scientific_method_selection_freeze_reuse_fit_release_approval':False,
}
audit['content_sha256']=canonical(audit)
publish('audit.json',audit)
validation={'status':'pure_snapshot_metadata_consistency_checks_passed','source_snapshot_count':len(sources),
 'snapshots_hash_and_size_match':True,'all16_continuation_source_pins_match':True,
 'all9_registration_content_and_identity_source_bindings_match':True,
 'root_supplied_29125_ps_logs_match_actual_query_receipt':True,'source119_input_path_count':len(original_inputs),
 'original_changed_entry_count':len(changed),'original_changed_path_intersections':0,
 'four_git_common_dirs_equal_original_dot_git':True,'runtime_source_AST_count':len(ast_sources),
 'no_target_code_import_execution_or_scientific_computation':True,
 'instrumentation_notes':[
  'An earlier print heading said manifest159; the actual parsed retained input map is118, used consistently in machine evidence and report.',
  'The direct runtime original/guide literal rg search returned1 with no matches; that is a successful absence result, not a helper failure.',
  'Initial discovery guessed REPORT.md/audit.json in a historical producer audit; missing-file read failed before using its actual README/evidence.json names. No target execution or mutation occurred.',
 ]}
publish('validation.json',validation)
print(json.dumps(validation,sort_keys=True))
