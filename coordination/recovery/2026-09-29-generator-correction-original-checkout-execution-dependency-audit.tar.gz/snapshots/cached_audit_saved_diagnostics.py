"""Audit saved diagnostic arrays without fitting or modifying evidence."""

from __future__ import annotations

import hashlib
import json
import time
import warnings
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import arviz as az
import numpy as np

AUDIT = Path(__file__).resolve().parent
EXTENSION = Path('/Users/macuser/bayes-cox-runs/extensions-20260928/run')
PRIMARY = Path('/Users/macuser/bayes-cox-runs/frozen/reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651')
FIELDS = ('r_hat', 'ess_bulk', 'ess_tail', 'mcse_mean', 'mcse_sd')


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_cell(path: Path) -> tuple[dict, dict]:
    raw = path.read_bytes()
    cell = json.loads(raw)
    return cell, {'path': str(path), 'sha256': digest(raw), 'status': cell['status'],
                  'model_key': cell['model_key']}


def scalar_names(name: str, shape: tuple[int, ...]) -> list[str]:
    if not shape:
        return [name]
    return [name + '[' + ', '.join(map(str, index)) + ']' for index in np.ndindex(shape)]


def draw_array_boundary(name: str, array: np.ndarray) -> dict:
    """Inspect only posterior chain/draw values, retaining exact constants."""
    array = np.asarray(array, dtype=float)
    values = array.reshape(array.shape[0], array.shape[1], -1)
    labels = scalar_names(name, array.shape[2:])
    finite = np.isfinite(values)
    all_finite = finite.all(axis=(0, 1))
    constant = all_finite & (values.max(axis=(0, 1)) == values.min(axis=(0, 1)))
    within_chain = finite.all(axis=1) & (values.max(axis=1) == values.min(axis=1))
    return {'variable': name, 'shape': list(array.shape),
            'nonfinite_draw_values': int((~finite).sum()),
            'nonfinite_components': [labels[i] for i in np.flatnonzero(~all_finite)],
            'globally_constant_components': [labels[i] for i in np.flatnonzero(constant)],
            'chain_constant_components': [
                {'chain': int(chain), 'parameter': labels[column]}
                for chain, column in np.argwhere(within_chain)]}


def inspect_primary(cells: list[tuple[dict, dict]]) -> dict:
    """Inspect retained full beta summaries and thinned snapshots honestly."""
    records = []
    diagnostics_count = snapshots_count = coefficient_rows = 0
    for cell, source in cells:
        if not cell['model_key'].startswith('bayesian_'):
            continue
        record = {**source, 'stored_aggregate_nonfinite': [],
                  'coefficient_diagnostic_nonfinite': [], 'snapshot_issues': []}
        snapshots = []
        for attempt in cell.get('fit_attempts', []):
            diagnostic = attempt.get('diagnostics', {})
            if diagnostic:
                diagnostics_count += 1
                for name in (*FIELDS[:3], 'mcse_mean_max', 'mcse_sd_max', 'r_hat_max',
                             'ess_bulk_min', 'ess_tail_min', 'bfmi_min'):
                    if name in diagnostic:
                        value = diagnostic[name]
                        if value is None or not np.isfinite(float(value)):
                            record['stored_aggregate_nonfinite'].append(
                                {'attempt': attempt['attempt'], 'field': name, 'value': value})
            if attempt.get('posterior_trace_snapshot'):
                snapshots.append((f'attempt_{attempt["attempt"]}', attempt['posterior_trace_snapshot']))
        details = cell.get('model_details', {})
        if details.get('posterior_trace_snapshot'):
            snapshots.append(('accepted_model', details['posterior_trace_snapshot']))
        for index, row in enumerate(details.get('coefficient_summary', [])):
            coefficient_rows += 1
            for field in FIELDS:
                if field in row and (row[field] is None or not np.isfinite(float(row[field]))):
                    record['coefficient_diagnostic_nonfinite'].append(
                        {'row': index, 'parameter': row.get('feature', row.get('parameter')),
                         'field': field, 'value': row[field]})
        for label, snapshot in snapshots:
            snapshots_count += 1
            variables = []
            for name, variable in snapshot['variables'].items():
                values = np.asarray(variable['values'], dtype=float)
                dimensions = list(variable['dims'])
                order = [dimensions.index('chain'), dimensions.index('draw')]
                order += [i for i in range(values.ndim) if i not in order]
                boundary = draw_array_boundary(name, values.transpose(order))
                if (boundary['nonfinite_draw_values'] or boundary['globally_constant_components']
                        or boundary['chain_constant_components']):
                    variables.append(boundary)
            if variables:
                record['snapshot_issues'].append({'snapshot': label, 'variables': variables})
        records.append(record)
    findings = [r for r in records if r['stored_aggregate_nonfinite']
                or r['coefficient_diagnostic_nonfinite'] or r['snapshot_issues']]
    return {'bayesian_cells': len(records), 'stored_fit_diagnostic_records': diagnostics_count,
            'retained_thinned_snapshots': snapshots_count,
            'full_trace_coefficient_summary_rows': coefficient_rows,
            'status_counts': dict(Counter(r['status'] for r in records)),
            'findings': findings,
            'limitations': ['No full primary NetCDF traces or per-chain BFMI values are retained here.',
                            'Thinned snapshots cannot reconstruct the original full all-parameter gate.',
                            'Constant thinned draws alone do not prove constant unretained full draws.']}


def inspect_trace(job: dict) -> dict:
    path = Path(job['trace_path'])
    before = path.stat()
    observed_hash = digest(path.read_bytes())
    if observed_hash != job['expected_trace_sha256']:
        raise ValueError(f'trace differs from checkpoint hash: {path}')
    idata = az.from_netcdf(str(path))
    try:
        posterior = idata.posterior
        variable_boundaries = []
        for name, variable in posterior.data_vars.items():
            dimensions = [dim for dim in variable.dims if dim not in ('chain', 'draw')]
            boundary = draw_array_boundary(name, variable.transpose('chain', 'draw', *dimensions).values)
            if (boundary['nonfinite_draw_values'] or boundary['globally_constant_components']
                    or boundary['chain_constant_components']):
                variable_boundaries.append(boundary)
        with warnings.catch_warnings(record=True) as observed_warnings:
            warnings.simplefilter('always')
            summary = az.summary(idata, var_names=None, kind='diagnostics', round_to=None)
            bfmi = np.asarray(az.bfmi(idata), dtype=float)
        nonfinite = []
        masked = []
        reduced = {}
        for field in FIELDS:
            column = summary[field]
            value = float(column.abs().max() if field.startswith('mcse_') else
                          column.min() if field.startswith('ess_') else column.max())
            reduced[field] = value if np.isfinite(value) else None
            bad = ~np.isfinite(column.to_numpy(dtype=float))
            if bad.any():
                nonfinite.extend({'parameter': str(index), 'field': field,
                                  'kind': 'nan' if np.isnan(item) else 'infinity'}
                                 for index, item in column[bad].items())
                if np.isfinite(value):
                    masked.append({'field': field, 'count': int(bad.sum()),
                                   'is_acceptance_gate': field in ('r_hat', 'ess_bulk')})
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            bfmi_min = float(np.nanmin(bfmi)) if bfmi.size else float('nan')
        bad_bfmi = np.flatnonzero(~np.isfinite(bfmi))
        if len(bad_bfmi) and np.isfinite(bfmi_min):
            masked.append({'field': 'bfmi', 'count': len(bad_bfmi), 'is_acceptance_gate': True})
        energy = idata.sample_stats['energy'].transpose('chain', 'draw').values.astype(float)
        constant_energy = (np.isfinite(energy).all(axis=1)
                           & (energy.max(axis=1) == energy.min(axis=1)))
        with np.errstate(all='ignore'):
            energy_variance = np.var(energy, axis=1)
        stored = job['stored_diagnostics']
        matched = {}
        for field, observed in [('r_hat_max', reduced['r_hat']), ('ess_bulk_min', reduced['ess_bulk']),
                                ('bfmi_min', bfmi_min if np.isfinite(bfmi_min) else None)]:
            expected = stored.get(field)
            matched[field] = (expected is None and observed is None) or (
                expected is not None and observed is not None
                and bool(np.isclose(float(expected), observed, rtol=1e-10, atol=1e-10)))
        after = path.stat()
        assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        return {k: v for k, v in job.items() if k != 'stored_diagnostics'} | {
            'observed_trace_sha256': observed_hash,
            'groups_present': idata.groups(), 'groups_checked': ['posterior', 'sample_stats.energy'],
            'variables_checked': list(posterior.data_vars), 'summary_parameter_count': len(summary),
            'recorded_trace_converged': bool(stored.get('converged')),
            'raw_posterior_findings': variable_boundaries,
            'raw_energy_nonfinite_values': int((~np.isfinite(energy)).sum()),
            'nonfinite_diagnostic_rows': nonfinite, 'masked_nonfinite_fields': masked,
            'per_chain_bfmi': [float(x) if np.isfinite(x) else None for x in bfmi],
            'nonfinite_bfmi_chains': bad_bfmi.tolist(),
            'constant_energy_chains': np.flatnonzero(constant_energy).tolist(),
            'zero_energy_variance_chains': np.flatnonzero(energy_variance == 0).tolist(),
            'reduced_gate_statistics_match_stored': matched,
            'warnings': [str(w.message) for w in observed_warnings],
        }
    finally:
        idata.close()


def main() -> None:
    started = datetime.now(timezone.utc).isoformat()
    began = time.monotonic()
    extension_cells = [read_cell(p) for p in sorted((EXTENSION / 'cells').glob('*.json'))]
    primary_cells = [read_cell(p) for p in sorted((PRIMARY / 'cells').glob('*/*/*.json'))]
    manifest = json.loads((EXTENSION / 'manifest.json').read_text())
    jobs = []
    for cell, source in extension_cells:
        for index, attempt in enumerate(cell.get('fit_attempts', [])):
            posterior_pass = bool(attempt.get('diagnostics', {}).get('converged'))
            prior = attempt.get('prior_diagnostics', {})
            accepted_fit = (cell['status'] == 'complete' and index == len(cell['fit_attempts']) - 1
                            and posterior_pass and (not prior or bool(prior.get('converged'))))
            for label, trace in attempt.get('traces', {}).items():
                jobs.append({'cell_path': source['path'], 'cell_sha256': source['sha256'],
                             'cell_id': cell['cell_id'], 'model_key': cell['model_key'],
                             'cell_status': cell['status'], 'attempt': attempt['attempt'],
                             'trace_label': label, 'actual_accepted_fit': accepted_fit,
                             'trace_path': str(EXTENSION / 'traces' / cell['cell_id'] / trace['filename']),
                             'expected_trace_sha256': trace['sha256'],
                             'stored_diagnostics': attempt['diagnostics' if label == 'posterior' else 'prior_diagnostics']})
    snapshot = {'started_utc': started, 'extension_root': str(EXTENSION), 'primary_root': str(PRIMARY),
                'extension_manifest_sha256': digest((EXTENSION / 'manifest.json').read_bytes()),
                'extension_planned_cells': manifest['planned_fits'],
                'extension_snapshot_cells': len(extension_cells), 'referenced_trace_count': len(jobs),
                'extension_status_counts': dict(Counter(c['status'] for c, _ in extension_cells)),
                'extension_cells': [s for _, s in extension_cells],
                'primary_cells': [s for _, s in primary_cells], 'trace_jobs': jobs}
    (AUDIT / 'snapshot_inventory.json').write_text(json.dumps(snapshot, indent=2) + '\n')
    primary_result = inspect_primary(primary_cells)
    (AUDIT / 'primary_saved_diagnostic_audit.json').write_text(json.dumps(primary_result, indent=2) + '\n')
    print(f'Fixed snapshot: {len(extension_cells)}/{manifest["planned_fits"]} extension cells, '
          f'{len(jobs)} referenced traces; primary {primary_result["bayesian_cells"]} Bayesian cells.', flush=True)
    print(f'Primary retained-data findings: {len(primary_result["findings"])}.', flush=True)
    records = []
    with (AUDIT / 'extension_trace_audit.jsonl').open('w') as stream:
        for index, job in enumerate(jobs, start=1):
            try:
                record = inspect_trace(job)
            except Exception as exc:
                record = {'cell_id': job['cell_id'], 'trace_path': job['trace_path'],
                          'error_type': type(exc).__name__, 'error': str(exc)}
            records.append(record)
            stream.write(json.dumps(record, allow_nan=False) + '\n')
            stream.flush()
            if index % 50 == 0 or index == len(jobs):
                flagged = sum(bool(r.get('masked_nonfinite_fields')) for r in records)
                errors = sum('error' in r for r in records)
                print(f'{index}/{len(jobs)} traces checked; masked flags {flagged}; '
                      f'errors {errors}; elapsed {time.monotonic()-began:.1f}s.', flush=True)
    result = {'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
              'extension_snapshot_cells': len(extension_cells), 'extension_planned_cells': manifest['planned_fits'],
              'extension_snapshot_incomplete': len(extension_cells) != manifest['planned_fits'],
              'referenced_traces': len(jobs), 'trace_checks_completed': sum('error' not in r for r in records),
              'trace_errors': [r for r in records if 'error' in r],
              'traces_with_nonfinite_draws': sum(bool(r.get('raw_energy_nonfinite_values'))
                  or any(v['nonfinite_draw_values'] for v in r.get('raw_posterior_findings', [])) for r in records),
              'traces_with_nonfinite_diagnostic_rows': sum(bool(r.get('nonfinite_diagnostic_rows')) for r in records),
              'traces_with_nonfinite_bfmi': sum(bool(r.get('nonfinite_bfmi_chains')) for r in records),
              'traces_with_masked_nonfinite_gate': sum(any(f['is_acceptance_gate'] for f in r.get('masked_nonfinite_fields', [])) for r in records),
              'actual_accepted_fit_traces_with_masked_gate': sum(r.get('actual_accepted_fit', False)
                  and any(f['is_acceptance_gate'] for f in r.get('masked_nonfinite_fields', [])) for r in records),
              'traces_with_constant_posterior_components': sum(any(v['globally_constant_components']
                  or v['chain_constant_components'] for v in r.get('raw_posterior_findings', [])) for r in records),
              'traces_with_zero_energy_variance': sum(bool(r.get('zero_energy_variance_chains')) for r in records),
              'traces_with_reduced_gate_mismatch': sum(not all(r.get('reduced_gate_statistics_match_stored', {}).values()) for r in records if 'error' not in r),
              'primary': primary_result,
              'script_sha256': digest(Path(__file__).read_bytes()),
              'snapshot_inventory_sha256': digest((AUDIT / 'snapshot_inventory.json').read_bytes()),
              'extension_trace_audit_sha256': digest((AUDIT / 'extension_trace_audit.jsonl').read_bytes())}
    (AUDIT / 'audit_summary.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('primary', 'trace_errors')}, indent=2), flush=True)


if __name__ == '__main__':
    main()
