"""Capture the actual root-owned read-only observer child and its future rc."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PREP = Path('/Users/macuser/bayes-cox-runs/extensions-20260928/darwin_original_exit_observer_preparation_v3')
PYTHON = '/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python'
OUTPUT = Path('/Users/macuser/bayes-cox-runs/original-exit-observer-20260929-v1')
REQUEST_SHA = 'e995364f4c958cc33afe799bf0c059cfb8ad59884071c9d351883d15370cad43'
SOURCE_SHA = '7174d1f604385b11cafa6eb0dc7041ea5d3eab7dd9d14a16056f2af968a3ae03'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(ROOT / 'request.json') == REQUEST_SHA
assert sha(PREP / 'observer.py') == SOURCE_SHA
assert not OUTPUT.exists()
argv = [PYTHON, '-I', '-B', str(PREP / 'observer.py'), 'observe',
        '--request', str(ROOT / 'request.json'), '--request-sha256', REQUEST_SHA,
        '--output', str(OUTPUT)]
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
             'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    environment[name] = '1'
started = dt.datetime.now(dt.timezone.utc).isoformat()
with (ROOT / 'observer.stdout.log').open('xb') as stdout, (ROOT / 'observer.stderr.log').open('xb') as stderr:
    child = subprocess.Popen(argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
    (ROOT / 'observer.started.json').write_text(json.dumps({
        'schema_version': 1, 'status': 'actual_read_only_observer_child_launched_not_completed',
        'argv': argv, 'cwd': str(ROOT), 'pid': child.pid, 'wrapper_pid': os.getpid(),
        'started_at_utc': started, 'request_sha256': REQUEST_SHA,
        'observer_source_sha256': SOURCE_SHA,
        'root_scope_review_sha256': sha(ROOT / 'root_read_only_scope_review.md'),
        'original_processes_modified': False,
        'scientific_or_producer_completion_certified': False,
    }, sort_keys=True, indent=2) + '\n')
    rc = child.wait()
record = {
    'schema_version': 1, 'status': 'actual_read_only_observer_child_returned',
    'argv': argv, 'cwd': str(ROOT), 'pid': child.pid, 'started_at_utc': started,
    'finished_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'exit_code': rc,
    'request_sha256': REQUEST_SHA, 'observer_source_sha256': SOURCE_SHA,
    'request_and_observer_bytes_unchanged': sha(ROOT / 'request.json') == REQUEST_SHA and sha(PREP / 'observer.py') == SOURCE_SHA,
    'stdout_sha256': sha(ROOT / 'observer.stdout.log'),
    'stderr_sha256': sha(ROOT / 'observer.stderr.log'),
    'original_processes_modified': False, 'scientific_or_producer_completion_certified': False,
}
with (ROOT / 'observer.finished.json').open('x') as stream:
    stream.write(json.dumps(record, sort_keys=True, indent=2) + '\n')
sys.exit(rc)
