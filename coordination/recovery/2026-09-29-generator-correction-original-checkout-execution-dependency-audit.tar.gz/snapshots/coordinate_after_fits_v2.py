"""Wait for sealed workers, then run write-once verified extension stages.

This coordinator never changes a fitted cell or issues a visual-QA verdict.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path


BASE = Path("/Users/macuser/bayes-cox-runs")
HOME = BASE / "extensions-20260928"
RUN = HOME / "run"
REPRO = HOME / "reproduction"
RENDERED = HOME / "rendered_v1"
QA = HOME / "pdf_qa_v1"
ANALYSIS = BASE / "extensions-analysis-code-20260928-8551d32"
PRODUCTION = BASE / "extensions-code-20260928-119476f"
MATCHED = BASE / "extension-preparation-20260928/matched_metabric.parquet"
PRIMARY = BASE / "student-restore-check-20260928/reports/confirmatory/confirmatory_v1_confirmatory_cdcdcee84651"
SAMPLER = BASE / "student-programme-results-20260928/sampler_run"
ROBUSTNESS = BASE / "student-programme-results-20260928/robustness"
PYTHON = Path("/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/python")
PRODUCTION_PIDS = (62025, 62026, 62027, 62028, 62029, 62030)
PRESTAGE_PIDS = (64406, 64435)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def log(*parts: object) -> None:
    print(now(), *parts, flush=True)


def active(pid: int, needle: str) -> bool:
    output = subprocess.run(["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True, check=False)
    return output.returncode == 0 and needle in output.stdout


def records(directory: Path) -> int:
    return sum(1 for _ in directory.glob("*.json"))


def stage(command: list[str], cwd: Path) -> None:
    log("START", " ".join(command))
    subprocess.run(command, cwd=cwd, env={**os.environ, "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1",
                                           "VECLIB_MAXIMUM_THREADS": "1"}, check=True)
    log("DONE", command[1])


def main() -> None:
    log("coordinator starting", "production code", PRODUCTION, "analysis code", ANALYSIS)
    for root, short in ((PRODUCTION, "119476f"), (ANALYSIS, "8551d32")):
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
        if not commit.startswith(short):
            raise ValueError(f"wrong sealed checkout: {root}: {commit}")
        if subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True).strip():
            raise ValueError(f"sealed checkout is dirty: {root}")
    prior = -1
    while True:
        stored = records(RUN / "cells")
        if stored != prior:
            log("fit cells", stored, "/ 1625", "refit cells", records(REPRO / "cells"))
            prior = stored
        fitting = [pid for pid in PRODUCTION_PIDS if active(pid, "scripts/run_extensions.py")]
        if not fitting:
            if stored != 1625:
                raise RuntimeError(f"all fitting processes exited with only {stored}/1625 cells")
            break
        time.sleep(60)
    log("all fitting workers exited with complete grid")
    while any(active(pid, "prestage_refits.py") for pid in PRESTAGE_PIDS):
        log("waiting for selected pre-stage refits", records(REPRO / "cells"), "/ 92")
        time.sleep(60)
    if records(REPRO / "cells") != 92:
        raise RuntimeError(f"pre-stage workers ended with {records(REPRO / 'cells')}/92 refit cells")

    stage([str(PYTHON), "scripts/finalize_extensions.py", "--matched", str(MATCHED),
           "--run", str(RUN), "--production-code", str(PRODUCTION),
           "--primary", str(PRIMARY), "--sampler", str(SAMPLER),
           "--robustness", str(ROBUSTNESS)], ANALYSIS)
    stage([str(PYTHON), "scripts/reproduce_extensions.py", "--matched", str(MATCHED),
           "--source", str(RUN), "--output", str(REPRO), "--workers", "1", "--worker", "0"], PRODUCTION)
    if records(REPRO / "receipts") != 92:
        raise RuntimeError("official reproduction did not issue all 92 receipts")
    stage([str(PYTHON), "scripts/render_extensions.py", "--run", str(RUN),
           "--output", str(RENDERED)], ANALYSIS)
    stage([str(PYTHON), "scripts/extension_release/extension_pdf_qa.py", "prepare",
           "--run", str(RUN), "--rendered", str(RENDERED),
           "--renderer", str(ANALYSIS / "scripts/render_extensions.py"),
           "--qa-dir", str(QA)], ANALYSIS)
    if not (QA / "review_template.json").exists():
        raise RuntimeError("automated visual-QA preparation did not finish")
    (HOME / "analysis_prepared.json").write_text(json.dumps({"status": "numerical_render_verified_visual_review_pending",
                                                       "prepared_utc": now(), "source_cells": 1625,
                                                       "exact_refit_receipts": 92, "qa_dir": str(QA)},
                                                      indent=2, sort_keys=True) + "\n")
    log("PREPARED: final 32-page visual inspection remains required")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        log("COORDINATOR FAILED", repr(exc))
        (HOME / "coordinator_failure.json").write_text(json.dumps({"failed_utc": now(),
                                                             "error_type": type(exc).__name__,
                                                             "error": str(exc)}, indent=2, sort_keys=True) + "\n")
        raise
