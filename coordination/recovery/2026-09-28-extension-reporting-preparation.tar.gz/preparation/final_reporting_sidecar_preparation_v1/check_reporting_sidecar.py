"""Pure synthetic guard/interval/replay checks; never opens the real extension run.

Synthetic baseline metadata pins are substituted only inside unittest contexts.
The production CLI has no test switch or alternative pin. All test directories
are temporary, contain invented records, and are deleted after the checks.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import shutil
import tempfile
import unittest
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator
from unittest.mock import patch

import generate_reporting_sidecar as sidecar

PREPARATION = Path(__file__).resolve().parent


def seal(record: dict[str, Any], field: str) -> dict[str, Any]:
    """Bind a synthetic record using the same public canonical encoding."""
    record.pop(field, None)
    record[field] = sidecar.canonical_sha(record)
    return record


def toy_cell(
    dataset: str, setting: str, repeat: int, fold: int, model: str, condition: str, *, extension: bool
) -> dict[str, Any]:
    """Invent outcome/membership data with 8 train and 2 validation patients."""
    train = [f"{dataset}-r{repeat}f{fold}-T{i}" for i in range(8)]
    valid = [f"{dataset}-r{repeat}f{fold}-V{i}" for i in range(2)]
    model_order = sidecar.ORIGINAL + sidecar.NEW
    score = 0.1 + model_order.index(model) / 100 + repeat / 1000 + fold / 10000
    # Interaction ensures nonzero paired variance for the corrected-interval oracle.
    score += model_order.index(model) * repeat * fold / 100000
    record = {
        "dataset": dataset,
        "model_key": model,
        "repeat": repeat,
        "fold": fold,
        "n_train": 8,
        "n_validation": 2,
        "events_train": 4,
        "train_subject_ids": train,
        "validation_subject_ids": valid,
        "status": "complete",
        "metrics": {"ibs": score},
        "predictions": {
            "subject_ids": valid,
            "training_time": list(range(1, 9)),
            "training_event": [1, 0, 1, 0, 1, 0, 1, 0],
            "observed_time": [3, 7],
            "observed_event": [1, 0],
            "horizons": [2, 4, 6],
            "ibs_grid": [2, 3, 4, 5, 6],
        },
    }
    if extension:
        record.update(
            {
                "cell_id": sidecar.cell_id(dataset, setting, repeat, fold, model, condition),
                "setting": setting,
                "condition": condition,
                "evidence_status": "post_hoc_extension",
                "censoring_cutoff": None,
                "training_membership_sha256": sidecar.canonical_sha(train),
                "p": 2,
                "events_per_coefficient": 2.0,
            }
        )
    return seal(record, "cell_content_sha256")


def toy_families() -> dict[str, Any]:
    """Construct schema fixtures for the four already existing formal families."""
    original_priors = sidecar.ORIGINAL[3:]
    rows = {
        "penalized_vs_original_priors": [],
        "calibrated_vs_adr032_horseshoe": [],
        "catalytic_vs_original_priors": [],
        "expression_increment": [],
    }
    for dataset in sidecar.DATASETS:
        for family, models in (
            ("penalized_vs_original_priors", sidecar.EXTRA[:3]),
            ("catalytic_vs_original_priors", sidecar.CATALYTIC),
        ):
            for model in models:
                for prior in original_priors:
                    rows[family].append(
                        {
                            "dataset": dataset,
                            "left": model,
                            "right": prior,
                            "horseshoe_reference": "ADR-032 post-hoc sampler"
                            if prior == "bayesian_horseshoe"
                            else None,
                        }
                    )
        rows["calibrated_vs_adr032_horseshoe"].append(
            {"dataset": dataset, "left": "pv_horseshoe", "right": "ADR032_horseshoe"}
        )
    for model in sidecar.ORIGINAL + sidecar.NEW:
        rows["expression_increment"].append(
            {"dataset": "metabric_matched", "model": model, "left": "expression", "right": "clinical"}
        )
    for records in rows.values():
        for row in records:
            row.update(
                {
                    "n_pairs": 25,
                    "expected_pairs": 25,
                    "status": "estimable",
                    "effect": {"p_value": 1.0},
                    "holm_adjusted_p": 1.0,
                    "holm_reject": False,
                    "superiority_language_permitted": False,
                }
            )
    return {
        name: {"contrasts": records, "expected_contrasts": len(records), "family_complete": True}
        for name, records in rows.items()
    }


def save(path: Path, value: Any) -> str:
    """Write only a fresh synthetic JSON path and return its exact byte hash."""
    path.parent.mkdir(parents=True, exist_ok=True)
    data = sidecar.json_bytes(value)
    with path.open("xb") as handle:
        handle.write(data)
    return sidecar.sha_bytes(data)


@contextmanager
def changed(path: Path, data: bytes) -> Iterator[None]:
    """Change one synthetic fixture temporarily, restoring even after refusal."""
    original = path.read_bytes()
    path.write_bytes(data)
    try:
        yield
    finally:
        path.write_bytes(original)


class ReportingChecks(unittest.TestCase):
    """Exercise actual guard paths with invented complete records and corrupt variants."""

    @classmethod
    def setUpClass(cls) -> None:
        """Build one complete toy programme, preserving all actual source files."""
        cls.temporary = tempfile.TemporaryDirectory(prefix="sidecar-pure-synthetic-")
        cls.root = Path(cls.temporary.name)
        cls.run_root = cls.root / "run"
        cls.primary_root = cls.root / "primary"
        cls.cells = [toy_cell(*values, extension=True) for _, values in sorted(sidecar.expected_extension().items())]
        plan = [
            {
                "cell_id": c["cell_id"],
                "train_sha256": sidecar.canonical_sha(c["train_subject_ids"]),
                "validation_sha256": sidecar.canonical_sha(c["validation_subject_ids"]),
                "censoring_cutoff": None,
            }
            for c in cls.cells
        ]
        cls.manifest = seal(
            {
                "plan": plan,
                "planned_fits": 1625,
                "evidence_status": "post_hoc_extension",
                "code": {"git_commit": sidecar.PRODUCTION_COMMIT, "git_dirty": False},
            },
            "manifest_content_sha256",
        )
        manifest_sha = save(cls.run_root / "manifest.json", cls.manifest)
        inventory = {
            f"cells/{c['cell_id']}.json": save(cls.run_root / "cells" / f"{c['cell_id']}.json", c) for c in cls.cells
        }
        cls.families = toy_families()
        aggregates = {
            name: save(cls.run_root / name, value)
            for name, value in (
                ("paired_families.json", cls.families),
                ("rq2_effects.json", {}),
                ("decision_curves.json", {}),
            )
        }
        cls.claim = sidecar.load_pinned_module(
            PREPARATION / "summarize_verified_claim_inputs.py",
            (PREPARATION / "summarize_verified_claim_inputs.py").read_bytes(),
            "_synthetic_claim_fixture",
        )
        cls.interval = sidecar.load_pinned_module(
            PREPARATION / "frozen_repeated_cv.py",
            (PREPARATION / "frozen_repeated_cv.py").read_bytes(),
            "_synthetic_interval_fixture",
        )
        verification = {
            "planned": 1625,
            "stored": 1625,
            "status_counts": {"complete": 1625},
            "verification": "deep",
            "independently_rescored": 1625,
            "independently_checked_traces": 0,
            "production_code_commit": sidecar.PRODUCTION_COMMIT,
            "analysis_only_sha256": cls.claim.ANALYSIS_ONLY_HASHES,
        }
        save(cls.run_root / "verification.json", verification)
        cls.completion = seal(
            {
                **verification,
                "evidence_status": "post_hoc_extension",
                "cell_sha256": inventory,
                "aggregate_sha256": aggregates,
                "manifest_sha256": manifest_sha,
                "selected_reproduction_status": "pending",
                "render_status": "pending",
            },
            "completion_content_sha256",
        )
        save(cls.run_root / "completion.json", cls.completion)
        primary_inventory = {}
        cls.primary_cells = {}
        failures = 0
        for relative, (dataset, model, repeat, fold) in sorted(sidecar.expected_primary().items()):
            cell = toy_cell(dataset, "clinical", repeat, fold, model, "full", extension=False)
            if model == "bayesian_horseshoe" and failures < 20:
                cell["status"] = "failed_diagnostics"
                cell.pop("metrics")
                cell.pop("predictions")
                seal(cell, "cell_content_sha256")
                failures += 1
            primary_inventory[relative] = save(cls.primary_root / relative, cell)
            cls.primary_cells[(dataset, model, repeat, fold)] = sidecar.CellRef("primary", relative, cell)
        cls.primary_pins = {
            "manifest.json": save(cls.primary_root / "manifest.json", {"synthetic_fixture_only": True}),
            "completion.json": save(
                cls.primary_root / "completion.json",
                seal(
                    {
                        "stored_cells": 450,
                        "planned_cells_in_this_invocation": 450,
                        "status_counts": {"complete": 430, "failed_diagnostics": 20},
                        "all_stored_cell_hashes": primary_inventory,
                    },
                    "completion_content_sha256",
                ),
            ),
        }
        cls.scope = sidecar.strict_json((PREPARATION / "scope.json").read_bytes(), "scope fixture")
        cls.extension = sidecar.extension_refs(cls.cells, cls.manifest)
        cls.family_summary = cls.claim.summarize_families(cls.families)

    @classmethod
    def tearDownClass(cls) -> None:
        """Remove invented fixture files; no actual project path was touched."""
        cls.temporary.cleanup()

    def args(self, suffix: str, *, verify: bool = False) -> argparse.Namespace:
        """Return CLI-shaped arguments using temporary invented evidence only."""
        return sidecar.arguments(
            ["--run", str(self.run_root), "--primary", str(self.primary_root), "--output", str(self.root / suffix)]
            + (["--verify-existing"] if verify else [])
        )

    def reject(self, function: Any, fragment: str) -> None:
        """Require a specific refusal, not an accidental unrelated exception."""
        with self.assertRaisesRegex(ValueError, fragment):
            function()

    def test_01_exact_scope_and_grid(self) -> None:
        """Every frozen job and reporting row is represented exactly once."""
        self.assertEqual(len(self.extension), 1625)
        self.assertEqual(len(self.primary_cells), 450)
        self.assertEqual(self.scope["rows"], sidecar.expected_scope_rows())
        self.assertEqual(Counter(r["right_source_role"] for r in self.scope["rows"]), {"primary": 27, "extension": 96})
        self.assertEqual(sum(r["dataset"] != "metabric_matched" for r in self.scope["rows"]), 63)
        self.assertEqual(sum(r["dataset"] == "metabric_matched" for r in self.scope["rows"]), 60)
        self.assertFalse(any(r["right"] in sidecar.CATALYTIC for r in self.scope["rows"]))

    def test_02_ratios_keep_failure_counts_and_missing_p(self) -> None:
        """Diagnostic/execution failures retain real p; absent p remains null."""
        refs = copy.deepcopy(self.extension)
        selected = list(refs)[:3]
        refs[selected[0]].record["status"] = "failed_diagnostics"
        refs[selected[1]].record["status"] = "failed"
        refs[selected[2]].record["status"] = "failed"
        refs[selected[2]].record.pop("p")
        refs[selected[2]].record.pop("events_per_coefficient")
        for identity in selected:
            sidecar.validate_record(refs[identity].record, "synthetic failed cell")
        rows = sidecar.dimension_rows(refs)
        by_id = {r["cell_id"]: r for r in rows}
        self.assertEqual(len(rows), 1625)
        for identity in selected[:2]:
            self.assertEqual(by_id[identity]["p_over_n_train"], 0.25)
            self.assertEqual(by_id[identity]["events_over_p"], 2.0)
        self.assertIsNone(by_id[selected[2]]["p"])
        self.assertIsNone(by_id[selected[2]]["p_over_n_train"])
        self.assertIsNone(by_id[selected[2]]["events_over_p"])
        counts = sidecar.reporting_counts(rows, [])
        self.assertEqual(counts["ratios_available"], 1624)
        self.assertEqual(counts["ratios_unavailable"], 1)
        self.assertEqual(counts["extension_status_counts"], {"complete": 1622, "failed": 2, "failed_diagnostics": 1})

    def test_03_complete_interval_independent_numeric_oracle(self) -> None:
        """Mean/SE/bounds agree with a manual sample-variance and t24 oracle."""
        row = sidecar.descriptive_row(
            self.scope["rows"][0], self.extension, self.primary_cells, self.interval.nadeau_bengio_paired_effect
        )
        differences = [r["difference"] for r in row["paired_records"]]
        mean = math.fsum(differences) / 25
        variance = math.fsum((x - mean) ** 2 for x in differences) / 24
        expected_se = math.sqrt((1 / 25 + 1 / 4) * variance)
        t24_975 = 2.0638985616280205
        self.assertAlmostEqual(row["mean_difference"], mean, places=14)
        self.assertAlmostEqual(row["corrected_standard_error"], expected_se, places=14)
        self.assertAlmostEqual(row["confidence_lower"], mean - t24_975 * expected_se, places=14)
        self.assertAlmostEqual(row["confidence_upper"], mean + t24_975 * expected_se, places=14)
        self.assertEqual(row["n_pairs"], 25)
        self.assertEqual(row["degrees_of_freedom"], 24)
        self.assertEqual(row["confidence_level"], 0.95)
        self.assertEqual(row["test_train_ratio"], 0.25)
        for forbidden in ("p_value", "t_statistic", "holm_adjusted_p", "holm_reject", "superiority_language_permitted"):
            self.assertNotIn(forbidden, row)

    def test_04_partial_pair_mean_with_no_interval(self) -> None:
        """A failed catalytic fold yields 24 observed pairs without interval computation."""
        refs = copy.deepcopy(self.extension)
        key = sidecar.cell_id("gbsg2", "clinical", 1, 1, "catalytic_fixed", "full")
        refs[key].record["status"] = "failed_diagnostics"

        def forbidden(*args: Any, **kwargs: Any) -> None:
            raise AssertionError("partial coverage called corrected interval routine")

        row = sidecar.descriptive_row(self.scope["rows"][0], refs, self.primary_cells, forbidden)
        self.assertEqual(row["n_pairs"], 24)
        self.assertEqual(row["missing_pairs"], 1)
        self.assertEqual(row["interval_status"], "partial_observed_pairs_no_interval")
        self.assertEqual(row["paired_records"][0]["exclusions"], ["left_failed_diagnostics"])
        self.assertAlmostEqual(
            row["mean_difference"], math.fsum(p["difference"] for p in row["paired_records"] if p["included"]) / 24
        )
        for field in ("confidence_lower", "confidence_upper", "corrected_standard_error", "confidence_level"):
            self.assertIsNone(row[field])

    def test_05_zero_pairs_null_and_both_failure_accounting(self) -> None:
        """No accepted pairs returns no mean/interval and preserves both failure types."""
        refs = copy.deepcopy(self.extension)
        primary = copy.deepcopy(self.primary_cells)
        for repeat in range(1, 6):
            for fold in range(1, 6):
                refs[sidecar.cell_id("gbsg2", "clinical", repeat, fold, "catalytic_fixed", "full")].record["status"] = (
                    "failed"
                )
                primary[("gbsg2", "cox_ph", repeat, fold)].record["status"] = "failed_diagnostics"
        row = sidecar.descriptive_row(
            self.scope["rows"][0], refs, primary, lambda *a, **k: self.fail("no-pair interval")
        )
        self.assertEqual(row["n_pairs"], 0)
        self.assertEqual(row["missing_pairs"], 25)
        self.assertIsNone(row["mean_difference"])
        self.assertIsNone(row["confidence_lower"])
        self.assertEqual(row["paired_records"][0]["exclusions"], ["left_failed", "right_failed_diagnostics"])

    def test_06_missing_and_duplicate_grid_refused(self) -> None:
        """Missing and duplicated cells/plans cannot be called a complete programme."""
        self.reject(lambda: sidecar.extension_refs(self.cells[:-1], self.manifest), "partial extension")
        duplicate = self.cells[:-1] + [self.cells[0]]
        self.reject(lambda: sidecar.extension_refs(duplicate, self.manifest), "duplicate extension cell")
        plan = copy.deepcopy(self.manifest)
        plan["plan"][-1] = plan["plan"][0]
        self.reject(lambda: sidecar.extension_refs(self.cells, plan), "duplicate planned")

    def test_07_patient_train_and_all_prediction_alignment(self) -> None:
        """Patients, training members, outcomes, horizons and IBS grids must align exactly."""
        spec = self.scope["rows"][0]
        left = self.extension[sidecar.cell_id("gbsg2", "clinical", 1, 1, "catalytic_fixed", "full")]
        right = self.primary_cells[("gbsg2", "cox_ph", 1, 1)]
        for field in ("train_subject_ids", "validation_subject_ids"):
            with self.subTest(field=field):
                changed_right = copy.deepcopy(right)
                changed_right.record[field].reverse()
                self.reject(lambda: sidecar.assert_pair_alignment(left, changed_right), f"pair mismatch at {field}")
        for field in (
            "subject_ids",
            "observed_time",
            "observed_event",
            "training_time",
            "training_event",
            "horizons",
            "ibs_grid",
        ):
            with self.subTest(field=field):
                changed_right = copy.deepcopy(right)
                changed_right.record["predictions"][field] = list(reversed(changed_right.record["predictions"][field]))
                self.reject(lambda: sidecar.assert_pair_alignment(left, changed_right), f"pair mismatch at {field}")
        self.assertEqual(spec["right_source_role"], "primary")

    def test_08_duplicates_nonfinite_counts_and_recorded_ratio_refused(self) -> None:
        """Bad patient IDs, IBS, denominators and inconsistent events/p cannot enter tables."""
        original = self.cells[0]
        bad = copy.deepcopy(original)
        bad["train_subject_ids"][1] = bad["train_subject_ids"][0]
        self.reject(lambda: sidecar.validate_record(bad, "toy"), "duplicate patient")
        for scalar in (float("nan"), float("inf"), None, "0.2", True):
            with self.subTest(ibs=scalar):
                bad = copy.deepcopy(original)
                bad["metrics"]["ibs"] = scalar
                self.reject(lambda: sidecar.validate_record(bad, "toy"), "nonnumeric toy/IBS")
        for field, value in (("p", 0), ("p", True), ("p", float("nan")), ("n_train", 0), ("events_train", 9)):
            with self.subTest(field=field, value=value):
                bad = copy.deepcopy(original)
                bad[field] = value
                self.reject(lambda: sidecar.validate_record(bad, "toy"), "invalid count|events exceed")
        bad = copy.deepcopy(original)
        bad["events_per_coefficient"] = 9.0
        self.reject(lambda: sidecar.validate_record(bad, "toy"), "stored events/p differs")

    def test_09_strict_json_rejects_duplicate_and_nonfinite(self) -> None:
        """Duplicate keys and both literal and overflow nonfinite numbers are refused."""
        for text in ('{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}', '{"x":1e999}'):
            with self.subTest(text=text):
                self.reject(lambda: sidecar.strict_json(text.encode(), "toy JSON"), "duplicate|nonstandard|nonfinite")

    def test_10_complete_build_has123_rows_and_linked27(self) -> None:
        """Build all descriptive rows without duplicating inherited-prior formal effects."""
        report = sidecar.build_report(
            self.extension,
            self.primary_cells,
            self.scope,
            self.families,
            self.family_summary,
            self.interval.nadeau_bengio_paired_effect,
        )
        counts = report["counts"]
        self.assertEqual(counts["extension_cells"], 1625)
        self.assertEqual(counts["descriptive_rows"], 123)
        self.assertEqual(counts["planned_fold_pairs"], 3075)
        self.assertEqual(counts["included_fold_pairs"], 3075)
        self.assertEqual(len(report["formal_clinical_prior_family"]["contrasts"]), 27)
        identities = Counter(r["right_identity"] for r in report["formal_clinical_prior_family"]["contrasts"])
        self.assertEqual(identities, {"ADR032_post_hoc_sampler": 9, "unchanged_original_primary_prior": 18})
        encoded = json.dumps(report)
        for forbidden in (
            '"p_value"',
            '"t_statistic"',
            '"holm_adjusted_p"',
            '"holm_reject"',
            '"superiority_language_permitted"',
        ):
            self.assertNotIn(forbidden, encoded)

    def test_11_partial_and_missing_file_refused_before_destination(self) -> None:
        """Actual entry-point guards refuse invented incomplete outputs before mkdir."""
        args = self.args("partial-refusal")
        partial = copy.deepcopy(self.completion)
        partial["stored"] = 1624
        seal(partial, "completion_content_sha256")
        with changed(self.run_root / "completion.json", sidecar.json_bytes(partial)):
            self.reject(lambda: sidecar.run(args), "partial/unverified")
        self.assertFalse(args.output.exists())
        member = self.run_root / "cells" / f"{self.cells[0]['cell_id']}.json"
        hidden = member.with_suffix(".temporarily-missing")
        member.rename(hidden)
        try:
            self.reject(lambda: sidecar.run(self.args("missing-refusal")), "missing or linked input")
            self.assertFalse((self.root / "missing-refusal").exists())
        finally:
            hidden.rename(member)

    def test_12_changed_bytes_and_dependency_pin_refused(self) -> None:
        """Even whitespace changes or a altered dependency must fail exact-byte pins."""
        member = self.run_root / "cells" / f"{self.cells[0]['cell_id']}.json"
        args = self.args("changed-byte-refusal")
        with changed(member, member.read_bytes() + b" "):
            self.reject(lambda: sidecar.run(args), "changed input bytes")
        self.assertFalse(args.output.exists())
        dependency = self.root / "altered_claim.py"
        dependency.write_bytes((PREPARATION / "summarize_verified_claim_inputs.py").read_bytes() + b"\n")
        args = self.args("changed-dependency-refusal")
        args.claim_helper = dependency
        self.reject(lambda: sidecar.run(args), "changed input bytes")
        self.assertFalse(args.output.exists())

    def test_13_snapshot_race_inventory_escape_and_changed_content(self) -> None:
        """Read/write races, unsafe inventory paths and internal digest changes fail closed."""
        path = self.root / "small-source.json"
        path.write_bytes(b"{}")
        snapshot = sidecar.Snapshot()
        snapshot.capture("toy/source", path)
        with changed(path, b"{ } "):
            self.reject(snapshot.recheck, "input changed during reporting")
        for relative in ("../escape.json", str(path)):
            self.reject(lambda: sidecar.inventory_path(self.root, relative), "unsafe inventory")
        record = copy.deepcopy(self.cells[0])
        record["metrics"]["ibs"] += 0.1
        self.reject(lambda: sidecar.verify_content(record, "cell_content_sha256"), "content digest mismatch")

    def test_14_write_once_generation_and_relocated_root_replay(self) -> None:
        """A complete synthetic generation replays identical bytes from wholly new roots."""
        args = self.args("generated")
        with patch.dict(sidecar.PRIMARY_PINS, self.primary_pins):
            receipt = sidecar.run(args)
        self.assertEqual(receipt["status"], "reporting_sidecar_generated")
        self.assertFalse(receipt["scientific_completion_certified"])
        self.assertEqual(set(p.name for p in args.output.iterdir()), set(sidecar.ARTIFACT_FILES))
        before = {p.name: p.read_bytes() for p in args.output.iterdir()}
        for name in sidecar.CORE_FILES + ("lineage.json",):
            self.assertNotIn(str(self.root).encode(), before[name])
            self.assertNotIn(b"started_utc", before[name])
        relocated = self.root / "independent-laptop"
        relocated.mkdir()
        shutil.copytree(self.run_root, relocated / "extension")
        shutil.copytree(self.primary_root, relocated / "baseline")
        shutil.copytree(args.output, relocated / "tables")
        for name in ("scope.json", "summarize_verified_claim_inputs.py", "frozen_repeated_cv.py"):
            shutil.copyfile(PREPARATION / name, relocated / name)
        replay_args = sidecar.arguments(
            [
                "--run",
                str(relocated / "extension"),
                "--primary",
                str(relocated / "baseline"),
                "--output",
                str(relocated / "tables"),
                "--scope-file",
                str(relocated / "scope.json"),
                "--claim-helper",
                str(relocated / "summarize_verified_claim_inputs.py"),
                "--interval-source",
                str(relocated / "frozen_repeated_cv.py"),
                "--verify-existing",
            ]
        )
        with patch.dict(sidecar.PRIMARY_PINS, self.primary_pins):
            replay = sidecar.run(replay_args)
        self.assertEqual(replay["status"], "reporting_sidecar_replayed")
        self.assertEqual(replay["deterministic_artifacts_compared"], 4)
        self.assertEqual(replay["artifact_sha256"], receipt["artifact_sha256"])
        self.assertEqual(replay["source_binding_sha256"], receipt["source_binding_sha256"])
        self.assertEqual(replay["original_receipt_sha256"], hashlib.sha256(before["receipt.json"]).hexdigest())
        self.assertEqual({p.name: p.read_bytes() for p in replay_args.output.iterdir()}, before)
        sidecar.verify_content(replay, "receipt_content_sha256")
        with changed(replay_args.output / "dimension_ratios.csv", b"altered\n"):
            with patch.dict(sidecar.PRIMARY_PINS, self.primary_pins):
                self.reject(lambda: sidecar.run(replay_args), "replayed artifact differs")
        self.reject(lambda: sidecar.run(args), "output already exists")
        self.assertEqual({p.name: p.read_bytes() for p in args.output.iterdir()}, before)

    def test_15_write_failure_never_produces_final_receipt(self) -> None:
        """A reporting IO failure preserves its partial directory without completion receipt."""
        output = self.root / "synthetic-io-failure"
        original = Path.open

        def fail(path: Path, *args: Any, **kwargs: Any) -> Any:
            if path.name == "report.json":
                raise OSError("synthetic disk failure")
            return original(path, *args, **kwargs)

        with patch.object(Path, "open", fail):
            with self.assertRaisesRegex(OSError, "synthetic disk failure"):
                sidecar.write_new(output, {"dimension_ratios.csv": b"toy\n", "report.json": b"{}\n"}, {})
        self.assertTrue(output.exists())
        self.assertTrue((output / "dimension_ratios.csv").exists())
        self.assertFalse((output / "receipt.json").exists())
        self.reject(lambda: sidecar.write_new(output, {}, {}), "output already exists")

    def test_16_formal_original_vs_adr032_identity_and_grid_scope_refused(self) -> None:
        """Mislabelled ADR-032 and newly added comparison rows are forbidden."""
        families = copy.deepcopy(self.families)
        row = next(
            r for r in families["catalytic_vs_original_priors"]["contrasts"] if r["right"] == "bayesian_horseshoe"
        )
        row["horseshoe_reference"] = "original primary horseshoe"
        self.reject(lambda: sidecar.formal_links(families, self.family_summary), "horseshoe identity is ambiguous")
        scope = copy.deepcopy(self.scope)
        scope["rows"].append(scope["rows"][0])
        self.reject(lambda: sidecar.check_scope(scope), "reporting roster changed")

    def test_17_zero_variance_interval_omits_internal_infinity(self) -> None:
        """The frozen routine's infinite test statistic never enters reporting JSON."""
        refs = copy.deepcopy(self.extension)
        primary = copy.deepcopy(self.primary_cells)
        for repeat in range(1, 6):
            for fold in range(1, 6):
                refs[sidecar.cell_id("gbsg2", "clinical", repeat, fold, "catalytic_fixed", "full")].record["metrics"][
                    "ibs"
                ] = 0.5
                primary[("gbsg2", "cox_ph", repeat, fold)].record["metrics"]["ibs"] = 0.25
        row = sidecar.descriptive_row(self.scope["rows"][0], refs, primary, self.interval.nadeau_bengio_paired_effect)
        self.assertEqual(row["mean_difference"], 0.25)
        self.assertEqual(row["corrected_standard_error"], 0.0)
        self.assertEqual(row["confidence_lower"], 0.25)
        self.assertEqual(row["confidence_upper"], 0.25)
        sidecar.json_bytes(row)
        self.assertNotIn("p_value", row)
        self.assertNotIn("t_statistic", row)

    def test_18_mismatched_identity_baseline_pin_and_extra_inventory(self) -> None:
        """Changed source identity, baseline marker and extra stored cells are refused."""
        cells = copy.deepcopy(self.cells)
        cells[0]["model_key"] = "invented_model"
        seal(cells[0], "cell_content_sha256")
        self.reject(lambda: sidecar.extension_refs(cells, self.manifest), "fields differ from its identity")
        args = self.args("baseline-byte-refusal")
        marker = self.primary_root / "manifest.json"
        with changed(marker, marker.read_bytes() + b" "):
            with patch.dict(sidecar.PRIMARY_PINS, self.primary_pins):
                self.reject(lambda: sidecar.run(args), "changed input bytes: primary/manifest")
        self.assertFalse(args.output.exists())
        extra = self.run_root / "cells" / "unexpected.json"
        extra.write_bytes(b"{}")
        try:
            self.reject(lambda: sidecar.run(self.args("extra-cell-refusal")), "stored cells differ from plan")
        finally:
            extra.unlink()
        self.assertFalse((self.root / "extra-cell-refusal").exists())

    def test_19_receipt_write_and_close_failure_leave_no_final_receipt(self) -> None:
        """A partial receipt write or failed close cannot publish the final receipt name."""
        original_open = Path.open
        for stage in ("write", "close"):
            with self.subTest(stage=stage):
                output = self.root / f"receipt-{stage}-failure"

                class BrokenReceipt:
                    def __init__(self, handle: Any) -> None:
                        self.handle = handle

                    def __enter__(self) -> Any:
                        return self

                    def __exit__(self, kind: Any, value: Any, traceback: Any) -> Any:
                        self.handle.close()
                        if stage == "close":
                            raise OSError("synthetic receipt close failure")
                        return False

                    def write(self, data: bytes) -> Any:
                        if stage == "write":
                            self.handle.write(data[:3])
                            raise OSError("synthetic receipt write failure")
                        return self.handle.write(data)

                    def flush(self) -> None:
                        self.handle.flush()

                    def fileno(self) -> int:
                        return self.handle.fileno()

                def fail(path: Path, *args: Any, **kwargs: Any) -> Any:
                    handle = original_open(path, *args, **kwargs)
                    return BrokenReceipt(handle) if path.name == "receipt.pending" else handle

                with patch.object(Path, "open", fail):
                    with self.assertRaisesRegex(OSError, f"synthetic receipt {stage} failure"):
                        sidecar.write_new(output, {"report.json": b"{}\n"}, {"synthetic_only": True})
                self.assertTrue((output / "receipt.pending").is_file())
                self.assertFalse((output / "receipt.json").exists())
                self.reject(lambda: sidecar.write_new(output, {}, {}), "output already exists")

    def test_20_atomic_receipt_install_never_overwrites_a_final_name(self) -> None:
        """A competing final receipt name is retained, and no success is returned."""
        output = self.root / "receipt-install-collision"
        original_link = sidecar.os.link

        def collide(source: Any, destination: Any) -> None:
            Path(destination).write_bytes(b"preserved competing receipt")
            original_link(source, destination)

        with patch.object(sidecar.os, "link", collide):
            with self.assertRaises(FileExistsError):
                sidecar.write_new(output, {"report.json": b"{}\n"}, {})
        self.assertEqual((output / "receipt.json").read_bytes(), b"preserved competing receipt")
        self.assertTrue((output / "receipt.pending").exists())

    def test_21_residual_temporary_link_refuses_success(self) -> None:
        """A committed valid receipt plus failed temporary cleanup is not successful output."""
        output = self.root / "residual-pending-link"
        original_unlink = Path.unlink

        def ignore_pending(path: Path, *args: Any, **kwargs: Any) -> Any:
            if path.name == "receipt.pending":
                return None
            return original_unlink(path, *args, **kwargs)

        with patch.object(Path, "unlink", ignore_pending):
            self.reject(lambda: sidecar.write_new(output, {"report.json": b"{}\n"}, {}), "inventory retains incomplete")
        self.assertTrue((output / "receipt.json").exists())
        self.assertTrue((output / "receipt.pending").exists())
        self.reject(lambda: sidecar.write_new(output, {}, {}), "output already exists")


if __name__ == "__main__":
    unittest.main(verbosity=2)
