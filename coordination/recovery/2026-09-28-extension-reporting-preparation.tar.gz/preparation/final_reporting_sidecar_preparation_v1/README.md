# Reporting sidecar preparation v1

This is reporting preparation, not completed extension evidence. The helper has
not been invoked on the actual extension run. The 1,625-fit programme, official
92-cell reproduction, trace and failure-provenance checks, visual review,
private release and fresh remote restoration remain separately owned gates.
No fit, refit, metric rescoring, trace hashing, finalizer, renderer or new test is
executed by this helper.

The frozen addendum already requires actual encoded p, p/n and events/p
(`docs/protocol_addendum_extensions.md:69`), mean paired IBS differences with
the Nadeau–Bengio correction and 95% intervals for all 25 aligned pairs
(`:185–200` in sealed analysis commit 8551d326), and descriptive other-comparator
effects. T-189 requires catalytic comparisons against the other priors and
comparators. These tables present those existing requirements. Their roster was
fixed in `scope.json` before any actual sidecar invocation; this preparation is
not a new result-blind experiment or new preregistration. The production run was
already in progress during preparation.

## Frozen inputs and scope

The production commit is `119476fef55b1eeb690527f234c1423440720d45` and the sealed
analysis commit is `8551d326b02bfe88915cfd9eb50c6ca8e5690e3a`.
`source_bindings.json` records exact source files and bytes. The copied original
claim helper and interval source are byte-exact dependencies, not modified
variants. Their source bytes are pinned before importing them. The interval
routine requires NumPy and SciPy from the previously verified frozen environment;
the rest of this helper uses the Python standard library.

The numerical prerequisite reuses the exact original claim helper's
`load_numerical` function. It requires all 1,625 planned/stored attempted fits,
sealed clean production identity, deep verification/rescoring counts, internal
content digests, every cell byte, and all three aggregate byte bindings. Stored
failure outcomes count as attempted fits; complete numerical coverage does not
mean all fits passed. Additional strict parsing rejects duplicate JSON keys,
NaN/infinity literals and overflowing numbers. Every expected job identity is
checked once, with manifest membership hashes and saved outcome/count validation.
The helper trusts the separate deep verification receipt: it does not repeat
trace/diagnostic/rescoring work or certify the remaining programme gates.

The unchanged original primary directory is also required. Its frozen manifest
and completion bytes, all 450 planned cell bytes, embedded content hashes and
430 accepted/20 diagnostic-failure accounting are verified. Baseline cells are
not copied into the sidecar. Use the existing baseline restoration from
`docs/ravi_handoff.md`; the extension restorer already requires this directory.
Only this primary baseline is needed by the sidecar. The full scientific restore
and factual claim helper additionally need the separately restored ADR-032
sampler and robustness evidence.

The dimension table contains all 1,625 extension cells, sorted by cell ID. Here
n means **actual analysis-training n** after the frozen condition membership
selection; events means actual training events after its administrative censoring
rule. p is the actual encoded feature count saved by preprocessing. Ratios are
p/n_train and events_train/p. Execution or diagnostic failures retain these
ratios when actual p exists. If p was genuinely not recorded, JSON stores nulls
and the table marks `actual_encoded_p_not_recorded`. No p is reconstructed or
imputed. Existing recorded events_per_coefficient is checked against the counts
when present. Invalid/nonfinite counts or a contradictory recorded ratio refuse
report generation.

The comparator roster is exactly **123 additional descriptive rows**:

- 63 clinical rows: gbsg2, whas500, metabric; each catalytic_fixed,
  catalytic_adaptive and catalytic_wme versus cox_ph, random_survival_forest,
  deepsurv, ridge, lasso, elastic_net and pv_horseshoe, in that order.
- 60 matched rows: metabric_matched clinical, then expression; each catalytic
  arm versus the six inherited model names (CoxPH, RSF, DeepSurv, normal,
  horseshoe and spike-slab), then ridge, lasso, elastic_net and pv_horseshoe.

Clinical CoxPH/RSF/DeepSurv references come from the unchanged original primary
record. Clinical penalised/PV references are full clinical extension cells.
Every matched comparator is the fresh extension fit in the same matched feature
setting. Its horseshoe is the matched extension horseshoe: it is neither the
original full-cohort failed horseshoe nor an ADR-032 substitution. Within each
contrast, pair order is repeat 1..5, fold 1..5.

The existing 27 clinical catalytic-versus-inherited-prior formal contrasts are
linked to `extension/paired_families.json` and are **not duplicated**. Their
normal/spike-slab reference is unchanged primary; their horseshoe reference is
explicitly ADR-032 post-hoc sampler. The original primary horseshoe record and
its failures remain unchanged. All four formal families remain the sealed
aggregate's responsibility. There is no catalyst-versus-catalyst grid, new
Holm family, additional p-value or significance/superiority layer.

## Pair coverage and uncertainty

Each planned repeat/fold must have exact ordered training/validation patient
memberships and counts. An accepted pair additionally requires exact saved
prediction patients, observed/training outcomes, horizons and IBS grid. Duplicate
patients, mismatched order/membership/outcomes/grid, missing cells or nonfinite
accepted IBS refuse reporting; they are not silently excluded or repaired.
A stored nonaccepted fit instead produces an explicit status exclusion for its
planned pair, with execution (`failed`) and diagnostic (`failed_diagnostics`)
failures recorded separately for each side.

The difference is catalytic left IBS minus comparator right IBS, with equal
weight per observed repeat/fold. A negative value describes lower IBS for the
catalytic arm in those pairs. No significance or clinical-impact interpretation
is attached. Complete 25-pair rows use the exact sealed routine's paired mean,
sample SD, corrected SE and 95% interval (five repeats, five folds, test/train
ratio 1/4, 24 degrees of freedom). The existing routine internally supplies test
fields; an explicit allowlist excludes its p-value and t-statistic from every
sidecar artifact. No Holm, rejection or superiority fields are added.

A partial 1..24-pair row reports only its observed-pair mean and coverage;
its corrected SE, interval bounds/level/df/test-train ratio are null. This mean
summarizes the available pairs and does not estimate the missing pairs. Zero
pairs yield null mean and interval. There are 3,075 planned paired records across
the fixed 123 rows; these reuse fits and are not 3,075 independent patients or
new model fits. Cohorts/settings are never pooled into one effect.

## Exact output schema

A successful output directory has **exactly five regular files**:

| File | Deterministic contents |
| --- | --- |
| `dimension_ratios.csv` | 1,625 rows: cell ID, dataset, setting, model, condition, repeat, fold, status, n_train, n_validation, events_train, p, p_available, p_over_n_train, events_over_p, ratio_availability. |
| `descriptive_catalytic_pairs.csv` | 123 rows: comparison identity and source roles, planned/observed/missing pair counts, coverage, interval_status, mean and allowed complete-pair uncertainty fields. |
| `report.json` | Typed/versioned report containing both row inventories, each contrast's 25 paired_records (logical source IDs, statuses, scores, inclusion and exclusion reasons), status/availability group counts, coverage totals and links to the 27 existing formal prior contrasts. |
| `lineage.json` | Logical relative input-role IDs and exact byte hashes; canonical source_binding_sha256; source commits and dependency/scope pins; hashes of the two CSV files and report JSON. No host paths or timestamps. |
| `receipt.json` | Generation-only receipt with hashes of four deterministic files, helper/source binding, factual counts, operation/status, scientific_completion_certified=false and canonical receipt_content_sha256. Actual argv, resolved host paths, interpreter and UTC timing are confined to its invocation metadata. |

CSV uses UTF-8, LF newlines, header order frozen in the helper, lower-case boolean
values, and blank cells for JSON nulls. JSON uses sorted keys, two-space indent,
UTF-8 and one final newline. `interval_status` is one of
`complete_25_pair_corrected_interval`, `partial_observed_pairs_no_interval` or
`zero_pairs_no_interval`. The report and lineage are byte deterministic after
relocation. Original stored JSON/trace/source bytes are never rewritten.

Generation is write-once and refuses an existing destination before input work.
The parent directory must already exist. No destination is created until all
prerequisites, tables and small source bytes have been checked. Artifacts are
opened exclusively. A receipt is first fully written, flushed, fsynced and closed
as `receipt.pending`, then atomically hard-linked to its exclusive final name.
The temporary name is removed, and an exact final inventory/byte pass is required
before successful stdout/exit. Artifact or receipt write/close failures retain
an incomplete output directory without publishing a final receipt. Installation
collision retains the competing final bytes. A cleanup failure or residual
pending file cannot be represented as CLI success. Incomplete directories are
retained for investigation and are never overwritten/resumed; use a reviewed
fresh destination after the cause is resolved. Receipt presence alone is not a
completion check: successful exit, five-file inventory and a passing replay are
required.

## Invocation and relocated replay

Do not use these commands on the live partial programme. Root owns invocation
only after its official verified results and prior gates exist. Paths below are
placeholders for the restored/source evidence, not hardcoded original Mac paths.

```sh
set -o noclobber
RAVI_SIDECAR_PREP="/path/to/reporting_sidecar_preparation_v1"
RAVI_EXTENSION_RUN="/path/to/complete/evidence/run"
RAVI_ORIGINAL="/path/to/restored/original/confirmatory"
RAVI_SIDECAR="/path/to/final_reporting_sidecar"
RAVI_PYTHON="/path/to/frozen/environment/bin/python"
"$RAVI_PYTHON" -B "$RAVI_SIDECAR_PREP/generate_reporting_sidecar.py" \
  --run "$RAVI_EXTENSION_RUN" --primary "$RAVI_ORIGINAL" \
  --output "$RAVI_SIDECAR" \
  > "/path/to/new/reporting_sidecar_generation_stdout.json"
```

An existing result is replayed without fitting or any file write by the helper:

```sh
"$RAVI_PYTHON" -B "$RAVI_SIDECAR_PREP/generate_reporting_sidecar.py" \
  --run "$RAVI_EXTENSION_RUN" --primary "$RAVI_ORIGINAL" \
  --output "$RAVI_SIDECAR" --verify-existing \
  > "/path/outside/immutable/payload/new_reporting_sidecar_replay_receipt.json"
```

Accept the captured replay JSON only when the subprocess exits zero. Replay
recomputes and compares the exact two CSV, report and lineage bytes; it verifies
and separately binds the preserved original generation receipt. Its new stdout
receipt has operation `verify_existing`, status `reporting_sidecar_replayed`,
`deterministic_artifacts_compared=4`, original_receipt_sha256, current hashes/counts,
scientific_completion_certified=false, fresh invocation metadata and its own
internal content digest. Paths/time may differ; deterministic bytes and original
receipt remain unchanged. The release's transfer inventory independently pins the
original receipt bytes. Optional --scope-file, --claim-helper and --interval-source
accept relocated dependency paths while enforcing identical frozen bytes.

Source/pre-package replay stdout enters the sealed v3 supporting bundle as
`reporting_sidecar_source_replay_receipt.json`, **outside** its five-file
`final_reporting_sidecar/` directory. Later fresh-remote replay stdout is retained
outside the immutable downloaded/restored payload and gates publication. It must
not be added retroactively to that payload. A restored invocation uses
`<RESTORED>/evidence/run`, the already restored original baseline, and
`<RESTORED>/execution/current_integration_validation/reporting_sidecar_preparation_v1/`
with sidecar sibling
`<RESTORED>/execution/current_integration_validation/final_reporting_sidecar/`.

## Bounded packaging integration

The sealed stager already copies the complete supporting bundle to
`execution/current_integration_validation/`. It copies no original primary fit
cells; baseline evidence is restored first by the existing receiving handoff and
passed through --primary. There is no need for a new complete baseline copy or
any change to sealed fits, finalizer, renderer, aggregates or transfer scripts.

The separately versioned future bundle assembler must include this preparation,
the actual five-file sidecar, original generation stdout if retained, the source
replay receipt and the full factual claim summary plus invocation receipt. It
must require source replay success, bind the exact helper/preparation and original
receipts, and retain immutable v1 assembler preparation. Its receiving runbook
must invoke this helper against restored roots and keep the fresh replay receipt
outside the payload before publication. Root owns that integration. These are
compact tabular facts; no new PDFs or expansion of the 32-figure roster is needed.

## Preparation validation and limits

`check_reporting_sidecar.py` uses wholly invented temporary records and substitutes
synthetic primary metadata pins only inside unittest contexts. The production CLI
has no alternate-pin/test mode. Tests include a manual corrected-interval oracle,
complete/partial/zero coverage, 1,625/450/123/27 identities/counts, ratio availability
for failures, missing/duplicate/misaligned/nonfinite/changed inputs, write-once
refusal, receipt write/close/install/cleanup failures, omission of all inference
fields, and byte-identical replay after relocating run, baseline, output and
copied dependencies to new roots. No synthetic result is archived as real science.
The preparation receipt binds final sources, synthetic checks, scoped Ruff and
syntax logs, the independent review and its resolved receipt-publication finding.

This sidecar does not close T-182..T-189, certify all trace bytes/refits, replace
root's final claim review, reproduce every fit, revisit the failed/incomplete
primary finding, or establish a release/restore/visual QA completion claim. Those
remain separate evidence and owner decisions. No actual sidecar/result invocation,
repo edit or numerical/transfer operation occurred in this preparation task.
