This is an unfinished, unsealed implementation draft. It has not launched the
environment checker or an original refit, read actual results/arrays/traces,
created a review or changed the original programme. The release-v2 provenance
repair takes priority. No preparation receipt or test-pass claim exists yet.

The proposed capture uses the unchanged119 `scripts/reproduce_extensions.py`
route `official_fresh_refit`. A root-selected original92 identity uses the
position in the original manifest's ordered repeat1/fold1 plan, with
`--workers 92 --worker INDEX`. The lexicographic ADR041 selection order is not
the worker index. An actual fresh absent output is exclusively reserved; there
is no resume, cached-cell promotion, automatic retry or automatic all92 rerun.
Every retained failure remains separate. Later actual execution must preserve
the exact full259 report, all five numeric variables1, current/specified Python
same-file identity, clean119 source and complete original input SHA set,
matched bytes, actual argv/cwd/rc/raw logs, official stdout/receipt and outcomes.
The adapter will document the same genuine official process in two separate
records: numerical invocation and official scientific comparison. The official
script performs both on a genuinely new target. A failed original scientific
outcome may reproduce its original failure; no successful science is implied.

Actual independent root scientific-lineage, owner/trace-comparison and later
numerical-resolution reviews are required by the unchanged consumers. This
adapter cannot write them. A historical environment-checker argv/return-code
record is not an additional existing gate; a newly invoked checker is merely
captured accurately as this new execution's prerequisite.

There is a concrete topology constraint. `run_reproduction.py:196–221` fixes
one `selection.paths.original_reproduction` directory. Its producer gate
requires the actual invocation's `reproduction_output` and official `--output`
to be that exact root. Fresh per-cell outputs elsewhere cannot be copied there
and falsely certified. Root must decide the genuinely unproven inherited
subset and evidence topology before the ADR041 selection freeze. No all92
rerun follows from this constraint. If necessary, a separately authorized
per-entry evidence-root adapter would have to preserve each existing original
manifest/source/input/interpreter/environment/argv/rc/log/official receipt,
owner/scientific-lineage review and all referenced/orphan trace comparisons;
the current v1 gate must otherwise remain unchanged. No such adapter is part
of this draft. The runnable draft refuses a selection/output-root mismatch.

Pending preparation: focused fictional/injected guard tests, strict schema and
publication reviews, scoped Ruff/AST checks, independent source review and
byte-pinned receipt/interface. No actual command should be run from this draft.
