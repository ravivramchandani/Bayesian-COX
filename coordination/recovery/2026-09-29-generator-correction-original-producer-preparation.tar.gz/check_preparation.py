"""Actual stdlib fictional-test/lint invocation evidence, never scientific dispatch."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=("tests", "lint"))
    parser.add_argument("name")
    args = parser.parse_args()
    own = Path(__file__).absolute().parent
    sources = sorted(own.glob("*.py"))
    before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    command = (["/opt/homebrew/opt/python@3.14/bin/python3.14", "-B", "-m", "unittest", "-v", "test_original_capture"]
               if args.kind == "tests" else ["/Users/macuser/miniconda3/envs/bayes-cox-lock-verify-20260815-b/bin/ruff",
                   "check", "--no-cache", "--select", "E,F,I,UP,B", "--ignore", "E501", "--target-version", "py312",
                   *(str(path) for path in sources)])
    prefix = own / args.name
    if prefix.parent != own or any(own.glob(prefix.name + ".*")):
        raise ValueError("exclusive ordinary check prefix required")
    started = datetime.now(UTC).isoformat()
    result = subprocess.run(command, cwd=own, capture_output=True, check=False)
    for suffix, content in ((".stdout.txt", result.stdout), (".stderr.txt", result.stderr)):
        with prefix.with_name(prefix.name + suffix).open("xb") as stream:
            stream.write(content)
    after = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    record = {"argv": command, "cwd": str(own), "exit_code": result.returncode,
              "started_at_utc": started, "finished_at_utc": datetime.now(UTC).isoformat(),
              "source_sha256_before": before, "source_sha256_after": after, "actual_science_executed": False}
    with prefix.with_name(prefix.name + ".invocation.json").open("x") as stream:
        stream.write(json.dumps(record, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"kind": args.kind, "name": args.name, "exit_code": result.returncode,
                      "source_bytes_unchanged": before == after}, sort_keys=True))


if __name__ == "__main__":
    main()
