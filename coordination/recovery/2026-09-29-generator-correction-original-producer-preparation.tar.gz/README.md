This is stdlib execution preparation for ORIGINAL numerical reproduction whose
actual producer proof remains unavailable. No environment checker, model,
generator, optimizer, scientific comparator or actual job was launched; no real
cell, array or trace was read. The tests use invented metadata, ordinary dummy
bytes and injected process responses. They emit only synthetic proof statuses.
`PLAN.md` and `draft_status.json` preserve the earlier unsealed draft history.

Root must first finish the actual reuse/evidence audit and the prospective
ADR041 selection. Only selected inherited-original identities still lacking
adequate actual numerical-producer proof are candidates. Root alone determines
that list from real provenance. The adapter cannot select identities, rank
source scores, choose successful subsets or automatically rerun all92. One
explicit identity is captured per invocation. It must belong to the fixed
original92 and root's supplied missing-proof list, which binds the actual
selected union and original manifest. Changed corrected refits and terminal
recipe replays remain their distinct existing routes.

The production child is exactly the clean119 original
`scripts/reproduce_extensions.py`. The worker index is the identity's position
in the original manifest's ordered repeat1/fold1 plan, with `--workers 92`;
the lexicographically sorted scope list is a different order. The child itself
rebuilds the complete frozen plan, verifies all original cells, runs the
original full-budget model/remedies/diagnostic gates for a missing target and
performs the original scientific-content and posterior/sample-stat comparisons.
The adapter imports none of those functions and never interprets a trace
container. It does bind every retained output file, including failed/orphan
trace bytes, after the genuine official process returns. The separate root
owner review and existing reproduction readers still perform their required
source/refit/orphan trace checks; byte hashes here cannot replace them.

Before any destination creation, the adapter verifies the exact83b904 original
manifest/content identity, clean119 Git state and every manifest input SHA,
matched bytes, root selection/list bindings, the selected source cell seal,
no active selected original owner, all own source bytes, actual requested/current
Python same-file identity, all five numeric variables already1, and absence/
non-overlap/unlinked ancestry of both new output directories. It reserves fresh
outputs exclusively and captures the genuine default subprocess's actual argv,
cwd, raw stdout/stderr, exit code or launch error, timing and runtime. It runs
the original pinned environment checker and requires its complete259 report
equal the explicitly supplied frozen report before the numerical child. This
new operational checker capture does not add a historical checker argv/rc gate
to previously available original evidence. The existing sealed gates require
the actual complete report and its original bindings, unchanged.

The official script performs the numerical refit and comparison in one real
fresh process. The adapter records two distinct sealed documents bound to that
same process: `invocation_record.json` with the actual numerical execution and
`official_comparison_record.json` with its separate official receipt/semantic
comparison event. It does not claim a second comparator process. A cached
comparison cannot become a fresh numerical fit: the output must be absent,
is reserved empty, and is checked still empty immediately before dispatch.
The exact `<identity> scientific_match` stdout and original five-field receipt
must match the source/refit content seals. Failed scientific outcomes remain
failed outcomes even when their reproducibility comparison succeeds.

All nonzero, launch, report, byte, comparison, inventory or publication failures
retain raw evidence and refuse a success receipt. There is no retry or resume.
A failed/partial output must remain intact; root may review a new separately
owned attempt. Publication uses the unchanged byte-pinned exclusive atomic IO:
closed/fsynced temporary bytes, no-replace hard link, cleanup and parent fsync.
Errors propagate, including failure after a receipt was committed; exact
inventory/recheck must pass before CLI success. Residual/temp/extra files refuse
completion. No automatic cleanup or source/result mutation occurs.

The successful process-capture status is
`original_missing_producer_execution_captured_root_review_pending`. It is not
accepted original reproduction evidence by itself. The partial producer
descriptor explicitly has no scientific-lineage, original owner or numerical
resolution reviews. Root must later supply actual independent reviews with
the unchanged fields required by `verify_old_numerical_producer` and receiving
`verify_producer`, then bind the official receipt, both exact source/refit
trace inventories, actual original source/inputs/seeds/budgets/gates, actual
invocation and distinct official comparison bytes. This preparation cannot
issue those reviews or complete the selected programme/release.

There is a precise unresolved evidence topology decision. The sealed v1
inherited reader fixes one `selection.paths.original_reproduction` root and
requires every producer invocation's actual `reproduction_output` and official
`--output` to equal it. A fresh per-identity directory elsewhere cannot be copied
there and silently certified. This adapter refuses that mismatch. Root must
choose a truthful compatible topology before the selection freeze. If a
separate per-entry evidence-root adapter is necessary, it requires separate
authorization/review and must preserve all existing actual original manifest,
source/input/matched/interpreter/full259/numeric/argv/rc/log/owner/algorithm/
receipt/trace gates, historical paths and independent actual root reviews.
Such an adapter is not implemented here. This constraint does not imply that
all92 must be rerun, or weaken proof for any existing adequate producer.

A future invocation, only after root has supplied the real reviewed selection,
compatible absent output roots and exact request bytes, is:

```sh
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
"$LOCKED_PYTHON" -I -B "$PREPARATION/capture_original_producer.py" \
  --preparation-receipt "$PREPARATION/preparation_receipt.json" \
  --preparation-receipt-sha256 "$PREPARATION_SHA" \
  --request "$ROOT_REQUEST" --request-sha256 "$ROOT_REQUEST_SHA" \
  --python "$LOCKED_PYTHON"
```

No supplied placeholder is runnable evidence or permission to start a job.
The CLI has no arbitrary command, injection, alternate source, worker-count,
scope-count, repair, review or automatic-selection option. The programmatic
injection seam is limited to explicitly labelled fictional tests and cannot
produce production status. Actual candidate counts, resource/storage needs,
execution decisions, reviews and receiving integration remain root-owned.
