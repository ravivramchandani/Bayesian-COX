"""Archive exact non-adopted engineering preparations and actual checkpoint."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
HERE = Path(__file__).absolute().parent
REPO = Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
helper = BASE / 'correction_reporting_release_root_closeout_20260929_v1/preserve_checked_records.py'
spec = importlib.util.spec_from_file_location('_root_archive_guard_v2_checkpoint', helper)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.RECOVERY = REPO / 'coordination/recovery'

def sealed_archive(name, directory, receipt_name, pin):
    root = BASE / directory
    receipt = m.load(root / receipt_name)
    assert m.binding(root / receipt_name)['sha256'] == pin
    expected = set(receipt['artifacts']) | {receipt_name}
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    assert actual == expected
    assert not any(p.is_symlink() or not (p.is_file() or p.is_dir()) for p in root.rglob('*'))
    if 'artifact_directories' in receipt:
        assert sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_dir()) == receipt['artifact_directories']
    return m.sealed(name, root, receipt_name, pin)

review_root = BASE / 'generator_correction_guarded_dispatch_independent_review_v2'
verification = m.load(review_root / 'final_verification.json')
assert verification['all154_sources_unchanged'] and verification['source_before'] == verification['source_after']
assert {name: m.binding(Path(name)) for name in verification['source_after']} == verification['source_after']
for label in ('unit', 'reuse_probe'):
    value = m.load(review_root / (label + '.invocation.json'))
    assert type(value['exit_code']) is int and value['exit_code'] == 0
    assert value['source_before'] == value['source_after'] and value['all_sources_unchanged']
    for stream in ('stdout','stderr'):
        assert m.binding(review_root / (label + '.' + stream + '.log')) == value['raw_' + stream]
evidence = m.load(review_root / 'source_evidence.json')
for item in evidence['evidence']:
    path = Path(item['path'])
    assert m.binding(path) == {'sha256': item['sha256'], 'bytes': item['bytes']}
    lines = path.read_text().splitlines()
    assert item['lines'] == [{'line': line, 'text': lines[line - 1]} for line in range(item['line_start'], item['line_end'] + 1)]
probe = json.loads((review_root / 'reuse_probe.stdout.log').read_text())
assert len(probe['results']) == 4 and all(row['unexpectedly_accepted'] and not row['rejected'] for row in probe['results'])
assert probe['actual_controller_scientific_or_checker_calls'] == 0
archives = {}
for name,directory,receipt_name,pin in (
 ('guarded-dispatch-preparation-v2','generator_correction_guarded_dispatch_v2','preparation_receipt.json','46a95785348e9f54379178caaf728fd863cccef3d133b2f5a3c8116aa5d9e9cc'),
 ('guarded-dispatch-independent-runtime-review-v2','generator_correction_guarded_dispatch_independent_review_v2','receipt.json','459403799a2ce70aebb805ddfd0b0a706fd8a1db69776f596884bf44adea5c06'),
 ('guarded-dispatch-portable-adapter-v2','generator_correction_guarded_dispatch_repository_test_adapter_v1','preparation_receipt.json','a1ae7162f038e30e1073bbe38492183715be51ee1b36c4f421720a809c0061ab')):
    archives[name] = sealed_archive(name,directory,receipt_name,pin)
root_check = m.load(HERE / 'v2_root_source_review.json')
progress = m.load(HERE / 'dated_checkpoint_v2.stdout.log')
assert progress['independent_first_draw_receipts'] == 582 and progress['original_stored_cells'] == 1111
snapshot = BASE / 'guarded_dispatch_v2_checkpoint_root_20260929_v1'
snapshot.mkdir()
names = ['capture_run_v5.py','collect_dated_checkpoint.py','check_v2_preparation_root.py','v2_root_source_review.json','archive_v2_review_checkpoint.py']
for label in ('dated_checkpoint_v2','v2_root_review'):
    names.extend(label + '.' + suffix for suffix in ('stdout.log','stderr.log','launch.json','invocation.json','tested_source_before.json','tested_source_after.json'))
for name in names:
    source = HERE / name
    target = snapshot / name
    with target.open('xb') as stream: stream.write(source.read_bytes())
    assert m.binding(source) == m.binding(target)
root_record = {'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'root_checked_unadopted_guard_v2_review_checkpoint',
 'root_review':root_check,'independent_review':{'receipt_sha256':'459403799a2ce70aebb805ddfd0b0a706fd8a1db69776f596884bf44adea5c06','independent_unit_methods':34,'actual_unit_exit_code':0,'actual_probe_exit_code':0,'all_154_sources_current_equal_before_after':True,'four_reuse_decision_contradictions_observed':True,'terminal_null_tuning_conclusion':'source_only'},
 'read_attempt_notes':[{'missing':'probe.stdout.log','actual':'reuse_probe.stdout.log'},{'missing':'capture_review_checks.py','actual':'capture_delta_checks.py'}],
 'dated_progress':progress,'guard_v2_adopted':False,'new_v3_preparation_pending':True,
 'actual_corrected_reviews_freeze_scope_fits_or_final_release_created':False}
m.write_new(snapshot / 'root_checkpoint.json',root_record)
archives['guarded-dispatch-v2-root-checkpoint'] = m.archive('guarded-dispatch-v2-root-checkpoint',{str(p.relative_to(snapshot)):p for p in snapshot.rglob('*') if p.is_file()})
compact = dict(root_record)
compact['new_archives'] = {name:{k:v for k,v in value.items() if k != 'members'} for name,value in archives.items()}
m.write_new(m.RECOVERY / '2026-09-29-generator-correction-guarded-dispatch-v2-review.json',compact)
m.write_new(HERE / 'v2_review_archive_actual.json',archives)
print(json.dumps({'status':compact['status'],'archives':{name:{k:v for k,v in value.items() if k in ('archive','sha256','bytes','regular_members')} for name,value in archives.items()},'progress_checked_at_utc':progress['checked_at_utc']},sort_keys=True))
