"""Read only small progress metadata, pinned source and actual owner presence."""
from pathlib import Path
import collections,datetime,hashlib,json,os,subprocess
base=Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
repo=Path('/Users/macuser/bayes-cox-runs/ravi-main-integration-20260929')
def bind(path):
 raw=path.read_bytes();return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
previous=base/'correction_release_v3_integration_validation_v1/make_test.tested_source_after.json'
expected=json.loads(previous.read_text());assert len(expected)==634
assert {key:bind(repo/key) for key in expected}==expected
sourcefile=base/'generator_correction_dispatch_guard_design_v1/source_bindings_before.json'
pins=json.loads(sourcefile.read_text())
if 'files' in pins:pins=pins['files']
assert isinstance(pins,dict)
for name,evidence in pins.items():
 actual=bind(Path(name))
 assert actual==evidence if isinstance(evidence,dict) else actual['sha256']==evidence,name
original=list((base/'run/cells').glob('*.json'))
replays=list(Path('/Volumes/BayesCoxTransfer20260929/correction-20260929/reuse_v2/replay/contexts').glob('*/*/receipt.json'))
owners=[62025,62026,62027,62028,62029,62030,64406,71385,98854,29118,29119,29120,29125,48620,48621]
argv=['/bin/ps','-p',','.join(map(str,owners)),'-o','pid=,ppid=,stat=,etime=,comm=']
process=subprocess.run(argv,capture_output=True,text=True,check=False)
assert type(process.returncode)is int
result={'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'dated_metadata_checkpoint_not_completion','collection_is_not_atomic':True,'original_stored_cells':len(original),'original_outcome_status_counts':dict(collections.Counter(json.loads(p.read_text()).get('status') for p in original)),'original_expected_cells':1625,'independent_first_draw_receipts':len(replays),'independent_receipt_status_counts':dict(collections.Counter(json.loads(p.read_text()).get('status') for p in replays)),'actual_owner_presence_query':{'argv':argv,'exit_code':process.returncode,'stdout':process.stdout,'stderr':process.stderr},'current_634_files_equal_successful_998_full_test_capture':True,'successful_test_reference':{'path':str(previous),'binding':bind(previous)},'original_20_design_source_pins_unchanged':True,'design_source_reference':{'path':str(sourcefile),'binding':bind(sourcefile)},'arrays_or_traces_read':False,'numerical_owners_modified':False,'actual_corrected_reviews_freeze_selection_fits_release_complete':False}
print(json.dumps(result,sort_keys=True,indent=2))
