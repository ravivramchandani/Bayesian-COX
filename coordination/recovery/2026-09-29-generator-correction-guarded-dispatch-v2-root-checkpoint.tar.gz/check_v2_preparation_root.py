"""Root byte/schema/method preservation recheck; no dispatch or science."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

BASE = Path('/Users/macuser/bayes-cox-runs/extensions-20260928')
CARRIER = BASE / 'generator_correction_guarded_dispatch_v2'
HERE = Path(__file__).absolute().parent

def binding(path):
    assert path.is_file() and not any(item.is_symlink() for item in (path, *path.parents))
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def methods(path):
    module = ast.parse(path.read_text())
    return {node.name: hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
            for node in ast.walk(module) if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}

receipt_path = CARRIER / 'preparation_receipt.json'
assert binding(receipt_path)['sha256'] == '46a95785348e9f54379178caaf728fd863cccef3d133b2f5a3c8116aa5d9e9cc'
receipt = read(receipt_path)
assert receipt['content_sha256'] == digest({k: v for k, v in receipt.items() if k != 'content_sha256'})
expected = {**receipt['artifacts'], receipt_path.name: binding(receipt_path)}
actual = {str(p.relative_to(CARRIER)): binding(p) for p in CARRIER.rglob('*') if p.is_file()}
directories = sorted(str(p.relative_to(CARRIER)) for p in CARRIER.rglob('*') if p.is_dir())
assert actual == expected and len(actual) == 79 and directories == receipt['artifact_directories']
assert directories == ['preserved_v1', 'preserved_v1_review']
source = read(CARRIER / 'source_preservation_receipt.json')
assert source['original20_before'] == source['original20_after']
assert {name: binding(Path(name)) for name in source['original20_before']} == source['original20_before']
assert methods(CARRIER / 'test_guarded_dispatch.py') == methods(CARRIER / 'preserved_v1/test_guarded_dispatch.py')
assert len(methods(CARRIER / 'test_guarded_dispatch.py')) == 23
assert len(methods(CARRIER / 'test_guarded_dispatch_regressions.py')) == 11
checks = {}
for label in ('unit_attempt2', 'ruff_attempt2', 'compile_attempt1'):
    record = read(CARRIER / (label + '.invocation.json'))
    assert type(record['exit_code']) is int and record['exit_code'] == 0 and record['source_unchanged']
    assert record['source_start'] == record['source_finish']
    assert {name: binding(CARRIER / name) for name in record['source_finish']} == record['source_finish']
    for suffix in ('stdout', 'stderr'):
        assert binding(CARRIER / (label + '.' + suffix + '.log')) == record['raw_' + suffix]
    checks[label] = {'invocation': binding(CARRIER / (label + '.invocation.json')), 'actual_exit_code': record['exit_code']}
assert 'Ran 34 tests' in (CARRIER / 'unit_attempt2.stderr.log').read_text()
result = {'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'root_checked_unadopted_v2_preparation', 'carrier_receipt': binding(receipt_path),
          'complete_carrier_files': 79, 'complete_carrier_directories': directories,
          'all_20_original_pins_unchanged': True, 'original_23_test_method_ASTs_unchanged': True,
          'additional_regression_methods': 11, 'actual_preparation_checks': checks,
          'root_read': ['entire_current_guard_core', 'entire_current_launcher', 'unchanged_readonly_entrypoint',
                        'V2_DELTA.json', 'interface_contract.json', 'all_11_regressions', 'changed_Fixture_builders',
                        'capture_preparation_checks.py', 'actual_final_check_invocations'],
          'read_only_path_error': {'requested_missing': 'scripts/catalytic_correction/contracts.py',
                                  'resolved_actual': 'scripts/catalytic_correction/correction_fit_contracts.py',
                                  'actual_contract_classify_source_read': True, 'source_modified': False},
          'independent_residual_reuse_contradiction': 'verified source grammar; independent sealed probe pending',
          'engineering_adoption': False, 'actual_controller_or_scientific_dispatch': False,
          'actual_freeze_or_scope_or_execution_review_approval': False}
with (HERE / 'v2_root_source_review.json').open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(result, sort_keys=True))
