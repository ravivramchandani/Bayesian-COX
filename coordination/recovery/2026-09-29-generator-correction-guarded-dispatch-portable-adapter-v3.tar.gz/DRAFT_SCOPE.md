# V3 portable adapter variant in preparation

Preserve the complete sealed V2 adapter predecessor (111 files) under preserved_v2_adapter. Initial helper identity deliberately refuses use until root supplies exact sealed V3 identity. No V3 draft has been read, hashed, copied, imported or tested. Keep existing fixture isolation, JSON path facade, native subprocess.run identity and cleanup controls unchanged; only whole-source/version/method binding will change. This is engineering preparation, never scientific or root-review adoption.
